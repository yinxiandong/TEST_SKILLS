from __future__ import annotations

import importlib.util
import subprocess
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[4]
GENERIC_PY = REPO_ROOT / ".codex/skills/feature-curl-test-generator/scripts/generate_module_curl_tests.py"
GENERIC_SH = REPO_ROOT / ".codex/skills/feature-curl-test-generator/scripts/generate_module_curl_tests.sh"
ALIASES_EXAMPLE = REPO_ROOT / ".codex/skills/feature-curl-test-generator/references/module-aliases.example.md"


def load_generic_module():
    spec = importlib.util.spec_from_file_location("feature_curl_generator", GENERIC_PY)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


class FeatureCurlGeneratorTest(unittest.TestCase):
    maxDiff = None

    def test_generic_generator_uses_explicit_alias_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            feature_dir = root / "feature-list"
            output_root = root / "tests/feature-curl"
            aliases_file = root / "aliases.md"
            feature_dir.mkdir(parents=True)
            (feature_dir / "alarm.md").write_text(
                textwrap.dedent(
                    """
                    # Alarm 模块功能清单

                    ### 接口列表
                    | 功能 | API | 方法 | 认证 | 说明 |
                    |---|---|---|---|---|
                    | 查询告警 | `/api/v1/alarms` | GET | 是 | 查询告警 |
                    """
                ).strip()
                + "\n",
                encoding="utf-8",
            )
            aliases_file.write_text("alarm: 告警管理\n", encoding="utf-8")

            completed = subprocess.run(
                [
                    "python3",
                    str(GENERIC_PY),
                    "--feature-dir",
                    str(feature_dir),
                    "--module",
                    "告警管理",
                    "--output-root",
                    str(output_root),
                    "--aliases-file",
                    str(aliases_file),
                    "--base-url",
                    "https://example.test:9443",
                ],
                capture_output=True,
                text=True,
                check=False,
            )

            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertTrue((output_root / "alarm/curl-tests.sh").exists())

    def test_generic_generator_does_not_embed_coms_aliases_by_default(self) -> None:
        module = load_generic_module()
        with tempfile.TemporaryDirectory() as tmpdir:
            feature_dir = Path(tmpdir)
            (feature_dir / "alarm.md").write_text(
                "# Alarm 模块功能清单\n",
                encoding="utf-8",
            )
            modules = module.extract_modules(feature_dir)

            with self.assertRaises(ValueError):
                module.resolve_module(modules, "告警管理")

    def test_generic_wrapper_derives_base_url_from_env_file(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            feature_dir = root / "feature-list"
            output_root = root / "custom-tests"
            env_file = root / "dev-env.conf"
            feature_dir.mkdir(parents=True)
            (feature_dir / "system.md").write_text(
                textwrap.dedent(
                    """
                    # 系统管理模块功能清单

                    ### 接口列表
                    | 功能 | API | 方法 | 认证 | 说明 |
                    |---|---|---|---|---|
                    | 系统信息 | `/api/v1/system/info` | GET | 是 | 查询系统信息 |
                    """
                ).strip()
                + "\n",
                encoding="utf-8",
            )
            env_file.write_text(
                'FEATURE_ENV_DEV_HOST="10.10.10.8"\n',
                encoding="utf-8",
            )

            completed = subprocess.run(
                [
                    "bash",
                    str(GENERIC_SH),
                    "--feature-dir",
                    str(feature_dir),
                    "--module",
                    "system",
                    "--output-root",
                    str(output_root),
                    "--env",
                    "dev",
                    "--env-file",
                    str(env_file),
                    "--env-host-key-template",
                    "FEATURE_ENV_{ENV}_HOST",
                    "--port",
                    "7443",
                ],
                capture_output=True,
                text=True,
                check=False,
            )

            self.assertEqual(completed.returncode, 0, completed.stderr)
            script_text = (output_root / "system/curl-tests.sh").read_text(encoding="utf-8")
            self.assertIn('BASE_URL="${BASE_URL:-https://10.10.10.8:7443}"', script_text)

    def test_generic_wrapper_defaults_to_tests_feature_curl(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            feature_dir = root / "feature-list"
            feature_dir.mkdir(parents=True)
            (feature_dir / "system.md").write_text(
                textwrap.dedent(
                    """
                    # 系统管理模块功能清单

                    ### 接口列表
                    | 功能 | API | 方法 | 认证 | 说明 |
                    |---|---|---|---|---|
                    | 系统信息 | `/api/v1/system/info` | GET | 是 | 查询系统信息 |
                    """
                ).strip()
                + "\n",
                encoding="utf-8",
            )

            completed = subprocess.run(
                [
                    "bash",
                    str(GENERIC_SH),
                    "--feature-dir",
                    str(feature_dir),
                    "--module",
                    "system",
                    "--base-url",
                    "https://127.0.0.1:6050",
                ],
                cwd=root,
                capture_output=True,
                text=True,
                check=False,
            )

            self.assertEqual(completed.returncode, 0, completed.stderr)
            self.assertTrue((root / "tests/feature-curl/system/curl-tests.sh").exists())

    def test_generic_skill_ships_aliases_example(self) -> None:
        self.assertTrue(ALIASES_EXAMPLE.exists())
        content = ALIASES_EXAMPLE.read_text(encoding="utf-8")
        self.assertIn("slug", content)
        self.assertIn("中文模块名", content)


if __name__ == "__main__":
    unittest.main()
