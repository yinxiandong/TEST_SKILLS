---
name: api-test-executor
description: API 测试执行器。封装 pytest 执行逻辑，支持按级别、覆盖类型、模块筛选执行，输出 JUnit XML 和 JSON 结果到 .tests/api-reports/ 目录。
---

# API 测试执行器技能

## 调用方

- `api-test-orchestrator`：在 Phase 4 调用，执行测试
- 用户直接调用：手动执行 API 测试

## 前置依赖

- pytest 脚本已生成（由 `api-test-detail-generator` 完成）
- `tests/api-test/api-test.config.yaml` 已配置
- Python 依赖已安装（httpx, pytest, pyyaml, jsonpath-ng）

---

## 执行流程

```
1. 读取 tests/api-test/api-test.config.yaml 获取执行参数
2. 检查 pytest 脚本目录是否存在
3. 生成 run-id（格式：run-YYYYMMDD-HHMMSS）
4. 构建 pytest 命令（根据筛选条件）
5. 执行 pytest，输出 JUnit XML + JSON 结果
6. 收集执行产物到 .tests/api-reports/{run-id}/
7. 更新 .tests/api-reports/latest 软链接
```

---

## 执行模式

### 冒烟测试

```bash
python scripts/run_api_tests.py --smoke
# 等价于: pytest -m smoke
```

### 按级别执行

```bash
python scripts/run_api_tests.py --level P0
python scripts/run_api_tests.py --level P0,P1
# 等价于: pytest -m "P0" / pytest -m "P0 or P1"
```

### 按模块执行

```bash
python scripts/run_api_tests.py --module auth
python scripts/run_api_tests.py --module auth,user
# 等价于: pytest tests/api-test/scripts/auth/ tests/api-test/scripts/user/
```

### 按覆盖类型执行

```bash
python scripts/run_api_tests.py --coverage-type security
python scripts/run_api_tests.py --coverage-type boundary
# 等价于: pytest -m security / pytest -m boundary
```

### 全量回归

```bash
python scripts/run_api_tests.py --all
# 等价于: pytest tests/api-test/scripts/
```

### 组合筛选

```bash
python scripts/run_api_tests.py --level P0 --coverage-type positive
# 等价于: pytest -m "P0 and positive"
```

---

## 执行参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--smoke` | 仅执行冒烟用例 | false |
| `--level` | 按级别筛选（逗号分隔） | 全部 |
| `--module` | 按模块筛选（逗号分隔） | 全部 |
| `--coverage-type` | 按覆盖类型筛选 | 全部 |
| `--all` | 全量回归 | false |
| `--env` | 指定环境（覆盖 config 中的 default_environment） | config 默认 |
| `--parallel` | 并行进程数（需安装 pytest-xdist） | config 中的 parallel_workers |
| `--retry` | 失败重试次数 | config 中的 retry_on_failure |
| `--fail-fast` | 遇到首个失败即停止 | config 中的 fail_fast |
| `--output-dir` | 报告输出目录 | .tests/api-reports |

---

## 输出

```
.tests/api-reports/
├── {run-id}/
│   ├── junit.xml              # pytest JUnit XML 报告
│   ├── result.json            # pytest JSON 结果（pytest-json-report）
│   └── logs/                  # 请求/响应日志
└── latest -> {run-id}/        # 软链接到最新报告
```

---

## pytest 配置

参见模板：`template/pytest.ini.template`

---

## 约束

- 不修改测试脚本和用例文件
- 执行前检查依赖包是否安装
- 报告目录自动创建，不覆盖历史报告
- 执行失败不中断流程，由报告生成器判断结果
