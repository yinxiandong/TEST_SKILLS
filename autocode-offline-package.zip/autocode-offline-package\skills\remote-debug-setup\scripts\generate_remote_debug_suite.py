#!/usr/bin/env python3
import argparse
import importlib.util
import json
import os
import re
import shutil
import stat
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


def load_json(path: Path) -> Dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise RuntimeError("answers 顶层必须为对象")
    return data


def dump_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def now_ts() -> str:
    return time.strftime("%Y%m%d-%H%M%S", time.localtime())


def sanitize_for_example(obj: Any) -> Any:
    if isinstance(obj, dict):
        out: Dict[str, Any] = {}
        for k, v in obj.items():
            key = str(k)
            lowered = key.lower()
            if lowered in {"password", "token", "secret", "access_token", "refresh_token"}:
                out[key] = "******"
                continue
            if lowered.endswith("_password") or "password" in lowered:
                out[key] = "******"
                continue
            out[key] = sanitize_for_example(v)
        return out
    if isinstance(obj, list):
        return [sanitize_for_example(x) for x in obj]
    if isinstance(obj, str):
        return obj
    return obj


def chmod_exec(path: Path) -> None:
    try:
        st = path.stat()
        path.chmod(st.st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    except Exception:
        pass


def copy_tree(src: Path, dst: Path) -> None:
    if not src.exists():
        raise RuntimeError(f"模板不存在: {src}")
    if dst.exists():
        raise RuntimeError(f"目标已存在: {dst}")
    shutil.copytree(src, dst)


def ensure_empty_or_force(path: Path, force: bool) -> None:
    if not path.exists():
        return
    if not force:
        raise RuntimeError(f"目标已存在: {path}（如需覆盖请加 --force）")
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink(missing_ok=True)


def backup_existing(project_root: Path, paths: List[Path]) -> Optional[Path]:
    existing = [p for p in paths if p.exists()]
    if not existing:
        return None
    backup_dir = project_root / ".tmp/remote-debug-setup" / "backup" / now_ts()
    backup_dir.mkdir(parents=True, exist_ok=True)
    for p in existing:
        rel = p.relative_to(project_root)
        target = backup_dir / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if p.is_dir():
            shutil.copytree(p, target)
        else:
            shutil.copy2(p, target)
    return backup_dir


def validate_answers_shape(answers: Dict[str, Any]) -> None:
    servers = answers.get("servers")
    if not isinstance(servers, list) or not servers:
        raise RuntimeError("answers.servers 必须为非空数组")
    for s in servers:
        if not isinstance(s, dict):
            raise RuntimeError("answers.servers[] 必须为对象")
        name = str(s.get("name") or "").strip()
        if not name:
            raise RuntimeError("servers[].name 必填")
        ssh = s.get("ssh")
        if not isinstance(ssh, dict):
            raise RuntimeError(f"servers[{name}].ssh 必须为对象")
        services = s.get("services")
        if not isinstance(services, list) or not services:
            raise RuntimeError(f"servers[{name}].services 必须为非空数组")


def validate_answers_strict(answers_path: Path) -> None:
    validator_path = Path(__file__).resolve().with_name("validate_answers.py")
    if not validator_path.exists():
        raise RuntimeError(f"严格校验器不存在: {validator_path}")
    spec = importlib.util.spec_from_file_location("remote_debug_validate_answers", validator_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载严格校验器: {validator_path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    fn = getattr(mod, "validate_answers", None)
    if not callable(fn):
        raise RuntimeError("严格校验器缺少 validate_answers()")
    fn(answers_path, allow_min=False)


def answers_to_secrets(answers: Dict[str, Any], include_sensitive: bool) -> Dict[str, Any]:
    project = answers.get("project") if isinstance(answers.get("project"), dict) else {}
    meta = {
        "server_name_whitelist_regex": str(project.get("server_name_whitelist_regex") or r"^(dev|test)"),
    }
    global_defaults = answers.get("defaults") if isinstance(answers.get("defaults"), dict) else {}
    servers_out: List[Dict[str, Any]] = []
    for s in answers.get("servers") or []:
        if not isinstance(s, dict):
            continue
        ssh = s.get("ssh") if isinstance(s.get("ssh"), dict) else {}
        auth = ssh.get("auth") if isinstance(ssh.get("auth"), dict) else {}
        ssh_out = {
            "host": ssh.get("host"),
            "port": ssh.get("port", 22),
            "username": ssh.get("username"),
            "auth": {
                "type": auth.get("type", "password"),
                "password": auth.get("password") if include_sensitive else "******",
                "identity_file": auth.get("identity_file", "") if auth.get("type") == "key" else "",
            },
        }

        server_out: Dict[str, Any] = {
            "name": s.get("name"),
            "ssh": ssh_out,
            # 运行时套件脚本优先读 servers[].defaults，因此这里合并顶层 defaults，避免配置“写了但不生效”。
            "defaults": {
                **global_defaults,
                **(s.get("defaults") if isinstance(s.get("defaults"), dict) else {}),
            },
            "services": s.get("services"),
            "api_debug": s.get("api_debug") if isinstance(s.get("api_debug"), dict) else {},
            "components": s.get("components") if isinstance(s.get("components"), dict) else {},
        }
        servers_out.append(server_out)

    return {
        "schema_version": "remote-debug-suite/v2",
        "generated_at": time.strftime("%F %T"),
        "meta": meta,
        "servers": servers_out,
    }


def select_plugins(answers: Dict[str, Any], allowed_plugins: Set[str]) -> Tuple[List[str], List[str]]:
    plugins: set[str] = set()
    for s in answers.get("servers") or []:
        if not isinstance(s, dict):
            continue
        comp = s.get("components") if isinstance(s.get("components"), dict) else {}
        # 单一事实来源：优先使用 components.<name>.enabled；兼容旧字段 components.plugins.*.enabled。
        for key, val in comp.items():
            if key in {"plugins"}:
                continue
            if isinstance(val, dict) and bool(val.get("enabled") or False):
                plugins.add(str(key))

        plugin_cfg = comp.get("plugins") if isinstance(comp.get("plugins"), dict) else {}
        for key, val in plugin_cfg.items():
            if not isinstance(val, dict):
                continue
            if bool(val.get("enabled") or False):
                plugins.add(str(key))
    known = sorted([p for p in plugins if p in allowed_plugins])
    unknown = sorted([p for p in plugins if p not in allowed_plugins])
    return known, unknown


def collect_skill_dirs(skills_root: Path) -> List[Path]:
    if not skills_root.exists() or not skills_root.is_dir():
        return []
    return sorted([p for p in skills_root.iterdir() if p.is_dir()], key=lambda p: p.name)


def collect_required_relpaths_from_template_skill(skill_dir: Path) -> List[str]:
    required: List[str] = []
    # Always require SKILL.md
    required.append("SKILL.md")
    scripts_dir = skill_dir / "scripts"
    if scripts_dir.exists() and scripts_dir.is_dir():
        for p in sorted([x for x in scripts_dir.rglob("*") if x.is_file()], key=lambda x: str(x)):
            rel = p.relative_to(skill_dir)
            required.append(str(rel))
    return required


def build_required_files_from_templates(skill_dirs: List[Path]) -> Dict[str, List[str]]:
    out: Dict[str, List[str]] = {}
    for d in skill_dirs:
        out[d.name] = collect_required_relpaths_from_template_skill(d)
    return out

def preflight_required_outputs(
    suite_skill_src: Path,
    plugins_root: Path,
    enabled_plugins: List[str],
) -> Tuple[List[Path], Dict[str, List[Path]]]:
    suite_dirs = collect_skill_dirs(suite_skill_src)
    plugin_skill_dirs: Dict[str, List[Path]] = {}
    for plugin in enabled_plugins:
        plugin_skills_root = plugins_root / plugin / ".codex" / "skills"
        plugin_skill_dirs[plugin] = collect_skill_dirs(plugin_skills_root)
    return suite_dirs, plugin_skill_dirs


def validate_preflight_files(suite_dirs: List[Path], plugin_skill_dirs: Dict[str, List[Path]]) -> List[str]:
    missing: List[str] = []
    if not suite_dirs:
        missing.append("suite-base/.codex/skills (技能目录不存在或为空)")
    for skill_dir in suite_dirs:
        if not (skill_dir / "SKILL.md").exists():
            missing.append(str(skill_dir / "SKILL.md"))
    for plugin, dirs in plugin_skill_dirs.items():
        if not dirs:
            missing.append(f"plugins/{plugin}/.codex/skills (技能目录不存在或为空)")
            continue
        for skill_dir in dirs:
            if not (skill_dir / "SKILL.md").exists():
                missing.append(str(skill_dir / "SKILL.md"))
    return missing


def validate_post_generated_files(
    project_root: Path,
    required_by_skill: Dict[str, List[str]],
    require_secrets_actual: bool,
) -> List[str]:
    missing: List[str] = []
    required_files: List[Path] = [project_root / ".secrets" / "dev-servers.example.yaml"]
    if require_secrets_actual:
        required_files.append(project_root / ".secrets" / "dev-servers.yaml")

    for skill_name, relpaths in required_by_skill.items():
        for rel in relpaths:
            required_files.append(project_root / ".codex" / "skills" / skill_name / rel)

    for path in required_files:
        if not path.exists():
            missing.append(str(path.relative_to(project_root)))
    return missing


def main() -> None:
    parser = argparse.ArgumentParser(description="remote-debug-setup: 生成目标项目的 remote 调试套件")
    parser.add_argument("--project-root", default=".", help="目标项目根目录")
    parser.add_argument("--answers", required=True, help="answers.full.json")
    parser.add_argument("--force", action="store_true", help="覆盖生成（会先备份）")
    parser.add_argument("--write-secrets", action="store_true", help="写入 .secrets/dev-servers.yaml（包含敏感值）")
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    answers_path = Path(args.answers).expanduser().resolve()
    if not answers_path.exists():
        raise SystemExit(f"[ERROR] answers 不存在: {answers_path}")

    validate_answers_strict(answers_path)
    answers = load_json(answers_path)
    validate_answers_shape(answers)

    skill_root = Path(__file__).resolve().parents[1]
    templates_root = skill_root / "assets" / "templates"
    suite_base = templates_root / "suite-base"
    plugins_root = templates_root / "plugins"
    available_plugins: Set[str] = set()
    if plugins_root.exists() and plugins_root.is_dir():
        available_plugins = {p.name for p in plugins_root.iterdir() if p.is_dir()}
    enabled_plugins, unknown_plugins = select_plugins(answers, available_plugins)
    for plugin in unknown_plugins:
        print(f"[WARN] 未识别插件已跳过: {plugin}", file=sys.stderr)

    suite_skill_src = suite_base / ".codex" / "skills"
    suite_skill_dirs, plugin_skill_dirs = preflight_required_outputs(
        suite_skill_src=suite_skill_src,
        plugins_root=plugins_root,
        enabled_plugins=enabled_plugins,
    )
    preflight_missing = validate_preflight_files(suite_skill_dirs, plugin_skill_dirs)
    if preflight_missing:
        lines = ["[ERROR] 模板预检失败，以下必需文件/目录缺失："]
        lines.extend([f"- {x}" for x in preflight_missing])
        raise SystemExit("\n".join(lines))

    # 目标项目可能已存在其它 skills，因此只对“本套件将写入的具体路径”做冲突判定。
    dst_secrets_dir = project_root / ".secrets"
    dst_skills_dir = project_root / ".codex" / "skills"
    dst_secrets_dir.mkdir(parents=True, exist_ok=True)
    dst_skills_dir.mkdir(parents=True, exist_ok=True)

    suite_skill_names = [p.name for p in suite_skill_dirs]
    plugin_skill_names: List[str] = []
    for dirs in plugin_skill_dirs.values():
        plugin_skill_names.extend([p.name for p in dirs])
    expected_skill_dirs = suite_skill_dirs + [p for dirs in plugin_skill_dirs.values() for p in dirs]
    required_by_skill = build_required_files_from_templates(expected_skill_dirs)

    conflict_paths: List[Path] = []
    example_path = dst_secrets_dir / "dev-servers.example.yaml"
    if example_path.exists():
        conflict_paths.append(example_path)
    actual_path = dst_secrets_dir / "dev-servers.yaml"
    if args.write_secrets and actual_path.exists():
        conflict_paths.append(actual_path)
    for name in suite_skill_names:
        dst = dst_skills_dir / name
        if dst.exists():
            conflict_paths.append(dst)

    copied_plugins: List[str] = []
    for dirs in plugin_skill_dirs.values():
        for child in dirs:
            if (dst_skills_dir / child.name).exists():
                conflict_paths.append(dst_skills_dir / child.name)

    backup_dir = None
    if conflict_paths and not args.force:
        raise SystemExit("[ERROR] 目标项目存在冲突路径；请加 --force 覆盖，或手动清理后再生成")
    if args.force and conflict_paths:
        backup_dir = backup_existing(project_root, conflict_paths)
        for p in conflict_paths:
            ensure_empty_or_force(p, True)

    # 1) copy suite-base skills（逐个技能目录拷贝，允许与现有 .codex/skills 并存）
    for skill_dir in suite_skill_dirs:
        copy_tree(skill_dir, dst_skills_dir / skill_dir.name)

    # 2) plugins (optional)
    for plugin in enabled_plugins:
        children = plugin_skill_dirs.get(plugin) or []
        if not children:
            continue
        for child in children:
            dst = dst_skills_dir / child.name
            if dst.exists():
                continue
            shutil.copytree(child, dst)
        copied_plugins.append(plugin)

    # 3) write secrets example + optional actual
    secrets_example = answers_to_secrets(answers, include_sensitive=False)
    (dst_secrets_dir / "dev-servers.example.yaml").write_text(
        json.dumps(sanitize_for_example(secrets_example), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    if args.write_secrets:
        secrets_actual = answers_to_secrets(answers, include_sensitive=True)
        (dst_secrets_dir / "dev-servers.yaml").write_text(
            json.dumps(secrets_actual, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    # 4) chmod scripts
    for f in dst_skills_dir.rglob("*"):
        if f.is_file() and (f.suffix in {".sh"}):
            chmod_exec(f)

    postcheck_missing = validate_post_generated_files(
        project_root,
        required_by_skill=required_by_skill,
        require_secrets_actual=bool(args.write_secrets),
    )
    preflight_ok = len(preflight_missing) == 0
    postcheck_ok = len(postcheck_missing) == 0

    summary = {
        "generated_at": time.strftime("%F %T"),
        "project_root": str(project_root),
        "answers": str(answers_path),
        "write_secrets": bool(args.write_secrets),
        "force": bool(args.force),
        "backup_dir": str(backup_dir) if backup_dir else "",
        "plugins": copied_plugins,
        "plugins_unknown_skipped": unknown_plugins,
        "validation": {
            "preflight_ok": preflight_ok,
            "postcheck_ok": postcheck_ok,
            "missing_required_files": postcheck_missing,
        },
        "paths": {
            "secrets_example": ".secrets/dev-servers.example.yaml",
            "secrets_actual": ".secrets/dev-servers.yaml" if args.write_secrets else "",
            "skills_root": ".codex/skills",
        },
    }
    dump_json(project_root / ".tmp" / "remote-debug-setup" / "generation-summary.json", summary)
    if not postcheck_ok:
        lines = ["[ERROR] 生成后校验失败，以下必需文件缺失："]
        lines.extend([f"- {x}" for x in postcheck_missing])
        lines.append("请检查模板目录或生成脚本。")
        raise SystemExit("\n".join(lines))
    print("[OK] remote debug suite generated")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
