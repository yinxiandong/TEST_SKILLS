# AutoCode 安装指南

## 概述

AutoCode 是一个用于 AI 辅助开发的智能体、技能包和模板集合。支持三种安装方式：Claude Code 插件市场安装、脚本安装、以及 Codex 安装。

## 安装方式

### 方式一：Claude Code 插件市场安装（推荐）

通过 Claude Code 的插件市场系统安装，享受一键安装和自动更新。

**第一步：添加 Marketplace**

在 Claude Code 中执行：

```bash
/plugin marketplace add git@gitlab.allcam.com.cn:dev-flow/autocode-marketplace.git
```

**第二步：安装插件**

```bash
/plugin install autocode@autocode-marketplace
```

**更新插件**

```bash
/plugin marketplace update
```

**卸载插件**

```bash
/plugin uninstall autocode
```

### 方式二：脚本安装（Claude Code / Gemini / OpenCode）

#### 项目级安装（推荐）

安装到当前项目的 `.claude` 目录，仅对当前项目生效：

```bash
./install-autocode.sh --project
```

#### 用户级安装

安装到用户主目录 `~/.claude`，对所有项目生效：

```bash
./install-autocode.sh --user
```

**安装要求**：Linux/macOS/WSL、bash shell、unzip 命令

**支持的工具**：

| 工具 | 命令示例 |
|------|---------|
| Claude Code（默认） | `./install-autocode.sh --project` |
| Gemini | `./install-autocode.sh -t gemini --project` |
| OpenCode | `./install-autocode.sh -t opencode --project` |

### 方式三：Codex 安装

告诉 Codex：

```
Fetch and follow instructions from https://gitlab.allcam.com.cn/dev-flow/autocode-marketplace/-/raw/master/.codex/INSTALL.md
```

Codex 会自动获取安装说明并执行 Git Clone + Symlink 安装，利用 Codex 原生技能发现机制（`~/.agents/skills/`）。

> **手动安装**：如需手动操作，参考插件仓库中的 [.codex/INSTALL.md](https://gitlab.allcam.com.cn/dev-flow/autocode-marketplace/-/blob/master/.codex/INSTALL.md)。

## 升级

### 插件市场方式

```bash
/plugin marketplace update
```

### 脚本方式（自动备份升级）

脚本会自动检测已有安装并创建备份：

```bash
./install-autocode.sh --project

# 强制覆盖（跳过备份）
./install-autocode.sh --project --force
```

备份目录格式：`.claude_backup_YYYYMMDD_HHMMSS`

## 脚本命令选项

| 选项 | 简写 | 说明 |
|------|------|------|
| `--project` | `-p` | 安装到项目 .{tool} 目录 |
| `--user` | `-u` | 安装到用户 ~/.{tool} 目录 |
| `--tool` | `-t` | 指定目标工具（claude-code/codex/gemini/opencode） |
| `--force` | `-f` | 强制覆盖，不进行备份 |
| `--help` | `-h` | 显示帮助信息 |

## 安装后验证

安装完成后，检查目录结构：

```bash
# 项目安装
ls -la .claude/

# 用户安装
ls -la ~/.claude/
```

应该看到以下目录：
- `agents/` - AI 智能体定义
- `skills/` - 技能包
- `commands/` - 命令集
- `.claude-plugin/` - 插件清单（仅 Claude Code）
- `skills/*/template/` - 模板文件（随 Skill 分发）

## 使用 AutoCode

### 在项目中使用

1. 确保项目根目录有 `CLAUDE.md` 文件
2. 在支持 Claude Code 的编辑器中打开项目
3. Claude Code 会自动加载 AllClaude 配置

### 验证安装

在项目根目录创建或检查 `CLAUDE.md` 文件，确保包含必要的引用：

```markdown
# 项目 Claude Code 配置

## AllClaude 智能体系统

@agents/requirement-analysis.md
@agents/architecture-design.md
...
```

## 常见问题

### Q: 如何选择安装位置？

**A:**
- **团队项目**：使用 `--project` 安装到项目目录，可以通过 git 共享配置
- **个人开发**：使用 `--user` 安装到用户目录，所有项目共享

### Q: 升级会丢失自定义配置吗？

**A:** 脚本会自动备份现有文件。如果你有自定义配置，建议：
1. 使用默认升级（会自动备份）
2. 升级后从备份目录恢复自定义内容

### Q: 如何恢复到旧版本？

**A:** 从备份目录恢复：

```bash
# 删除当前安装
rm -rf .claude

# 从备份恢复
cp -r .claude_backup_20260110_123456 .claude
```

### Q: 能同时使用项目安装和用户安装吗？

**A:** 可以。Claude Code 优先使用项目级配置（`.claude/`），如果不存在则使用用户级配置（`~/.claude/`）。插件市场安装与脚本安装互不冲突。

### Q: 如何卸载？

**A:** 直接删除目录：

```bash
# 卸载项目安装
rm -rf .claude

# 卸载用户安装
rm -rf ~/.claude
```

## Marketplace 发布（维护者）

如需构建和发布 Marketplace：

```bash
# 构建 marketplace 产出
./build-marketplace.sh

# 产出在 dist/autocode-marketplace/ 目录
# 将其推送到独立的 Git 仓库即可
```

## 更新日志

查看 AutoCode 的更新内容和版本变化，请参考项目文档。

## 技术支持

如遇到问题，请：
1. 检查安装日志输出
2. 查看备份目录是否正确创建
3. 确认文件权限设置正确

## 许可证

请遵循 AutoCode 项目的许可证要求。
