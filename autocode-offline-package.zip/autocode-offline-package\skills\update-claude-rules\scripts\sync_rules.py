#!/usr/bin/env python3
"""
sync_rules.py - 将项目规范文档同步到 Claude Rules

该脚本扫描目标项目的 docs/specification/ 目录，将规范文档转换为
.claude/rules/ 目录下的规则文件，并自动生成路径匹配规则。

使用方法：
    python sync_rules.py <目标项目路径>

示例：
    python sync_rules.py /path/to/your-project
"""

import os
import sys
import re
from pathlib import Path
from typing import Optional, List, Dict, Tuple


# 目录位置到路径模式的映射
DIRECTORY_PATTERNS = {
    'frontend': 'src/**/*.{ts,tsx,js,jsx,vue}',
    'ui': 'src/**/*.{tsx,jsx,vue}',
    'components': 'src/components/**/*',
    'pages': 'src/pages/**/*',
    'backend': 'src/**/*.{java,py,go,rs,php}',
    'server': 'src/**/*.{java,py,go,rs}',
    'api': 'src/api/**/*',
    'services': 'src/services/**/*',
    'database': '{src/**/*.sql,migrations/**/*}',
    'migrations': 'migrations/**/*',
    'schema': '{src/**/*.sql,schema/**/*}',
    'testing': '{tests/**/*,**/*.test.*,**/*.spec.*}',
    'test': '{tests/**/*,**/*.test.*}',
    'security': '**/*',
}

# 文件名模式到路径模式的映射
FILENAME_PATTERNS = {
    'typescript': '**/*.{ts,tsx}',
    'javascript': '**/*.{js,jsx}',
    'python': '**/*.py',
    'java': '**/*.java',
    'go': '**/*.go',
    'rust': '**/*.rs',
    'react': 'src/**/*.{tsx,jsx}',
    'vue': 'src/**/*.vue',
    'angular': 'src/**/*.{ts,html}',
    'spring': 'src/**/*.java',
    'django': '**/*.py',
    'api': 'src/api/**/*',
    'component': 'src/components/**/*',
    'style': '**/*.{css,scss,less}',
    'test': '{tests/**/*,**/*.test.*}',
}

# 通用规范关键词（不添加 paths 字段）
GENERAL_KEYWORDS = ['general', 'common', 'universal', 'overall']


def infer_paths_pattern(spec_file_path: str, spec_content: str) -> Optional[str]:
    """
    根据规范文档的路径和内容，推断适用的文件路径模式

    Args:
        spec_file_path: 规范文档相对于 docs/specification/ 的路径
        spec_content: 规范文档的内容

    Returns:
        paths 模式字符串，如果是通用规范则返回 None
    """

    # 1. 从目录位置推断
    path_parts = Path(spec_file_path).parts
    for part in path_parts[:-1]:  # 排除文件名本身
        dir_name = part.lower()
        if dir_name in DIRECTORY_PATTERNS:
            return DIRECTORY_PATTERNS[dir_name]

    # 2. 从文件名推断
    file_name = Path(spec_file_path).stem.lower()

    # 检查是否为通用规范
    if any(keyword in file_name for keyword in GENERAL_KEYWORDS):
        return None

    # 检查文件名模式
    for pattern, paths in FILENAME_PATTERNS.items():
        if pattern in file_name:
            return paths

    # 3. 从内容关键词推断
    content_lower = spec_content.lower()

    # 前端技术栈
    if any(keyword in content_lower for keyword in ['react', 'vue', 'angular', 'component', '组件']):
        if 'react' in content_lower:
            return 'src/**/*.{tsx,jsx}'
        elif 'vue' in content_lower:
            return 'src/**/*.vue'
        return 'src/**/*.{ts,tsx,js,jsx,vue}'

    # 后端技术栈
    if any(keyword in content_lower for keyword in ['spring', 'django', 'express', 'api', 'endpoint', '接口']):
        if 'api' in content_lower or 'endpoint' in content_lower or '接口' in content_lower:
            return 'src/api/**/*'
        return 'src/**/*.{java,py,go,rs}'

    # 数据库技术栈
    if any(keyword in content_lower for keyword in ['sql', 'database', '数据库', 'migration', '迁移']):
        return '{src/**/*.sql,migrations/**/*}'

    # 测试相关
    if any(keyword in content_lower for keyword in ['test', 'testing', '测试', 'spec']):
        return '{tests/**/*,**/*.test.*,**/*.spec.*}'

    # 4. 默认规则：常见代码文件
    return '**/*.{ts,tsx,js,jsx,py,java,go,rs}'


def generate_rule_file_content(spec_content: str, paths_pattern: Optional[str]) -> str:
    """
    生成规则文件的完整内容（包含 YAML frontmatter）

    Args:
        spec_content: 原规范文档的内容
        paths_pattern: 路径匹配模式，None 表示不添加 paths 字段

    Returns:
        完整的规则文件内容
    """
    if paths_pattern:
        frontmatter = f"---\npaths: {paths_pattern}\n---\n\n"
    else:
        frontmatter = ""

    return frontmatter + spec_content


def sync_specification_to_rules(project_path: str) -> Dict[str, any]:
    """
    将项目的规范文档同步到 .claude/rules/ 目录

    Args:
        project_path: 目标项目的根目录路径

    Returns:
        同步结果的字典，包含成功、失败、跳过的文件列表
    """
    project_path = Path(project_path).resolve()
    spec_dir = project_path / 'docs' / 'specification'
    rules_dir = project_path / '.claude' / 'rules'

    result = {
        'success': [],
        'failed': [],
        'skipped': [],
    }

    # 检查 specification 目录是否存在
    if not spec_dir.exists():
        raise FileNotFoundError(f"规范目录不存在: {spec_dir}")

    # 创建 .claude/rules/ 目录
    rules_dir.mkdir(parents=True, exist_ok=True)

    # 扫描所有规范文档
    spec_files = list(spec_dir.rglob('*.md'))

    if not spec_files:
        print(f"⚠️  未找到规范文档: {spec_dir}")
        return result

    print(f"📂 找到 {len(spec_files)} 个规范文档")

    for spec_file in spec_files:
        try:
            # 读取规范文档内容
            spec_content = spec_file.read_text(encoding='utf-8')

            # 计算相对路径
            rel_path = spec_file.relative_to(spec_dir)

            # 推断路径匹配模式
            paths_pattern = infer_paths_pattern(str(rel_path), spec_content)

            # 生成规则文件内容
            rule_content = generate_rule_file_content(spec_content, paths_pattern)

            # 创建规则文件路径（保持相同的目录结构）
            rule_file = rules_dir / rel_path
            rule_file.parent.mkdir(parents=True, exist_ok=True)

            # 写入规则文件
            rule_file.write_text(rule_content, encoding='utf-8')

            result['success'].append({
                'spec_file': str(rel_path),
                'rule_file': str(rule_file.relative_to(project_path)),
                'paths_pattern': paths_pattern or '(适用所有文件)',
            })

            print(f"✓ {rel_path} → paths: {paths_pattern or '(适用所有文件)'}")

        except Exception as e:
            result['failed'].append({
                'file': str(spec_file.relative_to(spec_dir)),
                'error': str(e),
            })
            print(f"✗ {spec_file.name}: {e}")

    return result


def print_summary(result: Dict[str, any], project_path: str):
    """打印同步结果摘要"""
    print("\n" + "="*60)
    print("📊 同步结果摘要")
    print("="*60)
    print(f"✅ 成功: {len(result['success'])} 个文件")
    print(f"❌ 失败: {len(result['failed'])} 个文件")
    print(f"⏭️  跳过: {len(result['skipped'])} 个文件")
    print(f"\n📁 规则目录: {Path(project_path) / '.claude' / 'rules'}")
    print("\n💡 建议: 请审查生成的 rules 文件，根据实际项目结构调整 paths 模式")


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法: python sync_rules.py <目标项目路径>")
        print("\n示例:")
        print("  python sync_rules.py /path/to/your-project")
        print("  python sync_rules.py ../my-app")
        sys.exit(1)

    project_path = sys.argv[1]

    # 验证项目路径
    if not os.path.exists(project_path):
        print(f"❌ 错误: 项目路径不存在: {project_path}")
        sys.exit(1)

    print(f"🚀 开始同步规范文档到 Claude Rules")
    print(f"📂 目标项目: {project_path}\n")

    try:
        result = sync_specification_to_rules(project_path)
        print_summary(result, project_path)

        if result['failed']:
            sys.exit(1)

    except Exception as e:
        print(f"\n❌ 同步失败: {e}")
        sys.exit(1)


if __name__ == '__main__':
    main()
