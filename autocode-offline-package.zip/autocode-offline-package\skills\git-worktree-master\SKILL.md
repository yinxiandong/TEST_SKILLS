---
name: git-worktree-master
description: Git worktree expert for requirement-based development workflow. Use when creating isolated development environments for requirements (rqXXX-*), managing worktrees with submodules, or switching between requirement workspaces. Handles worktree creation, branch binding for main project and all submodules, workspace switching, and cleanup operations.
---

# Git Worktree Master Skill

专门用于需求开发工作流的 Git Worktree 管理专家。在需求分析前创建隔离的工作区，为主项目和所有子模块绑定需求分支，确保开发工作在独立环境中进行。

## 核心原则

**工作区隔离**：每个需求使用独立的 worktree，避免分支切换干扰
**子模块同步**：主项目和所有子模块都绑定同名需求分支
**提前创建**：在需求分析阶段前就创建好工作区，后续工作在工作区内进行

## 使用场景

1. **需求分析前**：创建需求工作区（`/analysis-rq` 之前）
2. **开发准备阶段**：切换到需求工作区（`/prepare-rq` 时）
3. **开发实施阶段**：在需求工作区内开发（`/develop-rq` 时）


## 关键命令

### 创建需求工作区

```bash
# 完整流程脚本
create_requirement_worktree() {
    local req_id="$1"  # 例如：rq001-s3-storage-manage
    local project_name=$(basename $(pwd))
    local worktree_path="../${project_name}-${req_id}"

    # 1. 创建 worktree 和分支
    git worktree add "${worktree_path}" -b "${req_id}"

    # 2. 进入 worktree
    cd "${worktree_path}"

    # 3. 初始化子模块
    git submodule update --init --recursive

    # 4. 为所有子模块创建同名分支
    git submodule foreach "git checkout -b ${req_id} 2>/dev/null || git checkout ${req_id}"

    echo "✅ 需求工作区创建完成：${worktree_path}"
    echo "📍 当前位置：$(pwd)"
    echo "🌿 主项目分支：$(git branch --show-current)"
    echo "🌿 子模块分支："
    git submodule foreach --quiet 'echo "  - $(basename $sm_path): $(git branch --show-current)"'
}
```

### 切换到需求工作区

```bash
# 切换到指定需求的工作区
switch_to_requirement_worktree() {
    local req_id="$1"
    local project_name=$(basename $(git rev-parse --show-toplevel))
    local worktree_path="../${project_name}-${req_id}"

    if [ -d "${worktree_path}" ]; then
        cd "${worktree_path}"
        echo "✅ 已切换到需求工作区：${worktree_path}"
    else
        echo "❌ 工作区不存在：${worktree_path}"
        return 1
    fi
}
```

### 检查工作区状态

```bash
# 检查当前工作区和分支状态
check_worktree_status() {
    echo "📍 当前目录：$(pwd)"
    echo "🌿 主项目分支：$(git branch --show-current)"
    echo "📊 工作区状态："
    git status --short
    echo ""
    echo "🔗 子模块状态："
    git submodule foreach --quiet 'echo "  - $(basename $sm_path): $(git branch --show-current) $(git status --short | wc -l) changes"'
}
```

### 列出所有工作区

```bash
# 列出所有 worktree
git worktree list
```

### 清理工作区

```bash
# 清理指定需求的工作区
cleanup_requirement_worktree() {
    local req_id="$1"
    local project_name=$(basename $(git rev-parse --show-toplevel))
    local worktree_path="../${project_name}-${req_id}"

    # 1. 确保在主仓库
    cd $(git rev-parse --show-toplevel)

    # 2. 删除 worktree
    if git worktree list | grep -q "${worktree_path}"; then
        git worktree remove "${worktree_path}" --force
        echo "✅ 已删除工作区：${worktree_path}"
    fi

    # 3. 删除分支（如果已合并）
    if git branch --list "${req_id}" | grep -q "${req_id}"; then
        git branch -d "${req_id}" 2>/dev/null && echo "✅ 已删除主项目分支：${req_id}" || echo "⚠️  分支未合并，使用 -D 强制删除"
    fi

    # 4. 清理子模块分支
    git submodule foreach "git branch -d ${req_id} 2>/dev/null || echo '⚠️  子模块 \$sm_path 分支未合并'"
}
```

## 工作区命名规范

**格式**：`${项目名}-{rq_id}`

**示例**：
- 主仓库：`/home/workspace/ai-flow-rad`
- 需求标识：`rq001-s3-storage-manage`
- 工作区路径：`/home/workspace/ai-flow-rad-rq001-s3-storage-manage`

## 分支命名规范

**格式**：`{rq_id}`

**示例**：
- `rq001-s3-storage-manage`
- `rq002-user-auth-enhancement`
- `rq003-performance-optimization`

## 子模块处理

### 子模块分支同步

所有子模块必须创建与主项目同名的需求分支：

```bash
# 为所有子模块创建需求分支
git submodule foreach 'git checkout -b {rq_id} || git checkout {rq_id}'

# 检查所有子模块分支
git submodule foreach 'echo "$(basename $sm_path): $(git branch --show-current)"'
```

### 子模块提交和推送

在工作区内开发时，子模块的修改需要单独提交：

```bash
# 1. 进入子模块提交
cd ${path/to/submodule}
git add .
git commit -m "（举例）feat: 子模块功能实现"
git push origin {rq_id}

# 2. 返回主项目，更新子模块引用
cd ../..
git add ${path/to/submodule}
git commit -m "（举例）chore: 更新子模块引用"
```

## 安全检查

### 创建工作区前检查

```bash
# 1. 确保在主仓库根目录
if [ ! -d ".git" ]; then
    echo "❌ 错误：不在 Git 仓库根目录"
    exit 1
fi

# 2. 确保工作区不存在
if [ -d "../${project_name}-${req_id}" ]; then
    echo "❌ 错误：工作区已存在"
    exit 1
fi

# 3. 确保分支不存在
if git branch --list "${req_id}" | grep -q "${req_id}"; then
    echo "❌ 错误：分支已存在"
    exit 1
fi

# 4. 确保工作区干净
if [ -n "$(git status --porcelain)" ]; then
    echo "⚠️  警告：工作区有未提交的修改"
    git status --short
fi
```

### 切换工作区前检查

```bash
# 1. 检查目标工作区是否存在
if [ ! -d "${worktree_path}" ]; then
    echo "❌ 错误：目标工作区不存在"
    exit 1
fi

# 2. 检查当前工作区是否有未提交修改
if [ -n "$(git status --porcelain)" ]; then
    echo "⚠️  警告：当前工作区有未提交的修改"
    git status --short
    read -p "是否继续切换？(y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi
```

## 常见问题处理

### 问题 1：子模块未初始化

**症状**：子模块目录为空

**解决**：
```bash
git submodule update --init --recursive
```

### 问题 2：子模块分支不一致

**症状**：部分子模块不在需求分支

**解决**：
```bash
# 检查所有子模块分支
git submodule foreach 'git branch --show-current'

# 切换到需求分支
git submodule foreach 'git checkout {rq_id}'
```

### 问题 3：分支已存在但工作区不存在

**症状**：创建工作区时提示分支已存在

**解决**：
```bash
# 使用已有分支创建工作区
git worktree add ../project-{rq_id} {rq_id}
```
