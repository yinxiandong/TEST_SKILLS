---
name: remote-api-debug
description: "通用远程接口调测技能。读取 .secrets/dev-servers.yaml（v2 schema）选择目标服务器与默认 base_url，按 spec 文件批量调用 HTTP API 并输出断言结果。支持 none/token/login 三种鉴权策略，并以 SUMMARY: PASS|FAIL 作为收敛信号，供 remote-dev-debug 编排使用。"
---

# remote-api-debug

## 概述

本技能对指定远端环境执行批量 HTTP API 调测，输出逐条用例结果与汇总。

## spec 文件格式（JSON）

```json
{
  "base_url": "http://{host}:8080",
  "auth": {
    "mode": "none",
    "token": "",
    "login": {
      "url": "http://{host}:8080/api/login",
      "method": "POST",
      "headers": {"Content-Type": "application/json"},
      "body": {"username": "demo", "password": "demo"},
      "token_path": "data.token",
      "token_scheme": "Bearer"
    }
  },
  "cases": [
    {"name": "health", "method": "GET", "path": "/health", "expect": {"status": 200, "contains": "UP"}}
  ]
}
```

## 用法

```bash
.codex/skills/remote-api-debug/scripts/api_debug.sh \
  --server dev1 \
  --spec-file /tmp/api-spec.json \
  --config .secrets/dev-servers.yaml
```

