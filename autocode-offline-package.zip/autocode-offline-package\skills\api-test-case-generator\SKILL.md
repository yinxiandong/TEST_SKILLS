---
name: api-test-case-generator
description: API 测试用例列表生成（一阶段）。支持三条路径：需求驱动、后端代码提取、Git 变动刷新。基于覆盖率规则体系（正向/负向/边界/安全 4 大类 21 条规则）生成用例列表 CSV，供人工审查后进入二阶段详情生成。
---

# API 测试用例列表生成技能（一阶段）

## 调用方

- `api-test-orchestrator`：在 Phase 2 调用，选择路径 A/B/C 生成用例列表
- 用户直接调用：独立生成用例列表（指定路径和模块）

## 输入

### 前置依赖

- `tests/api-test/api-test.config.yaml`：测试配置文件（由 `api-test-config` 生成）
- API 特性清单 CSV（由 `feature-api-list-generator` 生成，路径从 `api-test.config.yaml` 的 `output.feature_dir` 读取，默认 `docs/features/`）

> **路径约定**：本技能中出现的所有目录路径（`docs/features/`、`tests/api-test/`、`.tests/cache/` 等）均为默认值，实际以 `tests/api-test/api-test.config.yaml` 的 `output` 配置为准。

### 路径 A：需求驱动

输入：`docs/requirement/{rq_id}/` 下的需求文档，提取涉及 API 变更的需求点

### 路径 B：后端代码提取

输入：目标项目后端源代码目录路径（路由、控制器、DTO/Schema）

### 路径 C：Git 变动刷新

输入：后端仓库 git 提交范围（如 `HEAD~10..HEAD` 或具体 commit range）

---

## 执行流程

```
输入路径判断
  ├─ 路径A: 需求驱动   → 提取需求中的 API 变更 → 匹配特性清单 → 按覆盖规则生成用例 → 输出 CSV
  ├─ 路径B: 代码提取   → 分析后端代码 → 提取接口信息 → 按覆盖规则生成用例 → 去重 → 输出 CSV
  └─ 路径C: Git刷新    → 分析变动文件 → 识别 API 变更 → 更新/新增/废弃用例 → 输出 CSV
```

---

## 覆盖率方法论

采用 **4 大类 21 条规则** 的覆盖率体系，详见 `references/coverage-rules.md`。

### 覆盖类型概览

| 覆盖类型 | 规则数 | 说明 |
|---------|--------|------|
| `positive` | 4 条 | 正向用例：合法输入、正常业务流 |
| `negative` | 6 条 | 负向用例：非法输入、异常流程 |
| `boundary` | 4 条 | 边界值用例：临界值、空值、长度 |
| `security` | 7 条 | 安全性用例：鉴权、注入攻击 |

### 用例生成策略

对特性清单中的每个 API，按以下优先级生成用例：

1. **必生成**（每个 API 至少 1 条）：
   - `positive-required-only`：仅传必填字段的正向用例
2. **按条件生成**：
   - 有必填字段 → `negative-missing-field`
   - 需要鉴权 → `security-auth-control`
   - 有字符串输入 → `security-sql-injection` + `security-xss`
   - 有枚举字段 → `positive-enum-combination`
   - 有数值范围 → `boundary-max-min` + `boundary-exceed`
   - 有长度限制 → `boundary-string-length`
   - 有格式要求 → `negative-format-error`
   - 接受 JSON 体 → `security-json-injection`
3. **补充生成**（提升覆盖率）：
   - `positive-valid-semantics`、`negative-type-error`、`boundary-null-zero-empty`
   - `security-fuzzing`、`security-command-injection`、`security-nosql-injection`

---

## 路径 A：需求驱动

### 流程

1. 读取 `docs/requirement/{rq_id}/` 下的需求文档
2. 识别涉及 API 变更的需求点（新增接口、修改接口、废弃接口）
3. 与 `docs/features/{module}-api-features.csv` 特性清单匹配
4. 按覆盖率规则为每个受影响的 API 生成用例列表
5. 输出增量用例 CSV

### 输出

- 用例列表追加到 `tests/api-test/usecase/{module}/` 目录下的 CSV（或新建）
- `source=requirement`，`source_ref` 指向需求文档路径

---

## 路径 B：后端代码提取

### 分析策略

1. **路由提取**：扫描后端路由定义，提取所有 API 端点
2. **参数分析**：从 DTO/Schema/Model 中提取参数信息（名称、类型、必填、校验规则）
3. **鉴权识别**：从中间件/装饰器/注解中识别鉴权需求
4. **业务规则提取**：从校验逻辑中提取边界值、枚举值、格式要求
5. **按覆盖规则生成**：根据提取的参数信息，自动匹配适用的覆盖规则

### 去重策略

生成前读取已有用例 CSV，对已有 `case_id` 的同 API 同覆盖规则跳过，仅生成增量用例。

### 输出

- 缓存分析结果到 `.tests/cache/code-analysis.json`
- 输出用例列表 CSV
- `source=code-extract`，`source_ref` 指向源代码文件路径

---

## 路径 C：Git 变动刷新

### 分析策略

1. **变动文件识别**：过滤后端 API 相关文件
   ```bash
   git diff --name-only {base}..{head}
   # 过滤：routes/, controllers/, handlers/, api/, routers/, dto/, schemas/, models/
   ```

2. **变动分类**：
   - **新增 API** → 标记"需新建用例"
   - **修改 API**（参数变更、路径变更、鉴权变更）→ 标记"需刷新用例"
   - **删除 API** → 标记"需废弃用例"（CSV 标记 `status=deprecated`）

3. **差分分析**：对修改类文件做 `git diff`，识别：
   - 路径变更 → 更新用例中的 `api_path`
   - 参数增减 → 补充或移除对应覆盖规则的用例
   - 鉴权变更 → 更新 `security-auth-control` 用例

### 输出

- 缓存分析结果到 `.tests/cache/git-diff-analysis.json`
- 更新受影响的用例 CSV
- 新增用例 `source=git-refresh`，`source_ref` 指向 commit hash
- 废弃用例标记 `status=deprecated`

---

## 用例列表 CSV 格式

参见模板文件：`template/api-usecase-list.csv.template`

### 字段说明

| 字段 | 必填 | 说明 |
|------|------|------|
| `case_id` | 是 | 唯一标识，格式 `TC-API-{MODULE}-{SEQ}`（三位序号） |
| `case_name` | 是 | 用例名称，格式建议：`{功能}-{覆盖类型}-{规则简述}` |
| `level` | 是 | `P0` / `P1` / `P2` / `P3` |
| `smoke` | 是 | `true` / `false`（P0 默认 true） |
| `type` | 是 | 固定为 `api-test` |
| `category` | 是 | 功能分类（如 auth, user, order） |
| `module` | 是 | 所属模块 |
| `api_path` | 是 | 接口路径 |
| `method` | 是 | HTTP 方法（大写） |
| `coverage_type` | 是 | `positive` / `negative` / `boundary` / `security` |
| `coverage_rule` | 是 | 规则 ID（见 coverage-rules.md） |
| `source` | 是 | `requirement` / `code-extract` / `git-refresh` |
| `source_ref` | 否 | 来源引用 |
| `script_path` | 否 | 生成的 pytest 脚本路径（一阶段留空，由二阶段 `api-test-detail-generator` 回填） |
| `status` | 是 | `pending`（待审查）/ `approved`（已审查）/ `deprecated` |
| `tags` | 否 | 标签（逗号分隔） |

### case_name 命名规范

```
{API功能简述}-{覆盖类型中文}-{规则简述}
```

示例：
- `用户登录-正向-仅必填字段`
- `用户登录-负向-缺失密码字段`
- `用户登录-安全-未登录访问`
- `创建订单-边界-金额极大值`
- `查询用户-安全-SQL注入`

---

## 输出路径

```
tests/api-test/usecase/
└── {module}/
    └── {module}-case-list.csv           # 用例列表（一阶段产物，供人工审查）

.tests/cache/
├── code-analysis.json               # 路径B 缓存
└── git-diff-analysis.json           # 路径C 缓存
```

---

## 人工审查要点

用例列表生成后，提示用户审查以下内容：

1. **用例完整性**：是否覆盖了所有关键 API
2. **级别合理性**：P0 是否覆盖核心冒烟场景
3. **覆盖均衡性**：正向/负向/边界/安全比例是否合理
4. **冗余检查**：是否有重复或低价值用例可删除
5. **补充需求**：是否有特殊业务场景需要手动补充

审查通过后，用户确认 `status` 从 `pending` 改为 `approved`，进入二阶段详情生成。

---

## 约束

- 一阶段只生成用例列表（CSV），不生成 YAML 详情和 pytest 脚本
- 不修改 `template/` 和 `references/` 下的文件
- `case_id` 全局唯一，生成前必须检查已有用例
- 路径 B/C 必须去重，避免与现有用例重复
- 用例列表初始 `status=pending`，等待人工审查
