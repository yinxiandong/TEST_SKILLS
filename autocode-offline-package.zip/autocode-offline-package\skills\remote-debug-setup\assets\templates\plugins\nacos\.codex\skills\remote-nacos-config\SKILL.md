---
name: remote-nacos-config
description: "Nacos 配置中心插件技能（通用、尽力而为）。读取 .secrets/dev-servers.yaml 中 servers[].components.nacos 或 servers[].nacos（兼容）配置，对 Nacos 执行连通性探测与配置 get/list/put/delete。支持 nacos api_version=v1/v3 两种常见登录与配置接口形态；若环境差异较大，脚本会输出需要人工确认的字段清单。"
---

# remote-nacos-config

## 配置要求（建议写入 .secrets/dev-servers.yaml）

建议配置位置：`servers[].components.nacos`

最小字段（推荐）：

```json
{
  "enabled": true,
  "protocol": "http",
  "host": "10.0.0.1",
  "port": 8848,
  "access": { "mode": "direct" },
  "username": "nacos",
  "password_plain": "******",
  "api_version": "v1"
}
```

说明：

- `api_version` 建议先填 `v1`；若执行失败，再改为 `v3`。
- `access.mode`：`direct|ssh`。`ssh` 表示通过 SSH 临时端口转发访问 Nacos（适合本地无法直连内网端口的场景）；password 认证需要本机 `sshpass`。若未显式配置 `host`，`ssh` 模式默认使用 `127.0.0.1` 作为远端目标地址。
- 若你不确定版本，可先运行 `probe_remote_nacos.sh`，它会尽力输出 `api_version` 提示（仍需人工确认）。

## 用法

```bash
.codex/skills/remote-nacos-config/scripts/probe_remote_nacos.sh --server dev1 --config .secrets/dev-servers.yaml
.codex/skills/remote-nacos-config/scripts/nacos_config.sh --server dev1 --action get --data-id demo --group DEFAULT_GROUP --namespace public
.codex/skills/remote-nacos-config/scripts/nacos_config.sh --server dev1 --action put --data-id demo --group DEFAULT_GROUP --namespace public --type yaml --content-file ./demo.yaml --confirm
```
