---
name: e2e-case-generator
description: E2E 测试用例生成（一阶段）。支持三条路径：需求驱动、前端代码提取、Git 变动刷新。使用分层覆盖方法论确保覆盖率，输出 YAML 用例到 tests/ui-test/usecase/，同步更新 CSV 注册表。
---

# E2E 用例生成技能（一阶段）

## 调用方

- `e2e-orchestrator`：在用例生成阶段调用，支持三条路径
- 用户直接调用：独立生成用例（指定路径 A/B/C）

## 输入模式

### 路径 A：需求驱动

输入：`docs/requirement/{rq_id}/20-{stage}-需求测试设计.md` 中 `test_type: e2e` 的场景

### 路径 B：前端代码提取

输入：目标项目前端源代码目录路径

### 路径 C：Git 变动刷新

输入：git 提交范围（如 `HEAD~5..HEAD` 或具体 commit range）

---

## 执行流程

```
输入路径判断
  ├─ 路径A: 需求驱动   → 提取 e2e 场景 → 分层覆盖补充 → 生成 YAML → 注册 CSV
  ├─ 路径B: 代码提取   → 分析前端代码 → 生成用例 → 去重 → 生成 YAML → 注册 CSV
  └─ 路径C: Git刷新    → 分析变动文件 → 分类处理 → 更新/新增/废弃 → 注册 CSV
```

---

## 测试方法论（分层覆盖模型）

采用**分层覆盖模型**，从粗到细保证覆盖率：

| 层级 | 方法论 | 覆盖目标 | 产出 |
|------|--------|---------|------|
| L1 页面覆盖 | 页面清单法 | 每个页面/路由至少有1个 P0 用例 | 页面可达性用例 |
| L2 流程覆盖 | 场景法 | 核心用户旅程端到端覆盖 | 业务流程用例 |
| L3 交互覆盖 | 等价类 + 边界值 | 表单输入、按钮操作的正反例 | 交互验证用例 |
| L4 状态覆盖 | 状态迁移法 | 权限态、登录态、数据态切换 | 状态转换用例 |
| L5 异常覆盖 | 错误推测法 | 网络异常、空数据、超长输入 | 异常场景用例 |

### 级别分配规则

- **P0**：L1 核心页面可达 + L2 核心业务流程（冒烟必测，smoke=true）
- **P1**：L2 次要流程 + L3 主要交互
- **P2**：L3 次要交互 + L4 状态覆盖
- **P3**：L5 异常场景 + 边缘用例

### 覆盖率检查清单（用例生成后自动校验）

- [ ] 所有路由页面至少有 1 个 P0 用例
- [ ] 核心业务旅程全部覆盖（登录→核心功能→登出）
- [ ] 每个表单至少有正例和反例各 1 个
- [ ] 关键状态切换有覆盖（如：未登录→已登录→会话过期）

---

## 路径 A：需求驱动

### 流程

1. 读取需求测试设计文档，提取 `test_type: e2e` 的场景
2. 按分层覆盖模型评估覆盖完整性，补充遗漏用例
3. 生成 YAML 用例 → `tests/ui-test/usecase/{category}/`
4. 注册到 CSV，`source=requirement`

### 输出

- YAML 用例文件（含模板格式，见 `template/usecase.yaml.template`）
- 更新 `tests/ui-test/testcase-registry.csv`

---

## 路径 B：前端代码提取

### 分析策略

1. **路由提取**：解析路由配置文件
   - React Router：`src/router/`、`src/App.tsx` 中的 `<Route>`
   - Vue Router：`src/router/index.ts` 中的 `routes` 数组
   - Next.js：`app/` 或 `pages/` 目录结构
   - Angular：`app-routing.module.ts`

2. **组件分析**：扫描页面组件，识别：
   - 表单元素（`<input>`, `<select>`, `<textarea>`）→ 生成输入类用例
   - 按钮和链接（`<button>`, `<a>`）→ 生成点击类用例
   - 条件渲染（`v-if`, `{cond && ...}`）→ 生成状态类用例

3. **API 端点提取**：从 `fetch`/`axios` 调用中提取 API 路径 → 辅助确定等待策略

4. **data-testid 收集**：提取已有的 `data-testid` 属性 → 优先使用为选择器

5. **权限/角色分析**：识别路由守卫和权限检查 → 生成权限态用例

### 去重策略

生成前读取 CSV，对已有 `case_id` 的同页面同操作跳过，仅生成增量用例。

### 输出

- 缓存分析结果到 `.tests/cache/code-analysis.json`
- 生成 YAML 用例 → `tests/ui-test/usecase/{category}/`
- 注册到 CSV，`source=code-extract`

---

## 路径 C：Git 变动刷新

### 分析策略

1. **变动文件识别**：过滤 UI 相关文件
   ```bash
   git diff --name-only {base}..{head}
   # 过滤：src/pages/, src/views/, app/, src/components/, src/router/, *.css, *.scss
   ```

2. **变动分类**：
   - **新增页面/组件** → 标记"需新建用例"
   - **修改已有组件** → 标记"需刷新用例"（检查选择器、交互变化）
   - **删除页面/组件** → 标记"需废弃用例"（CSV 标记 `deprecated`）
   - **路由变更** → 标记"需更新 URL 断言"

3. **差分分析**：对修改类文件做 `git diff`，识别：
   - 选择器变化（class/id/data-testid 修改）→ 更新 YAML 中的 `target`
   - 新增交互元素 → 补充用例步骤
   - API 路径变化 → 更新 `wait_pattern`

4. **用例变更建议**：输出变更清单，说明每个受影响用例的变更原因和建议动作

### 输出

- 缓存分析结果到 `.tests/cache/git-diff-analysis.json`
- 更新受影响的 YAML 用例文件
- 新增用例注册到 CSV，`source=git-refresh`
- 废弃用例在 CSV 中标记 `status=deprecated`

---

## YAML 用例格式

### 完整字段说明

参见模板文件：`template/usecase.yaml.template`（含所有字段及注释）

**必填字段速查**：

| 字段 | 必填 | 说明 |
|------|------|------|
| `case_id` | 是 | 唯一标识，格式 `TC-UI-{CATEGORY}-{SEQ}`（三位序号，如 001） |
| `case_name` | 是 | 用例名称，简明描述测试目标 |
| `level` | 是 | `P0` / `P1` / `P2` / `P3` |
| `smoke` | 是 | `true` / `false`（P0 默认 true） |
| `type` | 是 | 固定为 `ui-test` |
| `category` | 是 | 功能分类，与 usecase/ 子目录名一致 |
| `source` | 是 | `requirement` / `code-extract` / `git-refresh` |
| `source_ref` | 否 | 来源引用（需求文档路径 / 组件文件路径 / commit hash） |
| `tags` | 否 | 标签列表，如 `[auth, login, happy-path]` |
| `preconditions` | 否 | 测试前置条件列表 |
| `steps` | 是 | 测试步骤列表（含 seq/action/target/wait/input/screenshot） |
| `expected` | 是 | 预期结果列表（含 condition/value/assertion） |
| `postconditions` | 否 | 测试后置清理列表 |
| `script_path` | 否 | 初始为空串，二阶段由 e2e-script-generator 回填 |
| `created_at` | 是 | 创建日期，格式 `YYYY-MM-DD` |
| `updated_at` | 是 | 最后更新日期，格式 `YYYY-MM-DD` |

---

## CSV 注册表管理

文件路径：`tests/ui-test/testcase-registry.csv`

参见模板文件：`template/testcase-registry.csv.template`

### 维护规则

1. **新建用例**：追加新行，`status=active`（有脚本）或 `status=pending`（无脚本）
2. **更新用例**：更新 `updated_at` 和受影响字段
3. **废弃用例**：将 `status` 改为 `deprecated`
4. **脚本生成后**：`e2e-script-generator` 回填 `script_path`，`status` 从 `pending` 改为 `active`

---

## 输出路径约定

```
tests/
└── ui-test/
    ├── testcase-registry.csv          # UI 测试用例注册表（本技能维护）
    └── usecase/
        ├── {category}/
        │   └── {feature}.yaml         # YAML 用例文件
        └── ...
.tests/
└── cache/
    ├── code-analysis.json             # 路径B 缓存
    └── git-diff-analysis.json         # 路径C 缓存
```

---

## 约束

- 不修改 `tests/ui-test/scripts/` 下的脚本文件（由 `e2e-script-generator` 负责）
- 不修改 `template/` 下的模板文件本身
- CSV 注册表中 `case_id` 全局唯一，生成前必须检查
- 路径 B/C 必须去重，避免与现有用例重复
