---
name: remote-debug-setup
description: "在任意项目中通过问答+只读SSH探测，生成项目专属的远程调试套件：输出 .secrets/dev-servers.example.yaml，并在项目根目录生成 .codex/skills/remote-*（按服务逐个映射，支持 systemd/脚本/docker；按探测到的组件选择性生成插件能力）。适用于需要为新项目快速搭建远程部署、日志诊断、API 调测与远程调试闭环的场景。"
---

# remote-debug-setup

本技能用于“在目标项目里生成一套贴合该项目的远程调试 skill 套件”。核心流程是：

1) AskUserQuestion 收集最小 SSH 入口信息（不做业务假设）
2) 本地分析当前项目形态（生成 project-profile.json，提供项目强绑定信号）
3) 只读 SSH 探测远端部署形态/服务清单/端口与组件线索（结合 project-profile 做候选服务相关性排序）
4) 按服务逐个确认映射（systemd/脚本/docker 三选一）
5) 生成 `.secrets` 与 `.codex/skills/remote-*` 套件

> 重要：本技能默认只读探测，不会对远端执行写操作。

## 产物（生成到目标项目根目录）

- `.secrets/dev-servers.example.yaml`（JSON 兼容格式，脱敏示例）
- （可选）`.secrets/dev-servers.yaml`（实配；默认不写入敏感值）
- `.codex/skills/remote-dev-deploy/`（按 `services[]` 支持 systemd/脚本/docker）
- `.codex/skills/remote-log-diagnose/`
- `.codex/skills/remote-api-debug/`
- `.codex/skills/remote-dev-debug/`
- 可选插件：按探测到的组件与用户确认生成（例如 Nacos/DB 等）

## 使用流程（推荐按步骤执行）

本技能在 Codex UI 中使用时，应当由智能体**自动执行所有命令**；用户只需要通过 AskUserQuestion 交互回答问题。

你看到的命令（如 `python3 .../probe_remote_env.py`）是“智能体应执行的动作”，不是让用户手动在终端敲。

下面步骤按“智能体动作/用户输入”描述。

## 问答脚本（强约束，必须按此提问）

本节是“固定题库”，用于保证不同项目/不同操作者下生成结果一致可靠。

### Q0：覆盖与备份策略（仅当检测到冲突路径时提问）

当检测到目标项目存在以下任一冲突路径：

- `.secrets/dev-servers.example.yaml`
- `.secrets/dev-servers.yaml`（仅当用户同意写入实配时才算冲突）
- `.codex/skills/remote-dev-deploy`、`.codex/skills/remote-log-diagnose`、`.codex/skills/remote-api-debug`、`.codex/skills/remote-dev-debug`
- 插件技能目录（如 `.codex/skills/remote-nacos-config`）

必须 AskUserQuestion 让用户二选一：

1. **备份并覆盖（推荐）**：使用 `--force`，并告知会先备份到 `.tmp/remote-debug-setup/backup/`。
2. **停止并人工处理**：退出，不做任何写入。

### Q1：目标服务器数量

AskUserQuestion：

- 单台服务器（推荐）
- 多台服务器（随后对每台重复 Q2~Q6）

### Q2：服务器别名（server name）

AskUserQuestion：输入服务器别名。

强约束：

- 必须匹配白名单（默认 `^(dev|test)`），否则必须继续追问并要求更换。

### Q3：SSH 连接信息

AskUserQuestion（逐项收集）：

- host
- port（默认 22）
- username

### Q4：SSH 认证方式

AskUserQuestion：二选一

1. **password（推荐易用）**
2. **key（推荐安全）**

后续追问：

- 若选 password：再问 password（仅 UI 输入，不在对话中回显；默认不落盘到 `.secrets/dev-servers.yaml`）
- 若选 key：再问本机私钥路径 `identity_file`

### Q5：是否允许 HTTP 只读探测

AskUserQuestion：

- 不启用（默认）
- 启用（只读 GET / 响应头提示，不登录）

若启用，再问：常见 HTTP 端口提示（默认 `[80, 443, 8080, 8000, 9000, 10000, 10001, 10002]`）。

### Q6：是否启用可选插件（基于探测线索建议）

智能体读取 `probe-report.json` 的 `components_hints`：

- 若发现 `nacos` 线索：AskUserQuestion 是否启用 **Nacos 插件**（默认：启用）
- 若发现 `db` 线索：AskUserQuestion 是否启用 **DB 探测插件**（默认：启用）

强约束：

- 插件支持 dev/test 场景的“读写管理”能力（例如 Nacos 配置写入、Kafka topic 管理与 offset 重置、ES 索引/数据变更等）。
- 为避免误操作：插件脚本对写入/破坏性动作要求显式确认（例如 `--confirm`）。智能体在 UI 中也必须再次 AskUserQuestion 确认后才可执行。

### Q7：按服务逐个确认映射（核心）

智能体从 `probe-report.json` 的 `service_candidates[]` 生成候选列表，并对每个候选逐个 AskUserQuestion：

1) 是否纳入生成（默认：是）

2) 服务显示名（默认：候选的 `name_hint`）

3) 部署/启停模式（二选一/三选一，默认优先级：systemd > docker > script）

- `systemd`
- `docker`
- `script`

4) 日志抓取方式（三选一，默认与模式绑定）

- `journalctl`（systemd 默认）
- `docker`（docker 默认）
- `files`（script 默认；若选 files，必须继续追问日志路径列表）

5) 是否启用 API 调测（默认：否）

若启用，继续追问鉴权策略：

- `none`
- `token`
- `login`
- `openapi`（仅当用户能提供 openapi 地址或探测到线索时才推荐）

### Q8：是否写入 .secrets/dev-servers.yaml（实配）

AskUserQuestion：

- 仅生成 `.secrets/dev-servers.example.yaml`（默认）
- 同时写入 `.secrets/dev-servers.yaml`（包含敏感值；必须明确授权）

### Step 0：准备工作目录（智能体执行）

- 智能体在目标项目根目录创建：`.tmp/remote-debug-setup/`（如已存在则复用）。

### Step 1：收集最小 SSH 入口（AskUserQuestion，用户只回答）

智能体必须使用 AskUserQuestion 收集并确认：

1. 服务器别名（建议 `dev*` / `test*`）
2. SSH `host` / `port` / `username`
3. SSH 认证方式：`password` 或 `key`
   - password：只在 UI 内输入，不在对话中回显
   - key：让用户给出本机私钥路径 `identity_file`
4. 是否允许做 HTTP 只读探测（可选）

智能体将答案落盘为：`{project_root}/.tmp/remote-debug-setup/answers.min.json`

字段要求见：`references/answers-schema.md`。

### Step 1.5：分析当前项目（智能体执行）

- 智能体在目标项目根目录执行本地分析脚本生成：`{project_root}/.tmp/remote-debug-setup/project-profile.json`
- 目的：为共享/综合环境下的远端探测提供“项目强绑定信号”（关键词、jar/binary、部署路径前缀、端口提示等），用于候选服务的相关性排序与解释。

### Step 2：只读探测远端环境（智能体执行）

- 智能体执行探测脚本生成：`{project_root}/.tmp/remote-debug-setup/probe-report.json`
- 如 SSH 连接失败，必须停止并用 AskUserQuestion 要求用户修正 SSH 信息。

说明：
- 探测脚本支持 `--project-profile`，会在输出的 `service_candidates[]` 中增加 `project_match`（score+reasons），并优先把更像本项目的候选排在前面。
- 默认启用 `/proc` 只读取证（提升 Java/C++ 进程部署场景命中率）；可通过 `--disable-proc-enrich` 禁用。

### Step 3：按服务逐个确认映射（AskUserQuestion，用户只回答）

智能体基于 `probe-report.json` 的 `service_candidates[]`，对每个候选服务逐个提问并确认：

- 是否纳入生成（默认“是”）
- 服务名（默认取 unit/container/process 名）
- 部署/启停模式（`systemd|script|docker` 三选一）
- 日志抓取方式（`journalctl|docker|files` 三选一）
- （可选）是否需要 API 调测能力，以及鉴权策略（`none|token|login|openapi`）

同时，智能体应根据探测线索自动补齐 `components.nacos` / `components.db` 的最小骨架（不写敏感值），并通过 AskUserQuestion 询问用户是否启用对应插件。

智能体将最终确认后的完整答案落盘为：`{project_root}/.tmp/remote-debug-setup/answers.full.json`

> 若探测未识别到任何候选服务，智能体必须创建一个占位服务 `svc-main`，并通过 AskUserQuestion 让用户手工补齐该服务的启停/日志/模式。

强约束（避免误生成）：
- 禁止在未逐服务完成 Q7 AskUserQuestion 确认前，人工“裁剪候选服务列表”来追求配置干净。
- 即便草稿服务的 script.start/stop/check 是 TODO 占位，也必须先通过 Q7 决定是否纳入，并把命令补齐为真实可执行的启停/检查方式。

### Step 4：生成 remote 调试套件（智能体执行）

智能体执行生成器：

- 默认只写 `.secrets/dev-servers.example.yaml`（脱敏示例）
- 只有在用户明确授权后，才加 `--write-secrets` 写入 `.secrets/dev-servers.yaml`（实配，含敏感值）
- 若目标项目存在冲突路径，必须 AskUserQuestion 询问是否使用 `--force` 覆盖，并说明会先备份到 `.tmp/remote-debug-setup/backup/`。

## 重要约束（实现一致性）

1. `answers.full.json` 必须通过严格校验（例如 `services[].service_id` 必填）。生成器会在开始阶段执行严格校验，不通过则直接失败。
2. 插件仅对“模板目录实际存在”的插件生效（当前默认：`nacos`、`db`、`kafka`、`es`）。未知 `components.<key>.enabled=true` 会输出 `[WARN]` 并跳过，不会生成对应插件技能。

## 自检（不连接远端）

生成后建议在目标项目根目录执行：

```bash
bash .codex/skills/remote-dev-deploy/scripts/probe_remote.sh --help
bash .codex/skills/remote-dev-deploy/scripts/deploy_remote.sh --help
bash .codex/skills/remote-api-debug/scripts/api_debug.sh --help
bash .codex/skills/remote-log-diagnose/scripts/log_diagnose.sh --help
python3 .codex/skills/remote-dev-debug/scripts/debug_loop.py --help
```

> 在 Codex UI 中同样应由智能体执行上述自检命令，并将关键输出摘要反馈给用户。
