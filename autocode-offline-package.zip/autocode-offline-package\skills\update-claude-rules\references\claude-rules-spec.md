# Claude Rules 格式规范

本文档基于 Claude Code 官方文档，说明 `.claude/rules/` 目录下规则文件的格式要求和最佳实践。

**官方文档来源**：https://code.claude.com/docs/zh-CN/memory#claude-rules

## 基本结构

### 目录组织

```
your-project/
├── .claude/
│   ├── CLAUDE.md           # 主项目说明
│   └── rules/
│       ├── code-style.md   # 代码风格指南
│       ├── testing.md      # 测试约定
│       └── security.md     # 安全要求
```

`.claude/rules/` 中的所有 `.md` 文件都会自动加载为项目内存，优先级与 `.claude/CLAUDE.md` 相同。

### 规则文件格式

规则文件使用 Markdown 格式，可以包含可选的 YAML frontmatter：

```markdown
---
paths: src/api/**/*.ts
---

# API Development Rules

- All API endpoints must include input validation
- Use the standard error response format
- Include OpenAPI documentation comments
```

## YAML Frontmatter

### paths 字段

`paths` 字段用于指定规则适用的文件模式。使用标准 glob 语法。

**基本语法**：
```yaml
---
paths: src/**/*.ts
---
```

**多个模式（逗号分隔）**：
```yaml
---
paths: src/**/*.ts, tests/**/*.test.ts
---
```

**多个模式（大括号语法）**：
```yaml
---
paths: src/**/*.{ts,tsx}
---
```

**复杂组合**：
```yaml
---
paths: {src,lib}/**/*.ts, tests/**/*.test.ts
---
```

### 无条件规则

没有 `paths` 字段的规则会无条件加载，适用于所有文件：

```markdown
---
# 无 paths 字段
---

# General Coding Standards

这些规则适用于所有代码文件。
```

## Glob 模式语法

### 基本模式

| 模式 | 匹配 | 示例 |
|-----|------|------|
| `**/*.ts` | 任何目录中的所有 TypeScript 文件 | `src/app.ts`, `lib/utils/helper.ts` |
| `src/**/*` | `src/` 目录下的所有文件 | `src/index.js`, `src/components/Button.tsx` |
| `*.md` | 项目根目录中的 Markdown 文件 | `README.md`, `CHANGELOG.md` |
| `src/components/*.tsx` | 特定目录中的 React 组件 | `src/components/Button.tsx` |

### 通配符说明

- `*` - 匹配单个目录层级中的任意字符（不包括 `/`）
- `**` - 匹配任意数量的目录层级
- `?` - 匹配单个字符
- `[abc]` - 匹配方括号中的任意一个字符
- `{a,b}` - 匹配大括号中的任意一个模式

### 常用模式示例

**前端文件**：
```yaml
paths: src/**/*.{ts,tsx,js,jsx,vue}
```

**后端文件**：
```yaml
paths: src/**/*.{java,py,go,rs}
```

**测试文件**：
```yaml
paths: {tests/**/*,**/*.test.*,**/*.spec.*}
```

**API 文件**：
```yaml
paths: src/api/**/*
```

**样式文件**：
```yaml
paths: **/*.{css,scss,less,sass}
```

## 规则文件组织

### 按主题组织

推荐按照开发主题组织规则文件：

```
.claude/rules/
├── code-style.md      # 代码风格
├── testing.md         # 测试约定
├── security.md        # 安全要求
├── api-design.md      # API 设计
└── documentation.md   # 文档规范
```

### 使用子目录

对于大型项目，可以使用子目录组织：

```
.claude/rules/
├── frontend/
│   ├── react.md
│   └── styles.md
├── backend/
│   ├── api.md
│   └── database.md
└── general.md
```

所有 `.md` 文件都会被递归发现。

### 特定于路径的规则

使用 `paths` 字段将规则限定到特定文件：

```markdown
---
paths: src/api/**/*.ts
---

# API Development Rules

这些规则仅在处理 src/api/ 目录下的 TypeScript 文件时生效。
```

## 最佳实践

### 1. 保持规则专注

每个文件应涵盖一个主题：
- ✅ `testing.md` - 专注于测试约定
- ✅ `api-design.md` - 专注于 API 设计
- ❌ `everything.md` - 包含所有规则

### 2. 使用描述性文件名

文件名应清楚指示规则涵盖的内容：
- ✅ `react-component-guidelines.md`
- ✅ `database-migration-rules.md`
- ❌ `rules1.md`
- ❌ `misc.md`

### 3. 谨慎使用条件规则

仅在规则确实适用于特定文件类型时添加 `paths` frontmatter：
- ✅ TypeScript 规则 → `paths: **/*.{ts,tsx}`
- ✅ API 规则 → `paths: src/api/**/*`
- ❌ 通用编码规范 → 不添加 `paths`

### 4. 使用子目录组织

分组相关规则以提高可维护性：
```
.claude/rules/
├── frontend/        # 前端相关规则
├── backend/         # 后端相关规则
└── testing/         # 测试相关规则
```

### 5. 保持规则简洁

规则应该清晰、具体、可执行：
- ✅ "使用 2 空格缩进"
- ✅ "所有 API 端点必须包含输入验证"
- ❌ "写好代码"
- ❌ "遵循最佳实践"

## 规则加载机制

### 加载顺序

1. 用户级规则（`~/.claude/rules/`）
2. 项目级规则（`./.claude/rules/`）
3. 项目主配置（`./.claude/CLAUDE.md`）

项目规则具有更高的优先级。

### 条件加载

带有 `paths` 字段的规则仅在 Claude 处理匹配的文件时加载：
- 处理 `src/api/users.ts` → 加载 `paths: src/api/**/*.ts` 的规则
- 处理 `README.md` → 不加载上述规则

### 验证规则加载

使用 `/memory` 命令查看当前加载的规则文件：
```bash
/memory
```

## 常见错误和解决方案

### 错误 1: YAML 格式错误

❌ 错误：
```yaml
---
paths:src/**/*.ts
---
```

✅ 正确：
```yaml
---
paths: src/**/*.ts
---
```

注意：冒号后面必须有空格。

### 错误 2: Glob 模式错误

❌ 错误：
```yaml
paths: src/*.ts  # 只匹配 src/ 直接子文件
```

✅ 正确：
```yaml
paths: src/**/*.ts  # 匹配 src/ 下所有 TypeScript 文件
```

### 错误 3: 规则过于宽泛

❌ 错误：
```yaml
paths: **/*  # 匹配所有文件
```

✅ 正确：
```yaml
paths: src/**/*.{ts,tsx}  # 仅匹配相关文件
```

## 示例规则文件

### 示例 1: TypeScript 代码风格

```markdown
---
paths: **/*.{ts,tsx}
---

# TypeScript Code Style

- 使用 2 空格缩进
- 使用单引号而非双引号
- 接口名称使用 PascalCase
- 函数名称使用 camelCase
- 避免使用 `any` 类型
```

### 示例 2: API 设计规范

```markdown
---
paths: src/api/**/*
---

# API Design Guidelines

- 所有端点必须包含输入验证
- 使用标准的错误响应格式
- 包含 OpenAPI 文档注释
- 遵循 RESTful 设计原则
```

### 示例 3: 测试约定

```markdown
---
paths: {tests/**/*,**/*.test.*,**/*.spec.*}
---

# Testing Conventions

- 每个功能必须有对应的单元测试
- 测试文件命名：`*.test.ts` 或 `*.spec.ts`
- 使用描述性的测试名称
- 遵循 AAA 模式（Arrange, Act, Assert）
```

### 示例 4: 通用安全规范

```markdown
---
# 无 paths 字段，适用于所有文件
---

# Security Requirements

- 永远不要在代码中硬编码密钥或密码
- 所有用户输入必须经过验证和清理
- 使用参数化查询防止 SQL 注入
- 实施适当的访问控制
```

## 参考资料

- [Claude Code 官方文档](https://code.claude.com/docs/zh-CN/memory)
- [Glob 模式语法](https://en.wikipedia.org/wiki/Glob_(programming))
