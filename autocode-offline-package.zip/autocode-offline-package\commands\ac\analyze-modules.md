---
name: analyze-modules
description: "识别项目的所有子模块（根据.gitmodules），对每个子模块调用module-analyzer进行完整的架构分析和规范提取"
category: workflow
---

# /analyze-modules - 项目子模块批量分析命令


## 核心原则

🔴 **完整性检查**
- 必须识别所有子模块，避免遗漏
- 每个子模块必须完整执行完整的分析流程
- 分析结果的一致性和完整性是目标

🟡 **智能跳过**
- 对于已完成分析的模块，根据进度判断自动跳过不必要的重复分析
- 对于未开始的模块，执行完整的分析流程
- 对于进行中的模块，执行增量分析

🟡 **人工审核**
- 完成后提醒人工审核
- 不要生成中间记录文档

## 工作流程

### Step 1. 前置检查
- 验证项目根目录有效性
- 检查 `.gitmodules` 文件是否存在
- 解析 `.gitmodules` 获取所有子模块列表

### Step 2. 子模块识别
- 从 `.gitmodules` 中读取所有子模块定义
- 验证每个子模块目录的有效性
- 建立子模块清单并排序

### Step 3. 批量模块分析
对每个子模块按顺序调用 `module-analyzer` ，传递模块{module}名称和位置
Spawn the module-analyzer agent:
```
Task(
  subagent_type="module-analyzer",
  prompt="模块分析

module: {module}
module_root: {module_root}

要求：在 {module_root} 作为工作目录执行分析（必要时先 cd 到该目录）。"
)
```

### Step 4. 进度跟踪
- 实时显示分析进度（第 N/M 个模块）
- 记录每个模块的分析状态和耗时
- 标记分析过程中的警告或错误

### Step 5. 汇总报告生成
- 生成项目级别的模块分析汇总报告
- 列出所有已分析的模块及其状态
- 记录任何跨模块的问题和建议
- 在控制台输出，禁止在项目目录下生成报告文档
