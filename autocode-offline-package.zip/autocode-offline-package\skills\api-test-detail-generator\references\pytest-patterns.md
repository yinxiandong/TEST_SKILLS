# pytest 最佳实践参考（API 测试）

本文档为 `api-test-detail-generator` 生成 pytest 脚本时的参考指南。

---

## 1. 项目结构

```
tests/api-test/scripts/
├── conftest.py              # 全局 fixture（鉴权、配置、客户端）
├── utils/
│   ├── __init__.py
│   ├── api_client.py        # httpx 客户端封装
│   ├── yaml_loader.py       # YAML 用例加载器
│   └── assertions.py        # 断言辅助函数
└── {module}/
    ├── __init__.py
    └── test_{feature}.py    # 测试脚本
```

---

## 2. httpx 客户端封装

```python
import httpx
import time
from typing import Optional

class APIClient:
    def __init__(self, base_url: str, default_headers: dict = None, timeout: float = 10.0):
        self.base_url = base_url.rstrip("/")
        self.default_headers = default_headers or {}
        self.client = httpx.Client(
            base_url=self.base_url,
            headers=self.default_headers,
            timeout=timeout,
            verify=False,
        )

    def request(self, method: str, path: str, **kwargs) -> httpx.Response:
        headers = {**self.default_headers, **kwargs.pop("headers", {})}
        start = time.monotonic()
        response = self.client.request(method, path, headers=headers, **kwargs)
        response.elapsed_total = time.monotonic() - start
        return response

    def close(self):
        self.client.close()
```

---

## 3. YAML 用例加载器

```python
import os
import re
import yaml
from pathlib import Path

# 内置变量生成器
def _builtin_vars() -> dict:
    import time, random, string
    return {
        "random_string": "".join(random.choices(string.ascii_lowercase, k=8)),
        "random_int": str(random.randint(1, 99999)),
        "timestamp": str(int(time.time())),
    }

def _resolve_placeholders(obj, variables: dict):
    """递归替换 {{variable}} 占位符"""
    if isinstance(obj, str):
        def replacer(match):
            var_name = match.group(1)
            return variables.get(var_name, match.group(0))
        return re.sub(r"\{\{(\w+)\}\}", replacer, obj)
    elif isinstance(obj, dict):
        return {k: _resolve_placeholders(v, variables) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [_resolve_placeholders(item, variables) for item in obj]
    return obj

def load_cases(yaml_path: str, extra_vars: dict = None) -> dict:
    """加载 YAML 用例并替换占位符变量
    变量来源优先级：extra_vars > 环境变量 > 内置变量
    """
    path = Path(yaml_path)
    if not path.exists():
        raise FileNotFoundError(f"YAML file not found: {yaml_path}")
    with open(path, "r", encoding="utf-8") as f:
        docs = list(yaml.safe_load_all(f))

    # 合并变量：内置 < 环境变量 < 显式传入
    variables = _builtin_vars()
    variables.update({k: v for k, v in os.environ.items() if k.startswith("API_TEST_")})
    # 常用环境变量映射为短名
    variables.setdefault("test_user", os.environ.get("API_TEST_USER", ""))
    variables.setdefault("test_password", os.environ.get("API_TEST_PASSWORD", ""))
    variables.setdefault("auth_token", os.environ.get("API_TEST_TOKEN", ""))
    variables.setdefault("base_url", os.environ.get("API_TEST_BASE_URL", ""))
    if extra_vars:
        variables.update(extra_vars)

    cases = {}
    for doc in docs:
        if doc:
            resolved = _resolve_placeholders(doc, variables)
            cases[resolved["case_id"]] = resolved
    return cases
```

---

## 4. 断言辅助函数

```python
import jsonpath_ng
from httpx import Response

def assert_response(response: Response, expected: dict):
    # 状态码断言
    if "status_code" in expected:
        assert response.status_code == expected["status_code"], \
            f"Expected {expected['status_code']}, got {response.status_code}: {response.text}"

    # 响应时间断言
    max_time = expected.get("response_time_ms", 0)
    if max_time > 0:
        elapsed_ms = getattr(response, "elapsed_total", 0) * 1000
        assert elapsed_ms < max_time, \
            f"Response too slow: {elapsed_ms:.0f}ms > {max_time}ms"

    # JSONPath 断言
    for assertion in expected.get("assertions", []):
        if assertion["type"] == "json_path":
            _assert_json_path(response.json(), assertion)
        elif assertion["type"] == "header":
            _assert_header(response, assertion)

def _assert_json_path(data: dict, assertion: dict):
    expr = jsonpath_ng.parse(assertion["path"])
    matches = [m.value for m in expr.find(data)]
    condition = assertion["condition"]

    if condition == "exists":
        assert len(matches) > 0, f"JSONPath {assertion['path']} not found"
    elif condition == "not_empty":
        assert len(matches) > 0 and matches[0], f"JSONPath {assertion['path']} is empty"
    elif condition == "equals":
        assert matches[0] == assertion["value"], \
            f"Expected {assertion['value']}, got {matches[0]}"
    elif condition == "contains":
        assert assertion["value"] in str(matches[0])
    elif condition == "gt":
        assert matches[0] > assertion["value"]
    elif condition == "lt":
        assert matches[0] < assertion["value"]
    elif condition == "type_is":
        type_map = {"string": str, "int": int, "float": float, "bool": bool, "list": list, "dict": dict}
        assert isinstance(matches[0], type_map[assertion["value"]])

def _assert_header(response: Response, assertion: dict):
    header_value = response.headers.get(assertion["path"])
    condition = assertion["condition"]
    if condition == "exists":
        assert header_value is not None
    elif condition == "equals":
        assert header_value == assertion["value"]
    elif condition == "contains":
        assert assertion["value"] in header_value
```

---

## 5. pytest 标记使用

```python
# 按级别运行
pytest -m P0                          # 仅 P0
pytest -m "P0 or P1"                  # P0 + P1

# 按覆盖类型运行
pytest -m smoke                       # 冒烟测试
pytest -m security                    # 安全测试
pytest -m boundary                    # 边界值测试

# 按模块运行
pytest tests/api-test/scripts/auth/   # 仅 auth 模块

# 组合筛选
pytest -m "P0 and positive"           # P0 正向用例
pytest -m "security and not P3"       # 非 P3 安全用例
```

---

## 6. 依赖包

```
httpx>=0.27.0
pytest>=8.0.0
pyyaml>=6.0
jsonpath-ng>=1.6.0
jinja2>=3.1.0
```
