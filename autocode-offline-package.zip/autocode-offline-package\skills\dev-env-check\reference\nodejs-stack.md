# Node.js/Web 技术栈检查参考

> 本文档是 dev-env-check 技能的参考文档，包含 Node.js/Web 技术栈的详细检查流程。

## 识别特征

| 配置文件 | 说明 |
|----------|------|
| `package.json` | Node.js/Web 项目 |
| `package-lock.json` | npm 锁定文件 |
| `yarn.lock` | Yarn 锁定文件 |
| `pnpm-lock.yaml` | pnpm 锁定文件 |

## 检查项

- Node.js 版本
- npm 或 yarn/pnpm 版本
- 全局工具包（如 webpack、vue-cli 等）
- engines 版本要求

## 检查命令

```bash
# 检查 Node.js 版本
node -v 2>&1

# 检查 npm 版本
npm -v 2>&1

# 检查 yarn（如果使用）
yarn -v 2>&1

# 检查 pnpm（如果使用）
pnpm -v 2>&1

# 检查 package.json 的 engines 要求
cat package.json | grep -A 5 '"engines"' 2>/dev/null

# 检查全局安装的包
npm list -g --depth=0 2>/dev/null
```

## 版本要求提取

从 `package.json` 的 `engines` 字段提取：

```json
{
  "engines": {
    "node": ">=18.0.0",
    "npm": ">=9.0.0"
  }
}
```

提取命令：
```bash
# 提取 Node.js 版本要求
cat package.json | jq -r '.engines.node // "未指定"'

# 提取 npm 版本要求
cat package.json | jq -r '.engines.npm // "未指定"'
```

## 期望结果

- Node.js 版本符合 package.json 的 engines 要求
- npm/yarn/pnpm 可正常执行
- 必要的全局工具已安装

## 包管理器识别

根据锁定文件识别使用的包管理器：

| 锁定文件 | 包管理器 | 安装命令 | 构建命令 |
|----------|----------|----------|----------|
| `package-lock.json` | npm | `npm install` | `npm run build` |
| `yarn.lock` | Yarn | `yarn install` | `yarn build` |
| `pnpm-lock.yaml` | pnpm | `pnpm install` | `pnpm build` |

## 构建命令

| 场景 | 构建命令 | 说明 |
|------|----------|------|
| 安装依赖并构建 | `npm install && npm run build` | 标准构建流程 |
| 仅安装 | `npm ci` | CI 环境推荐，严格按 lock 文件安装 |
| 开发模式 | `npm run dev` | 启动开发服务器 |

## 常见问题

### Node.js 版本不匹配

推荐使用 nvm 管理多个 Node.js 版本：

```bash
# 安装 nvm
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc

# 安装指定版本
nvm install 18
nvm install 20

# 切换版本
nvm use 18
nvm alias default 18

# 自动切换版本（项目根目录创建 .nvmrc）
echo "18" > .nvmrc
nvm use  # 自动读取 .nvmrc
```

### npm 镜像配置

国内环境建议配置镜像：

```bash
# 配置淘宝镜像
npm config set registry https://registry.npmmirror.com

# 验证配置
npm config get registry

# 或使用 nrm 管理多个镜像
npm install -g nrm
nrm use taobao
```

### 依赖安装失败

```bash
# 清理缓存
npm cache clean --force

# 删除 node_modules 重新安装
rm -rf node_modules package-lock.json
npm install

# 跳过可选依赖
npm install --ignore-optional

# 使用淘宝二进制镜像（解决 node-sass 等问题）
npm config set sass_binary_site https://npmmirror.com/mirrors/node-sass
```

### 全局包权限问题

```bash
# 方案1：配置 npm 全局目录
mkdir ~/.npm-global
npm config set prefix '~/.npm-global'
echo 'export PATH=~/.npm-global/bin:$PATH' >> ~/.bashrc
source ~/.bashrc

# 方案2：使用 nvm（推荐）
# nvm 安装的 Node.js 自动处理权限问题
```

## 常用全局工具

```bash
# 脚手架工具
npm install -g @vue/cli        # Vue CLI
npm install -g create-react-app # Create React App
npm install -g @angular/cli    # Angular CLI
npm install -g create-next-app # Next.js

# 构建工具
npm install -g webpack webpack-cli
npm install -g vite
npm install -g typescript

# 开发工具
npm install -g nodemon         # 自动重启
npm install -g pm2             # 进程管理
npm install -g serve           # 静态文件服务
```

## 安装方式

### 包管理器

```bash
# Ubuntu/Debian
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# macOS
brew install node@18

# Windows
choco install nodejs-lts
```

### 推荐方式 - nvm

```bash
# Linux/macOS
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install --lts
nvm use --lts

# Windows - 使用 nvm-windows
# 下载: https://github.com/coreybutler/nvm-windows/releases
```

## 官方文档

- Node.js: https://nodejs.org/docs/
- npm: https://docs.npmjs.com/
- Yarn: https://yarnpkg.com/getting-started
- pnpm: https://pnpm.io/installation
- nvm: https://github.com/nvm-sh/nvm
