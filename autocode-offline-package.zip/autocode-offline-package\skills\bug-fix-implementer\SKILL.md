---
name: bug-fix-implementer
description: 按根因修复方案执行代码修复、控制改动边界并输出修复实施记录。Use when RCA and fix plan are ready and implementation changes must be applied safely.
---

# Bug Fix Implementer

根据 `10-根因修复与同类排查.md` 执行修复，并产出实施记录。

## 输入

- `bug_id`
- `docs/bugfix/{bug_id}/10-根因修复与同类排查.md`
- 代码规范：`.claude/rules/**`

## 输出

- `docs/bugfix/{bug_id}/20-修复实施记录.md`

## 模板引用

- `references/20-fix-record-template.md`

## 执行规则

1. 仅在方案边界内修复，不做无关重构。
2. 修复记录必须注明：改动文件、改动原因、影响范围、回滚方式。
3. 若实现与方案偏差，必须在实施记录中写明偏差与原因。
4. **前端修复要求**：涉及前端页面、组件、样式的修复，应调用 `ui-ux-pro-max` 技能确保 UI 修复质量符合设计规范。
