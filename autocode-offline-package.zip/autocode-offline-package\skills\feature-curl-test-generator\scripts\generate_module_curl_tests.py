#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import shlex
import subprocess
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Sequence, Tuple
from urllib.parse import urlencode


PATH_PARAM_SAMPLES = {
    "id": "1",
    "traceid": "trace-001",
    "sessionid": "session-001",
    "fileid": "file-001",
    "hostid": "1",
    "param": "sample-param",
    "namespace": "public",
    "group": "DEFAULT_GROUP",
    "dataid": "sample-data-id",
}


@dataclass
class ParamSpec:
    name: str
    ptype: str
    location: str
    required: bool


@dataclass
class Endpoint:
    feature: str
    method: str
    path: str
    desc: str
    auth_required: bool
    required_params: List[ParamSpec] = field(default_factory=list)


@dataclass
class ModuleMeta:
    slug: str
    title: str
    display_name: str
    file_path: Path
    aliases: List[str]


@dataclass
class Case:
    case_id: str
    title: str
    method: str
    path: str
    query: str
    body_type: str
    body: str
    auth_mode: str
    expected: str


def normalize_alias(text: str) -> str:
    value = (text or "").strip().lower()
    value = re.sub(r"[`'\"“”‘’]", "", value)
    value = re.sub(r"[\s_\-]+", "", value)
    value = re.sub(r"[^0-9a-z\u4e00-\u9fff]", "", value)
    return value


def clean_title(title: str) -> str:
    name = title.strip()
    for suffix in ("模块功能清单", "功能清单", "模块清单", "清单"):
        if name.endswith(suffix):
            name = name[: -len(suffix)].strip()
            break
    return name


def strip_backticks(value: str) -> str:
    text = value.strip()
    if text.startswith("`") and text.endswith("`") and len(text) >= 2:
        text = text[1:-1].strip()
    return text


def split_md_row(line: str) -> List[str]:
    body = line.strip().strip("|")
    return [part.strip() for part in body.split("|")]


def is_table_line(line: str) -> bool:
    s = line.strip()
    return s.startswith("|") and s.endswith("|")


def is_separator_row(cells: Sequence[str]) -> bool:
    if not cells:
        return False
    for c in cells:
        if not re.fullmatch(r":?-{2,}:?", c.replace(" ", "")):
            return False
    return True


def parse_markdown_table(lines: Sequence[str], start_idx: int) -> Tuple[List[str], List[List[str]], int]:
    if start_idx >= len(lines) or not is_table_line(lines[start_idx]):
        return [], [], start_idx

    headers = split_md_row(lines[start_idx])
    i = start_idx + 1
    if i < len(lines) and is_table_line(lines[i]):
        maybe_sep = split_md_row(lines[i])
        if is_separator_row(maybe_sep):
            i += 1

    rows: List[List[str]] = []
    while i < len(lines) and is_table_line(lines[i]):
        row = split_md_row(lines[i])
        if len(row) < len(headers):
            row = row + [""] * (len(headers) - len(row))
        elif len(row) > len(headers):
            row = row[: len(headers)]
        rows.append(row)
        i += 1
    return headers, rows, i


def detect_location(text: str, fallback: str) -> str:
    s = text.lower()
    if "路径参数" in text:
        return "path"
    if "query" in s:
        return "query"
    if "form" in s:
        return "form"
    if "json" in s or "请求体" in text:
        return "json"
    return fallback


def required_flag(value: str) -> bool:
    text = value.strip().lower()
    if not text:
        return False
    if "否" in text and "required" not in text and "条件" not in text:
        return False
    if "是" in text:
        return True
    if "required" in text:
        return True
    if "条件" in text:
        return True
    return False


def split_methods(value: str) -> List[str]:
    methods = re.findall(r"[A-Za-z]+", value.upper())
    unique: List[str] = []
    for m in methods:
        if m not in unique:
            unique.append(m)
    return unique or ["GET"]


def split_alias_text(value: str) -> List[str]:
    if not value:
        return []
    text = strip_backticks(value.strip())
    for sep in ("、", "，", ";", "；"):
        text = text.replace(sep, ",")
    parts = [part.strip() for part in text.split(",")]
    return [part for part in parts if part]


def load_aliases_file(file_path: Path | None) -> Dict[str, List[str]]:
    if file_path is None:
        return {}
    if not file_path.exists():
        raise FileNotFoundError(f"别名文件不存在: {file_path}")

    alias_map: Dict[str, List[str]] = {}
    lines = file_path.read_text(encoding="utf-8").splitlines()

    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if is_table_line(line):
            headers, rows, next_idx = parse_markdown_table(lines, i)
            header_map = {strip_backticks(h).strip().lower(): idx for idx, h in enumerate(headers)}
            slug_idx = header_map.get("slug")
            if slug_idx is not None:
                name_idx = header_map.get("中文模块名（常用）")
                if name_idx is None:
                    name_idx = header_map.get("中文模块名")
                aliases_idx = header_map.get("常用别名示例")
                if aliases_idx is None:
                    aliases_idx = header_map.get("aliases")
                for row in rows:
                    slug = strip_backticks(row[slug_idx]).strip()
                    if not slug:
                        continue
                    values: List[str] = []
                    if name_idx is not None and name_idx < len(row):
                        values.extend(split_alias_text(row[name_idx]))
                    if aliases_idx is not None and aliases_idx < len(row):
                        values.extend(split_alias_text(row[aliases_idx]))
                    if values:
                        alias_map.setdefault(slug, []).extend(values)
            i = next_idx
            continue

        if line and not line.startswith("#") and ":" in line:
            slug, raw_aliases = line.split(":", 1)
            slug = strip_backticks(slug).strip()
            if slug:
                alias_map.setdefault(slug, []).extend(split_alias_text(raw_aliases))
        i += 1

    deduped: Dict[str, List[str]] = {}
    for slug, aliases in alias_map.items():
        seen = set()
        ordered: List[str] = []
        for alias in aliases:
            key = normalize_alias(alias)
            if not key or key in seen:
                continue
            seen.add(key)
            ordered.append(alias)
        if ordered:
            deduped[slug] = ordered
    return deduped


def extract_modules(feature_dir: Path, extra_aliases: Dict[str, List[str]] | None = None) -> List[ModuleMeta]:
    extra_aliases = extra_aliases or {}
    result: List[ModuleMeta] = []
    for md in sorted(feature_dir.glob("*.md")):
        lines = md.read_text(encoding="utf-8").splitlines()
        title = md.stem
        for line in lines:
            s = line.strip()
            if s.startswith("# "):
                title = s[2:].strip()
                break
        display_name = clean_title(title)
        slug = md.stem
        aliases = {
            slug,
            slug.replace("-", ""),
            slug.replace("-", "_"),
            title,
            display_name,
        }
        aliases.update(extra_aliases.get(slug, []))
        result.append(
            ModuleMeta(
                slug=slug,
                title=title,
                display_name=display_name,
                file_path=md,
                aliases=sorted(a for a in aliases if a.strip()),
            )
        )
    return result


def resolve_module(modules: Sequence[ModuleMeta], module_input: str) -> ModuleMeta:
    normalized = normalize_alias(module_input)
    if not normalized:
        raise ValueError("模块参数不能为空")

    matches: List[ModuleMeta] = []
    for module in modules:
        alias_set = {normalize_alias(alias) for alias in module.aliases}
        if normalized in alias_set:
            matches.append(module)

    if not matches:
        candidates = ", ".join(m.slug for m in modules)
        raise ValueError(f"未找到模块: {module_input}。可用模块: {candidates}")

    if len(matches) == 1:
        return matches[0]

    for m in matches:
        if normalized == normalize_alias(m.slug):
            return m
    names = ", ".join(m.slug for m in matches)
    raise ValueError(f"模块别名存在歧义: {module_input} -> {names}")


def parse_feature_file(file_path: Path) -> List[Endpoint]:
    lines = file_path.read_text(encoding="utf-8").splitlines()
    endpoints: List[Endpoint] = []
    detail_map: Dict[Tuple[str, str], List[ParamSpec]] = {}

    # 解析接口列表
    i = 0
    while i < len(lines):
        if lines[i].strip() == "### 接口列表":
            j = i + 1
            while j < len(lines) and not is_table_line(lines[j]):
                if lines[j].strip().startswith("### "):
                    break
                j += 1
            if j < len(lines) and is_table_line(lines[j]):
                headers, rows, next_idx = parse_markdown_table(lines, j)
                header_map = {h.strip(): idx for idx, h in enumerate(headers)}
                for row in rows:
                    api = strip_backticks(row[header_map["API"]]) if "API" in header_map else ""
                    method_text = row[header_map["方法"]] if "方法" in header_map else "GET"
                    feature = row[header_map["功能"]] if "功能" in header_map else ""
                    desc = row[header_map["说明"]] if "说明" in header_map else ""
                    auth_text = row[header_map["认证"]] if "认证" in header_map else ""
                    if not api:
                        continue
                    api = strip_backticks(api)
                    methods = split_methods(method_text)
                    auth_required = True
                    if auth_text and ("否" in auth_text or "no" in auth_text.lower()):
                        auth_required = False
                    if "免认证" in desc or "无需认证" in desc:
                        auth_required = False
                    for method in methods:
                        endpoints.append(
                            Endpoint(
                                feature=feature.strip(),
                                method=method.strip().upper(),
                                path=api.strip(),
                                desc=desc.strip(),
                                auth_required=auth_required,
                            )
                        )
                i = next_idx
                continue
        i += 1

    # 解析接口详情中的参数定义
    i = 0
    while i < len(lines):
        match = re.match(r"^####\s+([A-Z]+)\s+(\S+)", lines[i].strip())
        if not match:
            i += 1
            continue
        method = match.group(1).upper()
        path = match.group(2).strip()
        params: List[ParamSpec] = []
        current_location = "query" if method in ("GET", "DELETE") else "json"
        i += 1
        while i < len(lines):
            s = lines[i].strip()
            if s.startswith("#### ") or s.startswith("### "):
                break
            if s:
                current_location = detect_location(s, current_location)

            if is_table_line(lines[i]):
                headers, rows, next_idx = parse_markdown_table(lines, i)
                header_map = {h.strip(): idx for idx, h in enumerate(headers)}
                if "参数" in header_map:
                    for row in rows:
                        name = strip_backticks(row[header_map["参数"]])
                        if not name:
                            continue
                        required_text = row[header_map["必填"]] if "必填" in header_map else ""
                        required = required_flag(required_text)
                        ptype = row[header_map["类型"]] if "类型" in header_map else "string"
                        params.append(
                            ParamSpec(
                                name=name,
                                ptype=ptype.strip(),
                                location=current_location,
                                required=required,
                            )
                        )
                i = next_idx
                continue

            path_param_line = re.search(r"路径参数[:：](.*)", s)
            if path_param_line:
                tail = path_param_line.group(1)
                names = re.findall(r"`([^`]+)`", tail) or re.findall(r":([A-Za-z0-9_]+)", tail)
                for name in names:
                    params.append(ParamSpec(name=name, ptype="string", location="path", required=True))
            i += 1

        key = (method, path)
        if key not in detail_map:
            detail_map[key] = []
        detail_map[key].extend(params)

    # 合并接口列表和详情参数
    merged: List[Endpoint] = []
    for ep in endpoints:
        detail_params = list(detail_map.get((ep.method, ep.path), []))
        for name in re.findall(r":([A-Za-z0-9_]+)", ep.path):
            detail_params.append(ParamSpec(name=name, ptype="string", location="path", required=True))

        # 去重：同名参数优先保留 required=true
        unique: Dict[Tuple[str, str], ParamSpec] = {}
        for p in detail_params:
            key = (p.name, p.location)
            existing = unique.get(key)
            if existing is None or (not existing.required and p.required):
                unique[key] = p
        ep.required_params = sorted(unique.values(), key=lambda x: (x.location, x.name))
        merged.append(ep)

    return merged


def sample_value(param: ParamSpec):
    name = param.name.lower()
    ptype = param.ptype.lower()
    if "file" in ptype or ("file" in name and param.location == "form"):
        return "@__AUTO_FILE__"
    if "bool" in ptype:
        return True
    if "[]" in ptype or "array" in ptype:
        return ["sample-1"]
    if "int" in ptype or "float" in ptype or "double" in ptype:
        if "port" in name:
            return 6050
        if "page" in name and "size" in name:
            return 10
        if "page" in name:
            return 1
        return 1
    if "time" in name or "date" in name:
        return "2026-01-01 00:00:00"
    if "ip" in name:
        return "127.0.0.1"
    if "trace" in name:
        return "trace-001"
    if "token" in name:
        return "sample-token"
    if "name" in name:
        return "sample-name"
    return "sample"


def path_param_sample(name: str) -> str:
    normalized = name.lower()
    if normalized in PATH_PARAM_SAMPLES:
        return PATH_PARAM_SAMPLES[normalized]
    if normalized.endswith("id") or normalized == "id":
        return "1"
    return "sample"


def build_request_parts(endpoint: Endpoint) -> Tuple[str, str, str]:
    query: Dict[str, object] = {}
    json_body: Dict[str, object] = {}
    form_parts: List[str] = []

    for param in endpoint.required_params:
        if not param.required:
            continue
        if param.location == "path":
            continue
        value = sample_value(param)
        location = param.location
        if location == "query":
            query[param.name] = value
        elif location == "form":
            form_parts.append(f"{param.name}={value}")
        elif location == "json":
            json_body[param.name] = value
        else:
            if endpoint.method in ("GET", "DELETE"):
                query[param.name] = value
            else:
                json_body[param.name] = value

    if endpoint.method in ("GET", "DELETE") and json_body and not query:
        query.update(json_body)
        json_body = {}

    query_str = urlencode(query, doseq=True)
    if form_parts:
        return query_str, "form", ";;".join(form_parts)
    if json_body:
        return query_str, "json", json.dumps(json_body, ensure_ascii=False)
    return query_str, "none", ""


def remove_required_field(endpoint: Endpoint, body_type: str, body: str, query: str) -> Tuple[str, str, str, str]:
    req_candidates = [p for p in endpoint.required_params if p.required and p.location != "path"]
    if not req_candidates:
        return "", body_type, body, query

    target = req_candidates[0]
    target_name = target.name

    if body_type == "json" and body:
        data = json.loads(body)
        data.pop(target_name, None)
        return target_name, "json", json.dumps(data, ensure_ascii=False), query

    if body_type == "form" and body:
        parts = [x for x in body.split(";;") if x]
        filtered = [x for x in parts if not x.startswith(f"{target_name}=")]
        return target_name, "form", ";;".join(filtered), query

    if query:
        pairs = [seg for seg in query.split("&") if seg]
        filtered = [seg for seg in pairs if not seg.startswith(f"{target_name}=")]
        return target_name, body_type, body, "&".join(filtered)

    return target_name, body_type, body, query


def build_cases(module: ModuleMeta, endpoints: Sequence[Endpoint]) -> List[Case]:
    cases: List[Case] = []
    for idx, ep in enumerate(endpoints, start=1):
        path = re.sub(r":([A-Za-z0-9_]+)", lambda m: path_param_sample(m.group(1)), ep.path)
        query, body_type, body = build_request_parts(ep)
        prefix = f"{module.slug.upper().replace('-', '_')}-{idx:03d}"

        title_base = ep.feature or ep.desc or f"{ep.method} {ep.path}"

        cases.append(
            Case(
                case_id=f"{prefix}-P",
                title=f"{title_base}-正向",
                method=ep.method,
                path=path,
                query=query,
                body_type=body_type,
                body=body,
                auth_mode="required" if ep.auth_required else "none",
                expected="2xx",
            )
        )

        missing_param_name, m_body_type, m_body, m_query = remove_required_field(ep, body_type, body, query)
        if missing_param_name:
            cases.append(
                Case(
                    case_id=f"{prefix}-R",
                    title=f"{title_base}-缺少必填参数({missing_param_name})",
                    method=ep.method,
                    path=path,
                    query=m_query,
                    body_type=m_body_type,
                    body=m_body,
                    auth_mode="required" if ep.auth_required else "none",
                    expected="400|422",
                )
            )

        if ep.auth_required:
            cases.append(
                Case(
                    case_id=f"{prefix}-A",
                    title=f"{title_base}-缺少APIKey",
                    method=ep.method,
                    path=path,
                    query=query,
                    body_type=body_type,
                    body=body,
                    auth_mode="none",
                    expected="401|403",
                )
            )

    return cases


def sh(value: str) -> str:
    return shlex.quote(value)


def render_curl_script(module: ModuleMeta, cases: Sequence[Case], base_url: str, api_key_header: str, api_key: str) -> str:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines: List[str] = []
    lines.append("#!/usr/bin/env bash")
    lines.append("set -u")
    lines.append("")
    lines.append(f"# 自动生成: {module.slug} ({module.display_name})")
    lines.append(f"# 生成时间: {now}")
    lines.append("")
    lines.append('SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"')
    lines.append(f'BASE_URL="${{BASE_URL:-{base_url}}}"')
    lines.append(f'API_KEY_HEADER="${{API_KEY_HEADER:-{api_key_header}}}"')
    lines.append(f'API_KEY="${{API_KEY:-{api_key}}}"')
    lines.append('REPORT_FILE="${REPORT_FILE:-${SCRIPT_DIR}/last-run-report.md}"')
    lines.append('MODULE_SLUG="${MODULE_SLUG:-' + module.slug + '}"')
    lines.append('MODULE_NAME="${MODULE_NAME:-' + module.display_name + '}"')
    lines.append("")
    lines.append('TMP_DIR="$(mktemp -d)"')
    lines.append('SAMPLE_FILE="${TMP_DIR}/sample-upload.txt"')
    lines.append('printf "sample upload content\\n" > "${SAMPLE_FILE}"')
    lines.append("TOTAL_CNT=0")
    lines.append("PASS_CNT=0")
    lines.append("FAIL_CNT=0")
    lines.append("")
    lines.append("cleanup() {")
    lines.append('  rm -rf "${TMP_DIR}"')
    lines.append("}")
    lines.append("trap cleanup EXIT")
    lines.append("")
    lines.append("mask_value() {")
    lines.append('  local value="$1"')
    lines.append('  local len="${#value}"')
    lines.append('  if (( len == 0 )); then')
    lines.append("    printf '<empty>'")
    lines.append("    return")
    lines.append("  fi")
    lines.append('  if (( len <= 8 )); then')
    lines.append("    printf '****'")
    lines.append("    return")
    lines.append("  fi")
    lines.append('  printf "%s****%s" "${value:0:4}" "${value: -4}"')
    lines.append("}")
    lines.append("")
    lines.append("status_match() {")
    lines.append('  local status="$1"')
    lines.append('  local expected="$2"')
    lines.append('  if [[ "${expected}" == "2xx" ]]; then')
    lines.append('    [[ "${status}" =~ ^2[0-9][0-9]$ ]]')
    lines.append("    return $?")
    lines.append("  fi")
    lines.append('  IFS="|" read -r -a codes <<< "${expected}"')
    lines.append('  local c')
    lines.append('  for c in "${codes[@]}"; do')
    lines.append('    if [[ "${status}" == "${c}" ]]; then')
    lines.append("      return 0")
    lines.append("    fi")
    lines.append("  done")
    lines.append("  return 1")
    lines.append("}")
    lines.append("")
    lines.append("md_escape() {")
    lines.append('  local value="$1"')
    lines.append('  value="${value//|/\\\\|}"')
    lines.append('  value="${value//$\'\\n\'/<br/>}"')
    lines.append('  printf "%s" "${value}"')
    lines.append("}")
    lines.append("")
    lines.append("init_report() {")
    lines.append('  cat > "${REPORT_FILE}" <<EOF')
    lines.append("# 接口测试执行报告")
    lines.append("")
    lines.append("- 模块: ${MODULE_NAME} (${MODULE_SLUG})")
    lines.append("- 生成时间: " + now)
    lines.append("- BASE_URL: ${BASE_URL}")
    lines.append("- API_KEY_HEADER: ${API_KEY_HEADER}")
    lines.append("- API_KEY(masked): $(mask_value \"${API_KEY}\")")
    lines.append("")
    lines.append("| 用例ID | 场景 | 方法 | 路径 | 期望状态码 | 实际状态码 | 结果 |")
    lines.append("|---|---|---|---|---|---|---|")
    lines.append("EOF")
    lines.append("}")
    lines.append("")
    lines.append("run_case() {")
    lines.append('  local case_id="$1"')
    lines.append('  local title="$2"')
    lines.append('  local method="$3"')
    lines.append('  local path="$4"')
    lines.append('  local query="$5"')
    lines.append('  local body_type="$6"')
    lines.append('  local body="$7"')
    lines.append('  local auth_mode="$8"')
    lines.append('  local expected="$9"')
    lines.append("")
    lines.append("  TOTAL_CNT=$((TOTAL_CNT + 1))")
    lines.append('  local url="${BASE_URL%/}${path}"')
    lines.append('  if [[ -n "${query}" ]]; then')
    lines.append('    url="${url}?${query}"')
    lines.append("  fi")
    lines.append("")
    lines.append('  local resp_file="${TMP_DIR}/${case_id}.resp"')
    lines.append('  local err_file="${TMP_DIR}/${case_id}.err"')
    lines.append('  local status=""')
    lines.append('  local rc=0')
    lines.append("")
    lines.append('  local -a cmd=(curl -sS -k -X "${method}" "${url}" -o "${resp_file}" -w "%{http_code}")')
    lines.append('  if [[ "${auth_mode}" != "none" ]]; then')
    lines.append('    cmd+=(-H "${API_KEY_HEADER}: ${API_KEY}")')
    lines.append("  fi")
    lines.append("")
    lines.append('  if [[ "${body_type}" == "json" && -n "${body}" ]]; then')
    lines.append('    cmd+=(-H "Content-Type: application/json" --data-raw "${body}")')
    lines.append('  elif [[ "${body_type}" == "form" && -n "${body}" ]]; then')
    lines.append('    IFS=";;" read -r -a items <<< "${body}"')
    lines.append('    local item')
    lines.append('    for item in "${items[@]}"; do')
    lines.append('      [[ -z "${item}" ]] && continue')
    lines.append('      item="${item//__AUTO_FILE__/${SAMPLE_FILE}}"')
    lines.append('      cmd+=(-F "${item}")')
    lines.append("    done")
    lines.append("  fi")
    lines.append("")
    lines.append('  status="$("${cmd[@]}" 2>"${err_file}")" || rc=$?')
    lines.append('  local result="FAIL"')
    lines.append('  local actual="${status}"')
    lines.append('  if (( rc != 0 )); then')
    lines.append('    actual="curl-error(${rc})"')
    lines.append("  elif status_match \"${status}\" \"${expected}\"; then")
    lines.append('    result="PASS"')
    lines.append("  fi")
    lines.append("")
    lines.append('  if [[ "${result}" == "PASS" ]]; then')
    lines.append("    PASS_CNT=$((PASS_CNT + 1))")
    lines.append("  else")
    lines.append("    FAIL_CNT=$((FAIL_CNT + 1))")
    lines.append('    echo "[FAIL] ${case_id} ${title} => expected ${expected}, got ${actual}" >&2')
    lines.append('    if [[ -s "${err_file}" ]]; then')
    lines.append('      echo "  stderr: $(head -n 1 "${err_file}")" >&2')
    lines.append("    fi")
    lines.append("  fi")
    lines.append("")
    lines.append('  printf "| %s | %s | %s | %s | %s | %s | %s |\\n" \\')
    lines.append('    "$(md_escape "${case_id}")" \\')
    lines.append('    "$(md_escape "${title}")" \\')
    lines.append('    "$(md_escape "${method}")" \\')
    lines.append('    "$(md_escape "${path}")" \\')
    lines.append('    "$(md_escape "${expected}")" \\')
    lines.append('    "$(md_escape "${actual}")" \\')
    lines.append('    "$(md_escape "${result}")" >> "${REPORT_FILE}"')
    lines.append("}")
    lines.append("")
    lines.append("main() {")
    lines.append("  init_report")
    for case in cases:
        lines.append(
            "  run_case "
            + " ".join(
                [
                    sh(case.case_id),
                    sh(case.title),
                    sh(case.method),
                    sh(case.path),
                    sh(case.query),
                    sh(case.body_type),
                    sh(case.body),
                    sh(case.auth_mode),
                    sh(case.expected),
                ]
            )
        )
    lines.append("")
    lines.append('  echo "" >> "${REPORT_FILE}"')
    lines.append('  echo "## 汇总" >> "${REPORT_FILE}"')
    lines.append('  echo "- 总用例: ${TOTAL_CNT}" >> "${REPORT_FILE}"')
    lines.append('  echo "- 通过: ${PASS_CNT}" >> "${REPORT_FILE}"')
    lines.append('  echo "- 失败: ${FAIL_CNT}" >> "${REPORT_FILE}"')
    lines.append("")
    lines.append('  echo "执行完成: 总用例=${TOTAL_CNT}, 通过=${PASS_CNT}, 失败=${FAIL_CNT}"')
    lines.append('  echo "报告路径: ${REPORT_FILE}"')
    lines.append("")
    lines.append('  if (( FAIL_CNT > 0 )); then')
    lines.append("    return 1")
    lines.append("  fi")
    lines.append("  return 0")
    lines.append("}")
    lines.append("")
    lines.append("main \"$@\"")
    lines.append("")
    return "\n".join(lines)


def render_report_template(module: ModuleMeta, cases: Sequence[Case]) -> str:
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "# 模块接口测试报告模板",
        "",
        f"- 模块: {module.display_name} ({module.slug})",
        f"- 生成时间: {now}",
        "",
        "| 用例ID | 场景 | 方法 | 路径 | 期望状态码 | 实际状态码 | 结果 | 备注 |",
        "|---|---|---|---|---|---|---|---|",
    ]
    for c in cases:
        lines.append(
            f"| {c.case_id} | {c.title} | {c.method} | {c.path} | {c.expected} |  |  |  |"
        )
    lines.append("")
    lines.append("## 结论")
    lines.append("- 结论: ")
    lines.append("- 风险与遗留: ")
    lines.append("")
    return "\n".join(lines)


def list_modules(modules: Sequence[ModuleMeta]) -> None:
    print("可用模块:")
    for m in modules:
        aliases = ", ".join(m.aliases)
        print(f"- {m.slug}: {m.display_name}")
        print(f"  aliases: {aliases}")


def run_execute(curl_script: Path, output_dir: Path) -> int:
    proc = subprocess.run(
        ["bash", str(curl_script)],
        cwd=str(output_dir),
        check=False,
    )
    return proc.returncode


def generate(
    feature_dir: Path,
    module_name: str,
    output_root: Path,
    base_url: str,
    api_key_header: str,
    api_key: str,
    execute: bool,
    aliases_file: Path | None = None,
) -> int:
    modules = extract_modules(feature_dir, load_aliases_file(aliases_file))
    module = resolve_module(modules, module_name)
    endpoints = parse_feature_file(module.file_path)
    if not endpoints:
        raise ValueError(f"模块 {module.slug} 未解析到接口列表，请检查文档格式")

    cases = build_cases(module, endpoints)
    output_dir = output_root / module.slug
    output_dir.mkdir(parents=True, exist_ok=True)
    curl_script = output_dir / "curl-tests.sh"
    report_template = output_dir / "report-template.md"

    curl_script.write_text(
        render_curl_script(module, cases, base_url, api_key_header, api_key),
        encoding="utf-8",
    )
    report_template.write_text(render_report_template(module, cases), encoding="utf-8")
    curl_script.chmod(0o755)

    print(f"模块: {module.slug} ({module.display_name})")
    print(f"接口数: {len(endpoints)}")
    print(f"用例数: {len(cases)}")
    print(f"脚本: {curl_script}")
    print(f"模板: {report_template}")

    if execute:
        print("开始执行生成的 curl 测试脚本...")
        rc = run_execute(curl_script, output_dir)
        print(f"执行完成，退出码: {rc}")
        return rc
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="根据特性清单目录生成模块 curl 接口测试脚本")
    parser.add_argument("--feature-dir", required=True, help="特性清单目录")
    parser.add_argument("--module", help="模块名或别名")
    parser.add_argument("--output-root", default="tests/feature-curl", help="输出根目录")
    parser.add_argument("--base-url", default="https://127.0.0.1:6050", help="接口基础 URL")
    parser.add_argument("--api-key-header", default="X-API-Key", help="API Key 请求头")
    parser.add_argument("--api-key", default="", help="API Key")
    parser.add_argument("--list-modules", action="store_true", help="列出可用模块")
    parser.add_argument("--execute", action="store_true", help="生成后立即执行脚本")
    parser.add_argument("--aliases-file", help="模块别名文件，可选")
    args = parser.parse_args()

    feature_dir = Path(args.feature_dir).resolve()
    if not feature_dir.exists():
        raise SystemExit(f"feature-list 目录不存在: {feature_dir}")

    aliases_file = Path(args.aliases_file).resolve() if args.aliases_file else None
    modules = extract_modules(feature_dir, load_aliases_file(aliases_file))
    if args.list_modules:
        list_modules(modules)
        return 0

    if not args.module:
        raise SystemExit("--module 为必填参数（除非使用 --list-modules）")

    output_root = Path(args.output_root).resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    return generate(
        feature_dir=feature_dir,
        module_name=args.module,
        output_root=output_root,
        base_url=args.base_url,
        api_key_header=args.api_key_header,
        api_key=args.api_key,
        execute=args.execute,
        aliases_file=aliases_file,
    )


if __name__ == "__main__":
    raise SystemExit(main())

