#!/usr/bin/env bash
set -euo pipefail

SERVER_NAME=""
SERVICE_ID=""
ARTIFACT_PATH=""
CONFIG_PATH=".secrets/dev-servers.yaml"
VERIFY_SECONDS="20"
TAIL_LINES="120"
DRY_RUN="false"
CONFIRM="false"

usage() {
  cat <<'USAGE'
用法:
  deploy_remote.sh --server <name> --service <service_id>
                 [--artifact <local_file>] [--config <path>]
                 [--verify-seconds <n>] [--tail-lines <n>]
                 [--confirm] [--dry-run]

说明:
  - systemd/script 模式：支持可选上传 artifact 并替换远端 artifact.path，然后重启/检查。
  - docker 模式：默认仅重启容器并抓日志（不做镜像替换）。
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --server)
      SERVER_NAME="$2"; shift 2 ;;
    --service)
      SERVICE_ID="$2"; shift 2 ;;
    --artifact)
      ARTIFACT_PATH="$2"; shift 2 ;;
    --config)
      CONFIG_PATH="$2"; shift 2 ;;
    --verify-seconds)
      VERIFY_SECONDS="$2"; shift 2 ;;
    --tail-lines)
      TAIL_LINES="$2"; shift 2 ;;
    --dry-run)
      DRY_RUN="true"; shift ;;
    --confirm)
      CONFIRM="true"; shift ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "[ERROR] 未知参数: $1"; usage; exit 1 ;;
  esac
done

if [[ -z "$SERVER_NAME" || -z "$SERVICE_ID" ]]; then
  echo "[ERROR] --server 与 --service 必填"; usage; exit 1
fi
if [[ ! -f "$CONFIG_PATH" ]]; then
  echo "[ERROR] 配置文件不存在: $CONFIG_PATH"; exit 1
fi

if [[ -n "$ARTIFACT_PATH" && ! -f "$ARTIFACT_PATH" ]]; then
  echo "[ERROR] artifact 不存在: $ARTIFACT_PATH"; exit 1
fi

for cmd in ssh sftp python3; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[ERROR] 缺少命令: $cmd"; exit 1
  fi
done

payload="$(python3 - "$CONFIG_PATH" "$SERVER_NAME" "$SERVICE_ID" <<'PY'
import json
import sys

config_path, server_name, service_id = sys.argv[1:]
cfg = json.loads(open(config_path,'r',encoding='utf-8').read())
server = next((s for s in cfg.get('servers',[]) if isinstance(s,dict) and s.get('name')==server_name), None)
if not server:
    print('')
    sys.exit(0)
ssh = server.get('ssh') if isinstance(server.get('ssh'), dict) else {}
auth = ssh.get('auth') if isinstance(ssh.get('auth'), dict) else {}
services = server.get('services') if isinstance(server.get('services'), list) else []
service = next((s for s in services if isinstance(s,dict) and s.get('service_id')==service_id), None)
if not service:
    print('')
    sys.exit(0)
out = {
  'server': server_name,
  'ssh': {
    'host': ssh.get('host',''),
    'port': int(ssh.get('port') or 22),
    'username': ssh.get('username',''),
    'auth_type': auth.get('type','password'),
    'password': auth.get('password',''),
    'identity_file': auth.get('identity_file',''),
  },
  'defaults': server.get('defaults') if isinstance(server.get('defaults'), dict) else {},
  'service': service,
}
print(json.dumps(out, ensure_ascii=False))
PY
)"

if [[ -z "$payload" ]]; then
  echo "[ERROR] 未找到 server 或 service：server=$SERVER_NAME service=$SERVICE_ID"; exit 1
fi

HOST="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["ssh"]["host"])' <<<"$payload")"
PORT="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["ssh"]["port"])' <<<"$payload")"
USERNAME="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["ssh"]["username"])' <<<"$payload")"
AUTH_TYPE="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["ssh"]["auth_type"])' <<<"$payload")"
PASSWORD="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["ssh"].get("password",""))' <<<"$payload")"
IDENTITY_FILE="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["ssh"].get("identity_file",""))' <<<"$payload")"
KNOWN_HOSTS_FILE="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d.get("defaults",{}).get("known_hosts_file","/tmp/remote-dev-deploy-known-hosts"))' <<<"$payload")"
STRICT_HOST_KEY="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print("yes" if d.get("defaults",{}).get("strict_host_key_check", False) else "no")' <<<"$payload")"

MODE="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["service"].get("mode",""))' <<<"$payload")"

DEPLOY_ROOT_TMP="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print((d.get("defaults",{}) or {}).get("deploy_root_tmp","/tmp/remote-dev-deploy"))' <<<"$payload")"

SSH_BASE=(ssh -n -p "$PORT" -o "StrictHostKeyChecking=$STRICT_HOST_KEY" -o "UserKnownHostsFile=$KNOWN_HOSTS_FILE" -o ConnectTimeout=8)
SFTP_BASE=(sftp -o "StrictHostKeyChecking=$STRICT_HOST_KEY" -o "UserKnownHostsFile=$KNOWN_HOSTS_FILE" -P "$PORT")
if [[ "$AUTH_TYPE" == "key" && -n "$IDENTITY_FILE" ]]; then
  SSH_BASE+=( -i "$IDENTITY_FILE" -o BatchMode=yes )
  SFTP_BASE+=( -i "$IDENTITY_FILE" )
fi

ssh_exec() {
  local cmd="$1"
  if [[ "$AUTH_TYPE" == "password" ]]; then
    if ! command -v sshpass >/dev/null 2>&1; then
      echo "[ERROR] 缺少 sshpass（password 认证需要）"; return 127
    fi
    sshpass -p "$PASSWORD" "${SSH_BASE[@]}" "$USERNAME@$HOST" "$cmd"
    return $?
  fi
  "${SSH_BASE[@]}" "$USERNAME@$HOST" "$cmd"
}

sftp_put() {
  local local_file="$1"
  local remote_file="$2"
  if [[ "$AUTH_TYPE" == "password" ]]; then
    if ! command -v sshpass >/dev/null 2>&1; then
      echo "[ERROR] 缺少 sshpass（password 认证需要）"
      return 127
    fi
    sshpass -p "$PASSWORD" "${SFTP_BASE[@]}" "$USERNAME@$HOST" <<<"put \"$local_file\" \"$remote_file\"\nquit\n" >/dev/null
    return $?
  fi
  "${SFTP_BASE[@]}" "$USERNAME@$HOST" <<<"put \"$local_file\" \"$remote_file\"\nquit\n" >/dev/null
}

run_as_user() {
  local user="$1"
  local cmd="$2"
  # 避免把自由文本命令直接拼进单引号（单引号/特殊字符会破坏语义）；用 shlex.quote 生成稳定的 -c 参数。
  local quoted
  quoted="$(python3 -c 'import shlex,sys; print(shlex.quote(sys.argv[1]))' "set -e; ${cmd}")"
  if [[ -z "$user" || "$user" == "$USERNAME" ]]; then
    ssh_exec "bash -lc ${quoted}"
    return $?
  fi
  ssh_exec "su - ${user} -s /bin/bash -c ${quoted}"
}

echo "[INFO] server=$SERVER_NAME service=$SERVICE_ID mode=$MODE"

if [[ "$DRY_RUN" == "true" ]]; then
  echo "[PLAN] mode=$MODE artifact=${ARTIFACT_PATH:-<none>}"
  echo "[RESULT] DRY_RUN_SUCCESS"
  exit 0
fi

if [[ "$CONFIRM" != "true" ]]; then
  echo "[ERROR] deploy_remote 属于写操作（重启/替换产物等），必须显式加 --confirm"
  exit 2
fi

TS="$(date +%Y%m%d-%H%M%S)"
REMOTE_TMP_DIR="${DEPLOY_ROOT_TMP}/${SERVICE_ID}/${TS}"

artifact_type="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print((d["service"].get("artifact") or {}).get("type","none"))' <<<"$payload")"
artifact_remote="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print((d["service"].get("artifact") or {}).get("path",""))' <<<"$payload")"

if [[ "$MODE" == "docker" ]]; then
  container="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print((d["service"].get("docker") or {}).get("container",""))' <<<"$payload")"
  if [[ -z "$container" ]]; then
    echo "[ERROR] docker.container 未配置"; exit 1
  fi
  echo "[STEP] docker restart $container"
  ssh_exec "command -v docker >/dev/null 2>&1 || { echo '[ERROR] remote has no docker'; exit 2; }; docker restart '$container'" || {
    echo "[ERROR] docker restart 失败"; echo "[RESULT] FAILED"; exit 2;
  }
  echo "[STEP] docker logs"
  ssh_exec "docker logs --tail ${TAIL_LINES} '$container' || true"
  echo "[RESULT] SUCCESS"
  exit 0
fi

if [[ "$MODE" != "systemd" && "$MODE" != "script" ]]; then
  echo "[ERROR] 未支持 mode=$MODE"; exit 1
fi

if [[ -n "$ARTIFACT_PATH" ]]; then
  if [[ "$artifact_type" != "file" || -z "$artifact_remote" ]]; then
    echo "[ERROR] 当前服务未配置 artifact.type=file 且 artifact.path 非空，无法替换 artifact"; exit 1
  fi
fi

echo "[STEP] 创建远端临时目录: $REMOTE_TMP_DIR"
ssh_exec "mkdir -p '$REMOTE_TMP_DIR'" >/dev/null

REMOTE_UPLOADED=""
if [[ -n "$ARTIFACT_PATH" ]]; then
  base="$(basename "$ARTIFACT_PATH")"
  REMOTE_UPLOADED="$REMOTE_TMP_DIR/$base"
  echo "[STEP] 上传 artifact"
  sftp_put "$ARTIFACT_PATH" "$REMOTE_UPLOADED" || { echo "[ERROR] sftp 上传失败"; echo "[RESULT] FAILED"; exit 2; }
fi

if [[ "$MODE" == "systemd" ]]; then
  unit="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print((d["service"].get("systemd") or {}).get("unit",""))' <<<"$payload")"
  unit_user="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print((d["service"].get("systemd") or {}).get("user",""))' <<<"$payload")"
  [[ -z "$unit" ]] && { echo "[ERROR] systemd.unit 未配置"; exit 1; }

  echo "[STEP] stop unit"
  ssh_exec "systemctl stop '$unit' || true"

  if [[ -n "$REMOTE_UPLOADED" ]]; then
    echo "[STEP] 备份并替换 artifact: $artifact_remote"
    ssh_exec "set -e; if [ -f '$artifact_remote' ]; then cp -f '$artifact_remote' '$artifact_remote.bak'; fi; cp -f '$REMOTE_UPLOADED' '$artifact_remote'"
    if [[ -n "$unit_user" ]]; then
      ssh_exec "chown '$unit_user':'$unit_user' '$artifact_remote' || true"
    fi
  fi

  echo "[STEP] start unit"
  ssh_exec "systemctl start '$unit'"
  echo "[STEP] wait ${VERIFY_SECONDS}s"
  sleep "$VERIFY_SECONDS"
  echo "[STEP] status"
  ssh_exec "systemctl is-active '$unit' && echo ACTIVE || echo INACTIVE" || true
  echo "[STEP] logs"
  ssh_exec "journalctl -u '$unit' -n ${TAIL_LINES} --no-pager || true"

  cat <<RB
[ROLLBACK-PLAN]
1) systemctl stop '$unit'
2) cp -f '$artifact_remote.bak' '$artifact_remote'   # 如存在
3) systemctl start '$unit'
4) systemctl is-active '$unit'
RB
  echo "[RESULT] SUCCESS"
  exit 0
fi

# script mode
script_user="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print((d["service"].get("script") or {}).get("user",""))' <<<"$payload")"
start_cmd="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print((d["service"].get("script") or {}).get("start",""))' <<<"$payload")"
stop_cmd="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print((d["service"].get("script") or {}).get("stop",""))' <<<"$payload")"
check_cmd="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print((d["service"].get("script") or {}).get("check",""))' <<<"$payload")"
if [[ -z "$start_cmd" || -z "$stop_cmd" || -z "$check_cmd" ]]; then
  echo "[ERROR] script.start/stop/check 未配置"; exit 1
fi

echo "[STEP] stop"
run_as_user "$script_user" "$stop_cmd" || true

if [[ -n "$REMOTE_UPLOADED" ]]; then
  echo "[STEP] 备份并替换 artifact: $artifact_remote"
  ssh_exec "set -e; if [ -f '$artifact_remote' ]; then cp -f '$artifact_remote' '$artifact_remote.bak'; fi; cp -f '$REMOTE_UPLOADED' '$artifact_remote'"
  if [[ -n "$script_user" ]]; then
    ssh_exec "chown '$script_user':'$script_user' '$artifact_remote' || true"
  fi
fi

echo "[STEP] start"
run_as_user "$script_user" "$start_cmd" || { echo "[ERROR] start 失败"; echo "[RESULT] FAILED"; exit 2; }
echo "[STEP] wait ${VERIFY_SECONDS}s"
sleep "$VERIFY_SECONDS"
echo "[STEP] check"
run_as_user "$script_user" "$check_cmd" || true

cat <<RB
[ROLLBACK-PLAN]
1) ${stop_cmd}
2) cp -f '${artifact_remote}.bak' '${artifact_remote}'   # 如存在
3) ${start_cmd}
4) ${check_cmd}
RB

echo "[RESULT] SUCCESS"
