#!/usr/bin/env bash
set -euo pipefail

SERVER_NAME=""
SERVICE_ID=""
CONFIG_PATH=".secrets/dev-servers.yaml"
TAIL_LINES="200"
DRY_RUN="false"

usage() {
  cat <<'USAGE'
用法:
  log_diagnose.sh --server <name> --service <service_id>
                 [--config <path>] [--tail-lines <n>] [--dry-run]
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --server)
      SERVER_NAME="$2"; shift 2 ;;
    --service)
      SERVICE_ID="$2"; shift 2 ;;
    --config)
      CONFIG_PATH="$2"; shift 2 ;;
    --tail-lines)
      TAIL_LINES="$2"; shift 2 ;;
    --dry-run)
      DRY_RUN="true"; shift ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "[ERROR] 未知参数: $1"; usage; exit 1 ;;
  esac
done

if [[ -z "$SERVER_NAME" || -z "$SERVICE_ID" ]]; then
  echo "[ERROR] --server 与 --service 必填"; usage; exit 1
fi
if [[ ! -f "$CONFIG_PATH" ]]; then
  echo "[ERROR] 配置文件不存在: $CONFIG_PATH"; exit 1
fi
if ! [[ "$TAIL_LINES" =~ ^[1-9][0-9]*$ ]]; then
  echo "[ERROR] --tail-lines 必须为正整数"; exit 1
fi

for cmd in ssh python3; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[ERROR] 缺少命令: $cmd"; exit 1
  fi
done

python3 - "$CONFIG_PATH" "$SERVER_NAME" "$SERVICE_ID" "$TAIL_LINES" "$DRY_RUN" <<'PY'
import json
import re
import shlex
import subprocess
import sys
import shutil
from typing import Any, Dict, List, Tuple

config_path, server_name, service_id, tail_lines, dry_run = sys.argv[1:]
tail_lines = int(tail_lines)
dry_run = dry_run.lower() == 'true'

cfg = json.loads(open(config_path,'r',encoding='utf-8').read())
server = next((s for s in cfg.get('servers',[]) if isinstance(s,dict) and s.get('name')==server_name), None)
if not server:
    print(f"[ERROR] 未找到服务器: {server_name}")
    sys.exit(1)

ssh = server.get('ssh') if isinstance(server.get('ssh'), dict) else {}
auth = ssh.get('auth') if isinstance(ssh.get('auth'), dict) else {}
host = str(ssh.get('host',''))
port = int(ssh.get('port') or 22)
username = str(ssh.get('username',''))
auth_type = str(auth.get('type','password'))
password = str(auth.get('password',''))
identity_file = str(auth.get('identity_file',''))

services = server.get('services') if isinstance(server.get('services'), list) else []
service = next((s for s in services if isinstance(s,dict) and s.get('service_id')==service_id), None)
if not service:
    print(f"[ERROR] 未找到服务: {service_id}")
    sys.exit(1)

known_hosts_file = str((server.get('defaults') or {}).get('known_hosts_file', '/tmp/remote-dev-deploy-known-hosts'))
strict = 'yes' if (server.get('defaults') or {}).get('strict_host_key_check', False) else 'no'

ssh_base = [
    'ssh','-n','-p',str(port),
    '-o',f'StrictHostKeyChecking={strict}',
    '-o',f'UserKnownHostsFile={known_hosts_file}',
    '-o','ConnectTimeout=8',
]
if auth_type == 'key' and identity_file:
    ssh_base += ['-i', identity_file, '-o', 'BatchMode=yes']
ssh_base.append(f'{username}@{host}')

def run_ssh(cmd: str) -> Tuple[int, str]:
    full = ssh_base + [cmd]
    if auth_type == 'password':
        if not password:
            return 127, '[ERROR] ssh.auth.password 为空（password 认证需要）\n'
        if shutil.which('sshpass') is None:
            return 127, '[ERROR] 缺少 sshpass（password 认证需要）\n'
        full = ['sshpass','-p',password] + full
    try:
        proc = subprocess.run(full, capture_output=True, text=True, timeout=25)
    except subprocess.TimeoutExpired:
        return 124, '[ERROR] SSH 命令超时（25s）\n'
    out = (proc.stdout or '') + (proc.stderr or '')
    return proc.returncode, out

def collect_logs() -> str:
    logs = service.get('logs') if isinstance(service.get('logs'), dict) else {}
    typ = str(logs.get('type') or 'files')
    if typ == 'journalctl':
        unit = str(logs.get('journal_unit') or (service.get('systemd') or {}).get('unit') or '')
        if not unit:
            return '[WARN] 缺少 journal_unit\n'
        code, out = run_ssh(f"journalctl -u {shlex.quote(unit)} -n {tail_lines} --no-pager || true")
        return out
    if typ == 'docker':
        container = str((service.get('docker') or {}).get('container') or '')
        if not container:
            return '[WARN] 缺少 docker.container\n'
        code, out = run_ssh(f"docker logs --tail {tail_lines} {shlex.quote(container)} || true")
        return out

    paths = logs.get('paths') if isinstance(logs.get('paths'), list) else []
    if not paths:
        return '[WARN] 未配置日志路径 services[].logs.paths\n'
    merged = []
    for p in paths[:5]:
        p = str(p)
        if not p:
            continue
        code, out = run_ssh(f"if [ -f {shlex.quote(p)} ]; then echo '--- {p}'; tail -n {tail_lines} {shlex.quote(p)}; else echo '[WARN] missing {p}'; fi")
        merged.append(out)
    return "\n".join(merged)

def classify(text: str) -> Dict[str, Any]:
    lines = [ln for ln in text.splitlines() if ln.strip()]
    content = "\n".join(lines[-2000:])
    rules = [
        ('DB', [
            r'relation does not exist', r'unknown column', r'SQLSTATE', r'duplicate key', r'could not connect to server', r'Access denied for user',
        ]),
        ('AUTH', [r'Unauthorized', r'401', r'403', r'invalid token', r'accessToken', r'permission denied']),
        ('CONFIG', [r'config not found', r'no such configuration', r'nacos', r'cannot resolve placeholder', r'Failed to load property']),
        ('NETWORK', [r'Connection refused', r'timed out', r'UnknownHostException', r'No route to host']),
        ('STARTUP', [r'Exception', r'FATAL', r'failed to start', r'Startup failed']),
    ]
    scored: List[Tuple[str,int]] = []
    evidence: Dict[str, List[str]] = {}
    for cat, patterns in rules:
        score = 0
        ev: List[str] = []
        for pat in patterns:
            m = re.search(pat, content, re.IGNORECASE)
            if m:
                score += 1
        if score:
            # 抽取部分证据行
            for ln in lines[-400:]:
                if any(re.search(p, ln, re.IGNORECASE) for p in patterns):
                    ev.append(ln[:300])
                    if len(ev) >= 8:
                        break
            evidence[cat] = ev
        scored.append((cat, score))
    scored.sort(key=lambda x: x[1], reverse=True)
    best_cat, best_score = scored[0]
    if best_score == 0:
        best_cat = 'UNKNOWN'
    return {
        'category': best_cat,
        'scores': {k: v for k, v in scored},
        'evidence_lines': evidence.get(best_cat, []),
        'suggested_action': {
            'DB': '检查数据库连通性/账号/表结构；必要时执行对应 DB 初始化流程',
            'AUTH': '检查鉴权策略（token/login/cookie）与权限；确认网关/接口返回',
            'CONFIG': '检查配置中心/配置文件缺失或占位符；必要时回滚最近配置变更',
            'NETWORK': '检查端口/网络策略/服务是否存活；确认依赖组件是否可达',
            'STARTUP': '优先抓取完整启动日志与异常栈；必要时切换前台启动方式',
            'UNKNOWN': '补充更多日志与上下文（部署方式/健康检查/接口用例）',
        }.get(best_cat, ''),
    }

if dry_run:
    print('[PLAN] collect logs + classify (dry-run)')
    print('[RESULT] DRY_RUN_SUCCESS')
    sys.exit(0)

log_text = collect_logs()
diag = classify(log_text)
diag['server'] = server_name
diag['service_id'] = service_id
diag['service_name'] = service.get('name','')

print(log_text)
print('DIAGNOSIS_RESULT=' + json.dumps(diag, ensure_ascii=False))
print('[RESULT] DIAGNOSIS_SUCCESS')
PY
