---
name: rq-stage-test-executor
description: 按阶段执行需求测试设计文档中的测试场景和用例，并输出可追溯测试报告。Use when stage-level test cases must be executed with gate decisions and evidence output.
---

# RQ 阶段测试执行器

负责把 `20-{stage_name}-需求测试设计.md` 转为可执行测试动作，输出阶段级测试结果。

## 文件命名规范（硬性）

`stage_name` 仅用于展示，文件落盘统一使用 `stage_slug`：
- 先将阶段名语义翻译为英文短语，再生成 slug
- 小写英数字与连字符（`[a-z0-9-]`）
- 空格与下划线转为 `-`
- 连续分隔符合并为单个 `-`
- 去除前后 `-`
- 禁止使用中文拼音作为 `stage_slug`

示例：
- `基础设施准备` → `infrastructure-setup`
- `用户认证与授权` → `user-auth-and-authorization`

`stage_slug` 来源于 `runtime-status.md`，禁止在本技能内重新发明命名。

## 输入契约

### 必需输入

| 输入项 | 路径 |
|---|---|
| 需求标识 | `{rq_id}` |
| 阶段名 | `{stage_name}` |
| 阶段标识 | `{stage_slug}` |
| 阶段测试设计 | `docs/requirement/{rq_id}/20-{stage_name}-需求测试设计.md` |
| 阶段任务映射 | `.claude/notepads/{rq_id}/runtime-status.md` |

### 可选输入

| 输入项 | 路径 | 说明 |
|---|---|---|
| 项目测试命令约定 | `.claude/rules/**` | 测试入口、门禁要求 |
| 历史测试记录 | `.claude/notepads/{rq_id}/test-report-*.md` | 回归对比 |

## 输出

路径：`.claude/notepads/{rq_id}/test-report-{stage_slug}.md`

历史摘要：`.claude/notepads/{rq_id}/test-report-history-{stage_slug}.md`

报告最小结构：

```markdown
# 阶段测试报告 - {stage_name}

## 概览
- rq: {rq_id}
- stage: {stage_name}
- stage_slug: {stage_slug}
- started_at: ...
- finished_at: ...
- result: pass/fail

## 用例结果
| case_id | case_name | priority | result | evidence |
|---|---|---|---|---|

## 失败明细
- 失败用例ID:
- 失败原因:
- 日志路径/摘要:

## 门禁结论
- P0通过率:
- P1通过率:
- 是否允许推进下一阶段:
```

## 执行流程

### Step 1：加载阶段测试设计

1. 读取当前阶段测试设计文档。
2. 提取测试策略、场景、用例、验收标准。
3. 无法提取用例索引时阻塞并提示修复测试设计文档。

### Step 2：映射执行项

1. 将测试用例映射到可执行测试动作（单元/集成/E2E/回归）。
2. 按优先级执行：P0 → P1 → P2 → P3。
3. **E2E 测试映射（当阶段测试设计含 `test_type: e2e` 用例时）**：
   1. 从测试设计文档中提取所有 `test_type: e2e` 的场景和用例
   2. 调用 `e2e-orchestrator` skill，传入：
      - E2E 场景列表（含用户旅程、浏览器范围、前置条件）
      - 目标环境 URL（从 `.secrets/dev-servers.yaml` 读取）
      - `result_output_path: .claude/notepads/{rq_id}/e2e-result-{stage_slug}.json`（指定结果写入路径）
   3. `e2e-orchestrator` 负责：测试代码生成/复用、多浏览器执行、artifact 采集
   4. 等待 `e2e-orchestrator` 完成后，从 `.claude/notepads/{rq_id}/e2e-result-{stage_slug}.json` 读取结构化结果（`e2e-orchestrator` 在执行完成后自动写入该路径）

### Step 3：执行并收集证据

1. 运行对应测试命令并记录原始输出摘要。
2. 汇总通过率、失败项、关键日志。
3. **E2E 执行证据（报告中必须包含，当阶段含 E2E 用例时）**：
   - HTML 报告路径（Playwright 生成）
   - 每个失败用例：截图路径 + 失败原因
   - trace 文件路径（on-first-retry 模式）
   - 浏览器维度通过率（chromium X%，firefox Y%，webkit Z%）
   - Flaky 用例列表（重试后通过，需标注）
4. 生成阶段测试报告并落盘。
5. 将本轮摘要追加到 `test-report-history-{stage_slug}.md`。

### Step 4：门禁判定

1. P0/P1 任一失败：阶段判定 `fail`。
2. 全部通过：阶段判定 `pass`。

**E2E 专属门禁规则（当阶段有 E2E 用例时）**：
- P0 E2E 用例：任一失败 → 阶段 `fail`（不允许 flaky 豁免）
- P1 E2E 用例：通过率 < 95% → 阶段 `fail`
- 整体 E2E 通过率 < 90% → 阶段 `fail`（即使 P0/P1 全通过）
- Flaky 用例 ≥ 5% → 阶段 `warn`（不阻断，但需在报告中记录）
- `e2e-orchestrator` 调用超时（> 15 分钟）→ 标记为 `fail` 并人工升级

## 约束

- 不修改测试设计文档本身。
- 不跳过 P0/P1 用例。
- 不以“应该通过”替代真实执行证据。
