#!/usr/bin/env python3
"""
Lightweight linter for autocode agent/command/skill markdown contracts.

Checks:
- Frontmatter name matches filename/dir name
- Referenced agents exist (agents/<name>.md, subagent_type=..., 调用agent)
- Referenced skills exist (skills/<name>, Skill(name))
- Flags obvious portability risks (absolute ~/.claude paths, references to templates/ not shipped)

This is intentionally heuristic: it should surface inconsistencies early, not block all workflows.
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]  # repo root
AUTOCODE = ROOT / "autocode"
AGENTS_DIR = AUTOCODE / "agents"
COMMANDS_DIR = AUTOCODE / "commands" / "ac"
SKILLS_DIR = AUTOCODE / "skills"


FRONTMATTER_RE = re.compile(r"(?s)\A---\s*\n(.*?)\n---\s*\n")
NAME_RE = re.compile(r"(?m)^\s*name:\s*(.+?)\s*$")

AGENT_REF_RE = re.compile(r"agents/([A-Za-z0-9_-]+)(?:\.md)?")
SUBAGENT_TYPE_RE = re.compile(r'subagent_type\s*=\s*"([^"]+)"')
CALL_AGENT_RE = re.compile(r"(?:调用agent|调用 agent)\s*：\s*`([^`]+)`")

SKILL_PATH_RE = re.compile(r"skills/([A-Za-z0-9_-]+)")
SKILL_CALL_RE = re.compile(r"Skill\(\s*([A-Za-z0-9_:-]+)\s*\)")

# Simple portability smells
ABS_CLAUDE_RE = re.compile(r"~/(?:\.claude|\.codex)/")
TEMPLATES_TOP_RE = re.compile(r"(?m)\btemplates/[^\\s`]+")


@dataclass(frozen=True)
class Finding:
    level: str  # ERROR/WARN
    path: Path
    message: str


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace")


def frontmatter_name(text: str) -> str | None:
    m = FRONTMATTER_RE.search(text)
    if not m:
        return None
    m2 = NAME_RE.search(m.group(1))
    if not m2:
        return None
    return m2.group(1).strip().strip('"').strip("'")


def is_external_id(x: str) -> bool:
    # Namespaced ids are typically external (e.g. oh-my-claudecode:designer)
    return ":" in x


def main() -> int:
    findings: list[Finding] = []

    # Index current agents/skills by name for reference validation.
    agent_names: set[str] = set()
    for p in sorted(AGENTS_DIR.glob("*.md")):
        name = frontmatter_name(read_text(p))
        if name:
            agent_names.add(name)

    skill_names: set[str] = set()
    for p in sorted(SKILLS_DIR.glob("*/SKILL.md")):
        name = frontmatter_name(read_text(p))
        if name:
            skill_names.add(name)

    # 1) Agent definitions
    for p in sorted(AGENTS_DIR.glob("*.md")):
        text = read_text(p)
        base = p.stem
        name = frontmatter_name(text)
        if not name:
            findings.append(Finding("ERROR", p, "missing YAML frontmatter name"))
        elif name != base:
            findings.append(Finding("ERROR", p, f"name mismatch: frontmatter name='{name}' != filename '{base}.md'"))

        for m in ABS_CLAUDE_RE.finditer(text):
            findings.append(Finding("WARN", p, f"absolute tool path reference: '{m.group(0)}...' (prefer {{tool_root}})"))

    # 2) Command definitions
    for p in sorted(COMMANDS_DIR.glob("*.md")):
        text = read_text(p)
        base = p.stem
        name = frontmatter_name(text)
        if not name:
            findings.append(Finding("ERROR", p, "missing YAML frontmatter name"))
        elif name != base:
            findings.append(Finding("ERROR", p, f"name mismatch: frontmatter name='{name}' != filename '{base}.md'"))

    # 3) Skill definitions
    for p in sorted(SKILLS_DIR.glob("*/SKILL.md")):
        text = read_text(p)
        dir_name = p.parent.name
        name = frontmatter_name(text)
        if not name:
            findings.append(Finding("ERROR", p, "missing YAML frontmatter name"))
        elif name != dir_name:
            findings.append(Finding("ERROR", p, f"name mismatch: frontmatter name='{name}' != dir '{dir_name}/'"))

        for m in ABS_CLAUDE_RE.finditer(text):
            findings.append(Finding("WARN", p, f"absolute tool path reference: '{m.group(0)}...' (prefer {{tool_root}})"))

        for m in TEMPLATES_TOP_RE.finditer(text):
            findings.append(Finding("WARN", p, f"references top-level templates path that is not packed by autocode/package.sh: '{m.group(0)}'"))

    # 4) Reference validation: scan agents + commands for agent/skill refs.
    scan_paths = list(sorted(AGENTS_DIR.glob("*.md"))) + list(sorted(COMMANDS_DIR.glob("*.md")))
    for p in scan_paths:
        text = read_text(p)

        for m in AGENT_REF_RE.finditer(text):
            ref = m.group(1)
            # If someone writes agents/xxx.md we only validate the file exists in autocode/agents.
            if (AGENTS_DIR / f"{ref}.md").exists():
                continue
            findings.append(Finding("WARN", p, f"agent file ref not found: agents/{ref}.md"))

        for m in SUBAGENT_TYPE_RE.finditer(text):
            ref = m.group(1)
            if is_external_id(ref):
                continue
            if ref not in agent_names:
                findings.append(Finding("WARN", p, f"subagent_type refers to unknown agent: '{ref}'"))

        for m in CALL_AGENT_RE.finditer(text):
            ref = m.group(1)
            if is_external_id(ref):
                continue
            if ref not in agent_names:
                findings.append(Finding("WARN", p, f"calls unknown agent: '{ref}'"))

        for m in SKILL_PATH_RE.finditer(text):
            ref = m.group(1)
            if ref not in skill_names:
                findings.append(Finding("WARN", p, f"references unknown skill: skills/{ref}"))

        for m in SKILL_CALL_RE.finditer(text):
            ref = m.group(1)
            if is_external_id(ref):
                continue
            if ref not in skill_names:
                findings.append(Finding("WARN", p, f"Skill(...) refers to unknown skill: '{ref}'"))

        for m in TEMPLATES_TOP_RE.finditer(text):
            # The zip packs only agents/commands/skills, so templates/ is not shipped unless the target project provides it.
            findings.append(Finding("WARN", p, f"references top-level templates path that is not packed by autocode/package.sh: '{m.group(0)}'"))

    # Print
    if not findings:
        print("OK: no findings")
        return 0

    err = [f for f in findings if f.level == "ERROR"]
    warn = [f for f in findings if f.level == "WARN"]

    for f in err + warn:
        print(f"{f.level}: {f.path.relative_to(ROOT)}: {f.message}")

    print(f"\nSummary: {len(err)} errors, {len(warn)} warnings")
    return 1 if err else 0


if __name__ == "__main__":
    raise SystemExit(main())
