#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path
from typing import Any, Dict, List


def load_json(path: Path) -> Dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise RuntimeError(f"JSON 顶层必须为对象: {path}")
    return data


def dump_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def normalize_service_id(text: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9]+", "-", (text or "svc").strip()).strip("-").lower()
    if not cleaned:
        cleaned = "svc"
    if not cleaned.startswith("svc-"):
        cleaned = "svc-" + cleaned
    return cleaned[:40]


def pick_mode(cand: Dict[str, Any]) -> str:
    modes = cand.get("mode_candidates")
    if isinstance(modes, list) and modes:
        m = str(modes[0])
        if m in {"systemd", "script", "docker"}:
            return m
    if cand.get("source") == "systemd":
        return "systemd"
    if cand.get("source") == "docker":
        return "docker"
    return "script"


def parse_source_quota(raw: str) -> Dict[str, int]:
    quotas = {"systemd": 8, "docker": 8, "port": 12}
    warnings: List[str] = []
    for part in (raw or "").split(","):
        part = part.strip()
        if not part:
            continue
        if "=" not in part:
            warnings.append(f"忽略非法 source_quota 片段: {part}")
            continue
        key, val = part.split("=", 1)
        key = key.strip()
        val = val.strip()
        if key not in quotas:
            warnings.append(f"忽略未知 source_quota 键: {key}")
            continue
        if not re.match(r"^\d+$", val):
            warnings.append(f"忽略非法 source_quota 值: {key}={val}")
            continue
        quotas[key] = int(val)
    for w in warnings:
        print(f"[WARN] {w}")
    return quotas


def pick_candidates_for_draft(
    candidates: List[Dict[str, Any]],
    max_services: int,
    source_quota: Dict[str, int],
) -> List[Dict[str, Any]]:
    max_total = max(1, int(max_services or 24))
    counts = {"systemd": 0, "docker": 0, "port": 0}

    # 若 probe-report 带 project_match，则按相关性优先排序（保底策略仍生效）
    def sort_key(c: Dict[str, Any]) -> float:
        pm = c.get("project_match") if isinstance(c.get("project_match"), dict) else {}
        try:
            return float(pm.get("score") or 0.0)
        except Exception:
            return 0.0

    has_pm = any(isinstance(c.get("project_match"), dict) for c in candidates)
    ordered = list(candidates)
    if has_pm:
        ordered.sort(key=sort_key, reverse=True)

    selected: List[Dict[str, Any]] = []
    selected_idx = set()
    # 第一轮：按来源配额保底
    for idx, cand in enumerate(ordered):
        source = str(cand.get("source") or "port")
        if source not in counts:
            source = "port"
        limit = int(source_quota.get(source, 0))
        if counts[source] >= limit:
            continue
        selected.append(cand)
        selected_idx.add(idx)
        counts[source] += 1
        if len(selected) >= max_total:
            return selected

    # 第二轮：补位填满（避免某来源不足导致总量过低）
    for idx, cand in enumerate(ordered):
        if idx in selected_idx:
            continue
        selected.append(cand)
        if len(selected) >= max_total:
            break
    return selected


def draft_services(candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    services: List[Dict[str, Any]] = []
    for cand in candidates:
        mode = pick_mode(cand)
        name_hint = str(cand.get("name_hint") or "service")
        service_id = normalize_service_id(name_hint)
        pm = cand.get("project_match") if isinstance(cand.get("project_match"), dict) else {}
        item: Dict[str, Any] = {
            "service_id": service_id,
            "name": name_hint,
            "mode": mode,
            "systemd": {"unit": "", "user": ""},
            # 这里用安全占位，确保 answers.full.json 在严格校验下可通过；实际命令必须由 AskUserQuestion 逐项确认替换。
            "script": {"user": "", "start": "echo TODO_START", "stop": "echo TODO_STOP", "check": "echo TODO_CHECK"},
            "docker": {"container": "", "compose_file": ""},
            "artifact": {"type": "none", "path": "", "pattern": ""},
            "logs": {"type": "files", "journal_unit": "", "paths": []},
            "deploy": {"enabled": False, "rollback_mode": "print-only"},
            "health": {"type": "none", "url": ""},
            "_draft_note": "请用 AskUserQuestion 逐服务确认 mode、启停方式、日志与端口。",
            "_needs_q7_confirmation": True,
            "_project_match": {
                "score": pm.get("score") if pm else 0.0,
                "reasons": pm.get("reasons") if pm else [],
                "matched_keywords": pm.get("matched_keywords") if pm else [],
                "matched_ports": pm.get("matched_ports") if pm else [],
            },
        }

        if mode == "systemd":
            systemd = cand.get("systemd") if isinstance(cand.get("systemd"), dict) else {}
            item["systemd"]["unit"] = str(systemd.get("unit") or "")
            item["systemd"]["user"] = str(systemd.get("user") or "")
            item["logs"]["type"] = "journalctl"
            item["logs"]["journal_unit"] = item["systemd"]["unit"]
            item["deploy"]["enabled"] = True

        if mode == "docker":
            docker = cand.get("docker") if isinstance(cand.get("docker"), dict) else {}
            item["docker"]["container"] = str(docker.get("container") or docker.get("name") or "")
            item["logs"]["type"] = "docker"
            item["deploy"]["enabled"] = False

        if mode == "script":
            proc = cand.get("process") if isinstance(cand.get("process"), dict) else {}
            port = proc.get("port")
            if port:
                item["health"]["type"] = "http"
                item["health"]["url"] = f"http://{{host}}:{port}/"
            # 严格校验要求 logs.paths 非空；此处仅给占位，需 AskUserQuestion 再确认真实路径。
            item["logs"]["paths"] = [f"/tmp/{service_id}.log"]

        services.append(item)

    # 去重 service_id
    seen = set()
    out: List[Dict[str, Any]] = []
    for item in services:
        sid = item.get("service_id")
        if sid in seen:
            continue
        seen.add(sid)
        out.append(item)
    return out


def placeholder_service() -> Dict[str, Any]:
    return {
        "service_id": "svc-main",
        "name": "main",
        "mode": "script",
        "systemd": {"unit": "", "user": ""},
        "script": {"user": "", "start": "echo TODO_START", "stop": "echo TODO_STOP", "check": "echo TODO_CHECK"},
        "docker": {"container": "", "compose_file": ""},
        "artifact": {"type": "none", "path": "", "pattern": ""},
        "logs": {"type": "files", "journal_unit": "", "paths": ["/tmp/svc-main.log"]},
        "deploy": {"enabled": False, "rollback_mode": "print-only"},
        "health": {"type": "none", "url": ""},
        "_draft_note": "探测未识别到可用服务候选，请手工补齐本服务的 mode/启停/日志/端口。",
    }


def pick_component_port(comp_items: List[Dict[str, Any]], fallback: int) -> int:
    for item in comp_items:
        if not isinstance(item, dict):
            continue
        port = item.get("port")
        if isinstance(port, int) and port > 0:
            return port
        if isinstance(port, str) and port.isdigit():
            return int(port)
        evidence = str(item.get("evidence") or "")
        m = re.search(r"\b(\d{2,5})\b", evidence)
        if m:
            try:
                return int(m.group(1))
            except Exception:
                pass
    return fallback


def guess_db_type_by_port(port: int) -> str:
    if port == 5432:
        return "postgresql"
    if port == 3306:
        return "mysql"
    return "auto"


def main() -> None:
    parser = argparse.ArgumentParser(description="根据 answers.min.json + probe-report.json 生成 answers.full.json 草稿")
    parser.add_argument("--project-root", default=".")
    parser.add_argument("--min", required=True, help="answers.min.json")
    parser.add_argument("--probe", required=True, help="probe-report.json")
    parser.add_argument("--out", required=True, help="answers.full.json")
    parser.add_argument("--max-services", type=int, default=24, help="草稿服务总上限（默认 24）")
    parser.add_argument(
        "--source-quota",
        default="systemd=8,docker=8,port=12",
        help="草稿分来源配额，如 systemd=8,docker=8,port=12",
    )
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    min_path = Path(args.min).expanduser().resolve()
    probe_path = Path(args.probe).expanduser().resolve()
    out_path = Path(args.out).expanduser().resolve()

    min_answers = load_json(min_path)
    probe = load_json(probe_path)

    servers_in = min_answers.get("servers") if isinstance(min_answers.get("servers"), list) else []
    probe_servers = probe.get("servers") if isinstance(probe.get("servers"), list) else []
    probe_by_name = {str(s.get("server", {}).get("name")): s for s in probe_servers if isinstance(s, dict)}
    source_quota = parse_source_quota(args.source_quota)
    max_services = max(1, int(args.max_services or 24))

    full: Dict[str, Any] = {
        "suite_version": "2",
        "project": min_answers.get("project") if isinstance(min_answers.get("project"), dict) else {"project_root": str(project_root)},
        "defaults": min_answers.get("defaults") if isinstance(min_answers.get("defaults"), dict) else {},
        "generation": {"write_secrets": False, "force": False},
        "servers": [],
        "_draft_note": "本文件为草稿：请使用 AskUserQuestion 逐服务确认并补齐字段。",
    }

    for server in servers_in:
        if not isinstance(server, dict):
            continue
        name = str(server.get("name") or "").strip()
        probe_one = probe_by_name.get(name) or {}
        candidates = probe_one.get("service_candidates") if isinstance(probe_one.get("service_candidates"), list) else []
        candidate_list = [c for c in candidates if isinstance(c, dict)]
        selected_candidates = pick_candidates_for_draft(candidate_list, max_services=max_services, source_quota=source_quota)
        services = draft_services(selected_candidates)
        if not services:
            services = [placeholder_service()]

        comp_hints = probe_one.get("components_hints", {}) if isinstance(probe_one.get("components_hints"), dict) else {}
        config_centers = [x for x in (comp_hints.get("config_centers") or []) if isinstance(x, dict)]
        databases = [x for x in (comp_hints.get("databases") or []) if isinstance(x, dict)]
        middlewares = [x for x in (comp_hints.get("middlewares") or []) if isinstance(x, dict)]
        has_nacos = any(x.get("type") == "nacos" for x in config_centers)
        has_db = bool(databases)
        has_kafka = any(x.get("type") == "kafka" for x in middlewares)
        has_es = any(x.get("type") == "elasticsearch" for x in middlewares)

        # 自动补齐插件最小骨架（不写入敏感值，需用户后续确认/补齐）
        ssh = server.get("ssh") if isinstance(server.get("ssh"), dict) else {}
        ssh_host = str(ssh.get("host") or "")
        nacos_port = pick_component_port([x for x in config_centers if x.get("type") == "nacos"], 8848)
        db_port = pick_component_port(databases, 5432)
        db_type = guess_db_type_by_port(db_port)
        kafka_port = pick_component_port([x for x in middlewares if x.get("type") == "kafka"], 9092)
        es_port = pick_component_port([x for x in middlewares if x.get("type") == "elasticsearch"], 9200)

        full["servers"].append(
            {
                "name": name,
                "ssh": server.get("ssh"),
                "probe": server.get("probe", {}),
                "defaults": {"deploy_root_tmp": "/tmp/remote-dev-deploy"},
                "services": services,
                "api_debug": {
                    "enabled": False,
                    "strategy": "none",
                    "default_base_url": "",
                },
                "components": {
                    "plugins": {
                        "nacos": {"enabled": has_nacos},
                        "db": {"enabled": has_db},
                        "kafka": {"enabled": has_kafka},
                        "es": {"enabled": has_es},
                    },
                    "nacos": {
                        "enabled": has_nacos,
                        "protocol": "http",
                        "host": ssh_host,
                        "port": nacos_port,
                        "access": {"mode": "direct"},
                        "username": "nacos",
                        "password_plain": "",
                        "api_version": "v1",
                        "_todo": [
                            "确认 nacos 是否存在以及 api_version(v1/v3)",
                            "如本地无法直连 Nacos，可将 access.mode 改为 ssh（通过 SSH 临时端口转发）",
                            "补齐 password_plain（通用脚本默认不支持自动解密）",
                            "如接口路径不同，补齐 login_path/config_api_base",
                        ],
                    },
                    "db": {
                        "enabled": has_db,
                        "db_type": db_type,
                        "host": ssh_host,
                        "port": db_port,
                        "access": {"mode": "direct"},
                        "username": "",
                        "password": "",
                        "database": "",
                        "_todo": [
                            "确认 db_type(mysql/postgresql) 与端口是否一致",
                            "如本地无法直连 DB，可将 access.mode 改为 ssh（通过 SSH 临时端口转发）",
                            "补齐 username/password/database（仅用于探测/连接验证）",
                        ],
                    },
                    "kafka": {
                        "enabled": has_kafka,
                        "bootstrap_servers": f"{ssh_host}:{kafka_port}" if ssh_host else f"127.0.0.1:{kafka_port}",
                        "cli": {
                            "mode": "ssh",
                            "bin_dir": "/opt/kafka/bin",
                            "docker_container": "",
                        },
                        "_todo": [
                            "确认 bootstrap_servers（可能是内网地址/多 broker）",
                            "确认 Kafka CLI 路径（bin_dir）或是否运行在 docker（docker_container）",
                        ],
                    },
                    "es": {
                        "enabled": has_es,
                        "protocol": "http",
                        "host": ssh_host or "127.0.0.1",
                        "port": es_port,
                        "access": {"mode": "direct"},
                        "auth": {"mode": "none", "username": "", "password_plain": ""},
                        "_todo": [
                            "确认 ES 是否需要鉴权（basic/api key）以及访问地址是否可达",
                            "如本地无法直连 ES，可将 access.mode 改为 ssh（通过 SSH 临时端口转发）",
                        ],
                    },
                },
                "_probe_notes": probe_one.get("notes", []),
                "_components_hints": comp_hints,
            }
        )

    dump_json(out_path, full)
    print(f"[OK] drafted answers.full.json: {out_path}")


if __name__ == "__main__":
    main()
