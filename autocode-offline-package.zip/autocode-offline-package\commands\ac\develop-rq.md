---
name: develop-rq
description: "启动开发实施阶段：基于 prepare-rq 产物调用总入口技能执行开发闭环"
category: workflow
---

# /develop-rq - 开发实施命令

**功能说明**：该命令用于启动开发实施工作流。基于 `/prepare-rq` 已完成的开发计划和测试设计，调用总入口 Skill `rq-auto-dev-orchestrator` 执行“开发-测试-修复-评审”自动闭环，直到通过门禁。

## 使用方法

```bash
/develop-rq {rq_id} [--continue]
```

**参数说明**：
- `{rq_id}`：必需，需求文件夹名称（对应目标项目的 `docs/requirement/{rq_id}/`）
- `--continue`：可选，读取需求目录与评审目录下已有产物与进度，识别上次卡点并继续完成剩余流程

## 使用示例

```bash
# 标准用法：先 prepare，再 develop
/prepare-rq rq001-s3-storage-manage
# ... 人工确认计划和设计 ...
/develop-rq rq001-s3-storage-manage

# 中断后续跑
/develop-rq rq001-s3-storage-manage --continue
```

## 前置条件

**需求目录**
- `{project_root}/docs/requirement/{rq_id}/`

**需求计划位置**
- 需求目录下：`10-需求开发计划表.md`

**中间产物输出位置**: 开发过程中的测试脚本、开发报告等中间文档，不要直接保存到项目根目录，保存在如下路径，后续恢复也可以读取：
- `.claude/notepads/{rq_id}/`

## 工作职责

**MUST**: 
- 理解需求背景、需求设计、开发任务
- 严格依据设计执行
- 严格执行测试项

**DO NOT**: 
- design
- 遗漏工作项

## 前置准备

检查工作区，使用Skill: git-worktree-master，检查当前是否处于需求工作区
**Skill**: git-worktree-master
**命令**: 检查工作区状态
**异常**: 终止行动，请求人工处理

## 工作流程

按照 task 模式，执行以下步骤：
Step 1. 开启 tdd 模式
Step 2. 调用总入口 Skill：`rq-auto-dev-orchestrator`
Step 3. 自动闭环执行（开发→测试→修复→评审）
Step 4. 完成收尾并输出最终交付报告

### Step 1: 开启tdd模式

调用命令：/oh-my-claudecode:tdd
```
/oh-my-claudecode:tdd
```

兼容性说明（降级路径）：
- 若当前环境不支持 `/oh-my-claudecode:tdd`，则跳过该命令，但仍需按 TDD 心智执行：先对照 `20-{stage_name}-需求测试设计.md` 明确验收标准，再实现与验证。

### Step 2: 调用总入口技能执行开发闭环

总入口 Skill：`rq-auto-dev-orchestrator`

由该技能统一协调以下技能执行需求开发：
- `rq-plan-runtime`
- `rq-stage-test-executor`
- `rq-defect-triage-fix-loop`
- `rq-review-gatekeeper`
- `rq-delivery-closure`

使用 executor 代理，根据需求标识启动自动闭环：
```
Task(
  subagent_type="requirement-coder",
  model="sonnet",
  prompt="RQ AUTO DEVELOP ORCHESTRATION

理解需求，读取计划和测试设计，执行开发闭环：

说明:
1. 需求标识，格式为：`{rq_id}`
2. 计划真源：`{project_root}/docs/requirement/{rq_id}/10-需求开发计划表.md`
3. 测试设计：`{project_root}/docs/requirement/{rq_id}/20-{stage_name}-需求测试设计.md`
4. 过程数据落盘：`.claude/notepads/{rq_id}/`
5. 调度 Skill: `rq-auto-dev-orchestrator`，执行自动闭环直到所有门禁通过
6. 遵循项目 `.claude/rules/` 下定义的规则
7. 允许在执行过程中调度子agent：
   - 前端实现：`oh-my-claudecode:designer`
   - 代码评审：`superpowers:code-reviewer`
   - 代码简化：`code-simplifier:code-simplifier`

以 `10-需求开发计划表.md` 为唯一计划真源，按阶段推进并支持 --continue 续跑"
)
```

### Step 3: 自动闭环细则（由总入口技能执行）

1. 按阶段执行开发任务
2. 执行阶段测试，失败则自动修复并回归
3. 进行代码评审门禁（优先 `superpowers:code-reviewer`）
4. Critical/Important 未清零不得放行
5. 阶段通过后推进下一阶段，直至全部完成

### Step 4. 收尾工作

总结开发过程，展示测试通过情况。

生成最终报告：
- `.claude/notepads/{rq_id}/final-delivery-report.md`
