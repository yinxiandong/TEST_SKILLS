---
name: feature-api-list-generator
description: API 功能特性清单生成。从后端代码、API 文档或路由定义中提取 API 接口信息，输出 CSV 格式的特性清单到 docs/features/，供 api-test-case-generator 消费。
---

# API 功能特性清单生成技能

## 调用方

- `api-test-orchestrator`：在 Phase 1 调用，生成特性清单
- 用户直接调用：为指定模块生成或更新 API 特性清单

## 与 feature-list-generator 的关系

- `feature-list-generator`：输出 **Markdown** 格式，供 `feature-curl-test-generator` 消费
- `feature-api-list-generator`（本技能）：输出 **CSV** 格式，供 `api-test-case-generator` 消费
- 两者独立，不互相依赖，但可共用分析过程中获取的接口信息

---

## 输入

- 后端代码目录路径（路由文件、控制器、DTO/Schema 定义）
- 或 API 文档（OpenAPI/Swagger JSON/YAML、Apifox 导出）
- 或已有的 `docs/feature-list/*.md` 特性文档（可从中提取）

---

## 执行流程

```
1. 确定分析范围（指定模块或全部模块）
2. 识别 API 接口来源：
   ├─ 路由定义文件（Express routes, FastAPI routers, Spring Controllers 等）
   ├─ OpenAPI/Swagger 文档
   ├─ 已有 feature-list Markdown 文档
   └─ Apifox/Postman 导出文件
3. 提取每个接口的元信息：
   ├─ 模块归属（module）
   ├─ 接口路径（api_path）
   ├─ HTTP 方法（method）
   ├─ 功能摘要（summary）
   ├─ 是否需要鉴权（auth_required）
   ├─ 请求内容类型（request_content_type）
   ├─ 参数类型标识（has_path_params, has_query_params, has_request_body）
   ├─ 响应类型（response_type）
   └─ 标签和备注
4. 去重：对比已有 CSV，跳过已存在的 api_path + method 组合
5. 输出 CSV 到 docs/features/{module}-api-features.csv
```

---

## CSV 格式

参见模板文件：`template/api-features.csv.template`

### 字段说明

| 字段 | 必填 | 说明 |
|------|------|------|
| `module` | 是 | 模块名称（如 auth, user, order） |
| `feature_id` | 是 | 特性唯一标识，格式 `F-{MODULE}-{SEQ}`（如 F-AUTH-001） |
| `api_path` | 是 | 接口路径（如 /api/v1/auth/login） |
| `method` | 是 | HTTP 方法（GET/POST/PUT/PATCH/DELETE） |
| `summary` | 是 | 功能描述（简明中文说明） |
| `auth_required` | 是 | 是否需要鉴权（true/false） |
| `request_content_type` | 否 | 请求体类型（application/json, multipart/form-data, 无则留空） |
| `has_path_params` | 是 | 是否有路径参数（true/false） |
| `has_query_params` | 是 | 是否有查询参数（true/false） |
| `has_request_body` | 是 | 是否有请求体（true/false） |
| `response_type` | 否 | 响应体类型（json/blob/text/无） |
| `tags` | 否 | 标签（逗号分隔，如 core,crud） |
| `status` | 是 | active / deprecated / planned |
| `notes` | 否 | 补充说明 |

### 兼容性约束

CSV 文件必须遵守以下规则，确保 `api-test-case-generator` 正确解析：

1. 使用 UTF-8 with BOM 编码
2. 第一行为表头，字段名与模板完全一致
3. `feature_id` 全局唯一
4. `method` 使用大写（GET, POST, PUT, PATCH, DELETE）
5. 布尔值统一使用小写 `true` / `false`
6. `tags` 字段内多值用逗号分隔，不加空格

---

## 分析策略（按技术栈）

### Node.js / Express

```
- 扫描 routes/*.ts, routes/*.js
- 识别 router.get/post/put/patch/delete 调用
- 从中间件推断鉴权需求（如 authMiddleware, requireAuth）
- 从 req.body, req.query, req.params 推断参数类型
```

### Python / FastAPI

```
- 扫描 routers/*.py, api/*.py
- 识别 @router.get/post/put/patch/delete 装饰器
- 从 Depends() 推断鉴权需求
- 从 Pydantic Model 推断请求体结构
```

### Java / Spring Boot

```
- 扫描 controller/*.java
- 识别 @GetMapping, @PostMapping 等注解
- 从 @PreAuthorize, @Secured 推断鉴权需求
- 从 @RequestBody DTO 推断请求体结构
```

### OpenAPI/Swagger 文档

```
- 解析 openapi.json / swagger.yaml
- 直接提取 paths 下所有接口信息
- 从 security 定义推断鉴权需求
- 从 requestBody/parameters schema 推断参数信息
```

---

## 输出路径

```
docs/features/
├── {module}-api-features.csv    # 按模块拆分的特性清单
└── ...
```

> **路径约定**：默认输出到 `docs/features/`，实际以 `tests/api-test/api-test.config.yaml` 的 `output.feature_dir` 配置为准。

---

## 约束

- 输出文件为 CSV 格式，不输出 Markdown
- 不修改后端源代码
- 不修改 `template/` 下的模板文件
- 未确认的信息标记 `notes` 字段为"待补充"
- `feature_id` 生成前检查已有 CSV 避免重复
