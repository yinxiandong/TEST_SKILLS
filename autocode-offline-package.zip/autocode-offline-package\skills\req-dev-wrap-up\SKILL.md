---
name: req-dev-wrap-up
description: 评审需求开发成果和代码，并对发现的问题进行修复
---

# Requirement Develop Wrap Up Skill

基于需求的开发任务，对需求开发的代码进行评审，发现遗漏工作项和代码问题，并进行修复，所有的修复要经过测试验证

如果需求还未进行开发，则按照开发计划进行tdd模式的开发工作，直到完成所有任务

如果需求设计和计划不完整，即使中断告知，禁止按照猜测完成工作

## Core Concept

### Requirement Document Location (READ ONLY)

需求文档描述了需求的背景、可行性分析、概要设计、架构设计和特性/任务分解
**DOC PATH**: {project_root}/docs/requirement/{rq_id}/

### Plan Location (READ ONLY)

需求计划是依据需求的分析设计，和分解的任务，按照依赖关系整理的行动方案
**PLAN PATH**: {project_root}/docs/requirement/{rq_id}/10-需求开发计划表.md
- plan-name = {rq_id}

### Development Rules Location (READ ONLY)

开发规范，是当前项目编码所必须遵循的准则，是review和coding的重要依据
DOC PATH: .claude/rules/**
- 规范文件按照模块区分目录：frontend、backend、{module}
- 规范按照开发项分类存放在不同文件：api、entity、component、and so on

### Notepad Location (for recording learnings)

coding过程记录，是可选输出件
NOTEPAD PATH: .claude/notepads/{rq_id}/
- learnings.md: Record patterns, conventions, successful approaches
- issues.md: Record problems, blockers, gotchas encountered
- decisions.md: Record architectural choices and rationales

### Subagent Dispatch (ALLOWED)

在符合工作流约束时，允许调度子agent完成专项工作：
- 前端实现：`oh-my-claudecode:designer`
- 代码评审：`superpowers:code-reviewer`
- 代码简化：`code-simplifier:code-simplifier`

## Execution Workflow
1. **READ**: 读取需求相关文档，理解需求
2. **IDENTIFY**: 依照需求开发计划，确认coding进度和代码质量，如果发现coding还没有开始，则要求你按照开发计划和要求全量进行需求的开发
3. **RUN**: 补充缺失项的开发工作，修复代码质量问题 (test, build, lint)
4. **TEST**: 对完成的工作进行完整的测试
5. **PREVIEW**: 再次审视整体需求的完成情况，有未完成工作需要到步骤3继续

## 原则
- 遵循TDD规范，开发前先设计测试用例，完成的代码一定经过测试
- 禁止猜测，即使提问
- 必须依照代码规范：.claude/rules/**
- 必须以 `10-需求开发计划表.md` 作为唯一计划真源
- 中间过程文件统一写入 `.claude/notepads/`
