#!/usr/bin/env python3
import argparse
import json
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


def run_cmd(cmd: List[str], cwd: Optional[Path] = None) -> Tuple[int, str]:
    proc = subprocess.run(cmd, cwd=str(cwd) if cwd else None, text=True, capture_output=True)
    out = (proc.stdout or "") + (proc.stderr or "")
    return proc.returncode, out


def load_json(path: Path) -> Dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise RuntimeError(f"JSON 顶层必须为对象: {path}")
    return data


def find_server(config: Dict[str, Any], name: str) -> Dict[str, Any]:
    for s in config.get("servers") or []:
        if isinstance(s, dict) and s.get("name") == name:
            return s
    raise RuntimeError(f"未找到服务器: {name}")


def ensure_whitelist(config: Dict[str, Any], server_name: str) -> None:
    regex = r"^(dev|test)"
    meta = config.get("meta") if isinstance(config.get("meta"), dict) else {}
    if meta.get("server_name_whitelist_regex"):
        regex = str(meta.get("server_name_whitelist_regex"))
    if not re.search(regex, server_name):
        raise RuntimeError(f"服务器不在白名单内: {server_name}, regex={regex}")


def main() -> None:
    parser = argparse.ArgumentParser(description="remote-dev-debug: 通用远程调试编排")
    parser.add_argument("--server", required=True)
    parser.add_argument("--service", required=True, help="services[].service_id")
    parser.add_argument("--config", default=".secrets/dev-servers.yaml")
    parser.add_argument("--api-spec-file", default="", help="remote-api-debug 的 spec 文件")
    parser.add_argument("--artifact", default="", help="可选部署 artifact（systemd/script）")
    parser.add_argument(
        "--deploy",
        choices=["auto", "skip", "always"],
        default="auto",
        help="是否执行 deploy_remote.sh：auto=仅当提供 --artifact 时执行；skip=不执行；always=每轮都执行（需要 --confirm-deploy）",
    )
    parser.add_argument("--confirm-deploy", action="store_true", help="允许执行 deploy_remote.sh（写操作门禁）")
    parser.add_argument("--max-rounds", type=int, default=3)
    parser.add_argument("--cmd-timeout", type=int, default=600, help="单步命令超时（秒），用于避免 ssh 卡死导致编排阻塞")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    project_root = Path(".").resolve()
    config_path = Path(args.config).resolve()
    if not config_path.exists():
        raise SystemExit(f"[ERROR] 配置文件不存在: {config_path}")

    cfg = load_json(config_path)
    ensure_whitelist(cfg, args.server)
    _ = find_server(cfg, args.server)

    probe_script = ["bash", ".codex/skills/remote-dev-deploy/scripts/probe_remote.sh", "--server", args.server, "--service", args.service, "--config", str(config_path)]
    deploy_script_base = ["bash", ".codex/skills/remote-dev-deploy/scripts/deploy_remote.sh", "--server", args.server, "--service", args.service, "--config", str(config_path)]
    if args.artifact:
        deploy_script_base += ["--artifact", args.artifact]
    api_script = ["bash", ".codex/skills/remote-api-debug/scripts/api_debug.sh", "--server", args.server, "--config", str(config_path), "--spec-file", args.api_spec_file]
    log_script = ["bash", ".codex/skills/remote-log-diagnose/scripts/log_diagnose.sh", "--server", args.server, "--service", args.service, "--config", str(config_path)]

    def should_deploy() -> bool:
        if args.deploy == "skip":
            return False
        if args.deploy == "always":
            return True
        # auto
        return bool(args.artifact)

    def build_deploy_script() -> List[str]:
        if not args.confirm_deploy:
            raise RuntimeError("需要执行 deploy 但未授权：请加 --confirm-deploy")
        return [*deploy_script_base, "--confirm"]

    if args.dry_run:
        deploy_plan = "<skip>"
        if should_deploy():
            try:
                deploy_plan = " ".join(map(shlex.quote, build_deploy_script()))
            except Exception as exc:
                deploy_plan = f"<blocked: {exc}>"
        print("PLAN_SUMMARY=" + json.dumps({
            "probe": " ".join(map(shlex.quote, probe_script)),
            "deploy": deploy_plan,
            "api": " ".join(map(shlex.quote, api_script)) if args.api_spec_file else "<skip>",
            "log": " ".join(map(shlex.quote, log_script)),
        }, ensure_ascii=False))
        print("FINAL_RESULT=DRY_RUN")
        return

    def run_with_timeout(cmd: List[str]) -> Tuple[int, str]:
        try:
            proc = subprocess.run(cmd, cwd=str(project_root), text=True, capture_output=True, timeout=int(args.cmd_timeout))
            out = (proc.stdout or "") + (proc.stderr or "")
            return proc.returncode, out
        except subprocess.TimeoutExpired:
            return 124, f"[ERROR] 命令超时（{args.cmd_timeout}s）: {' '.join(map(shlex.quote, cmd))}\n"

    for round_no in range(1, max(1, args.max_rounds) + 1):
        print(f"[ROUND] {round_no}")
        code, out = run_with_timeout(probe_script)
        print(out)
        if code != 0:
            print("ESCALATION_REPORT=" + json.dumps({"reason": "probe_failed", "round": round_no}, ensure_ascii=False))
            print("FINAL_RESULT=NEED_HUMAN")
            sys.exit(3)

        if should_deploy():
            try:
                deploy_script = build_deploy_script()
            except Exception as exc:
                print(f"[ERROR] {exc}")
                print("ESCALATION_REPORT=" + json.dumps({"reason": "deploy_not_confirmed", "round": round_no}, ensure_ascii=False))
                print("FINAL_RESULT=NEED_HUMAN")
                sys.exit(4)
            code, out = run_with_timeout(deploy_script)
            print(out)
            if code != 0:
                code2, out2 = run_with_timeout(log_script)
                print(out2)
                print("ESCALATION_REPORT=" + json.dumps({"reason": "deploy_failed", "round": round_no}, ensure_ascii=False))
                print("FINAL_RESULT=NEED_HUMAN")
                sys.exit(4)
        else:
            print("[STEP] deploy skipped")

        if args.api_spec_file:
            api_code, api_out = run_with_timeout(api_script)
            print(api_out)
            if api_code == 0 and "SUMMARY: PASS" in api_out:
                print("FINAL_RESULT=SUCCESS")
                return

            _lc, lo = run_with_timeout(log_script)
            print(lo)
            if round_no >= args.max_rounds:
                print("ESCALATION_REPORT=" + json.dumps({"reason": "api_failed", "round": round_no}, ensure_ascii=False))
                print("FINAL_RESULT=NEED_HUMAN")
                sys.exit(5)
            time.sleep(2)
            continue

        print("FINAL_RESULT=SUCCESS")
        return


if __name__ == "__main__":
    main()
