#!/usr/bin/env bash
set -euo pipefail

SERVER_NAME=""
CONFIG_PATH=".secrets/dev-servers.yaml"
INSECURE_TLS="false"

usage() {
  cat <<'USAGE'
用法:
  probe_remote_nacos.sh --server <name> [--config <path>] [--insecure-tls]
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --server)
      SERVER_NAME="$2"; shift 2 ;;
    --config)
      CONFIG_PATH="$2"; shift 2 ;;
    --insecure-tls)
      INSECURE_TLS="true"; shift ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "[ERROR] 未知参数: $1"; usage; exit 1 ;;
  esac
done

if [[ -z "$SERVER_NAME" ]]; then
  echo "[ERROR] --server 必填"; usage; exit 1
fi

if [[ ! -f "$CONFIG_PATH" ]]; then
  echo "[ERROR] 配置文件不存在: $CONFIG_PATH"; exit 1
fi

for cmd in python3; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[ERROR] 缺少命令: $cmd"; exit 1
  fi
done

python3 - "$CONFIG_PATH" "$SERVER_NAME" "$INSECURE_TLS" <<'PY'
import json
import sys
import urllib.error
import urllib.request
import ssl
import atexit
import os
import signal
import socket
import time
import subprocess
import shutil

config_path, server_name, insecure_tls = sys.argv[1:]
insecure_tls = insecure_tls.lower() == 'true'

cfg = json.loads(open(config_path,'r',encoding='utf-8').read())
server = next((s for s in cfg.get('servers',[]) if isinstance(s,dict) and s.get('name')==server_name), None)
if not server:
    print(f"[ERROR] 未找到服务器: {server_name}")
    sys.exit(1)

comp = server.get('components') if isinstance(server.get('components'), dict) else {}
nacos = comp.get('nacos') if isinstance(comp.get('nacos'), dict) else None
if not nacos:
    nacos = server.get('nacos') if isinstance(server.get('nacos'), dict) else None
    if nacos:
        print('[WARN] 检测到已废弃字段 servers[].nacos，请迁移到 servers[].components.nacos')

if not nacos:
    print('[ERROR] 未配置 servers[].components.nacos')
    sys.exit(2)

protocol = str(nacos.get('protocol') or 'http')
host = str(nacos.get('host') or (server.get('ssh') or {}).get('host') or server.get('host') or '')
port = int(nacos.get('port') or nacos.get('server_port') or 8848)
api_version = str(nacos.get('api_version') or 'v1')
access = nacos.get('access') if isinstance(nacos.get('access'), dict) else {}
access_mode = str(access.get('mode') or 'direct')
if access_mode == 'ssh' and not str(nacos.get('host') or '').strip():
    host = '127.0.0.1'

ssh = server.get('ssh') if isinstance(server.get('ssh'), dict) else {}
ssh_auth = ssh.get('auth') if isinstance(ssh.get('auth'), dict) else {}
ssh_host = str(ssh.get('host') or '')
ssh_port = int(ssh.get('port') or 22)
ssh_user = str(ssh.get('username') or '')
ssh_auth_type = str(ssh_auth.get('type') or 'password')
ssh_password = str(ssh_auth.get('password') or '')
ssh_identity = str(ssh_auth.get('identity_file') or '')
defaults = server.get('defaults') if isinstance(server.get('defaults'), dict) else {}
known_hosts_file = str(defaults.get('known_hosts_file') or '/tmp/remote-dev-deploy-known-hosts')
strict = 'yes' if bool(defaults.get('strict_host_key_check') or False) else 'no'

tunnel_proc = None
def _cleanup() -> None:
    global tunnel_proc
    if tunnel_proc is None:
        return
    try:
        if hasattr(os, 'killpg'):
            os.killpg(os.getpgid(tunnel_proc.pid), signal.SIGTERM)
        else:
            tunnel_proc.terminate()
        tunnel_proc.wait(timeout=2)
    except Exception:
        pass
    tunnel_proc = None

def pick_free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    p = int(s.getsockname()[1])
    s.close()
    return p

def wait_listen(p: int, timeout_s: float = 4.0) -> bool:
    end = time.time() + timeout_s
    while time.time() < end:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.3)
            s.connect(('127.0.0.1', p))
            s.close()
            return True
        except Exception:
            try:
                s.close()
            except Exception:
                pass
            time.sleep(0.1)
    return False

def start_ssh_tunnel(target_host: str, target_port: int) -> int:
    global tunnel_proc
    if not ssh_host or not ssh_user:
        raise RuntimeError('servers[].ssh.host/username 为空，无法建立 ssh tunnel')
    lp = pick_free_port()
    ssh_cmd = [
        'ssh',
        '-p', str(ssh_port),
        '-o', f'StrictHostKeyChecking={strict}',
        '-o', f'UserKnownHostsFile={known_hosts_file}',
        '-o', 'ConnectTimeout=8',
        '-o', 'ExitOnForwardFailure=yes',
        '-o', 'ServerAliveInterval=5',
        '-o', 'ServerAliveCountMax=3',
        '-N',
        '-L', f'127.0.0.1:{lp}:{target_host}:{int(target_port)}',
    ]
    if ssh_auth_type == 'key' and ssh_identity:
        ssh_cmd += ['-i', ssh_identity, '-o', 'BatchMode=yes']
    ssh_cmd.append(f'{ssh_user}@{ssh_host}')
    if ssh_auth_type == 'password':
        if not ssh_password:
            raise RuntimeError('ssh.auth.password 为空，无法建立 tunnel')
        if shutil.which('sshpass') is None:
            raise RuntimeError('缺少 sshpass（password 认证需要）')
        ssh_cmd = ['sshpass', '-p', ssh_password] + ssh_cmd
    tunnel_proc = subprocess.Popen(
        ssh_cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        preexec_fn=os.setsid if hasattr(os, 'setsid') else None,
    )
    atexit.register(_cleanup)
    if not wait_listen(lp, timeout_s=4.0):
        err = ''
        try:
            err = (tunnel_proc.stderr.read(2000) if tunnel_proc.stderr else '')  # type: ignore[union-attr]
        except Exception:
            err = ''
        raise RuntimeError(f'ssh tunnel 建立失败: {err.strip()}')
    return lp

base = f"{protocol}://{host}:{port}"
try:
    if access_mode == 'ssh':
        local_port = start_ssh_tunnel(host or '127.0.0.1', port)
        base = f"{protocol}://127.0.0.1:{local_port}"
except Exception as exc:
    print(f"[ERROR] {exc}")
    sys.exit(8)

ctx = None
if insecure_tls and protocol == 'https':
    ctx = ssl._create_unverified_context()

def try_guess_version() -> str:
    # 只做“路径可达性”提示：不登录
    candidates = [
        ('v3', base + '/v3/auth/user/login', 'POST'),
        ('v1', base + '/nacos/v1/auth/login', 'POST'),
        ('v1', base + '/nacos', 'GET'),
    ]
    for ver, u, method in candidates:
        try:
            req = urllib.request.Request(u, method=method)
            kwargs = {"timeout": 3}
            if ctx is not None:
                kwargs["context"] = ctx
            with urllib.request.urlopen(req, **kwargs) as resp:
                return ver
        except urllib.error.HTTPError as exc:
            # 401/403/405/400 都视为“路径存在”
            if exc.code in (400, 401, 403, 405):
                return ver
        except Exception:
            pass
    return ''

hint_ver = try_guess_version()
if hint_ver and (not nacos.get('api_version')):
    api_version = hint_ver

url = base + ('/nacos' if api_version == 'v1' else '')

try:
    req = urllib.request.Request(url, method='GET')
    kwargs = {"timeout": 5}
    if ctx is not None:
        kwargs["context"] = ctx
    with urllib.request.urlopen(req, **kwargs) as resp:
        print(f"[INFO] base_url={base} api_version_hint={api_version} status={getattr(resp,'status',None)}")
        print('[RESULT] PROBE_SUCCESS')
        sys.exit(0)
except urllib.error.HTTPError as exc:
    print(f"[WARN] base_url={base} api_version_hint={api_version} http_status={exc.code}")
    print('[RESULT] PROBE_PARTIAL')
    sys.exit(0)
except Exception as exc:
    print(f"[ERROR] 访问失败: base_url={base}, err={exc}")
    print('[RESULT] PROBE_FAILED')
    sys.exit(3)
PY
