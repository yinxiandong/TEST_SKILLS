---
name: e2e-orchestrator
description: E2E 测试两阶段调度中心。协调用例生成（e2e-case-generator）→ 脚本生成（e2e-script-generator）→ Playwright 执行 → 报告构建（e2e-report-builder）全流程。支持需求驱动、代码提取、Git 变动三条路径。
---

# E2E 测试编排技能（两阶段调度中心）

统一承接当前仓库中的 E2E 执行入口，面向用户直接调用和需求工作流内嵌调用两种场景。

## 调用方

- 用户直接调用：独立生成、维护和执行 E2E 测试
- `rq-stage-test-executor`：阶段测试设计中存在 `test_type: e2e` 用例时调用
- `rq-auto-dev-orchestrator`：所有阶段完成后的全量 E2E 回归调用

---

## 输入路径选择

用户启动时，首先选择生成路径：

| 路径 | 触发条件 | 说明 |
|------|---------|------|
| **路径 A：需求驱动** | 提供需求文档路径 / 工作流内嵌调用 | 从需求测试设计中提取 e2e 场景 |
| **路径 B：代码提取** | 提供前端代码目录 | 分析路由、组件、API 自动生成用例 |
| **路径 C：Git 刷新** | 提供 commit 范围 | 根据代码变动增量更新用例 |
| **执行模式（无生成）** | 已有用例和脚本，仅需运行 | 跳过一/二阶段，直接执行并生成报告 |

---

## 两阶段执行流程

```
┌─────────────────────────────────────────────────────────┐
│                 e2e-orchestrator（调度中心）              │
│                                                           │
│  路径选择 ─────→ 一阶段：e2e-case-generator              │
│  (A/B/C)          ├─ 分层覆盖方法论驱动用例生成          │
│                   ├─ 输出 YAML → tests/ui-test/usecase/  │
│                   └─ 同步 CSV 注册表                      │
│                           │                              │
│                           ▼                              │
│                 二阶段：e2e-script-generator              │
│                   ├─ 读取 YAML 用例                      │
│                   ├─ 生成 Playwright 脚本 → scripts/     │
│                   └─ 回填 CSV script_path               │
│                           │                              │
│                           ▼                              │
│                 执行：Playwright 多浏览器回归             │
│                           │                              │
│                           ▼                              │
│                 报告：e2e-report-builder                  │
│                   ├─ ai-report.json → .tests/            │
│                   └─ report.html → .tests/               │
└─────────────────────────────────────────────────────────┘
```

---

## 详细执行步骤

### Step 1：环境检测

1. 检查项目是否已集成 E2E（参见 `e2e-checker`）
2. 若未集成，先执行 `e2e-checker` 输出接入方案，不继续执行
3. 读取现有 E2E 资产：
   - `tests/ui-test/playwright.config.ts`（确认 `testDir` 为 `tests/ui-test/scripts`）
   - `tests/ui-test/usecase/`（已有 YAML 用例）
   - `tests/ui-test/scripts/`（已有 Playwright 脚本）
   - `tests/ui-test/testcase-registry.csv`（用例注册表）

### Step 2：路径判断与用例生成（一阶段）

调用 `e2e-case-generator`，根据用户选择的路径执行：

- **路径 A**：从 `docs/requirement/{rq_id}/20-{stage}-需求测试设计.md` 提取 `test_type: e2e` 场景
- **路径 B**：分析前端源代码，提取路由、表单、组件交互
- **路径 C**：分析指定 commit 范围的 git 变动

**执行模式**（跳过此步骤）：直接使用已有 YAML 用例

### Step 3：脚本生成（二阶段）

调用 `e2e-script-generator`：

1. 读取 `tests/ui-test/usecase/` 中的 YAML 用例
2. 生成/更新 Playwright 脚本到 `tests/ui-test/scripts/`
3. 回填 CSV 中的 `script_path`

**执行模式**（跳过此步骤）：直接使用已有脚本

### Step 4：筛选执行范围

根据执行需求筛选用例：

| 执行模式 | 筛选条件 | 说明 |
|---------|---------|------|
| 冒烟测试 | `smoke=Y` | 仅运行冒烟用例 |
| 分级执行 | 按 level 筛选 | P0 / P0+P1 / 全量 |
| 指定分类 | 按 category 筛选 | 如仅运行 auth 分类 |
| 全量回归 | 全部 `status=active` | 默认模式 |
| 工作流内嵌 | 按 `test_type: e2e` 场景 | 阶段测试时使用 |

按优先级排序：P0 → P1 → P2 → P3

### Step 5：执行 Playwright 测试

**执行前：生成 run-id**

在执行 Playwright 之前，先生成本次运行的唯一 `run-id`，格式为 `run-YYYYMMDD-HHMMSS`，通过环境变量 `PLAYWRIGHT_OUTPUT_DIR` 传入，使 Playwright 将原始产物写入 `.tests/reports/{run-id}/` 目录：

```bash
# 生成 run-id（Shell）
RUN_ID="run-$(date +%Y%m%d-%H%M%S)"
PLAYWRIGHT_OUTPUT_DIR=".tests/reports/${RUN_ID}"

# 默认：全量多浏览器回归（原始产物写入 .tests/reports/{run-id}/）
PLAYWRIGHT_OUTPUT_DIR=".tests/reports/${RUN_ID}" npx playwright test --config tests/ui-test/playwright.config.ts tests/ui-test/scripts/

# 冒烟测试
PLAYWRIGHT_OUTPUT_DIR=".tests/reports/${RUN_ID}" npx playwright test --config tests/ui-test/playwright.config.ts --grep "@smoke"

# 指定分类
PLAYWRIGHT_OUTPUT_DIR=".tests/reports/${RUN_ID}" npx playwright test --config tests/ui-test/playwright.config.ts tests/ui-test/scripts/auth/

# CI 环境
CI=true PLAYWRIGHT_OUTPUT_DIR=".tests/reports/${RUN_ID}" npx playwright test --config tests/ui-test/playwright.config.ts
```

> **说明**：`tests/ui-test/playwright.config.ts` 中 reporter 路径通过 `process.env.PLAYWRIGHT_OUTPUT_DIR` 读取（见模板注释），若未传入则默认写入 `.tests/playwright-raw/`（用于调试场景）。

失败时：
- 保留原始错误输出，不得伪造通过证据
- P0 用例失败：立即标记为 `fail`，不等待全量完成

### Step 6：生成报告

将 `run-id` 和 Playwright 原始产物目录传给 `e2e-report-builder`：

1. 传入 `run_id`（Step 5 生成的 `RUN_ID`）和原始产物路径 `.tests/reports/{run-id}/`
2. report-builder 解析 JUnit XML / JSON 结果文件
3. 读取 CSV 注册表，补充用例元信息（level、smoke、category）
4. 生成 `ai-report.json` 和 `report.html`，写入 `.tests/reports/{run-id}/`
5. 更新软链接 `.tests/latest → .tests/reports/{run-id}/`

---

## 输出契约

### 输出路径

- 独立执行：`.tests/reports/{run-id}/ai-report.json`
- 工作流内嵌：同上，**同时**将 `ai-report.json` 内容复制写入调用方指定的 `result_output_path`（如 `.claude/notepads/{rq_id}/e2e-result-{stage_slug}.json`）

> **`result_output_path` 参数**：工作流内嵌调用时，调用方（如 `rq-stage-test-executor`）应在调用 `e2e-orchestrator` 时传入 `result_output_path`。`e2e-orchestrator` 在 Step 6 完成后，将 `ai-report.json` 的完整内容写入该路径，供调用方直接读取，无需额外适配层。未传入时仅写 `.tests/reports/{run-id}/ai-report.json`。

### JSON 结构（ai-report.json）

参见 `e2e-report-builder/template/ai-report.json.template`

关键字段：

```json
{
  "run_id": "run-20260314-143052",
  "result": "pass | fail | warn",
  "summary": { "total": N, "passed": N, "failed": N, "flaky": N, "pass_rate": "X%", "duration_ms": N },
  "smoke_result": { "total": N, "passed": N, "pass_rate": "X%" },
  "level_breakdown": { "P0": {...}, "P1": {...}, "P2": {...}, "P3": {...} },
  "browser_breakdown": { "chromium": {...}, "firefox": {...}, "webkit": {...} },
  "failed_cases": [{ "case_id": "...", "case_name": "...", "level": "...", "browser": "...", "error": "...", "screenshot": "...", "trace": "..." }],
  "flaky_cases": [{ "case_id": "...", "stability": "7/10", "failure_pattern": "...", "suggested_fix": "..." }],
  "coverage": { "pages_covered": N, "pages_total": N, "page_coverage": "X%", "categories": [...] },
  "artifacts": {
    "html_report": ".tests/reports/{run-id}/report.html",
    "junit_xml": ".tests/reports/{run-id}/junit.xml",
    "ai_report": ".tests/reports/{run-id}/ai-report.json"
  }
}
```

---

## 成功指标

| 指标 | 要求 |
|------|------|
| P0 用例通过率 | 100% |
| P1 用例通过率 | ≥ 95% |
| 整体通过率 | ≥ 90% |
| Flaky 比例 | < 5% |
| 单次回归时长 | < 10 分钟 |

---

## 失败处理

| 场景 | 处理方式 |
|------|---------|
| 项目未集成 E2E | 停止执行，转 `e2e-checker` |
| P0 用例失败 | 直接判定整体 fail，不允许豁免 |
| Flaky 比例过高 | 标记 `warn`，给出隔离修复建议 |
| 执行超时 | 保留已有 artifact，返回 fail 并提示人工介入 |
| 无可用脚本（pending 状态用例） | 先执行二阶段脚本生成，再执行 |

---

## 与其他技能的关系

| 技能 | 关系 |
|------|------|
| `e2e-checker` | 环境检测；发现未接入时引导接入 |
| `e2e-case-generator` | 一阶段：用例生成（YAML + CSV） |
| `e2e-script-generator` | 二阶段：脚本生成（Playwright spec） |
| `e2e-testing` | 提供执行规范（POM、等待策略、artifact、CI/CD） |
| `e2e-report-builder` | 报告构建（AI JSON + HTML） |
| `rq-stage-test-executor` | 消费本技能输出的 ai-report.json |

---

## 约束

- 不绕过真实执行证据
- 不为未明确要求的场景补写额外测试
- 不修改与当前 E2E 目标无关的项目资产
- CSV 注册表操作由各子技能负责，orchestrator 只读
