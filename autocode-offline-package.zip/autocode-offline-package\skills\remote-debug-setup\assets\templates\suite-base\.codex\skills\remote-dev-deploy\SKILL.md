---
name: remote-dev-deploy
description: "通用远程部署/重启/检查技能。读取项目内 .secrets/dev-servers.yaml（v2 schema，按 services[] 配置），支持 systemd / 脚本 / docker 三种服务形态；可选上传本地产物并替换远端 artifact（systemd/脚本模式），并输出半自动回滚命令。用于开发/测试环境的远程部署、快速回滚与部署后自检。"
---

# remote-dev-deploy

## 概述

本技能面向“开发/测试环境”的远程部署与重启。

特点：

- 按 `.secrets/dev-servers.yaml` 的 `servers[].services[]` **逐服务**执行
- 支持 `systemd` / `script` / `docker`
- 默认只输出回滚计划，不自动回滚

## 前置条件

- 目标项目根目录存在：`.secrets/dev-servers.yaml`（推荐由 `remote-debug-setup` 生成）
- 本机可用：`ssh`、`sftp`、`python3`
- 若 SSH 认证为 password：本机需 `sshpass`

## 工作流

1) 只读探测：`scripts/probe_remote.sh`
2) 远程部署/重启：`scripts/deploy_remote.sh`

## 用法

### 1) 探测服务器与服务映射

```bash
.codex/skills/remote-dev-deploy/scripts/probe_remote.sh \
  --server dev1 \
  --config .secrets/dev-servers.yaml
```

### 2) 部署或重启单个服务

```bash
.codex/skills/remote-dev-deploy/scripts/deploy_remote.sh \
  --server dev1 \
  --service svc-app \
  --confirm \
  --config .secrets/dev-servers.yaml
```

### 3) 上传并替换 artifact（systemd/脚本模式）

```bash
.codex/skills/remote-dev-deploy/scripts/deploy_remote.sh \
  --server dev1 \
  --service svc-app \
  --artifact /path/to/app.jar \
  --confirm \
  --config .secrets/dev-servers.yaml
```
