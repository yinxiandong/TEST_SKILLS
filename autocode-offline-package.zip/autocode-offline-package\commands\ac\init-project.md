---
name: init-project
description: "初始化项目文档体系，将现有项目改造为符合AI编码规范的结构，以项目构建成功为环境就绪判定标准"
category: workflow
---

# /init-project - 项目初始化命令

## 使用方法

```
/init-project [选项]
```

## 工作流程
调用：`skills/project-initialize` 对当前项目识别并完成初始化工作
```
Skill(project-initialize)
```

**流程概要**：
1. 前置检查
2. 判断初始化进度
3. 子模块分析
4. 整体架构提取
5. AGENTS生成
6. 结束检查和继续迭代
7. 初始化收尾工作
8. 初始化报告生成

**关键约束**：
- 在应用项目中文档时，禁止使用绝对路径，应当使用项目的当前相对路径，如使用 `{project_root}` 表示当前项目根路径，`{module_root}` 表示对应子模块根路径
- 不确定的依赖必须人工确认，禁止猜测
