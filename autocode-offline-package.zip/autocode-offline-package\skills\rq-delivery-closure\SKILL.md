---
name: rq-delivery-closure
description: 在所有阶段完成后进行交付收尾，校验计划完成度、测试通过率与评审结论并生成最终报告。Use when all development stages are done and final delivery gate must be decided.
---

# RQ 交付收尾

用于需求开发流程末端，做一次全量核对并输出最终交付报告。

## 输入

### 必需输入

- 需求标识：`{rq_id}`
- 计划文件：`docs/requirement/{rq_id}/10-需求开发计划表.md`
- 运行态：`.claude/notepads/{rq_id}/runtime-status.md`
- 阶段测试报告：`.claude/notepads/{rq_id}/test-report-*.md`
- 阶段评审报告：`.claude/notepads/{rq_id}/review-report-*.md`
- 评审汇总：`.claude/notepads/{rq_id}/review-summary.md`

## 输出

路径：`.claude/notepads/{rq_id}/final-delivery-report.md`

## 核验项（硬性）

1. 计划任务完成率 = 100%
2. 各阶段测试通过率 = 100%
3. 评审 Critical = 0
4. 评审 Important = 0
5. 无未关闭阻塞项

任一不满足则输出 `blocked` 并列出缺口。

## 汇总规则（硬性）

1. 按 `runtime-status.md` 的阶段列表逐阶段核对：
   - 是否存在 `test-report-{stage_slug}.md`
   - 是否存在 `review-report-{stage_slug}.md`
2. `review-summary.md` 仅作为辅助索引，最终结论以分阶段报告为准。
3. 禁止仅依据单个评审文件做全局通过判定。

## 输出模板

```markdown
# 最终交付报告 - {rq_id}

## 1. 交付概览
- status: completed/blocked
- completed_at:

## 2. 计划完成情况
| 维度 | 结果 |
|---|---|
| 任务完成率 | 100% |
| 子任务完成率 | 100% |

## 3. 测试结果汇总
| 阶段 | 通过率 | 结论 |
|---|---|---|

## 4. 评审结果汇总
- Critical: 0
- Important: 0
- Minor: N

## 5. 关键修复摘要
- 问题A -> 修复动作 -> 验证证据

## 6. 结论
- 是否可进入人工验收: 是/否
```
