---
name: update-claude-rules
description: "从一个完成了深度分析的模块中，提取开发规范到rules文件"
---

# Update Claude Rules Skill

遵循Claude Rules规则，基于深度分析的多层AGENTS.md文档，结合必要代码分析，提取开发规范Rules文件

## Core Concept

Claude Rules：
- @references/claude-rules-def.md

AGENTS.md：serve as **AI-readable documentation**

## 路径约定（重要）

- 本技能会被安装到“工具目录”的 `skills/` 下。
- 统一使用 `{tool_root}` 表示工具目录根：
  - 项目级安装：`{project_root}/.claude` 或 `{project_root}/.codex`（以当前工具为准）
  - 用户级安装：`~/.claude` 或 `~/.codex`

## Execution Workflow

### Step 1: 理解Rules规则

读取Skill下references/claude-rules-def.md规则说明文档
```
Read("{tool_root}/skills/update-claude-rules/references/claude-rules-def.md")
```

### Step 2: AGENTS.md读取

```
Task(subagent_type="explore", model="haiku",
  prompt="List all AGENTS.md file in this module recursively")
```

### Step 3: Rules整理

**重要**：当前步骤需要人工确认

1. 分析每一个AGENTS.md文档，提取规则分类
2. 分析合并相同类型的规则，整理出所有待提取的规则
3. 输出待人工确认

规则分类参考：
  - 生成目录规范
  - 代码风格
  - （backend）API代码规范（包括Request/Response定义）
  - （backend）Entity代码规范（包括Mapper）
  - （frontend）状态管理规范
  - （frontend）路由配置规范
  - （frontend）组件开发规范
  - and so on

### Step 4: Rules生成

目录（**不在子模块，而在项目根目录**）：
```
{project_root}/.claude/rules/
```

规范：
读取 @`references/claude-rules-spec.md`
```
Read("{tool_root}/skills/update-claude-rules/references/claude-rules-spec.md")
```

规则：
 - 按照规范所对应的技术栈区分第一级目录
 - 按照开发规范类型区分第二级目录

对每种规则类型生成一个task，每个task中执行：
  - 基于AGENTS.md，找到规则对应的现有代码片段
  - 在当前项目 {project_root}/.claude/rules/ 目录下，生成带 YAML frontmatter 的 rules 文件

**参考资料**：
- 详细的路径推断算法见 [@references/path-mapping-rules.md](references/path-mapping-rules.md)
- 技术栈类型：frontend、backend、testing、and so on

## 执行约束

### 写入边界

- **完全允许**：`{project_root}/.claude/rules/` - 创建和写入 rules 文件
- **禁止**：修改目标项目的源代码、构建配置、其他文档
