---
name: rq-defect-triage-fix-loop
description: 对开发和测试失败进行分诊、最小化修复并回归验证，直到门禁通过或升级人工。Use when stage test or review gates fail and automatic fix-loop is required.
---

# RQ 缺陷分诊与修复循环

用于测试失败、构建失败、规则违规后的自动修复闭环。

## 输入

### 必需

- 需求标识：`{rq_id}`
- 当前阶段：`{stage_name}`
- 阶段标识：`{stage_slug}`
- 测试报告：`.claude/notepads/{rq_id}/test-report-{stage_slug}.md`
- 运行态：`.claude/notepads/{rq_id}/runtime-status.md`

### 可选

- 评审报告：`.claude/notepads/{rq_id}/review-report-{stage_slug}.md`
- 开发规则：`.claude/rules/**`

## 输出

- 修复记录：`.claude/notepads/{rq_id}/fix-log-{stage_name}.md`
- 运行态重试次数更新：`runtime-status.md`

## 运行态写入规则（硬性）

- 更新 `runtime-status.md` 前必须获取 `runtime-status.lock`
- 更新采用“临时文件 -> 原子替换”
- 写入失败保留旧文件并记录错误

## 缺陷分类

1. `impl_bug`：实现缺陷（逻辑/边界/异常处理）
2. `test_data_issue`：测试数据或前置条件问题
3. `env_issue`：环境依赖/配置问题
4. `rule_violation`：不符合 `.claude/rules/**`
5. `unknown`：无法明确归因，触发人工升级

## 修复流程

### Step 1：读取失败证据

1. 提取失败用例、错误栈、失败上下文。
2. 对失败项逐条分诊并生成修复清单。

### Step 2：最小化修复

1. 优先修复 P0/P1 对应问题。
2. 禁止通过注释测试、跳过断言等方式“假通过”。
3. 修复后执行受影响测试进行快速验证。

### Step 3：阶段回归

1. 快速验证通过后，触发阶段测试全量回归。
2. 更新 `test-report-{stage_slug}.md` 和 `fix-log-{stage_name}.md`。

### Step 4：重试与升级

1. 每轮修复后 `retry_count +1`。
2. 超过阈值（默认 5）仍失败，生成人工升级说明并阻塞。

## 升级输出（阻塞时必填）

在 `fix-log-{stage_name}.md` 增加：

- 已尝试修复列表
- 每次修复结果
- 当前阻塞根因
- 需要人工决策点
