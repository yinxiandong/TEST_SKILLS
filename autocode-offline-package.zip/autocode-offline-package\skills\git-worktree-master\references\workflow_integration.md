# Git Worktree 工作流集成指南

本文档详细说明 git-worktree-master skill 如何与需求开发工作流的各个阶段集成。

## 工作流概览

```
需求输入
   ↓
[创建工作区] ← git-worktree-master
   ↓
需求分析 (/analysis-rq)
   ↓
开发准备 (/prepare-rq)
   ↓
开发实施 (/develop-rq)
   ↓
需求完成
   ↓
[清理工作区] ← git-worktree-master
```

## 阶段 0：创建工作区（需求分析前）

### 时机

在执行 `/analysis-rq` 命令之前，必须先创建需求工作区。

### 为什么要提前创建

1. **隔离环境**：避免需求分析产生的文档污染主分支
2. **分支管理**：提前绑定需求分支，后续无需切换
3. **子模块同步**：确保所有子模块都在正确的分支上
4. **工作连续性**：从分析到开发全程在同一工作区

### 操作步骤

```bash
# 1. 在主仓库根目录执行
cd /home/workspace/ai-flow-rad

# 2. 创建需求工作区
./skills/git-worktree-master/scripts/worktree_manager.sh create rq001-s3-storage-manage

# 3. 自动完成以下操作：
#    - 创建分支：rq001-s3-storage-manage
#    - 创建工作区：/home/workspace/ai-flow-rad-rq001-s3-storage-manage
#    - 初始化子模块
#    - 为所有子模块创建同名分支
#    - 切换到工作区目录
```

### 验证

```bash
# 检查当前位置和分支
pwd  # 应显示：/home/workspace/ai-flow-rad-rq001-s3-storage-manage
git branch --show-current  # 应显示：rq001-s3-storage-manage

# 检查子模块分支
git submodule foreach 'echo "$(basename $sm_path): $(git branch --show-current)"'
# 所有子模块都应显示：rq001-s3-storage-manage
```

## 阶段 1：需求分析阶段

### 命令

```bash
/analysis-rq 在运维管理平台增加一个S3存储管理功能;
详细描述: ...;
使用背景: ...
```

### 工作位置

**必须在需求工作区内执行**：`/home/workspace/ai-flow-rad-rq001-s3-storage-manage`

### 产出文档位置

```
docs/requirement/rq001-s3-storage-manage/
├── 00-原始需求澄清记录.md
├── 01-需求可行性与满足度评估.md
├── 02-需求分析概要设计文档.md
├── 03-需求分析架构设计.md (如有)
├── 04-需求分解架构开发任务清单.md (如有)
├── 05-需求分解特性清单.md
└── 09-需求分析产出评审结果.md
```

### 注意事项

1. 所有文档都在工作区内创建
2. 文档修改会自动关联到需求分支
3. 可以随时提交文档到需求分支

## 阶段 2：开发准备阶段

### 命令

```bash
/prepare-rq rq001-s3-storage-manage
```

### 工作位置

继续在需求工作区内：`/home/workspace/ai-flow-rad-rq001-s3-storage-manage`

### 前置检查

```bash
# 确认在正确的工作区
./skills/git-worktree-master/scripts/worktree_manager.sh status

# 应显示：
# 📍 当前目录：/home/workspace/ai-flow-rad-rq001-s3-storage-manage
# 🌿 主项目分支：rq001-s3-storage-manage
```

### 产出

开发计划文件：`.omc/plans/rq001-s3-storage-manage.md`

## 阶段 3：开发实施阶段

### 命令

```bash
/develop-rq rq001-s3-storage-manage
```

### 工作位置

继续在需求工作区内：`/home/workspace/ai-flow-rad-rq001-s3-storage-manage`

### 开发流程

```bash
# 1. 开启 TDD 模式
/oh-my-claudecode:tdd

# 2. 启动 Ralph 模式开发
# (由 develop-rq 命令自动调度)

# 3. 代码评审
# (由 develop-rq 命令自动调度)

# 4. 代码简化
# (由 develop-rq 命令自动调度)
```

### 提交代码

在工作区内提交代码到需求分支：

```bash
# 主项目提交
git add .
git commit -m "feat: 实现 S3 存储管理功能"

# 子模块提交（如有修改）
cd path/to/submodule
git add .
git commit -m "feat: 子模块功能实现"
git push origin rq001-s3-storage-manage

# 返回主项目，更新子模块引用
cd ../..
git add path/to/submodule
git commit -m "chore: 更新子模块引用"
```

## 阶段 4：需求完成后清理

### 时机

需求开发完成，代码已合并到主分支后。

### 操作步骤

```bash
# 1. 返回主仓库
cd /home/workspace/ai-flow-rad

# 2. 确认需求分支已合并
git log --oneline --graph --all | grep rq001-s3-storage-manage

# 3. 清理工作区和分支
./skills/git-worktree-master/scripts/worktree_manager.sh cleanup rq001-s3-storage-manage

# 4. 确认清理结果
./skills/git-worktree-master/scripts/worktree_manager.sh list
```

### 清理内容

- 删除工作区目录：`/home/workspace/ai-flow-rad-rq001-s3-storage-manage`
- 删除主项目分支：`rq001-s3-storage-manage`
- 删除所有子模块分支：`rq001-s3-storage-manage`

## 多需求并行开发

### 场景

同时开发多个需求：
- rq001-s3-storage-manage
- rq002-user-auth-enhancement

### 操作

```bash
# 创建第一个需求工作区
./skills/git-worktree-master/scripts/worktree_manager.sh create rq001-s3-storage-manage

# 创建第二个需求工作区
cd /home/workspace/ai-flow-rad  # 返回主仓库
./skills/git-worktree-master/scripts/worktree_manager.sh create rq002-user-auth-enhancement

# 查看所有工作区
./skills/git-worktree-master/scripts/worktree_manager.sh list
```

### 切换需求

```bash
# 切换到需求 1
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh switch rq001-s3-storage-manage

# 切换到需求 2
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh switch rq002-user-auth-enhancement
```

## 异常情况处理

### 情况 1：工作区创建失败

**原因**：分支已存在但工作区不存在

**解决**：
```bash
# 使用已有分支创建工作区
git worktree add ../ai-flow-rad-rq001-s3-storage-manage rq001-s3-storage-manage
```

### 情况 2：子模块分支不一致

**原因**：部分子模块未切换到需求分支

**解决**：
```bash
# 检查所有子模块分支
git submodule foreach 'git branch --show-current'

# 切换到需求分支
git submodule foreach 'git checkout rq001-s3-storage-manage'
```

### 情况 3：工作区有未提交修改

**原因**：切换工作区前有未提交的修改

**解决**：
```bash
# 方案 1：提交修改
git add .
git commit -m "wip: 保存当前工作"

# 方案 2：暂存修改
git stash save "临时保存"

# 方案 3：放弃修改
git reset --hard HEAD
```

## 最佳实践总结

1. **提前创建**：在需求分析前就创建工作区
2. **全程使用**：从分析到开发全程在工作区内进行
3. **定期提交**：及时提交文档和代码到需求分支
4. **子模块同步**：确保所有子模块都在正确的分支
5. **及时清理**：需求完成后及时清理工作区
6. **状态检查**：切换工作区前检查状态
7. **命名规范**：严格遵循 `rqXXX-需求名` 格式
