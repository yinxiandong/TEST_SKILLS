#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
analyze_project_profile.py

在目标项目本地（project_root）做静态分析，生成 project-profile.json，用于远端探测时做“项目相关性”排序与解释。

设计目标：
- 不依赖 PyYAML（只做 best-effort 的文本扫描/轻量解析）
- 输出稳定、可解释、可用于匹配的 signals（keywords/jar/binary/path_prefixes/ports 等）
"""

import argparse
import json
import os
import re
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple


def now_ts() -> str:
    return time.strftime("%F %T", time.localtime())


def load_json(path: Path) -> Dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise RuntimeError(f"JSON 顶层必须为对象: {path}")
    return data


def dump_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def safe_read_text(path: Path, limit_bytes: int = 512 * 1024) -> str:
    try:
        b = path.read_bytes()
    except Exception:
        return ""
    if len(b) > limit_bytes:
        b = b[:limit_bytes]
    try:
        return b.decode("utf-8", errors="ignore")
    except Exception:
        return ""


def iter_files(project_root: Path, globs: List[str], max_files: int = 300) -> List[Path]:
    out: List[Path] = []
    seen: Set[str] = set()
    for g in globs:
        for p in project_root.glob(g):
            try:
                if not p.is_file():
                    continue
            except Exception:
                continue
            sp = str(p.resolve())
            if sp in seen:
                continue
            seen.add(sp)
            out.append(p)
            if len(out) >= max_files:
                return out
    return out


def try_git_origin(project_root: Path) -> str:
    git_dir = project_root / ".git"
    if not git_dir.exists():
        return ""
    try:
        proc = subprocess.run(
            ["git", "-C", str(project_root), "config", "--get", "remote.origin.url"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        if proc.returncode == 0:
            return (proc.stdout or "").strip()
    except Exception:
        pass
    return ""


STOPWORDS = {
    "app",
    "apps",
    "service",
    "services",
    "server",
    "web",
    "api",
    "backend",
    "frontend",
    "java",
    "python",
    "node",
    "nodejs",
    "spring",
    "boot",
    "docker",
    "compose",
    "k8s",
    "kubernetes",
    "deploy",
    "deployment",
    "prod",
    "production",
    "dev",
    "test",
    "staging",
}


def normalize_keyword(s: str) -> str:
    s = (s or "").strip().lower()
    s = re.sub(r"[^a-z0-9._-]+", "-", s).strip("-")
    if not s:
        return ""
    # 过滤纯数字/过短
    if len(s) < 3:
        return ""
    if s.isdigit():
        return ""
    if s in STOPWORDS:
        return ""
    return s


def add_keywords(dst: Set[str], items: Iterable[str]) -> None:
    for it in items:
        k = normalize_keyword(str(it))
        if k:
            dst.add(k)


def looks_like_text_file(path: Path) -> bool:
    # 基于后缀的粗判；避免扫大体积二进制
    suf = path.suffix.lower()
    if suf in {".jar", ".war", ".zip", ".png", ".jpg", ".jpeg", ".gif", ".pdf"}:
        return False
    return True


def detect_tech(project_root: Path) -> Tuple[List[str], List[str], List[str]]:
    languages: Set[str] = set()
    build_tools: Set[str] = set()
    frameworks: Set[str] = set()

    if (project_root / "pom.xml").exists():
        languages.add("java")
        build_tools.add("maven")
    if any((project_root / x).exists() for x in ["build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts"]):
        languages.add("java")
        build_tools.add("gradle")
    if (project_root / "package.json").exists():
        languages.add("node")
        build_tools.add("npm")
    if (project_root / "pnpm-lock.yaml").exists():
        languages.add("node")
        build_tools.add("pnpm")
    if (project_root / "yarn.lock").exists():
        languages.add("node")
        build_tools.add("yarn")
    if (project_root / "go.mod").exists():
        languages.add("go")
        build_tools.add("go")
    if any((project_root / x).exists() for x in ["pyproject.toml", "requirements.txt", "setup.py"]):
        languages.add("python")
        build_tools.add("python")
    if any(project_root.glob("**/CMakeLists.txt")):
        languages.add("cpp")
        build_tools.add("cmake")
    if any(project_root.glob("**/*.sln")) or any(project_root.glob("**/*.vcxproj")):
        languages.add("cpp")
        build_tools.add("msbuild")

    # best-effort：扫少量文件看 spring-boot 线索
    for p in iter_files(project_root, ["pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts"], max_files=8):
        txt = safe_read_text(p, limit_bytes=256 * 1024).lower()
        if "spring-boot" in txt or "spring boot" in txt:
            frameworks.add("spring-boot")

    return sorted(languages), sorted(build_tools), sorted(frameworks)


def extract_jar_names(project_root: Path) -> Set[str]:
    jars: Set[str] = set()
    # 1) pom.xml: artifactId + finalName
    pom = project_root / "pom.xml"
    if pom.exists():
        txt = safe_read_text(pom, limit_bytes=256 * 1024)
        m_art = re.search(r"<artifactId>\s*([^<\s]+)\s*</artifactId>", txt)
        if m_art:
            aid = m_art.group(1).strip()
            if aid:
                jars.add(f"{aid}.jar")
        m_final = re.search(r"<finalName>\s*([^<\s]+)\s*</finalName>", txt)
        if m_final:
            fn = m_final.group(1).strip()
            if fn:
                jars.add(f"{fn}.jar" if not fn.endswith(".jar") else fn)
    # 2) gradle: archiveFileName / archivesBaseName
    for gp in [project_root / "build.gradle", project_root / "build.gradle.kts"]:
        if not gp.exists():
            continue
        txt = safe_read_text(gp, limit_bytes=256 * 1024)
        for pat in [
            r"archiveFileName\s*=\s*[\"']([^\"']+)[\"']",
            r"archivesBaseName\s*=\s*[\"']([^\"']+)[\"']",
        ]:
            for m in re.finditer(pat, txt):
                v = (m.group(1) or "").strip()
                if not v:
                    continue
                if v.endswith(".jar"):
                    jars.add(v)
                else:
                    jars.add(f"{v}.jar")
    # 3) 文档/脚本：显式 *.jar
    # 限制文件数量与大小
    doc_paths = iter_files(
        project_root,
        [
            "*.md",
            "*.txt",
            "*.sh",
            "deploy/**/*.sh",
            "scripts/**/*.sh",
            "docs/**/*.md",
            "README*",
        ],
        max_files=120,
    )
    jar_re = re.compile(r"\b([A-Za-z0-9_.-]{1,128}\.jar)\b")
    for p in doc_paths:
        if not looks_like_text_file(p):
            continue
        txt = safe_read_text(p, limit_bytes=256 * 1024)
        for m in jar_re.finditer(txt):
            jars.add(m.group(1))
    return jars


def extract_main_classes(project_root: Path) -> Set[str]:
    # 对 -cp MainClass 场景备用（不强依赖）
    classes: Set[str] = set()
    src_paths = iter_files(project_root, ["*.sh", "deploy/**/*.sh", "scripts/**/*.sh", "*.md", "docs/**/*.md"], max_files=120)
    cls_re = re.compile(r"\b([a-zA-Z_][\w$]*\.[\w$\.]{3,200})\b")
    for p in src_paths:
        if not looks_like_text_file(p):
            continue
        txt = safe_read_text(p, limit_bytes=256 * 1024)
        for m in cls_re.finditer(txt):
            s = m.group(1)
            if s.count(".") >= 2 and not s.endswith(".yml") and not s.endswith(".yaml"):
                classes.add(s)
    # 去掉明显不是类名的
    out: Set[str] = set()
    for c in classes:
        lc = c.lower()
        if lc.startswith("http.") or lc.startswith("https."):
            continue
        if "/" in c:
            continue
        out.add(c)
    return out


def extract_binary_names(project_root: Path) -> Set[str]:
    bins: Set[str] = set()
    # CMake: add_executable(name ...)
    for cm in iter_files(project_root, ["**/CMakeLists.txt"], max_files=40):
        txt = safe_read_text(cm, limit_bytes=256 * 1024)
        for m in re.finditer(r"add_executable\s*\(\s*([A-Za-z0-9_.-]{1,64})\b", txt):
            bins.add(m.group(1))
    # Makefile: TARGET=xxx / BIN=xxx / 输出名线索（best-effort）
    for mk in iter_files(project_root, ["**/Makefile", "**/*.mk"], max_files=40):
        txt = safe_read_text(mk, limit_bytes=256 * 1024)
        for m in re.finditer(r"^\s*(?:TARGET|BIN|BINARY|APP)\s*[:?+]?=\s*([A-Za-z0-9_.-]{1,64})\s*$", txt, flags=re.M):
            bins.add(m.group(1))
    # Go: cmd/<name>/main.go => name
    cmd_dir = project_root / "cmd"
    if cmd_dir.exists() and cmd_dir.is_dir():
        try:
            for child in cmd_dir.iterdir():
                if child.is_dir() and (child / "main.go").exists():
                    bins.add(child.name)
        except Exception:
            pass
    return bins


def best_effort_parse_compose_services(text: str) -> Tuple[Set[str], Set[str], Set[int]]:
    # 非 YAML 解析：只识别常见结构
    services: Set[str] = set()
    images: Set[str] = set()
    ports: Set[int] = set()

    lines = text.splitlines()
    in_services = False
    services_indent: Optional[int] = None
    current_service: Optional[str] = None
    current_indent: Optional[int] = None

    for raw in lines:
        line = raw.rstrip("\n")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        indent = len(line) - len(line.lstrip(" "))
        stripped = line.strip()
        if re.match(r"^services\s*:\s*$", stripped):
            in_services = True
            services_indent = indent
            current_service = None
            current_indent = None
            continue
        if not in_services:
            continue
        # 离开 services 块
        if services_indent is not None and indent <= services_indent and not stripped.startswith("-"):
            # 碰到同级 key
            if re.match(r"^[A-Za-z0-9_.-]+\s*:\s*$", stripped) and not stripped.startswith("services:"):
                in_services = False
            continue
        # 服务名：在 services 下一级的 "name:"
        m_svc = re.match(r"^([A-Za-z0-9_.-]{1,64})\s*:\s*$", stripped)
        if m_svc and services_indent is not None and indent > services_indent:
            current_service = m_svc.group(1)
            current_indent = indent
            services.add(current_service)
            continue
        # image:
        if current_service and stripped.startswith("image:"):
            img = stripped.split(":", 1)[1].strip().strip('"').strip("'")
            if img:
                images.add(img)
            continue
        # 端口： - "8080:8080" 或 - 8080:8080 或 - "8080"
        if stripped.startswith("-"):
            val = stripped[1:].strip().strip('"').strip("'")
            m = re.match(r"^(\d{2,5})(?::\d{2,5})?(?:/tcp|/udp)?$", val)
            if m:
                try:
                    ports.add(int(m.group(1)))
                except Exception:
                    pass
    return services, images, ports


def scan_compose(project_root: Path) -> Dict[str, Any]:
    compose_files = iter_files(
        project_root,
        ["docker-compose.yml", "docker-compose.yaml", "compose.yml", "compose.yaml", "docker-compose.*.yml", "docker-compose.*.yaml"],
        max_files=20,
    )
    services: Set[str] = set()
    images: Set[str] = set()
    ports: Set[int] = set()
    for p in compose_files:
        txt = safe_read_text(p, limit_bytes=512 * 1024)
        s, i, po = best_effort_parse_compose_services(txt)
        services |= s
        images |= i
        ports |= po
    return {
        "files": [str(p.relative_to(project_root)) for p in compose_files],
        "services": sorted(services),
        "images": sorted(images),
        "ports": sorted(ports),
    }


def scan_k8s(project_root: Path) -> Dict[str, Any]:
    # best-effort：扫描常见目录
    roots = []
    for d in ["k8s", "deploy", "deployment", "manifests", "helm", "charts"]:
        p = project_root / d
        if p.exists() and p.is_dir():
            roots.append(p)
    # 只扫有限数量文件
    yamls: List[Path] = []
    for r in roots:
        for p in r.rglob("*.yml"):
            yamls.append(p)
            if len(yamls) >= 120:
                break
        if len(yamls) >= 120:
            break
        for p in r.rglob("*.yaml"):
            yamls.append(p)
            if len(yamls) >= 120:
                break
        if len(yamls) >= 120:
            break

    workloads: Set[str] = set()
    images: Set[str] = set()
    ports: Set[int] = set()
    for p in yamls:
        txt = safe_read_text(p, limit_bytes=512 * 1024)
        # best-effort：仅在常见 workload kind 下提取 metadata.name，减少 name: 噪声
        allowed_kinds = {"Deployment", "StatefulSet", "DaemonSet", "Job", "CronJob"}
        current_kind = ""
        in_metadata = False
        metadata_indent: Optional[int] = None
        for raw in txt.splitlines():
            line = raw.rstrip("\n")
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            indent = len(line) - len(line.lstrip(" "))
            stripped = line.strip()
            m_kind = re.match(r"^kind\s*:\s*([A-Za-z]+)\s*$", stripped)
            if m_kind:
                current_kind = m_kind.group(1)
                in_metadata = False
                metadata_indent = None
            if re.match(r"^metadata\s*:\s*$", stripped):
                in_metadata = True
                metadata_indent = indent
                continue
            if in_metadata and metadata_indent is not None:
                # metadata block 结束：遇到同级 key
                if indent <= metadata_indent and not stripped.startswith("-"):
                    in_metadata = False
                    metadata_indent = None
                else:
                    m_name = re.match(r"^name\s*:\s*([A-Za-z0-9_.-]{1,64})\s*$", stripped)
                    if m_name and current_kind in allowed_kinds:
                        workloads.add(m_name.group(1))

            m_img = re.match(r"^image\s*:\s*([^\s#]+)\s*$", stripped)
            if m_img:
                images.add(m_img.group(1).strip().strip('"').strip("'"))
            m_port = re.match(r"^containerPort\s*:\s*(\d{2,5})\s*$", stripped)
            if m_port:
                try:
                    ports.add(int(m_port.group(1)))
                except Exception:
                    pass
    return {
        "manifests": [str(p.relative_to(project_root)) for p in yamls[:40]],
        "workloads": sorted(workloads),
        "images": sorted(images),
        "ports": sorted(ports),
    }


def scan_systemd_units_in_repo(project_root: Path) -> List[Dict[str, str]]:
    units: List[Dict[str, str]] = []
    # 逐个遍历并在达到上限后停止，避免在大仓库里先收全集合导致变慢
    count = 0
    for p in project_root.rglob("*.service"):
        if count >= 60:
            break
        if not p.is_file():
            continue
        txt = safe_read_text(p, limit_bytes=128 * 1024)
        unit = p.name
        exec_start_hint = ""
        m = re.search(r"(?m)^\s*ExecStart\s*=\s*(.+)\s*$", txt)
        if m:
            exec_start_hint = (m.group(1) or "").strip()
        units.append(
            {
                "unit": unit,
                "exec_start_hint": exec_start_hint[:200],
                "path": str(p.relative_to(project_root)),
            }
        )
        count += 1
    return units


def build_cmdline_regexes(
    keywords: List[str],
    jar_names: List[str],
    binary_names: List[str],
    path_prefixes: List[str],
) -> List[str]:
    regexes: List[str] = []
    # jar/binary 直接命中
    for j in jar_names[:40]:
        b = re.escape(j)
        regexes.append(rf"(?:^|\s)(?:-jar\s+)?[^\s]*{b}\b")
    for b in binary_names[:40]:
        bb = re.escape(b)
        regexes.append(rf"(?:^|\s)[^\s]*/{bb}\b")
    # 关键词命中（避免太泛）
    for k in keywords[:80]:
        kk = re.escape(k)
        regexes.append(rf"\b{kk}\b")
    # 路径前缀命中（只收集更窄的前缀，/home 本身不要生成 regex）
    for pref in path_prefixes:
        if pref.strip() == "/home":
            continue
        pp = re.escape(pref.rstrip("/"))
        regexes.append(rf"\b{pp}/")
    # 去重并限制
    out: List[str] = []
    seen: Set[str] = set()
    for r in regexes:
        if r in seen:
            continue
        seen.add(r)
        out.append(r)
        if len(out) >= 120:
            break
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description="remote-debug-setup: 分析本地项目生成 project-profile.json（用于远端探测匹配）")
    parser.add_argument("--project-root", default=".", help="目标项目根目录")
    parser.add_argument("--out", required=True, help="project-profile.json 输出路径")
    parser.add_argument("--answers-min", default="", help="可选：answers.min.json（用于读取 project.binding_hints.extra_*）")
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    out_path = Path(args.out).expanduser().resolve()

    languages, build_tools, frameworks = detect_tech(project_root)

    repo_dir_name = project_root.name
    git_origin = try_git_origin(project_root)

    compose = scan_compose(project_root)
    k8s = scan_k8s(project_root)
    systemd_units_in_repo = scan_systemd_units_in_repo(project_root)

    jar_names = sorted(extract_jar_names(project_root))
    main_classes = sorted(extract_main_classes(project_root))
    binary_names = sorted(extract_binary_names(project_root))

    keywords: Set[str] = set()
    add_keywords(keywords, [repo_dir_name])
    add_keywords(keywords, compose.get("services") or [])
    add_keywords(keywords, k8s.get("workloads") or [])
    add_keywords(keywords, [u.get("unit", "").replace(".service", "") for u in systemd_units_in_repo])
    # 从镜像名里取一段作为关键词（例如 org/vcms:tag -> vcms）
    for img in (compose.get("images") or []) + (k8s.get("images") or []):
        s = str(img)
        part = s.split("/")[-1].split(":")[0]
        add_keywords(keywords, [part])

    # path_prefixes：默认包含 /home（来自你们的部署惯例），并尽量追加更窄前缀（best-effort：从 systemd/unit hint 中提取）
    path_prefixes: Set[str] = {"/home"}
    for u in systemd_units_in_repo:
        hint = str(u.get("exec_start_hint") or "")
        # 提取形如 /home/xxx/yyy 的前两级
        for m in re.finditer(r"(/home/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)", hint):
            path_prefixes.add(m.group(1))

    port_hints: Set[int] = set()
    for p in compose.get("ports") or []:
        try:
            port_hints.add(int(p))
        except Exception:
            pass
    for p in k8s.get("ports") or []:
        try:
            port_hints.add(int(p))
        except Exception:
            pass

    user_hints = {"extra_keywords": [], "extra_path_prefixes": []}
    if args.answers_min:
        try:
            ans = load_json(Path(args.answers_min).expanduser().resolve())
            proj = ans.get("project") if isinstance(ans.get("project"), dict) else {}
            bh = proj.get("binding_hints") if isinstance(proj.get("binding_hints"), dict) else {}
            ek = bh.get("extra_keywords") if isinstance(bh.get("extra_keywords"), list) else []
            ep = bh.get("extra_path_prefixes") if isinstance(bh.get("extra_path_prefixes"), list) else []
            user_hints["extra_keywords"] = [str(x) for x in ek if str(x).strip()]
            user_hints["extra_path_prefixes"] = [str(x) for x in ep if str(x).strip()]
        except Exception:
            # 忽略，不影响输出
            pass

    add_keywords(keywords, user_hints["extra_keywords"])
    for p in user_hints["extra_path_prefixes"]:
        if p.strip():
            path_prefixes.add(p.strip())

    profile: Dict[str, Any] = {
        "schema_version": "remote-debug-suite/project-profile/v1",
        "generated_at": now_ts(),
        "project_root": str(project_root),
        "repo": {"dir_name": repo_dir_name, "git_remote_origin": git_origin},
        "tech": {"languages": languages, "build_tools": build_tools, "framework_hints": frameworks},
        "deploy": {
            "modes_expected": ["script", "systemd", "docker", "k8s"],
            "compose": compose,
            "k8s": k8s,
            "systemd_units_in_repo": systemd_units_in_repo,
        },
        "signals": {
            "keywords": sorted(keywords),
            "jar_names": jar_names[:80],
            "main_classes": main_classes[:80],
            "binary_names": binary_names[:80],
            "path_prefixes": sorted(path_prefixes),
            "port_hints": sorted(port_hints),
            "health_paths": ["/actuator/health", "/healthz", "/health", "/ping"],
        },
        "user_hints": user_hints,
    }
    profile["signals"]["cmdline_regexes"] = build_cmdline_regexes(
        keywords=profile["signals"]["keywords"],
        jar_names=profile["signals"]["jar_names"],
        binary_names=profile["signals"]["binary_names"],
        path_prefixes=profile["signals"]["path_prefixes"],
    )

    dump_json(out_path, profile)
    print(f"[OK] project profile written: {out_path}")


if __name__ == "__main__":
    main()
