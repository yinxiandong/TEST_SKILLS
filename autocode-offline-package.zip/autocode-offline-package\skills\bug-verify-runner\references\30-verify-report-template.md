# 30-远程验证报告

## 基本信息

| 字段 | 内容 |
|---|---|
| 缺陷标识 | {bug_id} |
| 轮次 | round-N |
| 验证时间 | YYYY-MM-DD HH:mm:ss |
| 目标环境 | dev/staging/prod-mirror |
| 远程主技能 | remote-dev-debug |

## 1. 远程调试执行摘要

- 执行状态：pass/fail/error
- 场景类型：api/start_fail/log/config/db/general
- 子技能（由主技能内部决定）：

## 2. 用例结果

| 用例ID | 用例名称 | 结果 | 证据 |
|---|---|---|---|
| | | pass/fail | |

## 3. 失败详情（如有）

- 失败原因：
- 关键日志：
- 建议下一步：

## 4. 证据清单

- 日志文件：
- 报告链接：
- 远程输出目录：

## 5. 结论

- 是否通过门禁：是/否
