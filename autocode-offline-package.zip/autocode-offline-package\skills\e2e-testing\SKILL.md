---
name: e2e-testing
description: E2E 测试执行规范：Playwright 测试生成、多浏览器运行、artifact 采集、flaky 处理、CI/CD 集成。为 e2e-orchestrator 和阶段测试执行流程提供规范参考。脚本目录约定为 tests/ui-test/scripts/，报告输出到 .tests/。
---

# E2E 测试执行技能

为 E2E 测试的生成与执行提供完整规范，包括 Playwright 模式、POM 结构、等待策略、artifact 管理和 CI/CD 集成。

## 调用方

本 Skill 由以下角色调用：
- `e2e-orchestrator`：提供执行规范与模式参考
- `e2e-script-generator`：脚本生成时复用 POM、等待策略等规范
- `rq-stage-test-executor`：E2E 测试执行时的规范依据
- `rq-auto-dev-orchestrator`：全量 E2E 回归时复用统一规范

## 目录约定

```
tests/
└── ui-test/
    ├── usecase/                       # 一阶段：YAML 用例（e2e-case-generator 生成）
    └── scripts/                       # 二阶段：Playwright 脚本（e2e-script-generator 生成）
        ├── {category}/
        │   └── {feature}.spec.ts
        ├── pages/                     # Page Object Model 类
        └── fixtures/                  # 测试夹具

.tests/                                # 隐藏目录：过程文件和报告
└── reports/
    └── {run-id}/
        ├── ai-report.json             # AI-readable 报告（e2e-report-builder 生成）
        ├── report.html                # 人读 HTML 报告（e2e-report-builder 生成）
        ├── junit.xml                  # JUnit XML（CI 集成）
        ├── screenshots/               # 失败截图
        ├── videos/                    # 录屏
        └── traces/                    # Playwright trace
```

## 测试设计 → 执行的映射规则

从 `20-{stage_name}-需求测试设计.md` 读取 E2E 测试场景时：

1. 识别标记为 `test_type: e2e` 的测试用例
2. 将"关键业务旅程"中的步骤列表映射为 `test.describe` 块
3. 将"测试步骤"中的"操作"映射为 `page` 交互操作（click/fill/goto）
4. 将"测试步骤"中的"等待策略"映射为对应的 Playwright 等待 API
5. 将"测试步骤"中的"断言点"映射为 `expect()` 断言
6. 将"截图时机"列映射为 `page.screenshot()` 调用
7. 将"前置状态"映射为 `test.beforeEach` 中的数据准备逻辑
8. 将"后置清理"映射为 `test.afterEach` 中的清理逻辑

## 功能特性

1. **生成测试旅程** — 为用户流程创建 Playwright 测试
2. **多浏览器运行** — 跨浏览器执行测试
3. **采集 Artifact** — 失败时截图、视频、trace（输出到 `.tests/`）
4. **上传结果** — HTML 报告和 JUnit XML
5. **识别 Flaky** — 隔离不稳定测试

## 使用场景

- 测试关键用户旅程（登录、核心业务流程、支付）
- 验证多步骤流程的端到端联通
- 测试 UI 交互和页面导航
- 验证前后端集成
- 上线前回归验证

## Playwright 配置模板

参见模板文件：`template/playwright.config.ts.template`

> **模板定位**：本文件（`e2e-testing/template/playwright.config.ts.template`）为**规范参考版本**，使用固定示例值（`baseURL: localhost:3000`），无 `webServer` 自动启动块，供已接入项目对齐配置使用。初始接入时请使用 `e2e-checker/template/playwright.config.ts.template`（含项目适配占位符）。两者 `testDir` 和 reporter 路径约定完全一致。

该模板包含：
- 多浏览器配置（Chromium、Firefox、WebKit）
- Artifact 配置（截图、视频、trace）
- 重试策略（CI 环境 2 次重试）
- 报告配置（HTML、JUnit XML、JSON，均输出到 `.tests/`）
- `testDir` 指向 `tests/ui-test/scripts`

## Page Object Model（POM）示例

参见模板文件：`template/page-object-example.ts.template`

该模板展示：
- 使用 `data-testid` 选择器（最佳实践）
- 封装页面交互逻辑
- 使用条件等待（`waitForLoadState`）

## 测试用例模板

参见模板文件：`template/test-case-example.spec.ts.template`

该模板展示：
- 使用 `test.describe` 组织测试场景
- 前置/后置钩子（`beforeEach`/`afterEach`）
- 等待 API 响应而非固定延时
- 明确的断言点
- 关键节点截图

## 等待策略规范

| 场景 | 推荐方式 | 禁止方式 |
|------|---------|---------|
| 等待页面加载 | `waitForLoadState('networkidle')` | `waitForTimeout(2000)` |
| 等待 API 响应 | `waitForResponse(urlPattern)` | `waitForTimeout(3000)` |
| 等待元素出现 | `waitForSelector` / `expect().toBeVisible()` | `waitForTimeout(1000)` |
| 等待动画结束 | `waitForLoadState('networkidle')` | `waitForTimeout(500)` |
| 等待路由跳转 | `waitForURL(pattern)` | `waitForTimeout(2000)` |

## Artifact 管理

```typescript
// tests/ui-test/playwright.config.ts artifact 配置
use: {
  screenshot: 'only-on-failure',    // 失败时截图
  video: 'on-first-retry',          // 首次重试时录视频
  trace: 'on-first-retry',          // 首次重试时记录 trace
}
```

**所有测试（始终生成）**：
- HTML 报告（含时间线和结果）→ `.tests/reports/{run-id}/playwright-report/`
- JUnit XML（供 CI 集成）→ `.tests/reports/{run-id}/junit.xml`
- JSON 结果文件 → `.tests/reports/{run-id}/test-results.json`

**失败时生成**：
- 失败状态截图 → `.tests/reports/{run-id}/screenshots/`
- 测试录屏视频 → `.tests/reports/{run-id}/videos/`
- Trace 文件（支持步骤回放）→ `.tests/reports/{run-id}/traces/`
- 网络日志
- 控制台日志

```bash
# 查看 HTML 报告
npx playwright show-report .tests/latest/playwright-report

# 查看指定 trace 文件
npx playwright show-trace .tests/latest/traces/trace.zip
```

## Flaky 测试处理流程

1. 本地 `--repeat-each=5` 运行，通过率 < 100% 则标记为 flaky
2. 用 `test.fixme()` 隔离，注明 Issue 编号
3. 分析根因：竞态条件 / 网络时序 / 动画时序
4. 修复后再次 `--repeat-each=10` 验证稳定性

```typescript
// 隔离不稳定测试
test('flaky: 支付流程', async ({ page }) => {
  test.fixme(true, 'Flaky - Issue #456，等待支付回调稳定')
})
```

常见根因与修复：

| 根因 | 修复方式 |
|------|---------|
| 竞态条件 | 改用自动等待 locator（`page.locator().click()`） |
| 网络时序 | `waitForResponse(url匹配)` |
| 动画时序 | `waitForLoadState('networkidle')` |
| 元素不稳定 | 增加 `data-testid` 属性，避免脆弱 CSS 选择器 |

## CI/CD 集成

参见模板文件：`template/github-actions-e2e.yml.template`

该模板包含：
- Playwright 浏览器安装
- E2E 测试执行
- Artifact 上传（报告和测试结果从 `.tests/` 目录上传）
- 失败时也上传 artifact（`if: always()`）

## 质量门禁

| 指标 | 要求 |
|------|------|
| P0 E2E 用例通过率 | 100% |
| P1 E2E 用例通过率 | ≥ 95% |
| 整体 E2E 通过率 | ≥ 90% |
| Flaky 用例比例 | < 5% |
| E2E 执行时长 | < 10 分钟（单次） |

## 最佳实践

**DO：**
- 使用 Page Object Model 提升可维护性
- 使用 `data-testid` 属性作为选择器
- 等待 API 响应，而非固定延时
- 测试关键用户旅程的端到端路径
- 合并前运行测试
- 使用 YAML 用例定义（一阶段）与 Playwright 脚本（二阶段）分离

**DON'T：**
- 不使用脆弱选择器（CSS class 可能变化）
- 不测试实现细节
- 不在生产环境运行测试
- 不忽略 flaky 测试
- 不跳过失败的 artifact 审查
- 不用 E2E 测试每个边界情况（用单元测试）
- 不直接手写 Playwright 脚本绕过用例生成阶段

## 快速命令参考

```bash
# 运行所有 E2E 测试
npx playwright test --config tests/ui-test/playwright.config.ts

# 运行指定测试文件
npx playwright test --config tests/ui-test/playwright.config.ts tests/ui-test/scripts/auth/login.spec.ts

# 运行冒烟测试
npx playwright test --config tests/ui-test/playwright.config.ts --grep @smoke

# 可视化运行（看到浏览器）
npx playwright test --config tests/ui-test/playwright.config.ts --headed

# 调试模式
npx playwright test --config tests/ui-test/playwright.config.ts --debug

# 录制测试代码
npx playwright codegen http://localhost:3000

# 查看报告
npx playwright show-report .tests/latest/playwright-report

# 重复运行检测 flaky
npx playwright test --config tests/ui-test/playwright.config.ts --repeat-each=5
```
