#!/usr/bin/env bash
set -euo pipefail

SERVER_NAME=""
CONFIG_PATH=".secrets/dev-servers.yaml"
TIMEOUT_SECONDS="3"

usage() {
  cat <<'USAGE'
用法:
  probe_remote_db.sh --server <name> [--config <path>] [--timeout <seconds>]
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --server)
      SERVER_NAME="$2"; shift 2 ;;
    --config)
      CONFIG_PATH="$2"; shift 2 ;;
    --timeout)
      TIMEOUT_SECONDS="$2"; shift 2 ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "[ERROR] 未知参数: $1"; usage; exit 1 ;;
  esac
done

if [[ -z "$SERVER_NAME" ]]; then
  echo "[ERROR] --server 必填"; usage; exit 1
fi
if [[ ! -f "$CONFIG_PATH" ]]; then
  echo "[ERROR] 配置文件不存在: $CONFIG_PATH"; exit 1
fi
if ! [[ "$TIMEOUT_SECONDS" =~ ^[0-9]+$ ]]; then
  echo "[ERROR] --timeout 必须是整数"; exit 1
fi

command -v python3 >/dev/null 2>&1 || { echo "[ERROR] 缺少 python3"; exit 1; }

python3 - "$CONFIG_PATH" "$SERVER_NAME" "$TIMEOUT_SECONDS" <<'PY'
import json
import socket
import sys
import os
import signal
import time
import subprocess
import shutil
from typing import Any, Dict

config_path, server_name, timeout_seconds = sys.argv[1:]
timeout_seconds = int(timeout_seconds)

cfg = json.loads(open(config_path,'r',encoding='utf-8').read())
server = next((s for s in cfg.get('servers',[]) if isinstance(s,dict) and s.get('name')==server_name), None)
if not server:
    print(f"[ERROR] 未找到服务器: {server_name}")
    sys.exit(1)

ssh_host = (server.get('ssh') or {}).get('host') or server.get('host') or ''
comp = server.get('components') if isinstance(server.get('components'), dict) else {}
db = comp.get('db') if isinstance(comp.get('db'), dict) else None
if not db:
    db = server.get('db') if isinstance(server.get('db'), dict) else None
    if db:
        print('[WARN] 检测到已废弃字段 servers[].db，请迁移到 servers[].components.db')

if not db:
    print('[ERROR] 未配置 servers[].components.db')
    sys.exit(2)

host = str(db.get('host') or ssh_host)
port = int(db.get('port') or 0)
db_type = str(db.get('db_type') or 'auto')
access = db.get('access') if isinstance(db.get('access'), dict) else {}
access_mode = str(access.get('mode') or 'direct')
if access_mode == 'ssh' and not str(db.get('host') or '').strip():
    host = '127.0.0.1'

if not host or not port:
    print('[ERROR] db.host/db.port 必填（或至少配置 port，host 默认取 ssh.host）')
    sys.exit(3)

ssh = server.get('ssh') if isinstance(server.get('ssh'), dict) else {}
ssh_auth = ssh.get('auth') if isinstance(ssh.get('auth'), dict) else {}
ssh_bastion = str(ssh.get('host') or '')
ssh_port = int(ssh.get('port') or 22)
ssh_user = str(ssh.get('username') or '')
ssh_auth_type = str(ssh_auth.get('type') or 'password')
ssh_password = str(ssh_auth.get('password') or '')
ssh_identity = str(ssh_auth.get('identity_file') or '')
defaults = server.get('defaults') if isinstance(server.get('defaults'), dict) else {}
known_hosts_file = str(defaults.get('known_hosts_file') or '/tmp/remote-dev-deploy-known-hosts')
strict = 'yes' if bool(defaults.get('strict_host_key_check') or False) else 'no'

tunnel_proc = None

def pick_free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    p = int(s.getsockname()[1])
    s.close()
    return p

def wait_listen(p: int, timeout_s: float = 4.0) -> bool:
    end = time.time() + timeout_s
    while time.time() < end:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.3)
            s.connect(('127.0.0.1', p))
            s.close()
            return True
        except Exception:
            try:
                s.close()
            except Exception:
                pass
            time.sleep(0.1)
    return False

def start_ssh_tunnel(target_host: str, target_port: int) -> int:
    global tunnel_proc
    if not ssh_bastion or not ssh_user:
        raise RuntimeError('servers[].ssh.host/username 为空，无法建立 ssh tunnel')
    lp = pick_free_port()
    ssh_cmd = [
        'ssh',
        '-p', str(ssh_port),
        '-o', f'StrictHostKeyChecking={strict}',
        '-o', f'UserKnownHostsFile={known_hosts_file}',
        '-o', 'ConnectTimeout=8',
        '-o', 'ExitOnForwardFailure=yes',
        '-o', 'ServerAliveInterval=5',
        '-o', 'ServerAliveCountMax=3',
        '-N',
        '-L', f'127.0.0.1:{lp}:{target_host}:{int(target_port)}',
    ]
    if ssh_auth_type == 'key' and ssh_identity:
        ssh_cmd += ['-i', ssh_identity, '-o', 'BatchMode=yes']
    ssh_cmd.append(f'{ssh_user}@{ssh_bastion}')
    if ssh_auth_type == 'password':
        if not ssh_password:
            raise RuntimeError('ssh.auth.password 为空，无法建立 tunnel')
        if shutil.which('sshpass') is None:
            raise RuntimeError('缺少 sshpass（password 认证需要）')
        ssh_cmd = ['sshpass', '-p', ssh_password] + ssh_cmd
    tunnel_proc = subprocess.Popen(
        ssh_cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        preexec_fn=os.setsid if hasattr(os, 'setsid') else None,
    )
    if not wait_listen(lp, timeout_s=4.0):
        err = ''
        try:
            err = (tunnel_proc.stderr.read(2000) if tunnel_proc.stderr else '')  # type: ignore[union-attr]
        except Exception:
            err = ''
        raise RuntimeError(f'ssh tunnel 建立失败: {err.strip()}')
    return lp

def tcp_probe(h: str, p: int) -> bool:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout_seconds)
    try:
        s.connect((h, p))
        return True
    except Exception:
        return False
    finally:
        try:
            s.close()
        except Exception:
            pass


def sniff_db_type(h: str, p: int) -> str:
    # 轻量鉴别：
    # - MySQL 会在建立连接后主动发送握手包（以 0x0a 版本字节开头，含 "mysql" 字样）。
    # - PostgreSQL 通常不主动发包，但对 SSLRequest 会返回单字节 'S' 或 'N'。
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout_seconds)
        s.connect((h, p))
        try:
            data = s.recv(128)
        except Exception:
            data = b''
        if data:
            if b'mysql' in data.lower() or (len(data) > 5 and data[4:5] == b'\x0a'):
                return 'mysql'
        # PostgreSQL SSLRequest: length=8, code=80877103
        try:
            s.sendall(b'\x00\x00\x00\x08\x04\xd2\x16\x2f')
            b1 = s.recv(1)
            if b1 in (b'S', b'N'):
                return 'postgresql'
        except Exception:
            pass
        return 'unknown'
    except Exception:
        return 'unknown'
    finally:
        try:
            s.close()
        except Exception:
            pass

try:
    actual_host = host
    actual_port = port
    if access_mode == 'ssh':
        try:
            lp = start_ssh_tunnel(host or '127.0.0.1', port)
        except Exception as exc:
            print(f"[ERROR] {exc}")
            sys.exit(8)
        actual_host = '127.0.0.1'
        actual_port = lp

    ok = tcp_probe(actual_host, actual_port)
    print(f"[INFO] access_mode={access_mode} db_type_hint={db_type} host={host} port={port}")
    if ok:
        detected = sniff_db_type(actual_host, actual_port)
        if db_type == 'auto' and detected in ('mysql','postgresql'):
            db_type = detected
        print(f"[INFO] db_type_detected={detected}")
        print('[RESULT] PROBE_SUCCESS')
        sys.exit(0)
    print('[RESULT] PROBE_FAILED')
    sys.exit(4)
finally:
    if tunnel_proc is not None:
        try:
            if hasattr(os, 'killpg'):
                os.killpg(os.getpgid(tunnel_proc.pid), signal.SIGTERM)
            else:
                tunnel_proc.terminate()
            tunnel_proc.wait(timeout=2)
        except Exception:
            pass
PY
