---
name: rq-finish
description: 在开发完成后提交代码、推送远程、创建 GitLab MR 并清理工作区，完成需求开发全流程闭环。Use when develop-rq is done and final-delivery-report status is completed.
---

# RQ Finish - 需求收尾闭环

用于需求开发流程最后一步，将已通过交付门禁的代码提交、推送到远程仓库、创建 Merge Request，并清理本地工作区。

## 输入

### 必需输入

| 输入项 | 路径 | 说明 |
|--------|------|------|
| 需求标识 | `{rq_id}` | 需求文件夹名称 |
| 最终交付报告 | `.claude/notepads/{rq_id}/final-delivery-report.md` | status 必须为 completed |
| 运行态 | `.claude/notepads/{rq_id}/runtime-status.md` | 阶段执行状态 |

### 可选输入

| 输入项 | 路径 | 说明 |
|--------|------|------|
| 需求分析概要设计 | `docs/requirement/{rq_id}/02-需求分析概要设计文档.md` | 用于提取需求简述和 MR 描述 |
| MR 目标分支 | `{target_branch}` | 可选，默认自动识别远程默认分支（常见为 main/master） |
| 是否清理工作区 | `{cleanup}` | 可选，默认询问用户；取值：`yes/no/ask` |

## 输出

- Git commits（需求分支上）
- 远程分支推送
- GitLab Merge Request
- 工作区清理（worktree 删除）

## 工作流程

### Step 1: 前置校验

目标：在任何破坏性动作（提交/推送/清理）之前，确认“门禁已通过、位置正确、远程可推送、状态可控”。任一条件不满足，**阻塞**并输出缺口清单。

1. 校验最终交付报告存在且完成：
   - 文件存在：`.claude/notepads/{rq_id}/final-delivery-report.md`
   - `status` 字段为 `completed`（建议用严格匹配，避免误判）
     ```bash
     rg -n "^status:\\s*completed\\b" ".claude/notepads/{rq_id}/final-delivery-report.md"
     ```
2. 校验处于需求工作区且分支正确：
   ```bash
   current_branch=$(git branch --show-current)
   # current_branch 必须等于 {rq_id}
   ```
3. 校验远程与权限（最低限度）：
   ```bash
   git remote get-url origin
   ```
   - 若 `origin` 不存在或不可用，阻塞并提示需要人工配置远程/权限。
4. 校验不存在进行中的 Git 操作（避免在 rebase/merge 过程中提交与推送）：
   ```bash
   git rev-parse -q --verify MERGE_HEAD && echo "merge in progress" && exit 1 || true
   git rev-parse -q --verify REBASE_HEAD && echo "rebase in progress" && exit 1 || true
   ```
5. 汇总当前改动面（主项目 + 子模块），用于后续提交决策与用户确认：
   ```bash
   git status --porcelain
   git submodule foreach --recursive --quiet 'if [ -n "$(git status --porcelain)" ]; then echo "$sm_path"; git status --porcelain; fi'
   ```
6.（可选但推荐）检查是否存在未推送提交（若无 upstream 视为“待推送”）：
   ```bash
   git rev-parse --abbrev-ref --symbolic-full-name @{u} >/dev/null 2>&1 || echo "no upstream (need push)"
   git rev-list --count @{u}..HEAD 2>/dev/null || true
   ```

### Step 2: 提交代码

#### 2a. 子模块提交

检测子模块是否有变更：

```bash
git submodule foreach --recursive --quiet 'if [ -n "$(git status --porcelain)" ]; then echo "$sm_path"; fi'
```

若有变更的子模块，逐个执行（关键：处理 detached HEAD / 分支不存在）：

```bash
cd {submodule_path}
# 确保子模块位于需求分支（避免 detached HEAD 造成推送失败）
git checkout "{rq_id}" 2>/dev/null || git checkout -b "{rq_id}"
git add .
git commit -m "feat({rq_id}): {子模块名}功能实现"
cd {回到主项目根目录}
```

#### 2b. 主项目提交

建议先展示改动与 diff 概览，避免误收：

```bash
git status --short
git diff --stat
```

建议使用 AskUserQuestion 让用户确认“即将提交的文件列表”与“提交摘要”，确认后再执行 `git add` 与 `git commit`。

```bash
git add .
```

生成结构化 commit message，从 `final-delivery-report.md` 或 `02-需求分析概要设计文档.md` 提取需求简述：

建议用文件承载多行 message，避免引号/换行导致提交失败：

```bash
mkdir -p .tmp
cat > .tmp/rq-finish.commitmsg.txt <<'EOF'
feat({rq_id}): {需求简述}

- 关键修改: {从 final-delivery-report.md 提取的真实摘要；提取不到则不自动编造}
- 测试结果: {从 final-delivery-report.md 提取；提取不到则写“见交付报告”}
- 评审结论: {从 final-delivery-report.md 提取；提取不到则写“见交付报告”}
EOF
```

执行提交：

```bash
git commit -F .tmp/rq-finish.commitmsg.txt
```

若无变更需要提交（工作区干净），跳过本步骤并提示。
注意：即便“当前无未提交变更”，仍可能存在“未推送提交”，仍应继续 Step 3 推送并创建/复用 MR。

### Step 3: 推送远程并创建 MR

#### 3a. 子模块推送

若 Step 2a 中有子模块提交，逐个推送：

```bash
cd {submodule_path}
git push -u origin {rq_id}
cd {回到主项目根目录}
```

#### 3b. 主项目推送并创建 MR

1. 识别 MR 目标分支：

优先使用 `{target_branch}`；未提供则自动识别远程默认分支：

```bash
target_branch="${target_branch:-$(git symbolic-ref --quiet --short refs/remotes/origin/HEAD 2>/dev/null | sed 's@^origin/@@')}"
target_branch="${target_branch:-master}"
```

2. 组装 MR 标题与描述：

- 标题：`feat({rq_id}): {需求简述}`
- 描述：从 `final-delivery-report.md` 提取“交付概览/测试汇总/评审结论”，并进行**单行化与长度控制**（push option 对换行和引号非常敏感）。
- 推荐将描述压缩为单行，并附上报告路径，避免换行/引号导致 push 失败：
  - `交付报告: .claude/notepads/{rq_id}/final-delivery-report.md | 测试: ... | 评审: ... | 变更摘要: ...`

建议生成“安全单行描述”（示例约束：去换行、压缩空白、裁剪长度、移除双引号）：

```bash
mr_desc="$(sed -n '1,120p' ".claude/notepads/{rq_id}/final-delivery-report.md" \
  | tr '\n' ' ' \
  | sed 's/[[:space:]]\\+/ /g; s/\"//g' \
  | cut -c 1-800)"
```

使用 GitLab push options 一步完成推送 + 创建 MR：

```bash
git push -u origin {rq_id} \
  -o merge_request.create \
  -o merge_request.target="${target_branch}" \
  -o merge_request.title="feat({rq_id}): {需求简述}" \
  -o merge_request.description="${mr_desc}" \
  -o merge_request.remove_source_branch
```

- 推送失败则**阻塞**，输出错误信息，不继续后续步骤。
- 若失败原因显示 MR 已存在（常见为 push option 创建失败），允许降级重试：仅执行 `git push -u origin {rq_id}`，不再带 `merge_request.create` 相关 options，并提示用户到 GitLab 上复用现有 MR。
- 推送成功后从 `git push` 输出中提取并展示 MR 链接（如输出包含）。

### Step 4: 清理工作区

清理属于破坏性动作，默认应交互确认。使用 AskUserQuestion 询问用户是否清理工作区，提供选项：
- **立即清理**：删除 worktree 目录，保留本地分支
- **暂不清理**：跳过清理，用户后续手动处理

若提供了可选输入 `{cleanup}`：
- `cleanup=yes`：跳过询问，直接执行清理（但仍需通过“最终安全校验”）
- `cleanup=no`：跳过清理
- `cleanup=ask` 或未提供：按默认交互询问

清理前必须做最终安全校验：确保所有变更已提交且已推送到远程（主项目 + 子模块）。

建议检查点：

```bash
# 1) 主项目必须干净
test -z "$(git status --porcelain)" || (git status --short && exit 1)

# 2) 主项目必须无未推送提交（需要 upstream；若无 upstream 视为未推送）
git rev-parse --abbrev-ref --symbolic-full-name @{u} >/dev/null 2>&1 || (echo "no upstream" && exit 1)
test "$(git rev-list --count @{u}..HEAD)" = "0" || (echo "unpushed commits" && exit 1)

# 3) 子模块逐个校验
git submodule foreach --recursive --quiet '
  test -z "$(git status --porcelain)" || (echo "dirty: $sm_path" && git status --porcelain && exit 1)
  git rev-parse --abbrev-ref --symbolic-full-name @{u} >/dev/null 2>&1 || (echo "no upstream: $sm_path" && exit 1)
  test "$(git rev-list --count @{u}..HEAD)" = "0" || (echo "unpushed commits: $sm_path" && exit 1)
'
```

若用户选择清理：

```bash
# 记录当前 worktree 路径（将被删除）
worktree_path="$(pwd -P)"

# 从 worktree 内定位主仓库根目录：git-common-dir 指向主仓库的 .git
common_dir="$(git rev-parse --path-format=absolute --git-common-dir)"
main_root="$(cd "${common_dir}/.." && pwd -P)"

# 必须先离开将被删除的目录
cd "${main_root}"

# 删除 worktree，保留本地分支（不做分支删除）
git worktree remove "${worktree_path}" --force
```

输出清理结果摘要和后续提示：
- MR 合并后可用 `git branch -d {rq_id}` 清理本地分支
- 子模块分支同理：`git submodule foreach 'git branch -d {rq_id} 2>/dev/null'`

### Step 5: 输出闭环总结

展示完整的需求开发闭环结果：

```
✅ 需求 {rq_id} 开发闭环完成

📝 提交记录:
  - {commit hash 简写} feat({rq_id}): {需求简述}
  - {子模块提交记录（如有）}

🔗 Merge Request:
  - {MR 链接}

🧹 工作区:
  - {清理状态：已清理/未清理}

📋 后续操作:
  - 等待 MR 审核合并
  - 合并后清理本地分支: git branch -d {rq_id}
```

## 约束

1. **禁止**在 `final-delivery-report.md` 不存在或 status 非 `completed` 时执行
2. **禁止**强制推送（`--force`）
3. 子模块提交和推送**必须**在主项目之前完成
4. 清理工作区前**必须**确认所有变更已推送到远程
5. commit message **必须**包含 `{rq_id}` 标识
6. 清理时仅删除 worktree，**保留**本地分支（等 MR 合并后再手动清理）
7. 使用 GitLab push options 创建 MR（`-o merge_request.create`），不依赖外部 CLI 工具
