---
name: feature-curl-test-generator
description: Use when 需要根据任意项目中的特性清单目录生成模块级 curl 接口测试脚本，且用户能够显式提供特性清单目录、目标模块和可选的访问地址或环境映射信息。
---

# feature-curl-test-generator

## 概览

基于特性清单目录中的 Markdown 模块清单，自动生成可执行的 curl 测试脚本与报告模板。该技能不再绑定 COMS 目录结构；只要用户提供特性清单目录，就可以在当前项目根目录下生成测试产物。

## 何时使用

- 用户要求“根据 feature list / 特性清单生成 curl 测试脚本”
- 用户能提供特性清单目录路径
- 目标项目需要把测试产物放在当前项目的 `tests` 目录下
- 希望通过 `--base-url` 或环境文件映射推导接口地址

## 命令

在项目根目录执行：

```bash
bash .codex/skills/feature-curl-test-generator/scripts/generate_module_curl_tests.sh \
  --feature-dir docs/feature-list \
  --list-modules
```

```bash
bash .codex/skills/feature-curl-test-generator/scripts/generate_module_curl_tests.sh \
  --feature-dir docs/feature-list \
  --module system \
  --base-url https://127.0.0.1:6050
```

```bash
bash .codex/skills/feature-curl-test-generator/scripts/generate_module_curl_tests.sh \
  --feature-dir docs/feature-list \
  --module 告警管理 \
  --aliases-file .codex/skills/feature-curl-test-generator/references/module-aliases.example.md \
  --env dev \
  --env-file .env/dev.conf \
  --env-host-key-template FEATURE_ENV_{ENV}_HOST \
  --port 7443
```

## 参数

- 必填：`--feature-dir <dir>`
- 二选一：`--module <模块>` 或 `--list-modules`
- 可选：
  - `--output-root <dir>`：输出根目录，默认 `tests/feature-curl`
  - `--execute`：生成后立即执行 `curl-tests.sh`
  - `--base-url <url>`：接口基地址，优先级最高
  - `--api-key-header <header>`：默认 `X-API-Key`
  - `--api-key <key>`：默认空
  - `--env <name>` + `--env-file <file>` + `--env-host-key-template <template>`：通过环境文件推导主机
  - `--port <port>`：环境推导时使用，默认 `6050`
  - `--aliases-file <file>`：可选别名文件，用于补充 slug / 标题之外的模块别名

## 运行时规则

- 默认输出到 `tests/feature-curl/<module>/`
- `--base-url` 优先于环境推导
- 未显式提供 `--base-url` 且环境推导不足时，回退到 `https://127.0.0.1:6050`
- API Key 仅使用显式参数，不再读取项目专属配置文件
- 别名文件可使用简单 `slug: alias1, alias2` 格式，也可使用 Markdown 表格格式

## 输出

- `curl-tests.sh`：可执行 curl 测试脚本
- `report-template.md`：测试报告模板
- `last-run-report.md`：仅在 `--execute` 时生成

## 解析规则

- 仅支持当前已有的 Markdown 特性清单规范
- 解析 `### 接口列表` 表格中的 `功能/API/方法/认证/说明`
- 解析 `#### METHOD PATH - ...` 详情段中的必填参数
- 默认生成正向、缺认证、缺必填参数三类用例

## 参考

- 示例别名文件：`references/module-aliases.example.md`
- 真实生成逻辑：`scripts/generate_module_curl_tests.py`
- 统一入口脚本：`scripts/generate_module_curl_tests.sh`
