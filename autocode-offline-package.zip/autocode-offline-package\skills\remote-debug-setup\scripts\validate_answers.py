#!/usr/bin/env python3
import argparse
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple


def load_json(path: Path) -> Dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    try:
        data = json.loads(text)
    except Exception as exc:
        raise SystemExit(f"[ERROR] JSON 解析失败: {path}, 错误: {exc}")
    if not isinstance(data, dict):
        raise SystemExit(f"[ERROR] 顶层必须为对象: {path}")
    return data


def err(msg: str) -> Tuple[bool, str]:
    return False, msg


def ok() -> Tuple[bool, str]:
    return True, "OK"


def validate_server_name_whitelist(project: Dict[str, Any], server_name: str) -> Tuple[bool, str]:
    regex = str(project.get("server_name_whitelist_regex") or r"^(dev|test)")
    try:
        pattern = re.compile(regex)
    except Exception as exc:
        return err(f"project.server_name_whitelist_regex 非法: {exc}")
    if not pattern.search(server_name):
        return err(f"服务器不在白名单内: {server_name}, regex={regex}")
    return ok()


def validate_ssh(ssh: Dict[str, Any]) -> Tuple[bool, str]:
    host = str(ssh.get("host") or "").strip()
    username = str(ssh.get("username") or "").strip()
    port = ssh.get("port", 22)
    if not host:
        return err("ssh.host 必填")
    if not username:
        return err("ssh.username 必填")
    try:
        port_int = int(port)
    except Exception:
        return err("ssh.port 必须是整数")
    if port_int <= 0 or port_int > 65535:
        return err("ssh.port 范围非法")

    auth = ssh.get("auth")
    if not isinstance(auth, dict):
        return err("ssh.auth 必须为对象")
    auth_type = str(auth.get("type") or "").strip()
    if auth_type not in {"password", "key"}:
        return err("ssh.auth.type 仅支持 password|key")
    if auth_type == "password":
        password = str(auth.get("password") or "")
        if not password:
            return err("ssh.auth.type=password 时 ssh.auth.password 必填")
    if auth_type == "key":
        identity_file = str(auth.get("identity_file") or "")
        if not identity_file:
            return err("ssh.auth.type=key 时 ssh.auth.identity_file 必填")
    return ok()


def validate_service(service: Dict[str, Any]) -> Tuple[bool, str]:
    service_id = str(service.get("service_id") or "").strip()
    name = str(service.get("name") or "").strip()
    mode = str(service.get("mode") or "").strip()
    if not service_id:
        return err("services[].service_id 必填")
    if not name:
        return err(f"services[{service_id}].name 必填")
    if mode not in {"systemd", "script", "docker"}:
        return err(f"services[{service_id}].mode 仅支持 systemd|script|docker")

    if mode == "systemd":
        systemd = service.get("systemd")
        if not isinstance(systemd, dict):
            return err(f"services[{service_id}].systemd 必须为对象")
        unit = str(systemd.get("unit") or "").strip()
        if not unit:
            return err(f"services[{service_id}].systemd.unit 必填")

    if mode == "script":
        script = service.get("script")
        if not isinstance(script, dict):
            return err(f"services[{service_id}].script 必须为对象")
        for key in ["start", "stop", "check"]:
            value = str(script.get(key) or "").strip()
            if not value:
                return err(f"services[{service_id}].script.{key} 必填")

    if mode == "docker":
        docker = service.get("docker")
        if not isinstance(docker, dict):
            return err(f"services[{service_id}].docker 必须为对象")
        container = str(docker.get("container") or "").strip()
        if not container:
            return err(f"services[{service_id}].docker.container 必填")

    logs = service.get("logs")
    if not isinstance(logs, dict):
        return err(f"services[{service_id}].logs 必须为对象")
    logs_type = str(logs.get("type") or "").strip()
    if logs_type not in {"journalctl", "docker", "files"}:
        return err(f"services[{service_id}].logs.type 仅支持 journalctl|docker|files")
    if logs_type == "journalctl":
        unit = str(logs.get("journal_unit") or "").strip()
        if not unit:
            # 允许从 systemd.unit 继承，但必须能拿到。
            systemd = service.get("systemd") if isinstance(service.get("systemd"), dict) else {}
            unit = str(systemd.get("unit") or "").strip()
        if not unit:
            return err(f"services[{service_id}].logs.journal_unit 必填（logs.type=journalctl）")
    if logs_type == "files":
        paths = logs.get("paths")
        if not isinstance(paths, list) or not paths:
            return err(f"services[{service_id}].logs.paths 必须为非空数组（logs.type=files）")
        ok_paths = [str(p).strip() for p in paths if str(p).strip()]
        if not ok_paths:
            return err(f"services[{service_id}].logs.paths 不能为空（logs.type=files）")
    if logs_type == "docker":
        docker = service.get("docker") if isinstance(service.get("docker"), dict) else {}
        container = str(docker.get("container") or "").strip()
        if not container:
            return err(f"services[{service_id}].docker.container 必填（logs.type=docker）")

    return ok()


def validate_components(components: Dict[str, Any], server_name: str) -> Tuple[bool, str]:
    if not isinstance(components, dict):
        return ok()

    nacos = components.get("nacos")
    if isinstance(nacos, dict) and bool(nacos.get("enabled") or False):
        access = nacos.get("access") if isinstance(nacos.get("access"), dict) else {}
        access_mode = str(access.get("mode") or "direct")
        for key in ["protocol", "port", "username"]:
            val = nacos.get(key)
            if val is None or str(val).strip() == "":
                return err(f"servers[{server_name}].components.nacos.{key} 必填（enabled=true）")
        host = str(nacos.get("host") or "").strip()
        if not host and access_mode != "ssh":
            return err(f"servers[{server_name}].components.nacos.host 必填（enabled=true, access.mode!=ssh）")
        # password_plain 允许为空：只读探测可用，写操作由插件技能再次确认。

    db = components.get("db")
    if isinstance(db, dict) and bool(db.get("enabled") or False):
        access = db.get("access") if isinstance(db.get("access"), dict) else {}
        access_mode = str(access.get("mode") or "direct")
        port = db.get("port")
        if port is None or str(port).strip() == "":
            return err(f"servers[{server_name}].components.db.port 必填（enabled=true）")
        host = str(db.get("host") or "").strip()
        if not host and access_mode != "ssh":
            return err(f"servers[{server_name}].components.db.host 必填（enabled=true, access.mode!=ssh）")

    kafka = components.get("kafka")
    if isinstance(kafka, dict) and bool(kafka.get("enabled") or False):
        bs = str(kafka.get("bootstrap_servers") or "").strip()
        if not bs:
            return err(f"servers[{server_name}].components.kafka.bootstrap_servers 必填（enabled=true）")

    es = components.get("es")
    if isinstance(es, dict) and bool(es.get("enabled") or False):
        access = es.get("access") if isinstance(es.get("access"), dict) else {}
        access_mode = str(access.get("mode") or "direct")
        for key in ["protocol", "port"]:
            val = es.get(key)
            if val is None or str(val).strip() == "":
                return err(f"servers[{server_name}].components.es.{key} 必填（enabled=true）")
        host = str(es.get("host") or "").strip()
        if not host and access_mode != "ssh":
            return err(f"servers[{server_name}].components.es.host 必填（enabled=true, access.mode!=ssh）")
    return ok()


def validate_answers(path: Path, allow_min: bool) -> None:
    data = load_json(path)
    suite_version = str(data.get("suite_version") or "").strip()
    if suite_version and suite_version not in {"2"}:
        raise SystemExit(f"[ERROR] suite_version 不支持: {suite_version}")

    project = data.get("project")
    if not isinstance(project, dict):
        raise SystemExit("[ERROR] project 必须为对象")

    servers = data.get("servers")
    if not isinstance(servers, list) or not servers:
        raise SystemExit("[ERROR] servers 必须为非空数组")

    seen_server_names: set[str] = set()
    for server in servers:
        if not isinstance(server, dict):
            raise SystemExit("[ERROR] servers[] 必须为对象")
        name = str(server.get("name") or "").strip()
        if not name:
            raise SystemExit("[ERROR] servers[].name 必填")
        if name in seen_server_names:
            raise SystemExit(f"[ERROR] servers[].name 重复: {name}")
        seen_server_names.add(name)
        ok1, msg1 = validate_server_name_whitelist(project, name)
        if not ok1:
            raise SystemExit(f"[ERROR] {msg1}")

        ssh = server.get("ssh")
        if not isinstance(ssh, dict):
            raise SystemExit(f"[ERROR] servers[{name}].ssh 必须为对象")
        ok2, msg2 = validate_ssh(ssh)
        if not ok2:
            raise SystemExit(f"[ERROR] servers[{name}] {msg2}")

        services = server.get("services")
        if services is None:
            if allow_min:
                continue
            raise SystemExit(f"[ERROR] servers[{name}].services 必填")
        if not isinstance(services, list) or not services:
            raise SystemExit(f"[ERROR] servers[{name}].services 必须为非空数组")
        seen_service_ids: set[str] = set()
        for service in services:
            if not isinstance(service, dict):
                raise SystemExit(f"[ERROR] servers[{name}].services[] 必须为对象")
            sid = str(service.get("service_id") or "").strip()
            if sid:
                if sid in seen_service_ids:
                    raise SystemExit(f"[ERROR] servers[{name}].services[].service_id 重复: {sid}")
                seen_service_ids.add(sid)
            ok3, msg3 = validate_service(service)
            if not ok3:
                raise SystemExit(f"[ERROR] servers[{name}] {msg3}")

        components = server.get("components")
        if isinstance(components, dict):
            ok4, msg4 = validate_components(components, name)
            if not ok4:
                raise SystemExit(f"[ERROR] {msg4}")


def main() -> None:
    parser = argparse.ArgumentParser(description="校验 remote-debug-setup 的 answers 输入")
    parser.add_argument("--answers", required=True, help="answers.min.json 或 answers.full.json")
    parser.add_argument("--mode", choices=["min", "full"], default="full")
    args = parser.parse_args()

    answers_path = Path(args.answers).expanduser().resolve()
    if not answers_path.exists():
        raise SystemExit(f"[ERROR] answers 文件不存在: {answers_path}")
    validate_answers(answers_path, allow_min=args.mode == "min")
    print("[OK] answers 校验通过")


if __name__ == "__main__":
    main()
