---
name: api-test-orchestrator
description: API 测试编排中心。协调整个 API 测试工作流：配置检查 → 特性清单生成 → 用例列表生成 → 人工审查 → 用例详情+脚本生成 → 执行测试 → 报告生成。支持断点续跑和阶段跳过。
---

# API 测试编排中心技能

## 调用方

- 用户直接调用：启动完整的 API 测试工作流
- 可指定从某个阶段开始执行

---

## 工作流总览

```
Phase 0: 配置检查
    │  检查 tests/api-test/api-test.config.yaml 是否存在
    │  不存在 → 调用 api-test-config 生成
    ↓
Phase 1: 特性清单生成
    │  调用 feature-api-list-generator
    │  输出: docs/features/{module}-api-features.csv
    ↓
Phase 2: 用例列表生成（一阶段）
    │  调用 api-test-case-generator（选择 Path A/B/C）
    │  输出: 用例列表 CSV（status=pending）
    │  ⏸ 暂停，等待人工审查
    │  人工审查通过 → status 改为 approved
    ↓
Phase 3: 用例详情+脚本生成（二阶段）
    │  调用 api-test-detail-generator
    │  输出: tests/api-test/usecase/ + tests/api-test/scripts/
    │  更新 tests/api-test/testcase-registry.csv
    ↓
Phase 4: 执行测试
    │  调用 api-test-executor
    │  输出: .tests/api-reports/{run-id}/
    ↓
Phase 5: 报告生成
    │  调用 api-test-report-builder
    │  输出: ai-report.json + report.html
    ↓
完成: 输出测试结果摘要
```

---

## 执行模式

### 完整流程

从 Phase 0 开始，依次执行所有阶段。

```
调用参数: 无特殊参数，或 --full
```

### 指定路径

选择用例生成路径（Phase 2）：

```
--path A    # 需求驱动（需指定 --rq-id）
--path B    # 后端代码提取（需指定 --backend-dir）
--path C    # Git 变动刷新（需指定 --git-range）
```

### 从指定阶段开始

跳过已完成的阶段：

```
--from phase3    # 从用例详情生成开始（假设用例列表已审查通过）
--from phase4    # 从执行测试开始（假设脚本已生成）
--from phase5    # 仅生成报告（假设测试已执行）
```

### 仅执行测试+报告

```
--run-only       # 等价于 --from phase4
--smoke-only     # 仅执行冒烟测试 + 报告
```

---

## 阶段详情

### Phase 0: 配置检查

1. 检查 `tests/api-test/` 目录下是否有 `api-test.config.yaml`
2. 不存在 → 调用 `api-test-config` 技能交互式生成
3. 存在 → 验证配置完整性（environments、auth 必填项）

### Phase 1: 特性清单生成

1. 确定目标模块（用户指定或自动检测）
2. 调用 `feature-api-list-generator`
3. 输出 `docs/features/{module}-api-features.csv`
4. 展示特性清单摘要（接口数量、模块分布）

### Phase 2: 用例列表生成

1. 根据 `--path` 参数选择生成路径
2. 调用 `api-test-case-generator`
3. 输出用例列表 CSV
4. 展示用例统计（总数、级别分布、覆盖类型分布）
5. **暂停**：提示用户审查用例列表
6. 用户确认后，将 `status` 从 `pending` 改为 `approved`

### Phase 3: 用例详情+脚本生成

1. 读取 `status=approved` 的用例
2. 调用 `api-test-detail-generator`
3. 生成 YAML 详情 + pytest 脚本 + conftest.py + utils/
4. 更新 `tests/api-test/testcase-registry.csv`
5. 展示生成摘要（文件数、用例数）

### Phase 4: 执行测试

1. 调用 `api-test-executor`
2. 根据执行模式选择筛选条件
3. 等待执行完成
4. 展示执行摘要（通过率、耗时）

### Phase 5: 报告生成

1. 调用 `api-test-report-builder`
2. 生成 `ai-report.json` + `report.html`
3. 展示最终结果（pass/fail/warn）
4. 输出报告文件路径

---

## 技能依赖关系

```
api-test-orchestrator
├── api-test-config              # Phase 0
├── feature-api-list-generator   # Phase 1
├── api-test-case-generator      # Phase 2
├── api-test-detail-generator    # Phase 3
├── api-test-executor            # Phase 4
└── api-test-report-builder      # Phase 5
```

---

## 状态管理

编排器在 `.tests/orchestrator-state.json` 中记录执行状态：

```json
{
  "current_phase": 3,
  "module": "auth",
  "path": "B",
  "run_id": null,
  "phase_status": {
    "phase0": "completed",
    "phase1": "completed",
    "phase2": "completed",
    "phase3": "in_progress",
    "phase4": "pending",
    "phase5": "pending"
  },
  "updated_at": "2026-03-14T14:30:00Z"
}
```

支持断点续跑：读取状态文件，从上次中断的阶段继续。

---

## 约束

- Phase 2 到 Phase 3 之间必须有人工审查环节，不可自动跳过
- 每个阶段的输出是下一阶段的输入，不可乱序执行
- 编排器本身不直接操作文件，通过调用子技能完成具体工作
- 执行失败不中断流程，由报告阶段汇总结果

## 路径约定

本技能及子技能中出现的所有目录路径均为默认值，实际以 `tests/api-test/api-test.config.yaml` 的 `output` 配置为准：

| 默认路径 | 配置键 | 说明 |
|---------|--------|------|
| `docs/features/` | `output.feature_dir` | API 特性清单 |
| `tests/api-test/usecase/` | `output.usecase_dir` | YAML 用例目录 |
| `tests/api-test/scripts/` | `output.script_dir` | pytest 脚本目录 |
| `tests/api-test/testcase-registry.csv` | `output.registry_file` | 统一用例注册表 |
| `.tests/api-reports/` | `execution.report_dir` | 报告输出目录 |
| `.tests/cache/` | — | 中间缓存（固定路径） |
