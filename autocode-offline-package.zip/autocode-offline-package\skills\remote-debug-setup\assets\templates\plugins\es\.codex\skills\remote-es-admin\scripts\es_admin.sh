#!/usr/bin/env bash
set -euo pipefail

SERVER_NAME=""
CONFIG_PATH=".secrets/dev-servers.yaml"
ACTION=""

INDEX_NAME=""
DOC_ID=""
JSON_BODY=""
JSON_FILE=""
QUERY_JSON=""
QUERY_FILE=""

INSECURE_TLS="false"
CONFIRM="false"
DRY_RUN="false"
HTTP_TIMEOUT_SECONDS="15"

usage() {
  cat <<'USAGE'
用法:
  es_admin.sh --server <name> --action <info|health|list-indices|create-index|delete-index|put-mapping|put-settings|put-doc|delete-doc|search>
             [--config <path>]
             [--index <name>] [--id <doc_id>]
             [--json <text> | --json-file <path>]
             [--query <text> | --query-file <path>]
             [--http-timeout <seconds>]
             [--insecure-tls] [--confirm] [--dry-run]

说明:
  - 通过 HTTP API 调用 ES；地址来自 servers[].components.es（默认 host=ssh.host）。
  - 写入/破坏性动作（create-index/delete-index/put-mapping/put-settings/put-doc/delete-doc）必须显式加 --confirm。
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --server) SERVER_NAME="$2"; shift 2 ;;
    --config) CONFIG_PATH="$2"; shift 2 ;;
    --action) ACTION="$2"; shift 2 ;;
    --index) INDEX_NAME="$2"; shift 2 ;;
    --id) DOC_ID="$2"; shift 2 ;;
    --json) JSON_BODY="$2"; shift 2 ;;
    --json-file) JSON_FILE="$2"; shift 2 ;;
    --query) QUERY_JSON="$2"; shift 2 ;;
    --query-file) QUERY_FILE="$2"; shift 2 ;;
    --http-timeout) HTTP_TIMEOUT_SECONDS="$2"; shift 2 ;;
    --insecure-tls) INSECURE_TLS="true"; shift ;;
    --confirm) CONFIRM="true"; shift ;;
    --dry-run) DRY_RUN="true"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "[ERROR] 未知参数: $1"; usage; exit 1 ;;
  esac
done

if [[ -z "$SERVER_NAME" || -z "$ACTION" ]]; then
  echo "[ERROR] --server 与 --action 必填"; usage; exit 1
fi
if [[ ! -f "$CONFIG_PATH" ]]; then
  echo "[ERROR] 配置文件不存在: $CONFIG_PATH"; exit 1
fi

if [[ -n "$JSON_FILE" && ! -f "$JSON_FILE" ]]; then
  echo "[ERROR] json 文件不存在: $JSON_FILE"; exit 1
fi
if [[ -n "$QUERY_FILE" && ! -f "$QUERY_FILE" ]]; then
  echo "[ERROR] query 文件不存在: $QUERY_FILE"; exit 1
fi
if [[ -n "$JSON_BODY" && -n "$JSON_FILE" ]]; then
  echo "[ERROR] --json 与 --json-file 只能二选一"; exit 1
fi
if [[ -n "$QUERY_JSON" && -n "$QUERY_FILE" ]]; then
  echo "[ERROR] --query 与 --query-file 只能二选一"; exit 1
fi
if ! [[ "$HTTP_TIMEOUT_SECONDS" =~ ^[1-9][0-9]*$ ]]; then
  echo "[ERROR] --http-timeout 必须为正整数"; exit 1
fi

case "$ACTION" in
  info|health|list-indices) ;;
  create-index|delete-index)
    [[ -n "$INDEX_NAME" ]] || { echo "[ERROR] action=$ACTION 时 --index 必填"; exit 1; }
    ;;
  put-mapping|put-settings)
    [[ -n "$INDEX_NAME" ]] || { echo "[ERROR] action=$ACTION 时 --index 必填"; exit 1; }
    ;;
  put-doc|delete-doc)
    [[ -n "$INDEX_NAME" ]] || { echo "[ERROR] action=$ACTION 时 --index 必填"; exit 1; }
    [[ -n "$DOC_ID" ]] || { echo "[ERROR] action=$ACTION 时 --id 必填"; exit 1; }
    ;;
  search)
    [[ -n "$INDEX_NAME" ]] || { echo "[ERROR] action=search 时 --index 必填"; exit 1; }
    ;;
  *) echo "[ERROR] 未支持 action=$ACTION"; usage; exit 1 ;;
esac

if [[ "$ACTION" == "create-index" || "$ACTION" == "delete-index" || "$ACTION" == "put-mapping" || "$ACTION" == "put-settings" || "$ACTION" == "put-doc" || "$ACTION" == "delete-doc" ]]; then
  if [[ "$CONFIRM" != "true" ]]; then
    echo "[ERROR] action=$ACTION 属于写/破坏性操作，必须显式加 --confirm"; exit 2
  fi
fi

for cmd in python3 curl; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "[ERROR] 缺少命令: $cmd"; exit 1; }
done

python3 - "$CONFIG_PATH" "$SERVER_NAME" "$ACTION" "$INDEX_NAME" "$DOC_ID" "$JSON_BODY" "$JSON_FILE" "$QUERY_JSON" "$QUERY_FILE" "$INSECURE_TLS" "$DRY_RUN" "$HTTP_TIMEOUT_SECONDS" <<'PY'
import json
import subprocess
import sys
import os
import signal
import socket
import time
import shlex
import shutil
from typing import Any, Dict, Tuple

(
  config_path, server_name, action, index_name, doc_id,
  json_body, json_file, query_json, query_file, insecure_tls, dry_run, http_timeout_seconds,
) = sys.argv[1:]

insecure_tls = insecure_tls.lower() == 'true'
dry_run = dry_run.lower() == 'true'
http_timeout_seconds = int(http_timeout_seconds)

cfg = json.loads(open(config_path,'r',encoding='utf-8').read())
server = next((s for s in cfg.get('servers',[]) if isinstance(s,dict) and s.get('name')==server_name), None)
if not server:
    print(f"[ERROR] 未找到服务器: {server_name}")
    sys.exit(1)

components = server.get('components') if isinstance(server.get('components'), dict) else {}
es = components.get('es') if isinstance(components.get('es'), dict) else None
if not es:
    es = server.get('es') if isinstance(server.get('es'), dict) else None
    if es:
        print('[WARN] 检测到已废弃字段 servers[].es，请迁移到 servers[].components.es')
if not es:
    print('[ERROR] 未配置 servers[].components.es')
    sys.exit(2)

ssh = server.get('ssh') if isinstance(server.get('ssh'), dict) else {}
ssh_auth = ssh.get('auth') if isinstance(ssh.get('auth'), dict) else {}
ssh_host = str(ssh.get('host') or '')
ssh_port = int(ssh.get('port') or 22)
ssh_user = str(ssh.get('username') or '')
ssh_auth_type = str(ssh_auth.get('type') or 'password')
ssh_password = str(ssh_auth.get('password') or '')
ssh_identity = str(ssh_auth.get('identity_file') or '')
defaults = server.get('defaults') if isinstance(server.get('defaults'), dict) else {}
known_hosts_file = str(defaults.get('known_hosts_file') or '/tmp/remote-dev-deploy-known-hosts')
strict = 'yes' if bool(defaults.get('strict_host_key_check') or False) else 'no'

protocol = str(es.get('protocol') or 'http')
access = es.get('access') if isinstance(es.get('access'), dict) else {}
access_mode = str(access.get('mode') or 'direct')

es_host = str(es.get('host') or '')
if not es_host:
    # direct 模式下默认取 ssh.host；ssh 模式下默认认为 ES 在远端本机回环（避免把公网 IP 作为远端目标）。
    es_host = ssh_host if access_mode != 'ssh' else '127.0.0.1'
port = int(es.get('port') or 0)
if not es_host or not port:
    print('[ERROR] es.host/es.port 必填（host 默认取 ssh.host；access.mode=ssh 时默认 127.0.0.1）')
    sys.exit(3)

auth = es.get('auth') if isinstance(es.get('auth'), dict) else {}
auth_mode = str(auth.get('mode') or 'none')
username = str(auth.get('username') or '')
password_plain = str(auth.get('password_plain') or '')

tunnel_proc = None

def pick_free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    p = int(s.getsockname()[1])
    s.close()
    return p

def wait_listen(p: int, timeout_s: float = 4.0) -> bool:
    end = time.time() + timeout_s
    while time.time() < end:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.3)
            s.connect(('127.0.0.1', p))
            s.close()
            return True
        except Exception:
            try:
                s.close()
            except Exception:
                pass
            time.sleep(0.1)
    return False

def start_ssh_tunnel(target_host: str, target_port: int) -> Tuple[subprocess.Popen, int]:
    if not ssh_host or not ssh_user:
        raise RuntimeError('servers[].ssh.host/username 为空，无法建立 ssh tunnel')
    lp = pick_free_port()
    ssh_cmd = [
        'ssh',
        '-p', str(ssh_port),
        '-o', f'StrictHostKeyChecking={strict}',
        '-o', f'UserKnownHostsFile={known_hosts_file}',
        '-o', 'ConnectTimeout=8',
        '-o', 'ExitOnForwardFailure=yes',
        '-o', 'ServerAliveInterval=5',
        '-o', 'ServerAliveCountMax=3',
        '-N',
        '-L', f'127.0.0.1:{lp}:{target_host}:{int(target_port)}',
    ]
    if ssh_auth_type == 'key' and ssh_identity:
        ssh_cmd += ['-i', ssh_identity, '-o', 'BatchMode=yes']
    ssh_cmd.append(f'{ssh_user}@{ssh_host}')
    if ssh_auth_type == 'password':
        if not ssh_password:
            raise RuntimeError('ssh.auth.password 为空，无法建立 tunnel')
        if shutil.which('sshpass') is None:
            raise RuntimeError('缺少 sshpass（password 认证需要）')
        ssh_cmd = ['sshpass', '-p', ssh_password] + ssh_cmd
    proc = subprocess.Popen(
        ssh_cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        preexec_fn=os.setsid if hasattr(os, 'setsid') else None,
    )
    if not wait_listen(lp, timeout_s=4.0):
        err = ''
        try:
            err = (proc.stderr.read(2000) if proc.stderr else '')  # type: ignore[union-attr]
        except Exception:
            err = ''
        try:
            if hasattr(os, 'killpg'):
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            else:
                proc.terminate()
        except Exception:
            pass
        raise RuntimeError(f'ssh tunnel 建立失败: {err.strip()}')
    return proc, lp

try:
    # dry-run 不应触发网络连接/ssh；仅输出计划。
    if dry_run:
        base = f"{protocol}://{es_host}:{port}"
    elif access_mode == 'ssh':
        tunnel_proc, local_port = start_ssh_tunnel(es_host, port)
        base = f"{protocol}://127.0.0.1:{local_port}"
    else:
        base = f"{protocol}://{es_host}:{port}"
except Exception as exc:
    print(f"[ERROR] {exc}")
    sys.exit(8)

curl_tls = ['-k'] if insecure_tls and protocol == 'https' else []

headers = ['-H', 'Content-Type: application/json']
auth_args = []
if auth_mode == 'basic':
    if not username or not password_plain:
        print('[ERROR] auth.mode=basic 需要 username/password_plain')
        sys.exit(4)
    auth_args = ['-u', f'{username}:{password_plain}']

def read_text(val: str, path: str) -> str:
    if path:
        return open(path,'r',encoding='utf-8').read()
    return val

def curl(method: str, url: str, body: str = "") -> Tuple[int, str]:
    args = ['curl', *curl_tls, '-sS', '-m', str(http_timeout_seconds), '-X', method, url, *headers, *auth_args]
    if body:
        args += ['--data-binary', body]
    proc = subprocess.run(args, text=True, capture_output=True)
    out = (proc.stdout or '') + (proc.stderr or '')
    return proc.returncode, out

def plan(method: str, url: str) -> None:
    print(f"[PLAN] {method} {url}")

try:
    if dry_run:
        print(f"[PLAN] base={base} action={action}")

    if action == 'info':
        url = base + '/'
        plan('GET', url)
        if dry_run: sys.exit(0)
        code, out = curl('GET', url)
        print(out); sys.exit(0 if code==0 else 5)

    if action == 'health':
        url = base + '/_cluster/health'
        plan('GET', url)
        if dry_run: sys.exit(0)
        code, out = curl('GET', url)
        print(out); sys.exit(0 if code==0 else 5)

    if action == 'list-indices':
        url = base + '/_cat/indices?format=json'
        plan('GET', url)
        if dry_run: sys.exit(0)
        code, out = curl('GET', url, "")
        print(out); sys.exit(0 if code==0 else 5)

if action == 'create-index':
    body = read_text(json_body, json_file).strip()
    if not body:
        body = '{}'
    url = base + f'/{index_name}'
    plan('PUT', url)
    if dry_run: sys.exit(0)
    code, out = curl('PUT', url, body)
    print(out); sys.exit(0 if code==0 else 5)

if action == 'delete-index':
    url = base + f'/{index_name}'
    plan('DELETE', url)
    if dry_run: sys.exit(0)
    code, out = curl('DELETE', url, "")
    print(out); sys.exit(0 if code==0 else 5)

if action == 'put-mapping':
    body = read_text(json_body, json_file)
    if not body.strip():
        print('[ERROR] put-mapping 需要 --json 或 --json-file')
        sys.exit(6)
    url = base + f'/{index_name}/_mapping'
    plan('PUT', url)
    if dry_run: sys.exit(0)
    code, out = curl('PUT', url, body)
    print(out); sys.exit(0 if code==0 else 5)

if action == 'put-settings':
    body = read_text(json_body, json_file)
    if not body.strip():
        print('[ERROR] put-settings 需要 --json 或 --json-file')
        sys.exit(6)
    url = base + f'/{index_name}/_settings'
    plan('PUT', url)
    if dry_run: sys.exit(0)
    code, out = curl('PUT', url, body)
    print(out); sys.exit(0 if code==0 else 5)

if action == 'put-doc':
    body = read_text(json_body, json_file)
    if not body.strip():
        print('[ERROR] put-doc 需要 --json 或 --json-file')
        sys.exit(6)
    url = base + f'/{index_name}/_doc/{doc_id}'
    plan('PUT', url)
    if dry_run: sys.exit(0)
    code, out = curl('PUT', url, body)
    print(out); sys.exit(0 if code==0 else 5)

if action == 'delete-doc':
    url = base + f'/{index_name}/_doc/{doc_id}'
    plan('DELETE', url)
    if dry_run: sys.exit(0)
    code, out = curl('DELETE', url, "")
    print(out); sys.exit(0 if code==0 else 5)

    if action == 'search':
        q = read_text(query_json, query_file)
        if not q.strip():
            q = '{"query":{"match_all":{}}}'
        url = base + f'/{index_name}/_search'
        plan('POST', url)
        if dry_run: sys.exit(0)
        code, out = curl('POST', url, q)
        print(out); sys.exit(0 if code==0 else 5)

    print(f"[ERROR] unsupported action={action}")
    sys.exit(7)
finally:
    if tunnel_proc is not None:
        try:
            if hasattr(os, 'killpg'):
                os.killpg(os.getpgid(tunnel_proc.pid), signal.SIGTERM)
            else:
                tunnel_proc.terminate()
            tunnel_proc.wait(timeout=2)
        except Exception:
            pass
PY
