---
name: e2e-script-generator
description: E2E 脚本生成（二阶段）。读取 tests/ui-test/usecase/ 中的 YAML 用例，生成 Playwright 脚本到 tests/ui-test/scripts/，遵循 POM 和等待策略规范，并回填 CSV 注册表中的 script_path。
---

# E2E 脚本生成技能（二阶段）

## 调用方

- `e2e-orchestrator`：在用例生成完成后的脚本生成阶段调用
- 用户直接调用：为已有 YAML 用例生成或更新 Playwright 脚本

## 输入

- `tests/ui-test/usecase/{category}/*.yaml`：一阶段产物 YAML 用例文件
- `tests/ui-test/testcase-registry.csv`：用例注册表（读取用例元信息）
- 可选：指定 category、case_id 或 level 范围，仅生成部分脚本

---

## 执行流程

```
Step 1: 读取 YAML 用例
Step 2: 按 category 分组，确定 POM 页面类
Step 3: 生成/更新 Page Object 类（tests/ui-test/scripts/pages/）
Step 4: 生成测试脚本（tests/ui-test/scripts/{category}/*.spec.ts）
Step 5: 回填 CSV 中的 script_path，status pending→active
```

---

## YAML → Playwright 映射规则

| YAML 字段 | Playwright 映射 |
|-----------|----------------|
| `case_id` + `case_name` | `test('TC-UI-AUTH-001: 用户登录成功', { tag: [...] }, ...)` |
| `smoke = true` | tag 列表中加入 `'@smoke'`，使 `--grep @smoke` 可筛出冒烟用例 |
| `level` | tag 列表中加入对应级别，如 `'@P0'` / `'@P1'`，支持按级别筛选 |
| 同 category 的多个用例 | `test.describe('auth', () => { ... })` |
| `preconditions` | `test.beforeEach(async ({ page }) => { ... })` |
| `steps[].action` + `target` | `page.locator(target).click()` 或 `.fill(input)` |
| `steps[].wait = visible` | `await page.locator(target).waitFor({ state: 'visible' })` |
| `steps[].wait = networkidle` | `await page.waitForLoadState('networkidle')` |
| `steps[].wait = response` | `await page.waitForResponse(wait_pattern)` |
| `steps[].wait = none` | 无等待（直接操作） |
| `steps[].screenshot = true` | `await page.screenshot({ path: ... })` |
| `expected[].assertion = toHaveURL` | `await expect(page).toHaveURL(value)` |
| `expected[].assertion = toBeVisible` | `await expect(page.locator(value)).toBeVisible()` |
| `expected[].assertion = toContainText` | `await expect(page.locator(value)).toContainText(...)` |
| `postconditions` | `test.afterEach(async ({ page }) => { ... })` |

> **tag 生成规则**：每个 `test()` 的 tag 数组由 `level` 和 `smoke` 共同决定。示例：
> - `smoke=true, level=P0` → `{ tag: ['@smoke', '@P0'] }`
> - `smoke=false, level=P1` → `{ tag: ['@P1'] }`
>
> 这样 `--grep @smoke` 可精确筛出冒烟用例，`--grep @P0` 可筛出 P0 用例，两者均依赖 Playwright 原生 tag 机制，无需修改测试标题。

---

## 脚本生成规范

### Page Object Model（POM）

每个 category 对应一个或多个 Page 类，放在 `tests/ui-test/scripts/pages/` 目录：

```typescript
// tests/ui-test/scripts/pages/{Category}Page.ts
import { Page, Locator } from '@playwright/test'

export class {{Category}}Page {
  readonly page: Page
  // 选择器声明（优先 data-testid）
  readonly {{element}}: Locator

  constructor(page: Page) {
    this.page = page
    this.{{element}} = page.locator('[data-testid={{testid}}]')
  }

  async {{action}}({{params}}: string) {
    await this.{{element}}.fill({{params}})
  }
}
```

### 测试脚本结构

```typescript
// tests/ui-test/scripts/{category}/{feature}.spec.ts
import { test, expect } from '@playwright/test'
import { {{Category}}Page } from '../pages/{{Category}}Page'

test.describe('{{category}}', () => {

  test.beforeEach(async ({ page }) => {
    // 前置条件：preconditions 映射
  })

  test('{{case_id}}: {{case_name}}', async ({ page }) => {
    const {{categoryPage}} = new {{Category}}Page(page)

    // Steps 映射
    await {{categoryPage}}.{{action}}(...)

    // Expected 映射
    await expect(page).toHaveURL('{{url}}')
  })

  test.afterEach(async ({ page }) => {
    // 后置清理：postconditions 映射
  })

})
```

### 选择器优先级

1. `data-testid` 属性（最优先，稳定）
2. ARIA role（`role=button`, `role=textbox`）
3. 文本内容（`text=登录`）
4. CSS 选择器（最后选项，避免脆弱选择器）

### 等待策略（禁止固定延时）

| 场景 | 推荐方式 |
|------|---------|
| 等待页面加载 | `waitForLoadState('networkidle')` |
| 等待 API 响应 | `waitForResponse(urlPattern)` |
| 等待元素出现 | `waitForSelector` / `expect().toBeVisible()` |
| 等待路由跳转 | `waitForURL(pattern)` |

---

## 输出路径约定

```
tests/
└── ui-test/
    └── scripts/
        ├── {category}/
        │   └── {feature}.spec.ts      # 测试脚本（与 usecase/ 目录结构对应）
        ├── pages/                     # Page Object Model 类
        │   └── {Category}Page.ts
        └── fixtures/                  # 测试夹具
            └── auth.ts                # 认证态夹具（示例）
```

### 用例文件与脚本文件的对应关系

```
usecase/auth/login.yaml        →  scripts/auth/login.spec.ts
usecase/order/create.yaml      →  scripts/order/create.spec.ts
```

同一 YAML 文件中的多个用例（多文档），合并生成到同一个 `.spec.ts` 文件的同一 `test.describe` 块中。

---

## CSV 回填规则

脚本生成完成后，更新 `tests/ui-test/testcase-registry.csv`：

- 填入 `script_path`：相对于 `tests/` 的路径，如 `ui-test/scripts/auth/login.spec.ts`
- 将 `status` 从 `pending` 改为 `active`
- 更新 `updated_at` 为当前日期

---

## 增量生成策略

- 优先**复用**已有脚本，不重新生成已存在的 `.spec.ts`
- 当 YAML 用例有更新（`updated_at` 变化或步骤变化）时，**更新**对应脚本
- 新增 YAML 用例时，**生成**新脚本
- 废弃用例（`status=deprecated`）：**不生成**对应脚本，若脚本已存在则注释或删除测试块

---

## 约束

- 不修改 `tests/ui-test/usecase/` 下的 YAML 文件（由 `e2e-case-generator` 负责）
- 不修改 `template/` 下的模板文件本身
- 生成的脚本必须可被 Playwright 执行（语法正确、导入路径正确）
- 等待策略严格遵守规范，禁止使用 `waitForTimeout` 固定延时
- Page Object 类只封装与当前用例相关的交互，不过度设计
