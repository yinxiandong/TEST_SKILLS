# 使用 .claude/rules/ 的模块化规则

对于较大的项目，您可以使用 .claude/rules/ 目录将说明组织到多个文件中。这允许团队维护专注、组织良好的规则文件，而不是一个大型 CLAUDE.md。

## 基本结构

在项目的 .claude/rules/ 目录中放置 markdown 文件：

```
your-project/
├── .claude/
│   ├── CLAUDE.md           # Main project instructions
│   └── rules/
│       ├── code-style.md   # Code style guidelines
│       ├── testing.md      # Testing conventions
│       └── security.md     # Security requirements
```

.claude/rules/ 中的所有 .md 文件都会自动加载为项目内存，优先级与 .claude/CLAUDE.md 相同。

## 特定于路径的规则

规则可以使用带有 paths 字段的 YAML 前置事项限定到特定文件。这些条件规则仅在 Claude 处理与指定模式匹配的文件时适用。

```yaml
---
paths: src/api/**/*.ts
---

# API Development Rules

- All API endpoints must include input validation
- Use the standard error response format
- Include OpenAPI documentation comments
```

没有 paths 字段的规则会无条件加载，适用于所有文件。

## Glob 模式

paths 字段支持标准 glob 模式：

| 模式 | 匹配 |
|------|-------------|
| `**/*.ts` | 任何目录中的所有 TypeScript 文件 |
| `src/**/*` | src/ 目录下的所有文件 |
| `*.md` | 项目根目录中的 Markdown 文件 |
| `src/components/*.tsx` | 特定目录中的 React 组件 |

您可以使用大括号有效地匹配多个模式：

```yaml
---
paths: src/**/*.{ts,tsx}
---

# TypeScript/React Rules
```

这会扩展为匹配 `src/**/*.ts` 和 `src/**/*.tsx`。您也可以用逗号组合多个模式：

```yaml
---
paths: {src,lib}/**/*.ts, tests/**/*.test.ts
---
```

## 子目录

规则可以组织到子目录中以获得更好的结构：

```
.claude/rules/
├── frontend/
│   ├── react.md
│   └── styles.md
├── backend/
│   ├── api.md
│   └── database.md
└── general.md
```

所有 `.md` 文件都会被递归发现。

## 符号链接

`.claude/rules/` 目录支持符号链接，允许您在多个项目中共享常见规则：

```bash
# Symlink a shared rules directory
ln -s ~/shared-claude-rules .claude/rules/shared

# Symlink individual rule files
ln -s ~/company-standards/security.md .claude/rules/security.md
```

符号链接会被解析，其内容会正常加载。循环符号链接会被检测并妥善处理。

## 用户级规则

您可以在 `~/.claude/rules/` 中创建适用于所有项目的个人规则：

```
~/.claude/rules/
├── preferences.md    # Your personal coding preferences
└── workflows.md      # Your preferred workflows
```

用户级规则在项目规则之前加载，使项目规则具有更高的优先级。

## 最佳实践

`.claude/rules/` 的最佳实践：

- **保持规则专注**：每个文件应涵盖一个主题（例如 testing.md、api-design.md）
- **使用描述性文件名**：文件名应指示规则涵盖的内容
- **谨慎使用条件规则**：仅在规则确实适用于特定文件类型时添加 paths 前置事项
- **使用子目录组织**：分组相关规则（例如 frontend/、backend/）

## 组织级内存管理

组织可以部署适用于所有用户的集中管理的 CLAUDE.md 文件。

要设置组织级内存管理：

- 在上面内存类型表中显示的托管策略位置创建托管内存文件。
- 通过您的配置管理系统（MDM、组策略、Ansible 等）部署，以确保在所有开发人员计算机上一致分发。
