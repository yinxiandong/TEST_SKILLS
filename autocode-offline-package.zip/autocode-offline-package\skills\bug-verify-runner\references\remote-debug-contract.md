# remote-dev-debug 调用契约（跨项目通用）

> 说明：本契约只定义跨项目通用接口。`remote-dev-debug` 在不同项目内部可选择不同子技能与执行细节。

## 1. 主技能定位

- 主技能名：`remote-dev-debug`
- 角色：远程调试入口，统一接收调试请求，并根据场景选择子技能执行。

## 2. 输入契约

| 字段 | 必需 | 说明 |
|---|---|---|
| `bug_id` | 是 | 缺陷标识 |
| `debug_scene` | 是 | `api/start_fail/log/config/db/general` |
| `target_env` | 是 | 目标环境标识 |
| `repro_steps` | 是 | 复现步骤列表 |
| `verify_cases` | 是 | 验证用例列表 |
| `timeout_sec` | 否 | 超时时间，默认 300 |
| `max_retries` | 否 | 最大重试次数，默认 1 |
| `artifacts_dir` | 是 | 远程调试证据输出目录 |

## 3. 输出契约

| 字段 | 必需 | 说明 |
|---|---|---|
| `status` | 是 | `pass/fail/error` |
| `scene_used` | 是 | 实际调试场景 |
| `subskill_used` | 否 | 主技能内部选择的子技能 |
| `case_results` | 是 | 用例执行明细 |
| `evidence_paths` | 是 | 证据路径列表 |
| `summary` | 是 | 文本摘要 |

## 3.1 debug_scene 推荐映射

- 接口调用或业务接口返回异常 → `api`
- 服务启动失败或启动后快速退出 → `start_fail`
- 日志异常排查 → `log`
- 配置中心/Nacos 配置问题 → `config`
- 数据初始化或数据一致性问题 → `db`
- 无法归类问题 → `general`

## 4. 兼容性约束

1. 工作流只依赖本契约，不直接依赖子技能名称。
2. 只要满足输入/输出契约，不限制 `remote-dev-debug` 内部编排方式。
3. `status=error` 视同验证失败，由上层流程进入阻塞或重试。
