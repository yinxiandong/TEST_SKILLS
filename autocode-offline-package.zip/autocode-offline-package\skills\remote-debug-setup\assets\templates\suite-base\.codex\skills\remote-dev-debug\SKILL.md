---
name: remote-dev-debug
description: "远程开发调试总控技能（通用版）。按 .secrets/dev-servers.yaml 的 services[] 逐服务编排：探测→（可选）部署/重启→（可选）API 调测→日志归因→输出人工介入建议。适用于在不确定项目组件栈的情况下，快速形成远程调试闭环与可追溯的调试报告。"
---

# remote-dev-debug

## 概述

本技能是远程调试的“总控编排器”，以服务为单位执行：

1. 远端只读探测（remote-dev-deploy/probe_remote.sh）
2. 可选部署/重启（remote-dev-deploy/deploy_remote.sh）
3. 可选 API 调测（remote-api-debug）
4. 若失败则抓日志归因（remote-log-diagnose）

## 用法

```bash
python3 .codex/skills/remote-dev-debug/scripts/debug_loop.py \
  --server dev1 \
  --service svc-app \
  --config .secrets/dev-servers.yaml \
  --api-spec-file /tmp/api-spec.json \
  --artifact /path/to/app.jar \
  --confirm-deploy \
  --max-rounds 3
```
