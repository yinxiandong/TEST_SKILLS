---
name: api-test-detail-generator
description: API 测试用例详情与脚本生成（二阶段）。读取人工审查通过的用例列表，生成完整的 YAML 用例详情和对应的 pytest 脚本（基于 httpx），输出到 tests/api-test/ 目录，同步更新 CSV 注册表。
---

# API 测试用例详情与脚本生成技能（二阶段）

## 调用方

- `api-test-orchestrator`：在 Phase 3 调用，用例列表审查通过后生成详情和脚本
- 用户直接调用：为指定模块生成用例详情和 pytest 脚本

## 前置依赖

- 用例列表 CSV（由 `api-test-case-generator` 生成，`status=approved`）
- API 特性清单 CSV（由 `feature-api-list-generator` 生成）
- `tests/api-test/api-test.config.yaml`（由 `api-test-config` 生成）
- 后端代码（可选，用于提取参数详情和校验规则）

---

## 执行流程

```
1. 读取用例列表 CSV，过滤 status=approved 的用例
2. 按模块分组处理：
   ├─ 读取对应模块的 API 特性清单
   ├─ 可选：分析后端代码获取参数详情
   ├─ 为每条用例生成 YAML 详情（含 request/expected 完整定义）
   ├─ 将同模块同功能的用例合并到同一 YAML 文件
   └─ 生成对应的 pytest 脚本
3. 生成/更新 conftest.py（鉴权 fixture、环境配置）
4. 生成/更新 utils/ 工具模块（请求封装、断言辅助）
5. 更新用例注册表（路径从 `api-test.config.yaml` 的 `output.registry_file` 读取，默认 `tests/api-test/testcase-registry.csv`）
6. 回填用例列表 CSV 中的 script_path
```

---

## YAML 用例详情格式

参见模板文件：`template/api-usecase-detail.yaml.template`

### 核心字段说明

| 字段 | 必填 | 说明 |
|------|------|------|
| `case_id` | 是 | 与用例列表 CSV 中的 case_id 一致 |
| `case_name` | 是 | 用例名称 |
| `level` / `smoke` / `type` | 是 | 继承自用例列表 |
| `coverage_type` / `coverage_rule` | 是 | 覆盖率分类和规则 ID |
| `request` | 是 | 请求定义（method, path, headers, query, path_params, body） |
| `expected` | 是 | 预期结果（status_code, response_body, assertions, response_time_ms） |
| `preconditions` | 否 | 前置条件 |
| `postconditions` | 否 | 后置清理 |

### 断言类型

| assertion type | 说明 | condition 可选值 |
|---------------|------|-----------------|
| `json_path` | JSONPath 断言 | `exists`, `not_empty`, `equals`, `contains`, `gt`, `lt`, `type_is` |
| `status_code` | HTTP 状态码 | `equals` |
| `header` | 响应头检查 | `exists`, `equals`, `contains` |
| `response_time` | 响应时间 | `lt`（小于指定毫秒数） |

### 变量占位符

YAML 中支持 `{{variable}}` 占位符，运行时从配置或 fixture 注入：

- `{{test_user}}` / `{{test_password}}`：测试凭据
- `{{base_url}}`：API 基础地址
- `{{auth_token}}`：鉴权 token
- `{{random_string}}` / `{{random_int}}`：随机测试数据
- `{{timestamp}}`：当前时间戳

---

## pytest 脚本生成规则

### 技术栈

- HTTP 客户端：`httpx`（同步模式，简洁直观）
- 测试框架：`pytest`
- 数据驱动：`pytest.mark.parametrize` + YAML 数据加载
- 标记系统：`@pytest.mark.smoke` / `@pytest.mark.P0` / `@pytest.mark.positive` 等

### 脚本结构

```python
# tests/api-test/scripts/{module}/test_{feature}.py

import pytest
from utils.api_client import APIClient
from utils.yaml_loader import load_cases
from utils.assertions import assert_response

# 加载 YAML 用例
CASES = load_cases("tests/api-test/usecase/{module}/{feature}.yaml")

class TestFeatureName:
    """功能名称 API 测试"""

    @pytest.mark.smoke
    @pytest.mark.P0
    @pytest.mark.positive
    def test_case_id_description(self, api_client: APIClient):
        """TC-API-MODULE-001: 用例名称"""
        case = CASES["TC-API-MODULE-001"]
        response = api_client.request(
            method=case["request"]["method"],
            path=case["request"]["path"],
            json=case["request"].get("body"),
            params=case["request"].get("query"),
        )
        assert_response(response, case["expected"])
```

### 生成规则

1. 同模块同功能的用例归入同一 `test_{feature}.py` 文件
2. 每个用例对应一个 `test_` 方法，方法名包含 `case_id`
3. pytest mark 从 YAML 的 `level`、`smoke`、`coverage_type` 自动生成
4. 正向用例验证 2xx 状态码 + 业务字段
5. 负向用例验证 4xx 状态码 + 错误消息
6. 边界值用例验证边界处理行为（接受或拒绝）
7. 安全用例验证 401/403 状态码或注入无效

### conftest.py 生成

参见模板：`template/conftest.py.template`

```python
# tests/api-test/scripts/conftest.py
# 提供：api_client fixture（自动鉴权）、环境配置加载、YAML 配置解析
```

核心 fixture：
- `api_client`：预配置的 httpx 客户端（含 base_url、auth token、timeout）
- `auth_token`：自动登录获取 token（session 级别缓存）
- `test_config`：加载 tests/api-test/api-test.config.yaml 配置

### utils/ 工具模块

- `api_client.py`：APIClient 封装类（基于 httpx）
- `yaml_loader.py`：YAML 用例加载器（支持多文档、变量替换）
- `assertions.py`：断言辅助函数（json_path、response_time、header 检查）

---

## 输出路径

```
tests/api-test/
├── usecase/
│   └── {module}/
│       └── {feature}.yaml              # YAML 用例详情
└── scripts/
    ├── {module}/
    │   └── test_{feature}.py           # pytest 脚本
    ├── conftest.py                     # pytest fixtures
    └── utils/
        ├── __init__.py
        ├── api_client.py               # httpx 客户端封装
        ├── yaml_loader.py              # YAML 用例加载
        └── assertions.py               # 断言辅助
```

---

## 注册表更新

生成完成后，将用例追加到注册表 CSV（路径从 `api-test.config.yaml` 的 `output.registry_file` 读取，默认 `tests/api-test/testcase-registry.csv`）：

```csv
case_id,case_name,level,smoke,type,category,module,api_path,method,coverage_type,coverage_rule,source,usecase_path,script_path,status,tags,created_at,updated_at
TC-API-AUTH-001,"用户登录-正向-仅必填字段",P0,true,api-test,认证,auth,/api/v1/auth/login,POST,positive,positive-required-only,requirement,api-test/usecase/auth/login.yaml,api-test/scripts/auth/test_login.py,active,"auth,login,positive,smoke",2026-03-14,2026-03-14
```

---

## 约束

- 不修改 `template/` 和 `references/` 下的文件
- 只处理 `status=approved` 的用例
- 安全用例的攻击 payload 写在 YAML 中，不硬编码到 pytest 脚本
- conftest.py 和 utils/ 采用增量更新，不覆盖用户自定义内容
- 生成的 pytest 脚本必须可直接运行（`pytest tests/api-test/scripts/`）
