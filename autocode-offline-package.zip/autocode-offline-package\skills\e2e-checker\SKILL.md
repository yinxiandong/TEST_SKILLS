---
name: e2e-checker
description: 检测当前项目 E2E 集成状态。已集成时输出现状报告（框架版本、覆盖情况、配置健康度）；未集成时分析项目架构并输出 Playwright 接入设计方案。检测目录为 tests/ui-test/（仅 UI 测试，api-test 由独立 skill 组管理）。
---

# E2E 集成检测技能

## 调用方

- 用户直接调用：检查当前项目 E2E 集成状态
- `e2e-orchestrator`：发现项目未接入 E2E 时，引导到本技能输出接入方案

## 执行流程

```
Phase 1：检测 → 判断是否已集成 e2e
  ├─ 已集成 → Phase 2a：输出现状报告
  ├─ 疑似集成 → Phase 2c：配置修复方案
  └─ 未集成 → Phase 2b：架构分析 + 接入设计方案
```

---

## Phase 1：检测阶段

### 输入意图处理

- **默认模式**：自动判断状态，根据检测结果执行对应 Phase
- **设计模式**：强制执行 Phase 2b（即使已集成也输出接入设计方案）

### 检测逻辑

扫描以下文件和目录，判断项目是否已集成 E2E：

### 配置文件检测

```bash
# Playwright 配置（检测 tests/ui-test/ 目录下）
tests/ui-test/playwright.config.ts
tests/ui-test/playwright.config.js
tests/ui-test/playwright.config.mjs

# Cypress 配置
cypress.config.ts
cypress.config.js
cypress.json
.cypress/
```

### 测试目录检测（按优先级）

```
tests/ui-test/           # 新规范目录（优先检测）
tests/ui-test/usecase/   # 一阶段产物：YAML 用例
tests/ui-test/scripts/   # 二阶段产物：Playwright 脚本
tests/e2e/               # 旧规范目录（兼容检测）
e2e/
test/e2e/
src/__tests__/e2e/
cypress/e2e/
```

> **注意**：`tests/api-test/` 目录由独立 api-test skill 组管理，本技能不检测 api-test 相关内容。

### package.json 依赖检测

检查 `dependencies` 和 `devDependencies` 中是否包含：
- `@playwright/test`
- `playwright`
- `cypress`

### Playwright 配置规范检测

当检测到 `tests/ui-test/playwright.config.ts` 时，额外检查：
- `testDir` 是否为 `tests/ui-test/scripts`（新规范）
- 报告输出路径是否包含 `.tests/`（新规范）

### 判定规则

| 条件 | 结论 | 后续流程 |
|------|------|---------|
| 存在 `tests/ui-test/playwright.config.*` 且安装了 `@playwright/test` | ✅ 已集成 Playwright | 执行 Phase 2a |
| 存在 `cypress.config.*` 或 `cypress/` 目录 | ✅ 已集成 Cypress | 执行 Phase 2a |
| 存在 e2e 测试目录但无配置文件 | ⚠️ 疑似集成（配置不完整） | 执行 Phase 2c |
| 均不满足 | ❌ 未集成 | 执行 Phase 2b |

### 异常处理

| 异常情况 | 处理方式 |
|---------|---------|
| 无 package.json | 提示"非标准 Node.js 项目，无法自动检测"，建议手动配置 |
| 无法识别前端框架 | 输出通用 Playwright 配置（不含框架特定优化） |
| 路由解析失败 | 提示用户手动提供关键路由，使用通用旅程模板 |
| 依赖版本冲突 | 标注版本不兼容风险，建议升级路径 |

### 多环境配置

Playwright 推荐使用环境变量切换测试环境：

```bash
# 本地环境（默认）
npx playwright test --config tests/ui-test/playwright.config.ts

# 开发环境
BASE_URL=https://dev.example.com npx playwright test --config tests/ui-test/playwright.config.ts

# 预发布环境
BASE_URL=https://staging.example.com npx playwright test --config tests/ui-test/playwright.config.ts
```

**推荐使用 .env 文件管理环境配置**：

```bash
# .env.local
BASE_URL=http://localhost:3000

# .env.dev
BASE_URL=https://dev.example.com
TEST_USER=dev-user@example.com
TEST_PASSWORD=dev-password

# .env.staging
BASE_URL=https://staging.example.com
TEST_USER=staging-user@example.com
TEST_PASSWORD=staging-password
```

**认证管理**：使用 Playwright 的 `storageState` 功能复用登录状态，避免每个测试都重新登录

---

## Phase 2a：已集成 → 现状报告

### 报告项

1. **框架与版本**：从 `package.json` 读取 `@playwright/test` 或 `cypress` 版本
2. **测试文件数量**：统计 `tests/ui-test/scripts/**/*.spec.ts` 文件数
3. **用例注册情况**：读取 `tests/ui-test/testcase-registry.csv`，统计 active/pending/deprecated 数量
4. **YAML 用例覆盖**：统计 `tests/ui-test/usecase/` 下的 YAML 文件数
5. **配置健康度检查**：

| 配置项 | 健康标准 | 检查方式 | 分值 |
|--------|---------|---------|------|
| 多浏览器 | `projects` 包含 chromium + firefox + webkit | 读取 `tests/ui-test/playwright.config.ts` | 20 分 |
| Artifact | `screenshot`、`video`、`trace` 已配置 | 读取 `use` 块 | 20 分 |
| 重试策略 | CI 环境下 `retries >= 1` | 检查 `retries` 字段 | 20 分 |
| 超时配置 | `timeout` 已显式设置 | 检查 `timeout` 字段 | 20 分 |
| baseURL | 已配置 `baseURL` | 检查 `use.baseURL` | 20 分 |

**目录规范检查（额外项）**：
- `testDir` 是否为 `tests/ui-test/scripts`（新规范，不影响评分，仅提示）
- 报告路径是否输出到 `.tests/`（新规范，不影响评分，仅提示）

**健康度评分规则**：
- 总分 = 100 分（每项 20 分）
- 评级：≥80 优秀 | 60-79 良好 | 40-59 一般 | <40 需改进

6. **优化建议**：针对未满足的健康项给出具体建议

---

## Phase 2c：疑似集成 → 配置修复方案

当检测到 e2e 测试目录存在但配置文件缺失时：

1. **诊断问题**：
   - 列出已存在的测试文件
   - 识别缺失的配置文件
   - 检查依赖安装情况

2. **输出修复方案**：
   - 生成缺失的配置文件（基于现有测试文件推断）
   - 补充缺失的依赖安装命令
   - 提供配置迁移建议（如从旧版本升级，或从 `tests/e2e/` 迁移到 `tests/ui-test/`）

3. **验证步骤**：
   - 提供验证命令（`npx playwright test --config tests/ui-test/playwright.config.ts --list`）
   - 说明预期输出

---

## Phase 2b：未集成 → 架构分析 + 接入设计

> **推荐触发 Brainstorm**：检测到未集成时，在输出设计方案之前，**推荐调用 `/superpowers:brainstorm` 技能**，通过头脑风暴深入探索用户意图与测试目标，再基于产出物生成接入设计方案。
>
> **Brainstorm 触发规则**：
> - 调用 `/superpowers:brainstorm`，主题设为"E2E 测试接入设计"
> - Brainstorm 应重点探索：测试覆盖目标（核心旅程 / 冒烟测试 / 回归全量）、运行环境（本地 / CI / 云端）、优先级排序（P0 旅程识别）、团队约束（维护成本 / 框架偏好）
> - Brainstorm 完成后，将产出的关键决策作为输入，驱动后续 Step 1 & Step 2 的个性化设计
>
> **降级处理**：若 `/superpowers:brainstorm` 技能不可用（未安装 superpowers 插件），跳过 Brainstorm 步骤，直接进入 Step 1 架构分析，并在设计方案中注明"建议后续补充需求探索"。

### Step 1：项目架构分析

从以下线索推断项目信息：

#### 前端框架识别

```
package.json dependencies:
  "react" → React
  "vue" → Vue
  "angular" / "@angular/core" → Angular
  "svelte" → Svelte
  "next" → Next.js
  "nuxt" → Nuxt
```

#### 路由结构推断（关键页面）

```
React Router: src/router/ 或 src/App.tsx 中的 <Route>
Vue Router: src/router/index.ts 中的 routes 数组
Next.js: app/ 或 pages/ 目录结构（文件系统路由）
Angular: app-routing.module.ts
```

**推断策略**（按优先级）：
1. **优先**：解析路由配置文件（router/index.ts、app-routing.module.ts）
2. **次选**：扫描页面目录结构（Next.js app/、pages/）
3. **兜底**：提示用户手动提供关键路由，使用通用旅程模板

读取路由文件，提取关键路径作为测试旅程起点。

#### 认证机制推断

```
localStorage.getItem('token') → JWT token 存储
document.cookie → Cookie 认证
axios.defaults.headers / interceptors → Bearer token
next-auth / @auth/core → NextAuth.js
@supabase/auth-helpers → Supabase Auth
firebase/auth → Firebase Auth
@auth0/auth0-react → Auth0
无 auth 关键词 → 可能无认证或使用外部服务
```

扫描 `src/` 目录下 `auth`、`login`、`token` 关键词，推断认证方式。

#### API 调用方式

```
axios → REST（检查 baseURL 配置）
fetch → REST
@apollo/client / graphql → GraphQL
msw → 已有 Mock 层
```

#### 本地开发地址推断

```
package.json scripts 中的 "dev" / "start" 命令
vite.config.ts 中的 server.port
.env / .env.local 中的 VITE_BASE_URL / REACT_APP_API_URL
next.config.js 中的 env
```

---

### Step 2：输出接入设计方案

#### 推荐的 `tests/ui-test/playwright.config.ts`

根据分析结果生成个性化配置（基于模板：`template/playwright.config.ts.template`）：

> **模板定位**：`e2e-checker/template/playwright.config.ts.template` 为**接入设计版本**，含 `{{PORT}}` / `{{DEV_COMMAND}}` 占位符和 `webServer` 自动启动配置，适用于初始接入方案输出。`e2e-testing/template/playwright.config.ts.template` 为**规范参考版本**，使用固定示例值，无 `webServer` 块，适用于已接入项目的配置对齐参考。两者 `testDir` 和 reporter 路径约定完全一致。

替换模板中的占位符：
- `{{PORT}}` → 推断的端口号
- `{{DEV_COMMAND}}` → 推断的 dev 启动命令

#### 推荐的目录结构

```
tests/
└── ui-test/                           # E2E skill 管辖范围
    ├── testcase-registry.csv          # UI 测试用例注册表
    ├── usecase/                       # 一阶段产物：YAML 用例
    │   └── {category}/
    │       └── {feature}.yaml
    └── scripts/                       # 二阶段产物：Playwright 脚本
        ├── {category}/
        │   └── {feature}.spec.ts
        ├── pages/                     # Page Object Model
        │   └── {Category}Page.ts
        └── fixtures/                  # 测试夹具
            └── auth.ts
.tests/                                # 隐藏目录：过程文件和报告
└── reports/
    └── {run-id}/
        ├── ai-report.json
        ├── report.html
        └── junit.xml
tests/ui-test/playwright.config.ts     # 指向 tests/ui-test/scripts/
```

#### 初始测试旅程清单

基于路由分析推断，例如：

| 旅程 | 路由 | 优先级 |
|------|------|--------|
| 用户登录 | `/login` | P0 |
| 首页加载 | `/` 或 `/dashboard` | P0 |
| 核心功能页面 | `/{主要路由}` | P1 |
| 用户登出 | 点击登出按钮 | P1 |

#### 接入步骤

参见模板文件：`template/e2e-integration-report.md.template`

该模板包含完整的接入步骤说明，包括：
1. 依赖安装
2. 配置文件创建
3. 测试目录结构
4. package.json 脚本配置
5. 首次运行验证

#### CI/CD 集成示例

参见 `e2e-testing` 技能的模板文件：`../e2e-testing/template/github-actions-e2e.yml.template`

---

## 输出格式

### 已集成时（Phase 2a）

```
╔══════════════════════════════════════════════════════════════╗
║                    E2E 集成检测结果                           ║
╠══════════════════════════════════════════════════════════════╣
║ 状态：✅ 已集成 Playwright v1.40.0                           ║
║ 脚本文件：12 个（tests/ui-test/scripts/）                    ║
║ YAML 用例：35 个（tests/ui-test/usecase/）                   ║
║ 注册表：35 active / 3 pending / 1 deprecated                 ║
║ 健康度评分：85/100（优秀）                                    ║
╠══════════════════════════════════════════════════════════════╣
║ 配置检查：                                                    ║
║  ✅ 多浏览器支持（20/20）                                     ║
║  ✅ Artifact 配置（20/20）                                    ║
║  ✅ 重试策略（20/20）                                         ║
║  ⚠️  超时配置（0/20）- 建议显式设置 timeout                  ║
║  ✅ baseURL 配置（20/20）                                     ║
╠══════════════════════════════════════════════════════════════╣
║ 优化建议：                                                    ║
║  1. 建议在 tests/ui-test/playwright.config.ts 中显式设置 timeout: 30_000   ║
║  2. 考虑增加移动端浏览器测试（Mobile Chrome/Safari）         ║
╚══════════════════════════════════════════════════════════════╝
```

### 疑似集成时（Phase 2c）

```
╔══════════════════════════════════════════════════════════════╗
║                    E2E 集成检测结果                           ║
╠══════════════════════════════════════════════════════════════╣
║ 状态：⚠️ 疑似集成（配置不完整）                              ║
║ 发现：tests/ui-test/ 目录存在，但缺少配置文件                ║
╠══════════════════════════════════════════════════════════════╣
║ 诊断：                                                        ║
║  ✅ 测试文件：5 个 *.spec.ts 文件                            ║
║  ❌ 配置文件：tests/ui-test/playwright.config.ts 缺失                      ║
║  ❌ 依赖安装：@playwright/test 未安装                        ║
╠══════════════════════════════════════════════════════════════╣
║ 修复步骤：                                                    ║
║  1. npm install -D @playwright/test                          ║
║  2. 创建 tests/ui-test/playwright.config.ts（见下方推荐配置）              ║
║  3. npx playwright install                                   ║
║  4. npx playwright test --config tests/ui-test/playwright.config.ts --list（验证配置）                   ║
╚══════════════════════════════════════════════════════════════╝
```

### 未集成时（Phase 2b）

```
╔══════════════════════════════════════════════════════════════╗
║                    E2E 集成检测结果                           ║
╠══════════════════════════════════════════════════════════════╣
║ 状态：❌ 未集成                                               ║
║ 项目类型：React + Vite                                        ║
║ 开发地址：http://localhost:5173                               ║
╠══════════════════════════════════════════════════════════════╣
║ 推荐方案：Playwright                                          ║
║ 识别到的关键路由：                                            ║
║  • /login（登录页）                                           ║
║  • /dashboard（主页）                                         ║
║  • /products（产品列表）                                      ║
╠══════════════════════════════════════════════════════════════╣
║ 接入步骤：见下方详细方案                                      ║
╚══════════════════════════════════════════════════════════════╝
```

然后输出完整的接入设计方案（架构分析摘要、推荐配置、目录结构、旅程清单、接入步骤）。
