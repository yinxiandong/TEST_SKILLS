---
name: rq-review-gatekeeper
description: 统一执行代码评审与质量门禁，优先 superpowers:code-reviewer，未通过则阻断阶段推进。Use when stage tests pass and code quality gate must be evaluated before stage completion.
---

# RQ 评审门禁

在阶段测试通过后执行代码评审，确保计划项落实与质量达标。

## 输入

### 必需

- 需求标识：`{rq_id}`
- 当前阶段：`{stage_name}`
- 阶段标识：`{stage_slug}`
- 计划真源：`docs/requirement/{rq_id}/10-需求开发计划表.md`
- 阶段测试报告：`.claude/notepads/{rq_id}/test-report-{stage_slug}.md`

### 可选

- 历史评审报告：`.claude/notepads/{rq_id}/review-report-*.md`
- 开发规则：`.claude/rules/**`

## 评审通道策略（硬性）

1. 首选：`superpowers:code-reviewer`
2. 降级：本地规则审查 + 静态检查 + 测试证据复核

## 输出

路径：`.claude/notepads/{rq_id}/review-report-{stage_slug}.md`

汇总路径：`.claude/notepads/{rq_id}/review-summary.md`

历史摘要：`.claude/notepads/{rq_id}/review-history-{stage_slug}.md`

最小字段：

- 阶段
- stage_slug
- 评审范围（对应计划任务）
- 问题清单（Critical/Important/Minor）
- 修复建议
- 门禁结论（pass/fail）

## 执行流程

### Step 1：准备评审上下文

1. 读取阶段相关任务和代码改动范围。
2. 读取阶段测试报告，确认测试证据完整。

### Step 2：执行评审

1. 调用 `superpowers:code-reviewer` 进行主评审。
2. 若不可用，执行本地降级评审策略。

### Step 3：门禁判定

- `Critical > 0`：fail
- `Important > 0`：fail
- `Critical=0 且 Important=0`：pass

### Step 4：反馈给编排器

- fail：返回缺陷清单，进入修复循环
- pass：允许阶段标记完成

### Step 5：更新评审汇总

1. 将当前阶段评审结果追加到 `review-summary.md`。
2. 汇总文件仅做追加，不覆盖历史阶段记录。
3. 将当前阶段本轮结果追加到 `review-history-{stage_slug}.md`。

## 禁止项

- 不得在 Critical/Important 未清零情况下放行。
- 不得仅凭主观判断给出“已通过”。
