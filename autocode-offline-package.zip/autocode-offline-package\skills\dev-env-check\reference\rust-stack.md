# Rust 技术栈检查参考

> 本文档是 dev-env-check 技能的参考文档，包含 Rust 技术栈的详细检查流程。

## 识别特征

| 配置文件 | 说明 |
|----------|------|
| `Cargo.toml` | Rust 项目配置 |
| `Cargo.lock` | 依赖锁定文件 |

## 检查项

- Rust 版本（rustc、cargo）
- rustup 工具链管理器
- 常用组件（rustfmt、clippy）

## 检查命令

```bash
# 检查 Rust 版本
rustc --version 2>&1

# 检查 Cargo 版本
cargo --version 2>&1

# 检查 rustup
rustup --version 2>&1

# 检查已安装组件
rustup component list --installed 2>&1

# 检查工具链
rustup toolchain list 2>&1

# 检查目标平台
rustup target list --installed 2>&1
```

## 版本要求提取

### Cargo.toml

```toml
[package]
name = "myproject"
version = "0.1.0"
edition = "2021"
rust-version = "1.70"  # MSRV (Minimum Supported Rust Version)
```

提取命令：
```bash
# 提取 Rust 版本要求
grep "rust-version" Cargo.toml | cut -d'"' -f2

# 提取 edition
grep "edition" Cargo.toml | cut -d'"' -f2
```

### rust-toolchain.toml

```toml
[toolchain]
channel = "1.75.0"
components = ["rustfmt", "clippy"]
targets = ["x86_64-unknown-linux-gnu"]
```

## 期望结果

- Rust 版本符合 Cargo.toml 要求
- cargo 可正常使用
- rustfmt 和 clippy 已安装

## 构建命令

| 场景 | 构建命令 | 说明 |
|------|----------|------|
| Debug 构建 | `cargo build` | 快速编译，包含调试信息 |
| Release 构建 | `cargo build --release` | 优化编译 |
| 检查编译 | `cargo check` | 仅检查不生成二进制 |
| 运行测试 | `cargo test` | 运行测试 |

## 常见问题

### rustup 安装

```bash
# 官方安装方式（推荐）
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# 按提示选择安装选项，通常选择默认即可

# 使环境变量生效
source "$HOME/.cargo/env"
```

### 切换 Rust 版本

```bash
# 安装指定版本
rustup install 1.75.0
rustup install nightly

# 切换默认版本
rustup default 1.75.0
rustup default stable

# 项目级版本（创建 rust-toolchain.toml）
cat > rust-toolchain.toml << EOF
[toolchain]
channel = "1.75.0"
EOF
```

### 安装组件

```bash
# 安装 rustfmt（代码格式化）
rustup component add rustfmt

# 安装 clippy（代码检查）
rustup component add clippy

# 安装 rust-src（源码，IDE 需要）
rustup component add rust-src

# 安装 rust-analyzer（语言服务器）
rustup component add rust-analyzer
```

### 添加编译目标

```bash
# 查看可用目标
rustup target list

# 添加交叉编译目标
rustup target add x86_64-unknown-linux-musl
rustup target add wasm32-unknown-unknown
rustup target add aarch64-apple-darwin

# 交叉编译
cargo build --target x86_64-unknown-linux-musl
```

### crates.io 镜像配置

```bash
# 编辑 ~/.cargo/config.toml
mkdir -p ~/.cargo
cat > ~/.cargo/config.toml << EOF
[source.crates-io]
replace-with = 'ustc'

[source.ustc]
registry = "sparse+https://mirrors.ustc.edu.cn/crates.io-index/"

# 或使用清华镜像
# [source.tuna]
# registry = "sparse+https://mirrors.tuna.tsinghua.edu.cn/crates.io-index/"
EOF
```

### 依赖编译失败

```bash
# 清理缓存
cargo clean

# 更新依赖
cargo update

# 查看详细编译输出
cargo build -vv

# 检查系统依赖（某些 crate 需要系统库）
# 例如 openssl-sys 需要 libssl-dev
sudo apt install pkg-config libssl-dev
```

## 常用开发工具

```bash
# 代码格式化
cargo fmt

# 代码检查
cargo clippy

# 生成文档
cargo doc --open

# 安全审计
cargo install cargo-audit
cargo audit

# 依赖更新检查
cargo install cargo-outdated
cargo outdated

# 二进制大小分析
cargo install cargo-bloat
cargo bloat --release
```

## Cargo 扩展

```bash
# 安装常用扩展
cargo install cargo-watch    # 文件变化时自动运行命令
cargo install cargo-edit     # 命令行添加依赖
cargo install cargo-expand   # 展开宏
cargo install cargo-tree     # 依赖树
cargo install cargo-deny     # 依赖许可证检查

# 使用示例
cargo watch -x check         # 文件变化时自动检查
cargo add serde              # 添加依赖
cargo tree                   # 查看依赖树
```

## 安装方式

### 推荐方式 - rustup

```bash
# Linux/macOS
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source "$HOME/.cargo/env"

# Windows
# 下载并运行 https://win.rustup.rs
```

### 包管理器（不推荐）

```bash
# Ubuntu/Debian - 版本可能较旧
sudo apt install rustc cargo

# macOS
brew install rust

# 注意：包管理器安装的版本可能不是最新的
# 强烈建议使用 rustup 安装
```

## IDE 支持

### VS Code

安装 `rust-analyzer` 扩展，它会自动使用 rustup 安装的工具链。

```json
// .vscode/settings.json
{
    "rust-analyzer.checkOnSave.command": "clippy"
}
```

### IntelliJ IDEA / CLion

安装 `Rust` 插件，支持完整的 Rust 开发体验。

## 官方文档

- Rust: https://www.rust-lang.org/learn
- Cargo: https://doc.rust-lang.org/cargo/
- rustup: https://rust-lang.github.io/rustup/
- crates.io: https://crates.io/
- Rust By Example: https://doc.rust-lang.org/rust-by-example/
