---
name: bug-verify-runner
description: 统一调用远程调试主技能 remote-dev-debug 执行缺陷复现与修复验证并生成验证报告。Use when code fixes need remote reproduction and verification evidence.
---

# Bug Verify Runner

负责远程验证步骤，统一调用 `remote-dev-debug` 主技能。

## 输入

- `bug_id`
- `target_env`
- `docs/bugfix/{bug_id}/00-缺陷原始输入.md`
- `docs/bugfix/{bug_id}/10-根因修复与同类排查.md`
- 可选：`docs/bugfix/{bug_id}/20-修复实施记录.md`

## 输出

- `docs/bugfix/{bug_id}/30-远程验证报告-{round}.md`
- `docs/bugfix/{bug_id}/30-远程验证报告.md`（最新快照，可覆盖）

## 模板与契约引用

- `references/30-verify-report-template.md`
- `references/remote-debug-contract.md`

## 执行流程

1. 组装远程调试输入参数（按 `remote-debug-contract.md`）。
2. 根据缺陷信息映射 `debug_scene`（见下方映射规则），并允许人工显式覆盖。
2. 调用远程调试主技能：`remote-dev-debug`。
3. 解析返回的 `status/case_results/evidence_paths/summary`。
4. **前端 UI 缺陷验证**：对于涉及前端页面、交互、样式的缺陷，在远程验证时结合 `playwright` 进行浏览器级 E2E 验证，按照缺陷复现步骤和验收标准自动化执行验证用例。
5. 生成轮次报告 `30-远程验证报告-{round}.md`。
6. 更新最新快照 `30-远程验证报告.md`。

## debug_scene 映射规则（默认）

- 接口调用异常/业务接口返回错误：`api`
- 启动即退出/启动失败：`start_fail`
- 运行时异常栈/告警日志排查：`log`
- 配置相关问题（Nacos/配置中心）：`config`
- 数据初始化或数据一致性问题：`db`
- 无法归类：`general`

人工覆盖优先级高于默认映射。

## 门禁

- `status=pass`：通过
- `status=fail|error`：阻塞，返回编排器进入修复循环
