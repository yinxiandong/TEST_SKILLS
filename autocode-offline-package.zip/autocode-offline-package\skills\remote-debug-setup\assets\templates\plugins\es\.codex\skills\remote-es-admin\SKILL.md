---
name: remote-es-admin
description: "Elasticsearch 管理插件技能（dev/test）。读取 .secrets/dev-servers.yaml 中 servers[].components.es 配置，使用 HTTP API 执行 info/health、索引列表/创建/删除、文档写入/删除、搜索等。写入/破坏性动作需要 --confirm。"
---

# remote-es-admin

## 配置要求（写入 .secrets/dev-servers.yaml）

建议配置位置：`servers[].components.es`

最小字段（推荐）：

```json
{
  "enabled": true,
  "protocol": "http",
  "host": "127.0.0.1",
  "port": 9200,
  "access": { "mode": "direct" },
  "auth": { "mode": "none", "username": "", "password_plain": "" }
}
```

说明：
- `auth.mode`：`none|basic`。basic 时必须提供 `username/password_plain`。
- `access.mode`：`direct|ssh`。`ssh` 表示通过 SSH 临时端口转发访问 ES（适合本地无法直连内网端口的场景）；password 认证需要本机 `sshpass`。
- 写入/破坏性动作（create-index/delete-index/put-mapping/put-settings/put-doc/delete-doc）必须显式加 `--confirm`。

## 用法

```bash
.codex/skills/remote-es-admin/scripts/es_admin.sh --server dev1 --action info
.codex/skills/remote-es-admin/scripts/es_admin.sh --server dev1 --action list-indices
.codex/skills/remote-es-admin/scripts/es_admin.sh --server dev1 --action create-index --index demo --confirm
.codex/skills/remote-es-admin/scripts/es_admin.sh --server dev1 --action put-mapping --index demo --json '{"properties":{"x":{"type":"integer"}}}' --confirm
.codex/skills/remote-es-admin/scripts/es_admin.sh --server dev1 --action put-doc --index demo --id 1 --json '{"x":1}' --confirm
.codex/skills/remote-es-admin/scripts/es_admin.sh --server dev1 --action search --index demo --query '{"query":{"match_all":{}}}'
.codex/skills/remote-es-admin/scripts/es_admin.sh --server dev1 --action health --http-timeout 30
```
