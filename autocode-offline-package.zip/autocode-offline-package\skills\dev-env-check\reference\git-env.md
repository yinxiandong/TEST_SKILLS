# Git 环境检查参考

> 本文档是 dev-env-check 技能的参考文档，包含 Git 环境的详细检查流程。

## 识别特征

| 标识 | 说明 |
|------|------|
| `.git/` 目录 | Git 仓库 |
| `.gitignore` | Git 忽略配置 |
| `.gitattributes` | Git 属性配置 |

## 检查项

- Git 版本
- Git 配置（用户名、邮箱）
- Git LFS（如果项目使用）
- SSH 密钥配置

## 检查命令

```bash
# 检查 Git 版本
git --version 2>&1

# 检查 Git 配置
git config --global user.name 2>&1
git config --global user.email 2>&1

# 检查 Git LFS
git lfs version 2>&1

# 检查 Git LFS 是否已初始化（在项目中）
git lfs status 2>&1

# 检查 SSH 密钥
ls -la ~/.ssh/id_*.pub 2>/dev/null

# 测试 SSH 连接（GitHub）
ssh -T git@github.com 2>&1

# 检查 Git 凭证助手
git config --global credential.helper 2>&1
```

## 期望结果

- Git 版本 ≥ 2.0
- Git 用户信息已配置
- Git LFS 已安装（如果需要）
- SSH 密钥已配置（用于私有仓库）

## 常见问题

### 用户信息未配置

```bash
# 配置用户名和邮箱（必须）
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"

# 验证配置
git config --list --global
```

### SSH 密钥配置

```bash
# 生成 SSH 密钥
ssh-keygen -t ed25519 -C "your.email@example.com"

# 如果系统不支持 ed25519，使用 RSA
ssh-keygen -t rsa -b 4096 -C "your.email@example.com"

# 启动 ssh-agent
eval "$(ssh-agent -s)"

# 添加密钥到 ssh-agent
ssh-add ~/.ssh/id_ed25519

# 复制公钥（添加到 GitHub/GitLab）
cat ~/.ssh/id_ed25519.pub

# 测试连接
ssh -T git@github.com
ssh -T git@gitlab.com
```

### Git LFS 安装

```bash
# Ubuntu/Debian
sudo apt install git-lfs

# macOS
brew install git-lfs

# Windows
# Git for Windows 已包含 Git LFS，或使用：
choco install git-lfs

# 全局初始化
git lfs install

# 在项目中启用（跟踪大文件）
git lfs track "*.psd"
git lfs track "*.zip"
git add .gitattributes
```

### 凭证存储

```bash
# macOS - 使用钥匙串
git config --global credential.helper osxkeychain

# Windows - 使用凭证管理器
git config --global credential.helper manager

# Linux - 缓存凭证（默认 15 分钟）
git config --global credential.helper cache

# Linux - 存储凭证到文件（不推荐，明文存储）
git config --global credential.helper store
```

### 代理配置

```bash
# HTTP 代理
git config --global http.proxy http://proxy.example.com:8080
git config --global https.proxy http://proxy.example.com:8080

# SOCKS5 代理
git config --global http.proxy socks5://127.0.0.1:1080
git config --global https.proxy socks5://127.0.0.1:1080

# 取消代理
git config --global --unset http.proxy
git config --global --unset https.proxy

# 仅对特定域名使用代理
git config --global http.https://github.com.proxy socks5://127.0.0.1:1080
```

## 推荐配置

```bash
# 基础配置
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"

# 默认分支名
git config --global init.defaultBranch main

# 编辑器
git config --global core.editor "code --wait"  # VS Code
# git config --global core.editor "vim"

# 换行符处理
git config --global core.autocrlf input  # Linux/macOS
# git config --global core.autocrlf true  # Windows

# 颜色输出
git config --global color.ui auto

# 拉取策略
git config --global pull.rebase false  # merge（默认）
# git config --global pull.rebase true  # rebase

# 别名
git config --global alias.co checkout
git config --global alias.br branch
git config --global alias.ci commit
git config --global alias.st status
git config --global alias.lg "log --oneline --graph --decorate"
```

## 安装方式

### 包管理器

```bash
# Ubuntu/Debian
sudo apt install git

# CentOS/RHEL
sudo yum install git

# macOS
brew install git

# Windows
choco install git
# 或下载 Git for Windows: https://git-scm.com/download/win
```

### 源码安装（获取最新版）

```bash
# 安装依赖
sudo apt install libcurl4-gnutls-dev libexpat1-dev gettext libz-dev libssl-dev

# 下载源码
wget https://github.com/git/git/archive/refs/tags/v2.43.0.tar.gz
tar -xzf v2.43.0.tar.gz
cd git-2.43.0

# 编译安装
make prefix=/usr/local all
sudo make prefix=/usr/local install
```

## Git 工作流

### 常用命令

```bash
# 克隆仓库
git clone git@github.com:user/repo.git

# 创建分支
git checkout -b feature/new-feature

# 提交更改
git add .
git commit -m "feat: add new feature"

# 推送分支
git push -u origin feature/new-feature

# 更新主分支
git checkout main
git pull origin main

# 合并分支
git merge feature/new-feature

# 删除分支
git branch -d feature/new-feature
```

### 提交规范

```bash
# 推荐的提交消息格式
# <type>(<scope>): <subject>
#
# type: feat, fix, docs, style, refactor, test, chore
# scope: 可选，表示影响范围
# subject: 简短描述

git commit -m "feat(auth): add JWT authentication"
git commit -m "fix(api): resolve null pointer exception"
git commit -m "docs: update README"
```

## Git 钩子

### 常用钩子

```bash
# 项目钩子位置
.git/hooks/

# 创建 pre-commit 钩子
cat > .git/hooks/pre-commit << 'EOF'
#!/bin/sh
# 运行代码检查
npm run lint
EOF
chmod +x .git/hooks/pre-commit

# 推荐使用 husky 管理钩子
npm install husky --save-dev
npx husky install
npx husky add .husky/pre-commit "npm run lint"
```

## 官方文档

- Git: https://git-scm.com/doc
- Pro Git 书籍: https://git-scm.com/book/zh/v2
- GitHub 文档: https://docs.github.com/
- GitLab 文档: https://docs.gitlab.com/
