# Git Worktree 快速参考

## 常用命令速查

### 创建工作区
```bash
# 使用脚本（推荐）
./skills/git-worktree-master/scripts/worktree_manager.sh create rq001-xxx

# 手动创建
git worktree add ../project-rq001-xxx -b rq001-xxx
cd ../project-rq001-xxx
git submodule update --init --recursive
git submodule foreach 'git checkout -b rq001-xxx'
```

### 切换工作区
```bash
# 使用脚本
./skills/git-worktree-master/scripts/worktree_manager.sh switch rq001-xxx

# 手动切换
cd ../project-rq001-xxx
```

### 查看状态
```bash
# 当前工作区状态
./skills/git-worktree-master/scripts/worktree_manager.sh status

# 指定工作区状态
./skills/git-worktree-master/scripts/worktree_manager.sh status rq001-xxx

# 列出所有工作区
./skills/git-worktree-master/scripts/worktree_manager.sh list
git worktree list
```

### 清理工作区
```bash
# 使用脚本（推荐）
./skills/git-worktree-master/scripts/worktree_manager.sh cleanup rq001-xxx

# 手动清理
cd /path/to/main/repo
git worktree remove ../project-rq001-xxx --force
git branch -d rq001-xxx
git submodule foreach 'git branch -d rq001-xxx'
```

## 子模块操作

### 检查子模块分支
```bash
git submodule foreach 'echo "$(basename $sm_path): $(git branch --show-current)"'
```

### 切换子模块分支
```bash
git submodule foreach 'git checkout rq001-xxx'
```

### 提交子模块修改
```bash
# 1. 进入子模块
cd path/to/submodule

# 2. 提交修改
git add .
git commit -m "feat: 子模块功能"
git push origin rq001-xxx

# 3. 返回主项目更新引用
cd ../..
git add path/to/submodule
git commit -m "chore: 更新子模块引用"
```

## 工作流集成

### 完整流程
```bash
# 1. 创建工作区（需求分析前）
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh create rq001-xxx

# 2. 需求分析
/analysis-rq ...

# 3. 开发准备
/prepare-rq rq001-xxx

# 4. 开发实施
/develop-rq rq001-xxx

# 5. 清理工作区（需求完成后）
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh cleanup rq001-xxx
```

## 常见问题

### Q1: 如何查看所有工作区？
```bash
git worktree list
```

### Q2: 如何强制删除工作区？
```bash
git worktree remove ../project-rq001-xxx --force
```

### Q3: 如何删除未合并的分支？
```bash
git branch -D rq001-xxx
```

### Q4: 子模块未初始化怎么办？
```bash
git submodule update --init --recursive
```

### Q5: 如何修复损坏的工作区？
```bash
# 1. 手动删除目录
rm -rf ../project-rq001-xxx

# 2. 清理 git 记录
git worktree prune

# 3. 重新创建
git worktree add ../project-rq001-xxx rq001-xxx
```
