---
name: feature-list-generator
description: Use when 需要为任意项目新增或补齐 docs/feature-list/*.md 特性清单，并要求文档显式包含接口调用方式、认证、入参、出参与业务规则，以便后续直接交给 feature-curl-test-generator 生成 curl 接口测试。
---

# feature-list-generator

## Overview

基于当前仓库 `docs/feature-list/*.md` 的既有写法，生成对 `feature-curl-test-generator` 友好的通用模块特性清单。

目标不是写“概念介绍”，而是产出**可被后续 curl 测试脚本消费的接口清单文档**：

- 模块边界清晰
- 接口列表完整
- 每个接口的调用方式明确
- 入参/出参/认证/路径参数/Query/Form/JSON 位置明确
- 关键业务规则和免认证说明明确

## 何时使用

- 用户要求“生成特性清单 / feature list / 模块功能清单”
- 目标输出位于 `docs/feature-list/<module>.md`
- 文档后续会交给 `.codex/skills/feature-curl-test-generator` 生成 curl 测试
- 需要从现有代码、路由、处理器、接口文档、页面行为中整理模块 API 能力
- 需要补齐现有特性清单中的接口调用方式、入参/出参、认证说明

## 输出位置

- 默认输出：`docs/feature-list/<module>.md`
- 文件名优先使用已有模块 slug，例如：
  - `product-deploy.md`
  - `monitor-ops.md`
  - `auth-user.md`

## 生成原则

### 1. 先复用现有风格，不要另起炉灶

优先参考当前目录下已有文档：

- `docs/feature-list/product-deploy.md`
- `docs/feature-list/monitor-ops.md`
- `docs/feature-list/auth-user.md`
- `docs/feature-list/alarm.md`

保持以下风格一致：

- 标题：`# XXX模块功能清单`
- 模块分节：`## 一、...` / `## 二、...`
- 每个分节下固定包含 `### 接口列表` 与 `### 接口详情`
- 接口详情标题使用 `#### METHOD PATH - 功能名`

### 2. 优先写“测试可消费信息”

对每个接口，优先补齐以下信息，而不是泛泛的业务描述：

- 请求方法：`GET/POST/PUT/PATCH/DELETE`
- 接口路径：保留完整路径，如 ``/api/v1/deploy/pre-check``
- 认证要求：是否需要认证、是否免认证、特殊 token 要求
- 参数位置：路径参数 / Query / JSON / Form / Header
- 必填参数：后续生成“缺必填参数”负向用例时必须依赖
- 响应体：至少给出成功响应示例
- 业务规则：幂等、状态前置条件、互斥约束、特殊默认值

### 3. 若信息不完整，优先落“已确认信息”

若代码里无法完全确认全部字段：

- 可以先写已确认的必填字段
- 未确认项不要臆造
- 用“待补充 / 待确认”明确标记
- 但不要破坏已有 Markdown 结构

## 对 feature-curl-test-generator 的兼容硬约束

下面这些格式**尽量不要改名**，否则后续脚本可能无法正确解析。

### 接口列表标题

必须使用：

```md
### 接口列表
```

### 接口列表表头

推荐固定使用以下列：

```md
| 功能 | API | 方法 | 认证 | 说明 |
|------|-----|------|------|------|
```

说明：

- `认证` 列虽非解析强依赖，但建议始终保留
- 免认证接口请写 `否`
- 若是旧接口/内部接口，也在 `说明` 中注明

### 接口详情标题

必须使用如下格式：

```md
#### POST /api/v1/example/path - 功能名称
```

要求：

- 方法名大写
- 路径与接口列表保持完全一致
- 路径参数保留 `:id` 形式

### 参数块标题

优先使用以下几种固定写法：

- `请求参数 (Query):`
- `请求体 (JSON):`
- `请求参数 (Form):`
- `请求头:`
- `路径参数:`
- `无请求参数`
- `无请求体`

### 参数表表头

推荐使用：

```md
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
```

如果已知校验规则，可扩展成：

```md
| 参数 | 类型 | 必填 | 校验规则 | 说明 |
|------|------|------|----------|------|
```

注意：

- `参数`、`类型`、`必填` 这三列名尽量保持不变
- `必填` 列值统一使用：`是 / 否 / 条件`
- 嵌套字段直接写全路径，例如：
  - `resources[].hostName`
  - `installParams.hostInfos[].networks[].ip`

### 响应体块

推荐固定写法：

```md
响应体:
```json
{
  "code": 0,
  "msg": "success",
  "data": {}
}
```
```

若暂无完整返回结构，至少保留：

```md
响应体: `{"code": 0, "msg": "success"}`
```

## 建议工作流

### 第一步：确定模块边界

先明确要写的是哪个模块：

- 菜单模块
- 后台能力模块
- 内部采集接口模块
- 第三方/KMS 类独立接口模块

如果一个文件里同时覆盖多个子域，优先按“菜单或业务闭环”组织，而不是按代码目录硬拆。

### 第二步：收集接口事实

至少从以下来源交叉确认：

- 路由注册
- handler/controller
- 请求结构体 / DTO / VO
- 前端页面真实调用
- 现有接口文档 / Apifox / README

优先写“实际能调用”的接口，而不是未来规划接口。

### 第三步：先写接口列表，再补接口详情

每个分节先落一张总表：

- 功能
- API
- 方法
- 认证
- 说明

然后按表中顺序补 `#### METHOD PATH - 功能名` 详情段。

### 第四步：详情里重点补齐这些内容

#### GET/DELETE 接口

- 是否无请求体
- Query 参数
- 路径参数
- 成功响应

#### POST/PUT/PATCH 接口

- `请求体 (JSON)` 或 `请求参数 (Form)`
- 必填字段
- 校验规则
- 成功响应
- 特殊业务规则

#### 认证相关接口

- `Authorization` 头写法
- refresh token / access token 的区别
- 免认证白名单说明

### 第五步：补充业务规则

以下信息建议单列 `业务规则:`：

- 是否幂等
- 是否允许重复调用
- 是否存在状态前置条件
- 是否支持局部操作（如按 hostId）
- 参数互斥 / 联动关系
- 特殊默认值和回退行为

## 可直接套用的模板

优先复制：

- `references/module-feature-list-template.md`

新建模块文档时，先复制模板，再按真实模块裁剪。

## 自检命令

生成或修改文档后，至少执行一次解析自检。

### 列出模块

```bash
bash .codex/skills/feature-curl-test-generator/scripts/generate_module_curl_tests.sh \
  --feature-dir docs/feature-list \
  --list-modules
```

### 校验单模块可解析

```bash
bash .codex/skills/feature-curl-test-generator/scripts/generate_module_curl_tests.sh \
  --feature-dir docs/feature-list \
  --module product-deploy \
  --output-root /tmp/feature-curl-check
```

如果脚本能成功生成 `curl-tests.sh`，说明文档结构基本兼容。

## 常见错误

### 1. 把接口列表写成自由文本

不要写成：

- “提供查询、创建、删除等接口”

要写成标准表格，并明确路径与方法。

### 2. 详情标题与列表路径不一致

错误示例：

- 列表里是 `/api/v1/deploy/tasks/start/:id`
- 详情里写成 `/api/v1/deploy/task/start/:id`

后续解析会丢接口或参数。

### 3. 必填字段没有单独标出来

如果 `必填` 列缺失或写法混乱，后续无法稳定生成“缺必填参数”测试用例。

### 4. 路径参数只写在路径里，不单独说明

虽然解析器会尝试从 `:id` 推断，但仍建议显式写：

```md
路径参数: `id` (int) - 任务ID
```

### 5. 完全不写响应体

至少提供一个成功响应示例，便于后续人工校验与测试报告编写。

## 最小验收标准

一份合格的特性清单，至少满足：

- 能在 `--list-modules` 中被识别
- 目标模块能被 `feature-curl-test-generator` 成功解析
- 每个接口都有列表项
- 关键接口都有详情段
- 参数位置与必填信息清晰
- 成功响应与业务规则可用于人工复核

## 参考

- 消费方技能：`.codex/skills/feature-curl-test-generator/SKILL.md`
- 模板：`references/module-feature-list-template.md`
- 现有样例：`docs/feature-list/product-deploy.md`
- 现有样例：`docs/feature-list/monitor-ops.md`
- 现有样例：`docs/feature-list/auth-user.md`
