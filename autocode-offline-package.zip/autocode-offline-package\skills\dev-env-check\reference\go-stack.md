# Go 技术栈检查参考

> 本文档是 dev-env-check 技能的参考文档，包含 Go 技术栈的详细检查流程。

## 识别特征

| 配置文件 | 说明 |
|----------|------|
| `go.mod` | Go modules 项目 |
| `go.sum` | Go 依赖校验文件 |

## 检查项

- Go 版本
- GOPATH 和 GOROOT 环境变量
- Go modules 支持
- 常用工具（gofmt、golint 等）

## 检查命令

```bash
# 检查 Go 版本
go version 2>&1

# 检查 Go 环境变量
go env GOROOT 2>&1
go env GOPATH 2>&1
go env GO111MODULE 2>&1
go env GOPROXY 2>&1

# 检查 Go 工具
which gofmt 2>&1
which golint 2>&1
which staticcheck 2>&1

# 验证 Go modules
cd [项目目录] && go mod verify 2>&1
```

## 版本要求提取

从 `go.mod` 文件提取版本要求：

```go
// go.mod
module example.com/myproject

go 1.21
```

提取命令：
```bash
grep "^go " go.mod | awk '{print $2}'
```

## 期望结果

- Go 版本符合 go.mod 要求
- GO111MODULE=on（modules 模式）
- GOPATH 正确配置
- GOPROXY 已配置（国内建议配置代理）

## 构建命令

| 场景 | 构建命令 | 说明 |
|------|----------|------|
| 构建所有包 | `go build ./...` | 构建当前目录下所有包 |
| 构建主程序 | `go build -o app .` | 构建并输出可执行文件 |
| 检查编译 | `go build -v ./...` | 详细输出编译过程 |

## 常见问题

### GO111MODULE 配置

```bash
# 启用 Go modules（推荐）
go env -w GO111MODULE=on

# 或设置环境变量
export GO111MODULE=on
```

### GOPROXY 代理配置

国内环境建议配置代理：

```bash
# 配置 GOPROXY
go env -w GOPROXY=https://goproxy.cn,direct

# 或使用其他代理
go env -w GOPROXY=https://goproxy.io,direct
```

### 私有仓库配置

```bash
# 配置私有仓库不走代理
go env -w GOPRIVATE=*.internal.company.com,github.com/private-org

# 配置 Git 使用 SSH
git config --global url."git@github.com:".insteadOf "https://github.com/"
```

### 依赖下载失败

```bash
# 清理模块缓存
go clean -modcache

# 重新下载依赖
go mod download

# 整理依赖
go mod tidy
```

## 环境变量配置

```bash
# Linux/macOS - 添加到 ~/.bashrc 或 ~/.zshrc
export PATH=$PATH:/usr/local/go/bin
export GOPATH=$HOME/go
export PATH=$PATH:$GOPATH/bin
export GO111MODULE=on
export GOPROXY=https://goproxy.cn,direct

# 使配置生效
source ~/.bashrc
```

## 安装方式

### 包管理器

```bash
# Ubuntu/Debian
sudo apt install golang-go

# macOS
brew install go

# Windows
choco install golang
```

### 官方安装

```bash
# Linux
wget https://go.dev/dl/go1.21.5.linux-amd64.tar.gz
sudo rm -rf /usr/local/go
sudo tar -C /usr/local -xzf go1.21.5.linux-amd64.tar.gz
export PATH=$PATH:/usr/local/go/bin

# macOS (官方安装包)
# 下载 https://go.dev/dl/go1.21.5.darwin-amd64.pkg 并安装

# Windows
# 下载 https://go.dev/dl/go1.21.5.windows-amd64.msi 并安装
```

### 常用开发工具

```bash
# 代码格式化（内置）
go fmt ./...

# 静态分析
go install golang.org/x/lint/golint@latest
go install honnef.co/go/tools/cmd/staticcheck@latest

# 语言服务器（IDE 支持）
go install golang.org/x/tools/gopls@latest

# 测试覆盖率可视化
go install golang.org/x/tools/cmd/cover@latest
```

## 官方文档

- Go 官方: https://go.dev/doc/
- Go modules: https://go.dev/ref/mod
- Go 工具: https://pkg.go.dev/golang.org/x/tools
