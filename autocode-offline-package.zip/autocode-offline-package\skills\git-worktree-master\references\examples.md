# Git Worktree Master 使用示例

## 示例 1：标准需求开发流程

### 场景
开发一个新需求：S3 存储管理功能

### 步骤

#### 1. 创建需求工作区（需求分析前）
```bash
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh create rq001-s3-storage-manage
```

**输出**：
```
ℹ️  开始创建需求工作区...
ℹ️  需求标识：rq001-s3-storage-manage
ℹ️  工作区路径：../ai-flow-rad-rq001-s3-storage-manage
✅ 工作区创建成功
ℹ️  已进入工作区：/home/workspace/ai-flow-rad-rq001-s3-storage-manage
ℹ️  初始化子模块...
ℹ️  为子模块创建需求分支...
✅ 子模块分支创建完成

✅ 需求工作区创建完成！

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📍 当前目录：/home/workspace/ai-flow-rad-rq001-s3-storage-manage
🌿 主项目分支：rq001-s3-storage-manage
📊 工作区状态：干净
🔗 子模块状态：
  - submodule1: rq001-s3-storage-manage
  - submodule2: rq001-s3-storage-manage
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

#### 2. 执行需求分析
```bash
# 已经在工作区内，直接执行需求分析
/analysis-rq 在运维管理平台增加一个S3存储管理功能;
详细描述: 在主机管理菜单下方，增加一个菜单基础服务管理...;
使用背景: 此功能主要是运维工程师使用...
```

#### 3. 开发准备
```bash
# 继续在工作区内
/prepare-rq rq001-s3-storage-manage
```

#### 4. 开发实施
```bash
# 继续在工作区内
/develop-rq rq001-s3-storage-manage
```

#### 5. 清理工作区（需求完成后）
```bash
# 返回主仓库
cd /home/workspace/ai-flow-rad

# 清理工作区
./skills/git-worktree-master/scripts/worktree_manager.sh cleanup rq001-s3-storage-manage
```

## 示例 2：多需求并行开发

### 场景
同时开发两个需求：
- rq001-s3-storage-manage
- rq002-user-auth-enhancement

### 步骤

#### 1. 创建第一个需求工作区
```bash
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh create rq001-s3-storage-manage
```

#### 2. 在第一个工作区进行需求分析
```bash
# 已在 rq001 工作区
/analysis-rq ...
```

#### 3. 返回主仓库，创建第二个需求工作区
```bash
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh create rq002-user-auth-enhancement
```

#### 4. 在第二个工作区进行需求分析
```bash
# 已在 rq002 工作区
/analysis-rq ...
```

#### 5. 查看所有工作区
```bash
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh list
```

**输出**：
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 所有工作区列表：

/home/workspace/ai-flow-rad                              771c144 [master]
/home/workspace/ai-flow-rad-rq001-s3-storage-manage      a1b2c3d [rq001-s3-storage-manage]
/home/workspace/ai-flow-rad-rq002-user-auth-enhancement  d4e5f6g [rq002-user-auth-enhancement]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

#### 6. 在两个需求之间切换
```bash
# 切换到需求 1
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh switch rq001-s3-storage-manage

# 切换到需求 2
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh switch rq002-user-auth-enhancement
```

## 示例 3：中断后继续

### 场景
需求分析进行到一半，需要暂停，第二天继续

### 步骤

#### Day 1：开始需求分析
```bash
# 创建工作区
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh create rq001-s3-storage-manage

# 开始需求分析
/analysis-rq ...

# 工作到一半，提交当前进度
git add docs/requirement/rq001-s3-storage-manage/
git commit -m "wip: 需求分析进行中"
```

#### Day 2：继续需求分析
```bash
# 切换到工作区
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh switch rq001-s3-storage-manage

# 检查状态
./skills/git-worktree-master/scripts/worktree_manager.sh status

# 继续需求分析
/analysis-rq rq001-s3-storage-manage --continue
```

## 示例 4：子模块修改

### 场景
需求开发涉及子模块修改

### 步骤

#### 1. 在工作区内修改子模块
```bash
# 已在需求工作区
cd submodule1

# 修改代码
vim src/feature.py

# 提交子模块修改
git add src/feature.py
git commit -m "feat: 实现子模块功能"
git push origin rq001-s3-storage-manage
```

#### 2. 更新主项目的子模块引用
```bash
# 返回主项目
cd ..

# 更新子模块引用
git add submodule1
git commit -m "chore: 更新 submodule1 引用"
```

#### 3. 检查所有子模块状态
```bash
git submodule foreach 'echo "$(basename $sm_path): $(git branch --show-current)"'
```

## 示例 5：异常恢复

### 场景 1：工作区创建失败（分支已存在）

```bash
# 尝试创建工作区
./skills/git-worktree-master/scripts/worktree_manager.sh create rq001-xxx

# 提示分支已存在
⚠️  分支已存在：rq001-xxx
是否使用已有分支创建工作区？(y/n) y

# 使用已有分支创建工作区
✅ 工作区创建成功
```

### 场景 2：子模块分支不一致

```bash
# 检查子模块分支
git submodule foreach 'git branch --show-current'

# 输出显示部分子模块不在需求分支
submodule1: rq001-xxx
submodule2: master  ← 不一致

# 修复：切换子模块到需求分支
git submodule foreach 'git checkout rq001-xxx'
```

### 场景 3：工作区有未提交修改

```bash
# 尝试切换工作区
./skills/git-worktree-master/scripts/worktree_manager.sh switch rq002-xxx

# 提示有未提交修改
⚠️  当前工作区有未提交的修改：
M  docs/requirement/rq001-xxx/02-需求分析概要设计文档.md
是否继续切换？(y/n) n

# 提交修改后再切换
git add .
git commit -m "docs: 完成需求分析文档"
./skills/git-worktree-master/scripts/worktree_manager.sh switch rq002-xxx
```

## 示例 6：查看工作区状态

### 查看当前工作区状态
```bash
./skills/git-worktree-master/scripts/worktree_manager.sh status
```

**输出**：
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📍 当前目录：/home/workspace/ai-flow-rad-rq001-s3-storage-manage
🌿 主项目分支：rq001-s3-storage-manage
📊 工作区状态：3 个文件有修改
M  docs/requirement/rq001-s3-storage-manage/02-需求分析概要设计文档.md
M  docs/requirement/rq001-s3-storage-manage/05-需求分解特性清单.md
A  docs/requirement/rq001-s3-storage-manage/09-需求分析产出评审结果.md
🔗 子模块状态：
  - submodule1: rq001-s3-storage-manage
  - submodule2: rq001-s3-storage-manage
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

### 查看指定工作区状态
```bash
cd /home/workspace/ai-flow-rad
./skills/git-worktree-master/scripts/worktree_manager.sh status rq001-s3-storage-manage
```
