---
name: module-arch-extract
description: 针对单个子模块，从现有项目代码中提取模块边界、关键流程、数据与接口契约，按模板生成对应文件。
---

# Mudule Archtecture Analysis

从模块代码和已有文档中，分析出模块架构、功能说明、接口规范

## 核心概念

模块架构，指的是对模块结构的描述，包括：
 - 模块的描述，所提供的作用
 - 模块的目录，每个目录是什么作用
 - 模块的结构，有哪些组件或者功能构成，组件之间是什么关系
 - 模块的依赖，依赖哪些第三方组件，需要什么环境要求
 - 模块的数据，有哪些数据结构，数据之间的关系
 - 模块的流程，功能之间的业务流图、数据流图

接口规范，指的是模块和其他模块或者外部系统交互遵循的接口定义：
 - 接口清单，总有有哪些接口，接口的作用是什么
 - 接口定义，接口的url、请求、响应分别是什么
 - 接口规范，鉴权方式、URI、Header规范、请求消息格式、响应消息格式、请求/响应字段描述

## 输入

指定模块：{module}，有调用方传递

## 输出（落盘位置）

- **子模块设计文档**：`{project_root}/docs/architecture/${module}/模块整体架构设计.md`
- **子模块 API 文档**：`{project_root}/docs/architecture/${module}/模块API接口规范.md`

## 工作流程

### Step 1 确认模块类型

根据指定模块{module}目录下的文件，和代码文件后缀，推断子模块属于哪种类型：
 - VUE前端
 - React前端
 - Java后端
 - C++后端
 - Go后端
 - QT客户端
 - Go采集器
 - Java SDK模块
 - 其他类型

### Step 2 分析模块架构

根据模块类型，执行explore，输出模块架构文档：
```
Task(subagent_type="oh-my-claudecode:explore",
  prompt="分析模块{module}下的所有AGENTS.md文件，依据模板 @template/model_design_template.md，在{project_root}/docs/architecture/${module}/目录下，输出：模块整体架构设计.md；如果AGENTS.md参考信息不足，则查找到对应代码，读取代码进行分析")

```

如果模块是后端类型模块，则需要生成API接口规范：
```
Task(subagent_type="oh-my-claudecode:explore",
  prompt="分析模块{module}下的所有AGENTS.md文件，确定api代码路径，读取定义api的代码，依据模板 @template/model_api_template.md，在{project_root}/docs/architecture/${module}/目录下，输出：模块API接口规范.md")
```

### Step 3 校验输出文件

检查输出文件是否已经生成：
 - `{project_root}/docs/architecture/${module}/模块整体架构设计.md`
 - `{project_root}/docs/architecture/${module}/模块API接口规范.md`

如果文件缺失，回到 Step 2 补充执行缺失的任务
