---
name: bug-rca-plan
description: 进行缺陷根因分析并制定修复方案与同类问题排查策略，在验证后回填最终结论。Use when a bug needs RCA documentation, fix planning, and post-verification backfill.
---

# Bug RCA Plan

负责输出和维护 `10-根因修复与同类排查.md`。

## 输入

- `bug_id`
- `mode`：`analyze|backfill`
- `docs/bugfix/{bug_id}/00-缺陷原始输入.md`
- 可选：`docs/bugfix/{bug_id}/20-修复实施记录.md`
- 可选：`docs/bugfix/{bug_id}/30-远程验证报告.md`

## 输出

- `docs/bugfix/{bug_id}/10-根因修复与同类排查.md`

## 模板引用

- `references/10-rca-plan-template.md`

## analyze 模式

必须包含：
- 根因假设与证据
- 候选修复方案与推荐方案
- 修复边界与风险
- 同类问题排查范围与方法

## backfill 模式

在远程验证成功后回填：
- 最终根因结论
- 实际修复动作与原方案差异
- 同类排查执行结果（命中/未命中）
- 后续防回归建议
