---
name: e2e-report-builder
description: E2E 报告构建。将 Playwright 执行结果转为 AI-readable JSON 和人读 HTML 双格式报告，输出到 .tests/reports/{run-id}/ 目录，并更新 .tests/latest 软链接。
---

# E2E 报告构建技能

## 调用方

- `e2e-orchestrator`：Playwright 执行完成后调用，生成双格式报告
- 用户直接调用：对已有 Playwright 执行结果重新生成报告

## 输入

- **`run_id`**（必填）：由 `e2e-orchestrator` 在 Step 5 执行前生成，格式 `run-YYYYMMDD-HHMMSS`；用户直接调用时可省略，自动生成
- **Playwright 原始产物目录**：`.tests/reports/{run-id}/`（含 `junit.xml`、`test-results.json`、`playwright-report/`、`screenshots/`、`videos/`、`traces/`）；若目录不存在则尝试读取 `.tests/playwright-raw/` 作为降级路径
- `tests/ui-test/testcase-registry.csv`：用例元信息（级别、冒烟状态、分类等）

---

## 执行流程

```
Step 1: 读取 Playwright 执行结果（JUnit XML / JSON 结果文件）
Step 2: 读取 CSV 注册表，补充用例元信息（level、smoke、category）
Step 3: 生成 AI-readable JSON 报告（ai-report.json）
Step 4: 基于 HTML 模板生成人读报告（report.html）
Step 5: 输出到 .tests/reports/{run-id}/
Step 6: 更新软链接 .tests/latest → .tests/reports/{run-id}/
```

---

## 报告输出路径

```
.tests/
├── reports/
│   └── {run-id}/
│       ├── ai-report.json          # AI-readable 报告（本技能生成）
│       ├── report.html             # 人读 HTML 报告（本技能生成）
│       ├── junit.xml               # Playwright 原生 JUnit XML（复制过来）
│       ├── screenshots/            # 失败截图（Playwright 原生）
│       ├── videos/                 # 测试录屏（Playwright 原生）
│       └── traces/                 # Playwright trace（Playwright 原生）
└── latest -> reports/{run-id}/    # 软链接，指向最新报告
```

---

## AI-readable 报告格式（ai-report.json）

参见模板文件：`template/ai-report.json.template`

### 关键字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `run_id` | string | 运行标识，格式 `run-YYYYMMDD-HHMMSS` |
| `result` | enum | `pass` / `fail` / `warn`（P0 失败或整体通过率 < 90% 为 fail；flaky 比例 ≥ 5% 为 warn） |
| `summary` | object | 整体统计（total/passed/failed/flaky/pass_rate/duration） |
| `smoke_result` | object | 冒烟用例单独统计 |
| `level_breakdown` | object | 按 P0/P1/P2/P3 分级统计 |
| `browser_breakdown` | object | 按浏览器（chromium/firefox/webkit）统计 |
| `failed_cases` | array | 失败用例详情列表，每项含 `case_id`、`case_name`、`level`、`browser`、`error`（错误信息）、`screenshot`（截图路径）、`trace`（trace 路径） |
| `flaky_cases` | array | 不稳定用例列表，每项含 `case_id`、`case_name`、`level`、`stability`（如 "7/10"，通过次数/总运行次数）、`failure_pattern`（失败模式描述，如"间歇性超时"）、`suggested_fix`（修复建议） |
| `coverage` | object | 页面覆盖率和分类覆盖情况，含 `pages_covered`（已覆盖页面数）、`pages_total`（总页面数）、`page_coverage`（覆盖率百分比）、`categories`（已覆盖功能分类列表） |
| `artifacts` | object | 所有产物的路径引用，含 `html_report`、`junit_xml`、`ai_report` |

### 判定规则

- **整体结果（result）**：
  - `fail`：存在任意 P0 失败，或整体通过率 < 90%
  - `warn`：flaky 比例 ≥ 5%（不阻断，但在报告中记录并给出修复建议）
  - `pass`：以上均不满足

> **说明**：flaky 超阈值不触发 `fail`，与 `e2e-orchestrator` 和 `rq-stage-test-executor` 的门禁语义保持一致——flaky 是质量信号，需要修复，但不应阻断当前发布流程。`result` 字段只有 `pass` / `fail` / `warn` 三种值，上层工作流按此字段判断是否阻断。

- **用例状态**：
  - `passed`：执行通过
  - `failed`：执行失败
  - `flaky`：多次运行结果不一致（Playwright retry 通过的视为 flaky）
  - `skipped`：跳过（test.skip 或 test.fixme）

---

## HTML 报告内容

参见模板文件：`template/report.html.template`

> **渲染方式说明**：HTML 模板使用 `{{FIELD}}` 单括号占位符（标量替换）和 `{{#if}}` / `{{#each}}` 块语法（结构参考）。实际使用时，**AI agent 直接生成完整 HTML 字符串**，不依赖外部模板引擎——模板文件提供结构参考和样式基础，agent 读取后以字符串替换的方式填充数据，最终写出完整的 `.html` 文件。

HTML 报告包含以下区块：

1. **执行概要**：通过率、冒烟结果、各级别统计、运行时长
2. **浏览器维度矩阵**：chromium / firefox / webkit 各自通过情况
3. **失败用例详情**：错误信息、截图内嵌（base64）、trace 路径
4. **Flaky 用例列表**：稳定性评分、失败模式、修复建议
5. **用例覆盖率摘要**：分类覆盖、级别分布

---

## Playwright 原生结果解析

### JUnit XML 解析

从 JUnit XML 提取：
- `<testsuite>` 的 `tests`、`failures`、`errors`、`skipped`、`time` 属性
- `<testcase>` 的 `name`、`classname`、`time` 属性
- `<failure>` 的错误信息

### Playwright JSON 结果解析

若存在 `test-results.json`（需在 `tests/ui-test/playwright.config.ts` 中配置 `json` reporter）：
- 直接读取结构化结果，比解析 JUnit XML 更准确
- 可获取重试次数、浏览器信息等

### case_id 提取规则

Playwright 测试名称格式：`{case_id}: {case_name}`

从测试名称中提取 `case_id`，再查询 CSV 注册表补充 `level`、`smoke`、`category` 信息。若无法匹配则使用 `unknown`。

---

## 软链接更新

```bash
# 更新 latest 软链接（Linux/macOS）
ln -sfn reports/{run-id} .tests/latest

# Windows 环境下，改为写入 .tests/latest.txt
echo "reports/{run-id}" > .tests/latest.txt
```

---

## 约束

- 不执行 Playwright 测试（仅处理已有结果）
- 不修改 Playwright 原生产物（只读）
- 不修改 `tests/ui-test/testcase-registry.csv`（只读用例元信息）
- HTML 报告截图采用 base64 内嵌，确保报告可独立分发
- run_id 必须全局唯一，避免覆盖历史报告
