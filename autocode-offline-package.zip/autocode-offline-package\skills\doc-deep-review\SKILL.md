---
name: doc-deep-review
description: 使用 Codex MCP 对需求文档进行深度评审，循环修复 P0/P1 问题直至通过
---

# Doc Deep Review Skill

## Purpose

使用 `mcp__plugin_oh-my-claudecode_x__ask_codex`（Codex MCP）对需求分析产出的文档进行多轮深度评审。
每轮评审产出带严重等级（P0/P1/P2/P3）的问题清单，自动修复 P0 和 P1 问题后重新提交评审，
循环直到所有 P0/P1 问题清零或达到最大轮次。

## When to Activate

- 用户说"文档评审"、"需求评审"、"doc review"、"deep review"
- 需求分析阶段产出文档后需要质量把关
- 用户指定某个 `.md` 文档需要专家评审

## Workflow

### Phase 1: 准备

1. **确定评审目标文档**
   - 如果用户提供了 `<doc-path>`，直接使用
   - 否则扫描 `docs/requirement/` 目录，列出可评审文档让用户选择
   - 支持单文件或批量评审

2. **读取文档内容**
   - 使用 Read 工具读取目标文档全文
   - 如果文档过长（>800行），分段处理

3. **准备评审 prompt 文件**
   - 将评审指令和文档内容写入临时 prompt 文件
   - 确保工作目录下存在 `.tmp/`（如不存在，先创建；例如执行 `mkdir -p .tmp`）
   - 路径: `.tmp/doc-review-prompt-{timestamp}.md`（必须位于工作目录内，避免 MCP 报错）

### Phase 2: Codex 评审循环

每轮执行以下步骤：

#### Step 1: 提交评审

调用 Codex MCP 进行评审：

```
mcp__plugin_oh-my-claudecode_x__ask_codex({
  agent_role: "analyst",
  prompt_file: "<prompt-file-path>",
  output_file: ".tmp/doc-review-result-round{N}.md",
  context_files: ["<doc-path>"]
})
```

**评审 Prompt 模板：**

```markdown
你是一位资深需求分析评审专家。请对以下需求文档进行严格评审。

## 评审维度

1. **完整性** - 是否覆盖所有必要内容（背景、目标、范围、功能需求、非功能需求、验收标准）
2. **一致性** - 文档内部是否自洽，术语是否统一，数据是否一致
3. **准确性** - 技术描述是否正确，业务逻辑是否合理
4. **可执行性** - 需求是否足够具体可落地，是否有明确的验收标准
5. **可追溯性** - 需求是否可追溯到业务目标，是否有优先级标注
6. **风险识别** - 是否识别了关键风险和依赖

## 输出格式

请严格按以下 JSON 格式输出评审结果：

```json
{
  "summary": "整体评价（1-2句话）",
  "score": 85,
  "issues": [
    {
      "id": "ISSUE-001",
      "severity": "P0",
      "dimension": "完整性",
      "location": "第X章/第Y节",
      "description": "问题描述",
      "suggestion": "修改建议"
    }
  ],
  "highlights": ["亮点1", "亮点2"]
}
```

严重等级定义：
- **P0（阻断）**: 缺失关键内容、逻辑错误、会导致开发方向错误
- **P1（严重）**: 描述模糊可能导致误解、缺少必要约束、验收标准不明确
- **P2（一般）**: 格式不规范、术语不统一、可改进但不影响理解
- **P3（建议）**: 优化建议、最佳实践推荐
```

#### Step 2: 解析评审结果

- 读取 Codex 输出文件
- 解析 JSON 格式的评审结果
- 统计各等级问题数量
- 向用户展示评审摘要：

```
📋 第 N 轮评审结果
━━━━━━━━━━━━━━━━━━
评分: 85/100
P0 (阻断): 2 个
P1 (严重): 3 个
P2 (一般): 5 个
P3 (建议): 2 个

P0 问题:
  ISSUE-001: [完整性] 缺少非功能需求章节 → 需补充性能/安全/可用性要求
  ISSUE-002: [准确性] 接口协议描述与系统架构不一致 → 需对齐 GB28181 版本

P1 问题:
  ISSUE-003: [可执行性] 验收标准缺少量化指标 → 需补充具体数值
  ...
```

#### Step 3: 自动修复

- 仅修复 P0 和 P1 问题
- 对每个问题：
  1. 定位文档中的对应位置
  2. 根据 suggestion 进行修改
  3. 使用 Edit 工具精确替换
- 修复后向用户展示变更摘要

#### Step 4: 循环判断

- 如果 P0 + P1 == 0 → 评审通过，进入 Phase 3
- 如果已达最大轮次（默认5轮）→ 输出剩余问题，人工介入
- 否则 → 回到 Step 1，开始下一轮评审

### Phase 3: 评审报告

评审通过后，生成最终评审报告：

```markdown
# 文档评审报告

## 基本信息
- 文档: <doc-path>
- 评审轮次: N 轮
- 最终评分: XX/100
- 评审状态: ✅ 通过

## 评审历程
| 轮次 | P0 | P1 | P2 | P3 | 评分 |
|------|----|----|----|----|------|
| 1    | 2  | 3  | 5  | 2  | 65   |
| 2    | 0  | 1  | 3  | 2  | 82   |
| 3    | 0  | 0  | 2  | 1  | 92   |

## 已修复问题
- [P0] ISSUE-001: 缺少非功能需求章节 → 已补充
- [P1] ISSUE-003: 验收标准缺少量化指标 → 已补充
- ...

## 遗留问题（P2/P3）
- [P2] ISSUE-005: 术语不统一 → 建议后续统一
- ...
```

默认不在项目 `docs/**` 下额外生成“评审中间文件”（避免产物散落）。

如需落盘评审报告，推荐写入过程目录（例如：`.claude/notepads/<rq-or-bug-id>/doc-review-report.md`）；仅当用户明确要求时，才写回文档同目录（例如：`<doc-name>-review-report.md`）。

## Configuration

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `--max-rounds` | 5 | 最大评审轮次 |
| `--fix-p2` | false | 是否也修复 P2 问题 |
| `--report-only` | false | 仅评审不修复 |

## Examples

```bash
# 评审单个文档
/doc-deep-review docs/requirement/rq001/02-需求概要设计.md

# 评审并限制轮次
/doc-deep-review docs/requirement/rq001/02-需求概要设计.md --max-rounds=3

# 仅生成评审报告不修复
/doc-deep-review docs/requirement/rq001/02-需求概要设计.md --report-only
```

## Notes

- Codex MCP 调用使用 `agent_role: "analyst"` 以获得需求分析视角
- 每轮评审的 prompt 和结果都保存在工作目录下的 `.tmp/`，便于回溯（避免写到 `/tmp/` 导致 MCP 认为路径不在工作目录内）
- 如果 Codex MCP 不可用，自动降级为使用 `oh-my-claudecode:analyst` agent
- P2/P3 问题默认不自动修复，仅记录在报告中
- 文档修改使用 Edit 工具的精确替换，确保不破坏文档结构
