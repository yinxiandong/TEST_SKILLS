# XXX模块功能清单

## 菜单结构

```text
模块名称 (menu_id: 待补充)
├── 子菜单A (menu_id: 待补充, path: /path-a)
└── 子菜单B (menu_id: 待补充, path: /path-b)
```

---

## 一、子域名称A

### 接口列表

| 功能 | API | 方法 | 认证 | 说明 |
|------|-----|------|------|------|
| 查询列表 | `/api/v1/example/list` | GET | 是 | 分页查询示例资源 |
| 获取详情 | `/api/v1/example/:id` | GET | 是 | 查询单条资源详情 |
| 新增资源 | `/api/v1/example` | POST | 是 | 创建资源 |
| 上传文件 | `/api/v1/example/upload` | POST | 是 | Form 上传文件 |
| 内部上报 | `/api/v1/example/report` | POST | 否 | 内部接口，免认证 |

### 接口详情

#### GET /api/v1/example/list - 查询列表

请求参数 (Query):

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| pageNo | int | 否 | 1 | 页码 |
| pageSize | int | 否 | 20 | 每页条数 |
| keyword | string | 否 | - | 关键字 |

响应体:
```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "total": 1,
    "list": [
      {
        "id": 1,
        "name": "sample"
      }
    ]
  }
}
```

#### GET /api/v1/example/:id - 获取详情

路径参数: `id` (int) - 资源ID

无请求参数

响应体:
```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "id": 1,
    "name": "sample"
  }
}
```

#### POST /api/v1/example - 新增资源

请求体 (JSON):

| 参数 | 类型 | 必填 | 校验规则 | 说明 |
|------|------|------|----------|------|
| name | string | 是 | required | 资源名称 |
| enabled | bool | 否 | - | 是否启用 |
| config.timeout | int | 否 | min=1 | 超时时间 |
| items[].code | string | 条件 | required_with=items | 子项编码 |

响应体:
```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "id": 1
  }
}
```

业务规则:

- 同名资源不可重复创建
- `items` 非空时，`items[].code` 必填

#### POST /api/v1/example/upload - 上传文件

请求参数 (Form):

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| file | file | 是 | 上传文件 |
| bizType | string | 是 | 业务类型 |

响应体:
```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "fileId": "file-001"
  }
}
```

#### POST /api/v1/example/report - 内部上报

请求体 (JSON):

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| source | string | 是 | 来源系统 |
| payload | object | 是 | 上报内容 |

响应体: `{"code": 0, "msg": "success"}`

---

## 二、子域名称B

### 接口列表

| 功能 | API | 方法 | 认证 | 说明 |
|------|-----|------|------|------|
| 示例操作 | `/api/v1/example/action/:id` | PUT | 是 | 执行示例操作 |

### 接口详情

#### PUT /api/v1/example/action/:id - 示例操作

路径参数: `id` (int) - 资源ID

请求头: `Authorization: Bearer <accessToken>`

请求体 (JSON):

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| force | bool | 否 | 是否强制执行 |

响应体:
```json
{
  "code": 0,
  "msg": "success"
}
```

业务规则:

- 当资源处于运行中时，`force=true` 才允许执行
