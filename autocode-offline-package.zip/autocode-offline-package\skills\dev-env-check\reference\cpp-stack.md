# C/C++ 技术栈检查参考

> 本文档是 dev-env-check 技能的参考文档，包含 C/C++ 技术栈的详细检查流程。

## 识别特征

| 配置文件 | 构建工具 | 说明 |
|----------|----------|------|
| `CMakeLists.txt` | CMake | 现代 C/C++ 构建 |
| `Makefile` | Make | 传统构建 |
| `meson.build` | Meson | 快速构建系统 |
| `configure` / `configure.ac` | Autotools | GNU 构建系统 |
| `vcxproj` / `sln` | MSBuild | Visual Studio 项目 |

## 检查项

- GCC/G++ 编译器版本
- Clang 编译器（如果使用）
- CMake 版本
- Make 工具
- 调试工具（gdb）

## 检查命令

```bash
# 检查 GCC 版本
gcc --version 2>&1
g++ --version 2>&1

# 检查 Clang（如果使用）
clang --version 2>&1
clang++ --version 2>&1

# 检查 CMake
cmake --version 2>&1

# 检查 Make
make --version 2>&1

# 检查 Ninja（可选构建工具）
ninja --version 2>&1

# 检查调试工具
gdb --version 2>&1
lldb --version 2>&1

# 检查构建工具链
which autoconf 2>&1
which automake 2>&1
which libtool 2>&1
which pkg-config 2>&1
```

## 版本要求提取

### CMakeLists.txt

```cmake
cmake_minimum_required(VERSION 3.16)

# C++ 标准要求
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
```

提取命令：
```bash
# 提取 CMake 最低版本
grep "cmake_minimum_required" CMakeLists.txt | grep -oP "VERSION \K[0-9.]+"

# 提取 C++ 标准
grep "CMAKE_CXX_STANDARD" CMakeLists.txt | grep -oP "[0-9]+"
```

## 期望结果

- GCC/G++ 版本满足项目要求
- CMake 或 Make 可正常使用
- 必要的构建工具链完整

## 构建命令

| 构建文件 | 构建命令 | 说明 |
|----------|----------|------|
| CMakeLists.txt | `cmake -B build && cmake --build build` | CMake 构建 |
| Makefile | `make` | Make 构建 |
| configure | `./configure && make` | Autotools 构建 |

### CMake 典型构建流程

```bash
# 创建构建目录
mkdir -p build && cd build

# 配置（生成 Makefile）
cmake ..

# 构建
cmake --build . --parallel

# 或使用 make
make -j$(nproc)

# 安装（可选）
cmake --install . --prefix /usr/local
```

## 常见问题

### 编译器版本过低

```bash
# Ubuntu - 安装新版 GCC
sudo add-apt-repository ppa:ubuntu-toolchain-r/test
sudo apt update
sudo apt install gcc-12 g++-12

# 设置默认编译器
sudo update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-12 100
sudo update-alternatives --install /usr/bin/g++ g++ /usr/bin/g++-12 100
```

### CMake 版本过低

```bash
# 使用 pip 安装最新版
pip install cmake

# 或从官方下载
wget https://github.com/Kitware/CMake/releases/download/v3.28.1/cmake-3.28.1-linux-x86_64.sh
chmod +x cmake-3.28.1-linux-x86_64.sh
sudo ./cmake-3.28.1-linux-x86_64.sh --prefix=/usr/local --skip-license
```

### 缺少依赖库

```bash
# 查找缺失的库
apt-cache search libxxx

# 安装开发包（通常以 -dev 结尾）
sudo apt install libssl-dev libcurl4-openssl-dev

# 使用 pkg-config 检查库
pkg-config --cflags --libs openssl
```

### 交叉编译配置

```bash
# CMake 交叉编译
cmake -DCMAKE_TOOLCHAIN_FILE=toolchain.cmake ..

# 指定编译器
cmake -DCMAKE_C_COMPILER=arm-linux-gnueabihf-gcc \
      -DCMAKE_CXX_COMPILER=arm-linux-gnueabihf-g++ ..
```

## 构建工具链

### 必需工具

```bash
# Ubuntu/Debian - 安装基础构建工具
sudo apt install build-essential

# 包含：gcc, g++, make, libc-dev 等

# 安装 CMake
sudo apt install cmake

# 安装 Ninja（可选，更快的构建）
sudo apt install ninja-build
```

### 可选工具

```bash
# Autotools 工具链
sudo apt install autoconf automake libtool

# 调试工具
sudo apt install gdb valgrind

# 静态分析
sudo apt install cppcheck clang-tidy

# 代码格式化
sudo apt install clang-format
```

## 安装方式

### 包管理器

```bash
# Ubuntu/Debian
sudo apt install build-essential cmake ninja-build gdb

# CentOS/RHEL
sudo yum groupinstall "Development Tools"
sudo yum install cmake ninja-build gdb

# macOS
xcode-select --install  # 安装命令行工具
brew install cmake ninja

# Windows
# 安装 Visual Studio Build Tools 或 MinGW
choco install visualstudio2022buildtools
# 或
choco install mingw cmake
```

### Clang/LLVM 安装

```bash
# Ubuntu/Debian
sudo apt install clang lldb lld

# 或安装完整 LLVM
wget https://apt.llvm.org/llvm.sh
chmod +x llvm.sh
sudo ./llvm.sh 17  # 安装 LLVM 17
```

## IDE 支持

### VS Code

```json
// .vscode/settings.json
{
    "cmake.configureOnOpen": true,
    "cmake.buildDirectory": "${workspaceFolder}/build",
    "C_Cpp.default.configurationProvider": "ms-vscode.cmake-tools"
}
```

### CLion

CLion 内置 CMake 支持，直接打开 CMakeLists.txt 即可。

## 官方文档

- GCC: https://gcc.gnu.org/onlinedocs/
- Clang: https://clang.llvm.org/docs/
- CMake: https://cmake.org/documentation/
- Make: https://www.gnu.org/software/make/manual/
- Ninja: https://ninja-build.org/manual.html
