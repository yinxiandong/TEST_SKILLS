---
name: api-test-report-builder
description: API 测试报告生成。将 pytest 执行结果（JUnit XML + JSON）转为双格式报告：ai-report.json（AI 可读）和 report.html（人读 HTML），支持覆盖率分类统计、响应时间分析和安全发现摘要。
---

# API 测试报告生成技能

## 调用方

- `api-test-orchestrator`：在 Phase 5 调用，生成最终报告
- 用户直接调用：从已有执行结果生成报告

## 前置依赖

- pytest 执行结果（由 `api-test-executor` 生成）
  - `.tests/api-reports/{run-id}/junit.xml`
  - `.tests/api-reports/{run-id}/result.json`
- 用例注册表 CSV（路径从 `tests/api-test/api-test.config.yaml` 的 `output.registry_file` 读取，默认 `tests/api-test/testcase-registry.csv`）

---

## 执行流程

```
1. 读取 .tests/api-reports/{run-id}/ 下的执行结果
2. 解析 JUnit XML + JSON 结果
3. 关联 testcase-registry.csv 获取用例元信息（level, coverage_type 等）
4. 计算统计指标：
   ├─ 总体通过率
   ├─ 按级别（P0/P1/P2/P3）分类统计
   ├─ 按覆盖类型（positive/negative/boundary/security）分类统计
   ├─ 按模块/API 路径统计
   ├─ 响应时间统计（avg/p50/p95/p99）
   └─ 安全用例发现摘要
5. 生成 ai-report.json
6. 使用 Jinja2 渲染 report.html
7. 判定测试结果（pass/fail/warn）
```

---

## 报告格式

### ai-report.json

```json
{
  "run_id": "run-20260314-143052",
  "timestamp": "2026-03-14T14:30:52Z",
  "result": "pass|fail|warn",
  "environment": "dev",
  "summary": {
    "total": 120,
    "passed": 115,
    "failed": 3,
    "error": 1,
    "skipped": 1,
    "pass_rate": "95.8%",
    "duration_ms": 45000
  },
  "smoke_result": {
    "total": 15,
    "passed": 15,
    "pass_rate": "100%"
  },
  "level_breakdown": {
    "P0": { "total": 15, "passed": 15, "rate": "100%" },
    "P1": { "total": 40, "passed": 38, "rate": "95.0%" },
    "P2": { "total": 45, "passed": 43, "rate": "95.6%" },
    "P3": { "total": 20, "passed": 19, "rate": "95.0%" }
  },
  "coverage_breakdown": {
    "positive": { "total": 48, "passed": 48, "rate": "100%" },
    "negative": { "total": 36, "passed": 34, "rate": "94.4%" },
    "boundary": { "total": 24, "passed": 22, "rate": "91.7%" },
    "security": { "total": 12, "passed": 11, "rate": "91.7%" }
  },
  "api_breakdown": {
    "auth": { "total": 20, "passed": 20, "rate": "100%" },
    "user": { "total": 30, "passed": 28, "rate": "93.3%" },
    "order": { "total": 40, "passed": 38, "rate": "95.0%" }
  },
  "response_time_stats": {
    "avg_ms": 120,
    "p50_ms": 95,
    "p95_ms": 350,
    "p99_ms": 800,
    "slowest": {
      "case_id": "TC-API-ORDER-015",
      "api_path": "/api/v1/orders/export",
      "time_ms": 2500
    }
  },
  "failed_cases": [
    {
      "case_id": "TC-API-USER-012",
      "case_name": "更新用户-边界-姓名超长",
      "level": "P2",
      "coverage_type": "boundary",
      "api_path": "/api/v1/users/:id",
      "error": "AssertionError: Expected 400, got 200",
      "suggestion": "后端缺少字符串长度校验"
    }
  ],
  "security_findings": [
    {
      "case_id": "TC-API-USER-020",
      "coverage_rule": "security-sql-injection",
      "api_path": "/api/v1/users/search",
      "finding": "SQL 注入 payload 返回 200 而非 400",
      "severity": "high",
      "suggestion": "检查 search 接口的参数过滤逻辑"
    }
  ],
  "artifacts": {
    "html_report": ".tests/api-reports/run-20260314-143052/report.html",
    "ai_report": ".tests/api-reports/run-20260314-143052/ai-report.json",
    "junit_xml": ".tests/api-reports/run-20260314-143052/junit.xml"
  }
}
```

### 结果判定规则

- `pass`：无 P0 失败 + 总通过率 ≥ 90%
- `fail`：任何 P0 失败 OR 总通过率 < 90%
- `warn`：有安全发现（security_findings 非空）但通过率达标

### report.html

使用 Jinja2 模板渲染，包含：

- 执行摘要卡片（总数、通过率、耗时）
- 级别分布饼图（P0/P1/P2/P3）
- 覆盖类型分布柱状图
- 模块通过率表格
- 失败用例详情表
- 安全发现高亮区域
- 响应时间分布图

---

## 输出路径

```
.tests/api-reports/{run-id}/
├── ai-report.json             # AI 可读报告
├── report.html                # 人读 HTML 报告
├── junit.xml                  # 原始 JUnit XML（已有）
├── result.json                # 原始 JSON 结果（已有）
└── meta.json                  # 执行元信息（已有）
```

---

## 约束

- 不修改原始执行结果文件（junit.xml, result.json）
- HTML 报告为自包含单文件（CSS 内联），方便上传研发系统
- 安全发现仅基于用例执行结果判断，不做深度安全扫描
- 报告中不包含敏感信息（密码、token 等）
