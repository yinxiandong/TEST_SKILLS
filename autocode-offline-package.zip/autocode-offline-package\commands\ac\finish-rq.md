---
name: finish-rq
description: "启动需求收尾阶段：提交代码、推送远程、创建 MR 并清理工作区，完成需求开发全流程闭环"
category: workflow
---

# /finish-rq - 需求收尾命令

**功能说明**：该命令用于启动需求收尾工作流。在 `/develop-rq` 完成并通过交付门禁后，自动化执行代码提交、远程推送、GitLab MR 创建和工作区清理，完成需求开发全流程闭环。

## 使用方法

```bash
/finish-rq {rq_id}
```

**参数说明**：
- `{rq_id}`：必需，需求文件夹名称（对应目标项目的 `docs/requirement/{rq_id}/`）

## 使用示例

```bash
# 标准用法：develop 完成后执行 finish
/develop-rq rq001-s3-storage-manage
# ... 开发闭环通过 ...
/finish-rq rq001-s3-storage-manage
```

## 前置条件

**交付报告**
- `.claude/notepads/{rq_id}/final-delivery-report.md` 存在且 status 为 `completed`

**需求工作区**
- 当前处于需求工作区，分支名为 `{rq_id}`

## 前置准备

建议先做最小校验（任一不满足应终止并人工处理）：

```bash
rg -n "^status:\\s*completed\\b" ".claude/notepads/{rq_id}/final-delivery-report.md"
test "$(git branch --show-current)" = "{rq_id}"
git remote get-url origin
```

## 工作流程

按照 task 模式，执行以下步骤：
Step 1. 调用 Skill：`rq-finish` 执行收尾闭环

### Step 1: 调用收尾技能

**Skill**: `rq-finish`

传入需求标识 `{rq_id}`，由该技能统一协调执行：

1. 前置校验（交付报告 + 分支检查）
2. 提交代码（子模块优先 → 主项目）
3. 推送远程并创建 GitLab MR
4. 清理工作区（用户确认后执行）
5. 输出闭环总结

## 完整工作流定位

```
/analysis-rq  →  需求分析
/prepare-rq   →  开发准备（计划 + 测试设计）
/develop-rq   →  开发实施（开发 → 测试 → 修复 → 评审）
/finish-rq    →  需求收尾（提交 → 推送 → MR → 清理）
```
