---
name: fix-bug
description: "启动缺陷修复工作流：输入 bug 后自动完成根因分析、修复、远程验证、文档回填与收尾"
category: workflow
---

# /fix-bug - 缺陷修复命令

**功能说明**：该命令用于启动缺陷修复工作流。命令层仅负责接收输入和组织上下文，核心逻辑全部由 Skill `bug-fix-orchestrator` 执行：缺陷标准化、根因分析与修复方案、代码修复、远程调试验证、方案文档回填、评审收尾，最终交由人工核对并提交代码。

## 使用方法

```bash
/fix-bug {bug_id} [--continue] [--analyze-only | --fix-only | --verify-only]
```

**参数说明**：
 - `{bug_id}`：必需，缺陷标识（格式：`bugXXX-<bug-slug>`，对应 `docs/bugfix/{bug_id}/`）
- `--continue`：可选，从中断点续跑
- `--analyze-only`：可选，仅执行缺陷分析与方案输出
- `--fix-only`：可选，仅执行修复与验证（要求已有分析方案）
- `--verify-only`：可选，仅执行远程验证与收尾（要求已有修复改动）

**参数约束**：
- `--analyze-only`、`--fix-only`、`--verify-only` 三者互斥，最多指定一个
- `--continue` 可与任一子模式组合

## 前置条件

**缺陷目录**
- `{project_root}/docs/bugfix/{bug_id}/`

**过程记录目录**
- `.claude/notepads/{bug_id}/`

## 前置准备

检查工作区，使用 Skill: `git-worktree-master`，确认当前位于正确需求/缺陷工作区。

**Skill**: `git-worktree-master`
**命令**: 检查工作区状态
**异常**: 终止行动，请求人工处理

## 子模式说明

默认不带子模式时，执行完整闭环：
1. 缺陷输入标准化
2. 根因分析与修复方案（含同类问题排查）
3. 代码修复
4. 远程调试验证
5. 回填根因修复方案文档
6. 评审收尾并生成人工核对清单

子模式执行规则：
- `--analyze-only`：仅执行 1~2
- `--fix-only`：执行 3~5（需先有 `10-根因修复与同类排查.md`）
- `--verify-only`：执行 4~6（需先有修复实施记录）

模式映射（命令层到技能层）：
- `execution_mode`：`default|analyze-only|fix-only|verify-only`
- `resume`：`true|false`（由 `--continue` 决定）

## 工作流程

### Step 1: 调用总入口 Skill

总入口 Skill：`bug-fix-orchestrator`

由该技能统一协调以下技能：
- `bug-intake-normalizer`
- `bug-rca-plan`
- `bug-fix-implementer`
- `bug-verify-runner`
- `bug-review-closure`

调用示例：

```text
Task(
  subagent_type="requirement-coder",
  model="sonnet",
  prompt="BUG FIX ORCHESTRATION

说明:
1. 缺陷标识: {bug_id}
2. 缺陷目录: {project_root}/docs/bugfix/{bug_id}/
3. 过程目录: .claude/notepads/{bug_id}/
4. 执行模式 execution_mode: default/analyze-only/fix-only/verify-only
5. 续跑开关 resume: true/false
6. 统一调用远程调试主 Skill: remote-dev-debug
7. 执行完成后生成 90-人工核对清单.md，等待人工提交代码"
)
```

### Step 2: 状态输出

流程输出状态：
- `running`：进行中
- `blocked`：缺失输入或验证失败阻塞
- `need_human_check`：自动流程已完成，等待人工核对与提交
- `completed`：人工核对完成（仅文档状态更新，不自动提交）

## 产物清单

输出目录：`docs/bugfix/{bug_id}/`

- `00-缺陷原始输入.md`
- `10-根因修复与同类排查.md`
- `20-修复实施记录.md`
- `30-远程验证报告.md`
- `90-人工核对清单.md`
