#!/usr/bin/env python3
"""
API 测试报告生成器
从 pytest 执行结果（JUnit XML + JSON）生成双格式报告：
- ai-report.json（AI 可读）
- report.html（人读 HTML，Jinja2 渲染）

用法:
    python build_api_report.py --run-dir .tests/api-reports/run-20260314-143052
    python build_api_report.py --latest    # 使用 latest 软链接
"""

import argparse
import json
import os
import sys
import statistics
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree

import yaml

try:
    from jinja2 import Template
except ImportError:
    Template = None


def parse_junit_xml(xml_path: str) -> list:
    """解析 JUnit XML，返回用例结果列表"""
    tree = ElementTree.parse(xml_path)
    root = tree.getroot()
    results = []

    for suite in root.iter("testsuite"):
        for case in suite.iter("testcase"):
            result = {
                "classname": case.get("classname", ""),
                "name": case.get("name", ""),
                "time": float(case.get("time", 0)),
                "status": "passed",
                "message": "",
            }
            failure = case.find("failure")
            error = case.find("error")
            skipped = case.find("skipped")

            if failure is not None:
                result["status"] = "failed"
                result["message"] = failure.get("message", "")
            elif error is not None:
                result["status"] = "error"
                result["message"] = error.get("message", "")
            elif skipped is not None:
                result["status"] = "skipped"
                result["message"] = skipped.get("message", "")

            results.append(result)

    return results


def parse_json_report(json_path: str) -> dict:
    """解析 pytest-json-report 输出"""
    if not os.path.exists(json_path):
        return {}
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_registry(registry_path: str) -> dict:
    """加载用例注册表，返回 case_id -> 元信息 映射"""
    import csv
    registry = {}
    if not os.path.exists(registry_path):
        return registry
    with open(registry_path, "r", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row.get("type") == "api-test":
                registry[row["case_id"]] = row
    return registry


def extract_case_id(test_name: str) -> str:
    """从测试方法名中提取 case_id（如 TC-API-AUTH-001）
    支持两种格式：
    - 原始格式: TC-API-AUTH-001（docstring 或 parametrize ids）
    - 下划线格式: TC_API_AUTH_001（函数名中使用）
    统一返回短横线格式
    """
    import re
    # 先尝试原始短横线格式
    match = re.search(r"TC-API-[A-Z]+-\d{3}", test_name)
    if match:
        return match.group(0)
    # 再尝试下划线格式（函数名）
    match = re.search(r"TC_API_([A-Z]+)_(\d{3})", test_name)
    if match:
        return f"TC-API-{match.group(1)}-{match.group(2)}"
    return ""


def _generate_suggestion(case_info: dict, error_msg: str) -> str:
    """根据用例元信息和错误消息生成修复建议"""
    coverage_rule = case_info.get("coverage_rule", "")
    api_path = case_info.get("api_path", "")

    suggestions = {
        "positive-required-only": f"检查 {api_path} 的核心业务逻辑是否正常",
        "negative-missing-field": f"检查 {api_path} 的必填字段校验逻辑",
        "negative-format-error": f"检查 {api_path} 的输入格式校验",
        "negative-type-error": f"检查 {api_path} 的参数类型校验",
        "boundary-max-min": f"检查 {api_path} 的数值范围校验",
        "boundary-string-length": f"检查 {api_path} 的字符串长度校验",
        "boundary-null-zero-empty": f"检查 {api_path} 的空值兼容处理",
        "security-auth-control": f"检查 {api_path} 的鉴权和权限控制逻辑",
        "security-sql-injection": f"检查 {api_path} 的参数过滤和 SQL 注入防护",
        "security-xss": f"检查 {api_path} 的 XSS 输入过滤",
        "security-json-injection": f"检查 {api_path} 的 JSON 解析防护",
    }

    if coverage_rule in suggestions:
        return suggestions[coverage_rule]

    # 从错误消息推断
    error_lower = error_msg.lower()
    if "status" in error_lower and ("expected" in error_lower or "assert" in error_lower):
        return f"后端返回了非预期的 HTTP 状态码，检查 {api_path} 的响应逻辑"
    if "timeout" in error_lower:
        return f"{api_path} 响应超时，检查后端性能或超时配置"

    return f"检查 {api_path} 的相关实现" if api_path else "检查对应接口实现"


def build_report(results: list, registry: dict, meta: dict, json_report: dict = None) -> dict:
    """构建 ai-report.json 数据
    Args:
        results: JUnit XML 解析结果
        registry: 用例注册表
        meta: 执行元信息
        json_report: pytest-json-report 输出（可选，提供更精确的时间和环境数据）
    """
    total = len(results)
    passed = sum(1 for r in results if r["status"] == "passed")
    failed = sum(1 for r in results if r["status"] == "failed")
    errors = sum(1 for r in results if r["status"] == "error")
    skipped = sum(1 for r in results if r["status"] == "skipped")

    # 优先使用 json_report 的精确总耗时，回退到 JUnit XML 累加
    if json_report and "duration" in json_report:
        duration_ms = json_report["duration"] * 1000
    else:
        duration_ms = sum(r["time"] for r in results) * 1000

    # 如果 json_report 有 summary，用它的统计数据交叉校验
    if json_report and "summary" in json_report:
        jr_summary = json_report["summary"]
        # json_report 的 total/passed/failed 更权威
        total = jr_summary.get("total", total)
        passed = jr_summary.get("passed", passed)
        failed = jr_summary.get("failed", failed)
        errors = jr_summary.get("error", errors)
        skipped = jr_summary.get("skipped", 0) + jr_summary.get("deselected", 0)

    pass_rate = f"{(passed / total * 100):.1f}%" if total > 0 else "0%"

    # 按级别统计
    level_breakdown = {}
    for level in ["P0", "P1", "P2", "P3"]:
        level_results = [r for r in results if registry.get(extract_case_id(r["name"]), {}).get("level") == level]
        level_passed = sum(1 for r in level_results if r["status"] == "passed")
        level_total = len(level_results)
        level_breakdown[level] = {
            "total": level_total,
            "passed": level_passed,
            "rate": f"{(level_passed / level_total * 100):.1f}%" if level_total > 0 else "N/A",
        }

    # 按覆盖类型统计
    coverage_breakdown = {}
    for ctype in ["positive", "negative", "boundary", "security"]:
        ct_results = [r for r in results if registry.get(extract_case_id(r["name"]), {}).get("coverage_type") == ctype]
        ct_passed = sum(1 for r in ct_results if r["status"] == "passed")
        ct_total = len(ct_results)
        coverage_breakdown[ctype] = {
            "total": ct_total,
            "passed": ct_passed,
            "rate": f"{(ct_passed / ct_total * 100):.1f}%" if ct_total > 0 else "N/A",
        }

    # 按模块统计
    api_breakdown = {}
    for r in results:
        case_id = extract_case_id(r["name"])
        module = registry.get(case_id, {}).get("module", "unknown")
        if module not in api_breakdown:
            api_breakdown[module] = {"total": 0, "passed": 0, "apis": {}}
        api_breakdown[module]["total"] += 1
        if r["status"] == "passed":
            api_breakdown[module]["passed"] += 1
        # 按 api_path 细分统计
        api_path = registry.get(case_id, {}).get("api_path", "")
        if api_path:
            if api_path not in api_breakdown[module]["apis"]:
                api_breakdown[module]["apis"][api_path] = {"total": 0, "passed": 0}
            api_breakdown[module]["apis"][api_path]["total"] += 1
            if r["status"] == "passed":
                api_breakdown[module]["apis"][api_path]["passed"] += 1
    for mod in api_breakdown:
        t = api_breakdown[mod]["total"]
        p = api_breakdown[mod]["passed"]
        api_breakdown[mod]["rate"] = f"{(p / t * 100):.1f}%" if t > 0 else "N/A"
        for api_path in api_breakdown[mod]["apis"]:
            at = api_breakdown[mod]["apis"][api_path]["total"]
            ap = api_breakdown[mod]["apis"][api_path]["passed"]
            api_breakdown[mod]["apis"][api_path]["rate"] = f"{(ap / at * 100):.1f}%" if at > 0 else "N/A"

    # 响应时间统计
    times = [r["time"] * 1000 for r in results if r["time"] > 0]
    times_sorted = sorted(times)
    response_time_stats = {
        "avg_ms": round(statistics.mean(times), 1) if times else 0,
        "p50_ms": round(times_sorted[len(times_sorted) // 2], 1) if times else 0,
        "p95_ms": round(times_sorted[int(len(times_sorted) * 0.95)], 1) if times else 0,
        "p99_ms": round(times_sorted[int(len(times_sorted) * 0.99)], 1) if times else 0,
        "slowest": None,
    }
    if times:
        slowest_idx = times.index(max(times))
        slowest_r = results[slowest_idx]
        slowest_case_id = extract_case_id(slowest_r["name"])
        slowest_info = registry.get(slowest_case_id, {})
        response_time_stats["slowest"] = {
            "case_id": slowest_case_id,
            "api_path": slowest_info.get("api_path", ""),
            "time_ms": round(max(times), 1),
        }

    # 冒烟结果
    smoke_results = [r for r in results if registry.get(extract_case_id(r["name"]), {}).get("smoke") == "true"]
    smoke_passed = sum(1 for r in smoke_results if r["status"] == "passed")
    smoke_total = len(smoke_results)

    # 失败用例
    failed_cases = []
    for r in results:
        if r["status"] in ("failed", "error"):
            case_id = extract_case_id(r["name"])
            info = registry.get(case_id, {})
            error_msg = r["message"][:500]
            failed_cases.append({
                "case_id": case_id,
                "case_name": info.get("case_name", r["name"]),
                "level": info.get("level", ""),
                "coverage_type": info.get("coverage_type", ""),
                "api_path": info.get("api_path", ""),
                "error": error_msg,
                "suggestion": _generate_suggestion(info, error_msg),
            })

    # 安全发现
    security_findings = []
    for r in results:
        case_id = extract_case_id(r["name"])
        info = registry.get(case_id, {})
        if info.get("coverage_type") == "security" and r["status"] in ("failed", "error"):
            security_findings.append({
                "case_id": case_id,
                "coverage_rule": info.get("coverage_rule", ""),
                "api_path": info.get("api_path", ""),
                "finding": r["message"][:300],
                "severity": "high" if info.get("level") in ("P0", "P1") else "medium",
                "suggestion": _generate_suggestion(info, r["message"][:300]),
            })

    # 结果判定
    p0_failed = level_breakdown["P0"]["total"] - level_breakdown["P0"]["passed"]
    pass_rate_num = (passed / total * 100) if total > 0 else 0
    if p0_failed > 0 or pass_rate_num < 90:
        result_verdict = "fail"
    elif security_findings:
        result_verdict = "warn"
    else:
        result_verdict = "pass"

    return {
        "run_id": meta.get("run_id", ""),
        "timestamp": meta.get("timestamp", datetime.now().isoformat()),
        "result": result_verdict,
        "environment": meta.get("environment", "dev"),
        "summary": {
            "total": total,
            "passed": passed,
            "failed": failed,
            "error": errors,
            "skipped": skipped,
            "pass_rate": pass_rate,
            "duration_ms": round(duration_ms),
        },
        "smoke_result": {
            "total": smoke_total,
            "passed": smoke_passed,
            "pass_rate": f"{(smoke_passed / smoke_total * 100):.1f}%" if smoke_total > 0 else "N/A",
        },
        "level_breakdown": level_breakdown,
        "coverage_breakdown": coverage_breakdown,
        "api_breakdown": api_breakdown,
        "response_time_stats": response_time_stats,
        "failed_cases": failed_cases,
        "security_findings": security_findings,
        "artifacts": {},
    }


def render_html(report: dict, template_path: str = None) -> str:
    """使用 Jinja2 渲染 HTML 报告"""
    if Template is None:
        return _render_html_fallback(report)

    # 优先使用指定模板，其次查找默认模板位置
    candidates = []
    if template_path:
        candidates.append(template_path)
    candidates.extend([
        os.path.join(os.path.dirname(__file__), "..", "template", "report.html.template"),
        os.path.join(os.path.dirname(__file__), "report.html.template"),
    ])

    for path in candidates:
        resolved = os.path.realpath(path)
        if os.path.exists(resolved):
            with open(resolved, "r", encoding="utf-8") as f:
                tmpl = Template(f.read())
            return tmpl.render(report=report)

    return _render_html_fallback(report)


def _render_html_fallback(report: dict) -> str:
    """无 Jinja2 时的简易 HTML 生成"""
    s = report["summary"]
    result_color = {"pass": "#22c55e", "fail": "#ef4444", "warn": "#f59e0b"}.get(report["result"], "#6b7280")

    failed_rows = ""
    for fc in report.get("failed_cases", []):
        failed_rows += f"""<tr>
            <td>{fc['case_id']}</td><td>{fc['case_name']}</td>
            <td>{fc['level']}</td><td>{fc['coverage_type']}</td>
            <td style="color:#ef4444">{fc['error'][:200]}</td>
        </tr>"""

    security_rows = ""
    for sf in report.get("security_findings", []):
        sev_color = "#ef4444" if sf["severity"] == "high" else "#f59e0b"
        security_rows += f"""<tr>
            <td>{sf['case_id']}</td><td>{sf['coverage_rule']}</td>
            <td>{sf['api_path']}</td>
            <td style="color:{sev_color}">{sf['severity']}</td>
            <td>{sf['finding'][:200]}</td>
        </tr>"""

    level_rows = ""
    for lv, data in report.get("level_breakdown", {}).items():
        level_rows += f"<tr><td>{lv}</td><td>{data['total']}</td><td>{data['passed']}</td><td>{data['rate']}</td></tr>"

    coverage_rows = ""
    for ct, data in report.get("coverage_breakdown", {}).items():
        coverage_rows += f"<tr><td>{ct}</td><td>{data['total']}</td><td>{data['passed']}</td><td>{data['rate']}</td></tr>"

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>API 测试报告 - {report['run_id']}</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; margin: 20px; background: #f8fafc; color: #1e293b; }}
.header {{ background: #1e293b; color: white; padding: 20px 30px; border-radius: 8px; margin-bottom: 20px; }}
.header h1 {{ margin: 0 0 8px 0; font-size: 22px; }}
.header .meta {{ font-size: 13px; opacity: 0.8; }}
.result-badge {{ display: inline-block; padding: 4px 16px; border-radius: 20px; font-weight: 600; font-size: 14px; background: {result_color}; color: white; }}
.cards {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; margin-bottom: 20px; }}
.card {{ background: white; padding: 16px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); text-align: center; }}
.card .value {{ font-size: 28px; font-weight: 700; color: #1e293b; }}
.card .label {{ font-size: 12px; color: #64748b; margin-top: 4px; }}
table {{ width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; }}
th {{ background: #f1f5f9; padding: 10px 12px; text-align: left; font-size: 13px; color: #475569; }}
td {{ padding: 10px 12px; border-top: 1px solid #e2e8f0; font-size: 13px; }}
h2 {{ font-size: 16px; color: #334155; margin: 20px 0 10px; }}
</style>
</head>
<body>
<div class="header">
    <h1>API 测试报告 <span class="result-badge">{report['result'].upper()}</span></h1>
    <div class="meta">Run ID: {report['run_id']} | 环境: {report['environment']} | 时间: {report['timestamp']}</div>
</div>
<div class="cards">
    <div class="card"><div class="value">{s['total']}</div><div class="label">总用例数</div></div>
    <div class="card"><div class="value" style="color:#22c55e">{s['passed']}</div><div class="label">通过</div></div>
    <div class="card"><div class="value" style="color:#ef4444">{s['failed']}</div><div class="label">失败</div></div>
    <div class="card"><div class="value">{s['pass_rate']}</div><div class="label">通过率</div></div>
    <div class="card"><div class="value">{s['duration_ms']}ms</div><div class="label">总耗时</div></div>
</div>
<h2>按级别统计</h2>
<table><tr><th>级别</th><th>总数</th><th>通过</th><th>通过率</th></tr>{level_rows}</table>
<h2>按覆盖类型统计</h2>
<table><tr><th>类型</th><th>总数</th><th>通过</th><th>通过率</th></tr>{coverage_rows}</table>
{"<h2>失败用例</h2><table><tr><th>Case ID</th><th>名称</th><th>级别</th><th>类型</th><th>错误</th></tr>" + failed_rows + "</table>" if failed_rows else ""}
{"<h2>安全发现</h2><table><tr><th>Case ID</th><th>规则</th><th>API</th><th>严重度</th><th>发现</th></tr>" + security_rows + "</table>" if security_rows else ""}
<div style="text-align:center;color:#94a3b8;font-size:12px;margin-top:30px;">Generated by api-test-report-builder</div>
</body>
</html>"""


def main():
    parser = argparse.ArgumentParser(description="API 测试报告生成器")
    parser.add_argument("--run-dir", type=str, help="执行结果目录")
    parser.add_argument("--latest", action="store_true", help="使用 latest 软链接")
    parser.add_argument("--registry", type=str, default=None, help="用例注册表路径（默认从 api-test.config.yaml 读取）")
    parser.add_argument("--html-template", type=str, help="HTML 模板路径")
    parser.add_argument("--config", type=str, help="api-test.config.yaml 路径")

    args = parser.parse_args()

    # 从配置文件读取 registry 路径（如果未通过 --registry 显式指定）
    registry_path = args.registry
    if registry_path is None:
        config_candidates = [
            os.path.join(os.getcwd(), "tests", "api-test", "api-test.config.yaml"),
        ]
        if args.config:
            config_candidates.insert(0, args.config)
        for cp in config_candidates:
            if os.path.exists(cp):
                try:
                    with open(cp, "r", encoding="utf-8") as f:
                        cfg = yaml.safe_load(f) or {}
                    registry_path = cfg.get("output", {}).get("registry_file")
                except Exception:
                    pass
                break
        if not registry_path:
            registry_path = "tests/api-test/testcase-registry.csv"

    if args.latest:
        run_dir = os.path.join(".tests", "api-reports", "latest")
    elif args.run_dir:
        run_dir = args.run_dir
    else:
        print("[ERROR] 请指定 --run-dir 或 --latest")
        sys.exit(1)

    run_dir = os.path.realpath(run_dir)
    if not os.path.isdir(run_dir):
        print(f"[ERROR] 目录不存在: {run_dir}")
        sys.exit(1)

    # 解析执行结果
    junit_path = os.path.join(run_dir, "junit.xml")
    json_path = os.path.join(run_dir, "result.json")
    meta_path = os.path.join(run_dir, "meta.json")

    if not os.path.exists(junit_path):
        print(f"[ERROR] JUnit XML 不存在: {junit_path}")
        sys.exit(1)

    results = parse_junit_xml(junit_path)
    json_report = parse_json_report(json_path)
    registry = load_registry(registry_path)
    meta = {}
    if os.path.exists(meta_path):
        with open(meta_path, "r", encoding="utf-8") as f:
            meta = json.load(f)

    # 构建报告
    report = build_report(results, registry, meta, json_report=json_report)
    report["artifacts"] = {
        "html_report": os.path.join(run_dir, "report.html"),
        "ai_report": os.path.join(run_dir, "ai-report.json"),
        "junit_xml": junit_path,
    }

    # 写入 ai-report.json
    ai_report_path = os.path.join(run_dir, "ai-report.json")
    with open(ai_report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(f"[INFO] AI report: {ai_report_path}")

    # 渲染 HTML
    html_content = render_html(report, args.html_template)
    html_path = os.path.join(run_dir, "report.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html_content)
    print(f"[INFO] HTML report: {html_path}")

    print(f"[INFO] Result: {report['result'].upper()}")
    print(f"[INFO] Pass rate: {report['summary']['pass_rate']}")


if __name__ == "__main__":
    main()
