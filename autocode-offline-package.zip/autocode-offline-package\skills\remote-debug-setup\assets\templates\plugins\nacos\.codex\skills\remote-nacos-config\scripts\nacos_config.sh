#!/usr/bin/env bash
set -euo pipefail

SERVER_NAME=""
CONFIG_PATH=".secrets/dev-servers.yaml"
ACTION=""
CONFIRM="false"
DATA_ID=""
GROUP_NAME="DEFAULT_GROUP"
NAMESPACE_ID="public"
CONTENT=""
CONTENT_FILE=""
CONFIG_TYPE="text"
SEARCH_MODE="blur"
PAGE_NO="1"
PAGE_SIZE="10"
INSECURE_TLS="false"
DRY_RUN="false"

usage() {
  cat <<'USAGE'
用法:
  nacos_config.sh --server <name> --action <get|list|put|delete>
                 [--config <path>]
                 [--data-id <id>] [--group <group>] [--namespace <ns>]
                 [--type <text|properties|json|yaml|xml>]
                 [--content <text> | --content-file <path>]
                 [--search <blur|accurate>] [--page-no <n>] [--page-size <n>]
                 [--insecure-tls] [--confirm] [--dry-run]

说明:
  - 该脚本为“通用尽力而为”实现：支持 nacos api_version=v1/v3 两类常见接口。
  - 若你的 Nacos 接口路径有差异，请在 .secrets 中补齐自定义字段（login_path/config_api_base）。
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --server) SERVER_NAME="$2"; shift 2 ;;
    --config) CONFIG_PATH="$2"; shift 2 ;;
    --action) ACTION="$2"; shift 2 ;;
    --data-id) DATA_ID="$2"; shift 2 ;;
    --group) GROUP_NAME="$2"; shift 2 ;;
    --namespace) NAMESPACE_ID="$2"; shift 2 ;;
    --type) CONFIG_TYPE="$2"; shift 2 ;;
    --content) CONTENT="$2"; shift 2 ;;
    --content-file) CONTENT_FILE="$2"; shift 2 ;;
    --search) SEARCH_MODE="$2"; shift 2 ;;
    --page-no) PAGE_NO="$2"; shift 2 ;;
    --page-size) PAGE_SIZE="$2"; shift 2 ;;
    --insecure-tls) INSECURE_TLS="true"; shift ;;
    --confirm) CONFIRM="true"; shift ;;
    --dry-run) DRY_RUN="true"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "[ERROR] 未知参数: $1"; usage; exit 1 ;;
  esac
done

if [[ -z "$SERVER_NAME" || -z "$ACTION" ]]; then
  echo "[ERROR] --server 与 --action 必填"; usage; exit 1
fi
if [[ ! -f "$CONFIG_PATH" ]]; then
  echo "[ERROR] 配置文件不存在: $CONFIG_PATH"; exit 1
fi
if [[ "$ACTION" != "get" && "$ACTION" != "list" && "$ACTION" != "put" && "$ACTION" != "delete" ]]; then
  echo "[ERROR] --action 仅支持 get|list|put|delete"; exit 1
fi
if [[ "$ACTION" != "list" && -z "$DATA_ID" ]]; then
  echo "[ERROR] action=$ACTION 时 --data-id 必填"; exit 1
fi
if [[ "$ACTION" == "put" ]]; then
  if [[ -n "$CONTENT" && -n "$CONTENT_FILE" ]]; then
    echo "[ERROR] --content 与 --content-file 只能二选一"; exit 1
  fi
  if [[ -z "$CONTENT" && -z "$CONTENT_FILE" ]]; then
    echo "[ERROR] action=put 时必须提供 content"; exit 1
  fi
  if [[ -n "$CONTENT_FILE" && ! -f "$CONTENT_FILE" ]]; then
    echo "[ERROR] content 文件不存在: $CONTENT_FILE"; exit 1
  fi
fi
if [[ "$ACTION" == "put" || "$ACTION" == "delete" ]]; then
  if [[ "$CONFIRM" != "true" ]]; then
    echo "[ERROR] action=$ACTION 属于写/破坏性操作，必须显式加 --confirm"; exit 2
  fi
fi

for cmd in python3 curl; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "[ERROR] 缺少命令: $cmd"; exit 1; }
done

python3 - "$CONFIG_PATH" "$SERVER_NAME" "$ACTION" "$DATA_ID" "$GROUP_NAME" "$NAMESPACE_ID" "$CONFIG_TYPE" "$CONTENT" "$CONTENT_FILE" "$SEARCH_MODE" "$PAGE_NO" "$PAGE_SIZE" "$INSECURE_TLS" "$DRY_RUN" <<'PY'
import json
import os
import shlex
import subprocess
import sys
from typing import Any, Dict, Tuple
from urllib.parse import urlencode
import socket
import time
import signal
import shutil

(
  config_path, server_name, action, data_id, group_name, namespace_id, config_type,
  content, content_file, search_mode, page_no, page_size, insecure_tls, dry_run,
) = sys.argv[1:]

insecure_tls = insecure_tls.lower() == 'true'
dry_run = dry_run.lower() == 'true'

cfg = json.loads(open(config_path,'r',encoding='utf-8').read())
server = next((s for s in cfg.get('servers',[]) if isinstance(s,dict) and s.get('name')==server_name), None)
if not server:
    print(f"[ERROR] 未找到服务器: {server_name}")
    sys.exit(1)

ssh = server.get('ssh') if isinstance(server.get('ssh'), dict) else {}
ssh_auth = ssh.get('auth') if isinstance(ssh.get('auth'), dict) else {}
ssh_host = str(ssh.get('host') or '')
ssh_port = int(ssh.get('port') or 22)
ssh_user = str(ssh.get('username') or '')
ssh_auth_type = str(ssh_auth.get('type') or 'password')
ssh_password = str(ssh_auth.get('password') or '')
ssh_identity = str(ssh_auth.get('identity_file') or '')
defaults = server.get('defaults') if isinstance(server.get('defaults'), dict) else {}
known_hosts_file = str(defaults.get('known_hosts_file') or '/tmp/remote-dev-deploy-known-hosts')
strict = 'yes' if bool(defaults.get('strict_host_key_check') or False) else 'no'

comp = server.get('components') if isinstance(server.get('components'), dict) else {}
nacos = comp.get('nacos') if isinstance(comp.get('nacos'), dict) else None
if not nacos:
    # 兼容历史字段：servers[].nacos（不推荐）
    nacos = server.get('nacos') if isinstance(server.get('nacos'), dict) else None
    if nacos:
        print('[WARN] 检测到已废弃字段 servers[].nacos，请迁移到 servers[].components.nacos')
if not nacos:
    print('[ERROR] 未配置 nacos 节点：请使用 servers[].components.nacos')
    sys.exit(2)

protocol = str(nacos.get('protocol') or 'http')
host = str(nacos.get('host') or (server.get('ssh') or {}).get('host') or server.get('host') or '')
port = int(nacos.get('port') or nacos.get('server_port') or 8848)
username = str(nacos.get('username') or 'nacos')
password_plain = str(nacos.get('password_plain') or '')
api_version = str(nacos.get('api_version') or '')
access = nacos.get('access') if isinstance(nacos.get('access'), dict) else {}
access_mode = str(access.get('mode') or 'direct')
if access_mode == 'ssh' and not str(nacos.get('host') or '').strip():
    host = '127.0.0.1'

def defaults_for(ver: str) -> tuple[str,str]:
    if ver == 'v3':
        return ('/v3/auth/user/login', '/v3/console/cs')
    return ('/nacos/v1/auth/login', '/nacos/v1/cs/configs')

if api_version not in {'v1','v3'}:
    api_version = ''

login_path = str(nacos.get('login_path') or (defaults_for(api_version or 'v1')[0]))
config_api_base = str(nacos.get('config_api_base') or (defaults_for(api_version or 'v1')[1]))

if not password_plain:
    print('[ERROR] nacos.password_plain 为空（通用脚本不支持自动解密，请先填明文）')
    sys.exit(3)

tunnel_proc = None

def pick_free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('127.0.0.1', 0))
    p = int(s.getsockname()[1])
    s.close()
    return p

def wait_listen(p: int, timeout_s: float = 4.0) -> bool:
    end = time.time() + timeout_s
    while time.time() < end:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.3)
            s.connect(('127.0.0.1', p))
            s.close()
            return True
        except Exception:
            try:
                s.close()
            except Exception:
                pass
            time.sleep(0.1)
    return False

def start_ssh_tunnel(target_host: str, target_port: int) -> Tuple[subprocess.Popen, int]:
    if not ssh_host or not ssh_user:
        raise RuntimeError('servers[].ssh.host/username 为空，无法建立 ssh tunnel')
    lp = pick_free_port()
    ssh_cmd = [
        'ssh',
        '-p', str(ssh_port),
        '-o', f'StrictHostKeyChecking={strict}',
        '-o', f'UserKnownHostsFile={known_hosts_file}',
        '-o', 'ConnectTimeout=8',
        '-o', 'ExitOnForwardFailure=yes',
        '-o', 'ServerAliveInterval=5',
        '-o', 'ServerAliveCountMax=3',
        '-N',
        '-L', f'127.0.0.1:{lp}:{target_host}:{int(target_port)}',
    ]
    if ssh_auth_type == 'key' and ssh_identity:
        ssh_cmd += ['-i', ssh_identity, '-o', 'BatchMode=yes']
    ssh_cmd.append(f'{ssh_user}@{ssh_host}')
    if ssh_auth_type == 'password':
        if not ssh_password:
            raise RuntimeError('ssh.auth.password 为空，无法建立 tunnel')
        if shutil.which('sshpass') is None:
            raise RuntimeError('缺少 sshpass（password 认证需要）')
        ssh_cmd = ['sshpass', '-p', ssh_password] + ssh_cmd
    proc = subprocess.Popen(
        ssh_cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        preexec_fn=os.setsid if hasattr(os, 'setsid') else None,
    )
    if not wait_listen(lp, timeout_s=4.0):
        err = ''
        try:
            err = (proc.stderr.read(2000) if proc.stderr else '')  # type: ignore[union-attr]
        except Exception:
            err = ''
        try:
            if hasattr(os, 'killpg'):
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
            else:
                proc.terminate()
        except Exception:
            pass
        raise RuntimeError(f'ssh tunnel 建立失败: {err.strip()}')
    return proc, lp

base = f"{protocol}://{host}:{port}"
if not dry_run and access_mode == 'ssh':
    try:
        tunnel_proc, local_port = start_ssh_tunnel(host or '127.0.0.1', port)
        base = f"{protocol}://127.0.0.1:{local_port}"
    except Exception as exc:
        print(f"[ERROR] {exc}")
        sys.exit(8)

curl_tls = []
if insecure_tls and protocol == 'https':
    curl_tls = ['-k']

def curl(args: list[str]) -> Tuple[int, str]:
    proc = subprocess.run(['curl', *curl_tls, '-sS', '-m', '15', *args], text=True, capture_output=True)
    out = (proc.stdout or '') + (proc.stderr or '')
    return proc.returncode, out

def build_url(path: str, params: Dict[str, str]) -> str:
    q = urlencode({k: str(v) for k, v in params.items()}, doseq=True)
    if q:
        return base + path + ("&" if "?" in path else "?") + q
    return base + path

def login_v1() -> str:
    code, out = curl(['-X','POST', base + login_path, '-H','Content-Type: application/x-www-form-urlencoded', '--data-urlencode', f'username={username}', '--data-urlencode', f'password={password_plain}'])
    if code != 0:
        raise RuntimeError(out)
    obj = json.loads(out)
    token = obj.get('accessToken') or obj.get('access_token') or ''
    return str(token)

def login_v3() -> str:
    code, out = curl(['-X','POST', base + login_path, '-H','Content-Type: application/x-www-form-urlencoded', '--data-urlencode', f'username={username}', '--data-urlencode', f'password={password_plain}'])
    if code != 0:
        raise RuntimeError(out)
    obj = json.loads(out)
    token = ''
    if isinstance(obj.get('data'), dict):
        token = obj['data'].get('accessToken','')
    token = token or obj.get('accessToken','')
    return str(token)

try:
    if dry_run:
        print(f"[PLAN] base={base} access_mode={access_mode} api_version={api_version} action={action}")
        print('[RESULT] DRY_RUN_SUCCESS')
        sys.exit(0)

token = ''
login_err = ''
if api_version in {'v1','v3'}:
    try:
        token = login_v1() if api_version == 'v1' else login_v3()
    except Exception as exc:
        login_err = str(exc)
else:
    # 未指定版本：先尝试 v3，再尝试 v1（尽力而为）
    try:
        login_path, config_api_base = defaults_for('v3')
        token = login_v3()
        api_version = 'v3'
    except Exception as exc:
        login_err = str(exc)
        try:
            login_path, config_api_base = defaults_for('v1')
            token = login_v1()
            api_version = 'v1'
        except Exception as exc2:
            login_err = login_err + ' | ' + str(exc2)

if not token:
    print(f"[ERROR] 登录失败（请确认 api_version(v1/v3)、login_path、账号口令与端口）：{login_err}")
    sys.exit(4)

if not token:
    print('[ERROR] 登录成功但未返回 token')
    sys.exit(5)

if api_version == 'v1':
    # v1 常见：token 作为 query 参数 accessToken
    if action == 'get':
        url = build_url(
            config_api_base,
            {"dataId": data_id, "group": group_name, "tenant": namespace_id, "accessToken": token},
        )
        code, out = curl([url])
        print(out)
        print('[RESULT] GET_SUCCESS')
        sys.exit(0)
    if action == 'list':
        url = build_url(
            config_api_base,
            {"search": search_mode, "pageNo": page_no, "pageSize": page_size, "tenant": namespace_id, "accessToken": token},
        )
        code, out = curl([url])
        print(out)
        print('[RESULT] LIST_SUCCESS')
        sys.exit(0)
    if action == 'put':
        if content_file:
            content = open(content_file,'r',encoding='utf-8').read()
        code, out = curl([
            '-X','POST', base + config_api_base,
            '-H','Content-Type: application/x-www-form-urlencoded',
            '--data-urlencode', f"dataId={data_id}",
            '--data-urlencode', f"group={group_name}",
            '--data-urlencode', f"tenant={namespace_id}",
            '--data-urlencode', f"type={config_type}",
            '--data-urlencode', f"content={content}",
            '--data-urlencode', f"accessToken={token}",
        ])
        print(out)
        print('[RESULT] PUT_SUCCESS')
        sys.exit(0)
    if action == 'delete':
        url = build_url(
            config_api_base,
            {"dataId": data_id, "group": group_name, "tenant": namespace_id, "accessToken": token},
        )
        code, out = curl(['-X', 'DELETE', url])
        print(out)
        print('[RESULT] DELETE_SUCCESS')
        sys.exit(0)

# v3：尽力而为，默认 bearer token
auth_header = f"Authorization: Bearer {token}"
if action == 'get':
    url = build_url(
        config_api_base + "/config",
        {"dataId": data_id, "groupName": group_name, "namespaceId": namespace_id},
    )
    code, out = curl(['-H', auth_header, url])
    print(out)
    print('[RESULT] GET_SUCCESS')
    sys.exit(0)
if action == 'list':
    url = build_url(
        config_api_base + "/config/list",
        {"pageNo": page_no, "pageSize": page_size, "namespaceId": namespace_id, "search": search_mode},
    )
    code, out = curl(['-H', auth_header, url])
    print(out)
    print('[RESULT] LIST_SUCCESS')
    sys.exit(0)
if action == 'put':
    if content_file:
        content = open(content_file,'r',encoding='utf-8').read()
    code, out = curl([
        '-X','POST', base + config_api_base + '/config',
        '-H', auth_header,
        '-H', 'Content-Type: application/x-www-form-urlencoded',
        '--data-urlencode', f"dataId={data_id}",
        '--data-urlencode', f"groupName={group_name}",
        '--data-urlencode', f"namespaceId={namespace_id}",
        '--data-urlencode', f"type={config_type}",
        '--data-urlencode', f"content={content}",
    ])
    print(out)
    print('[RESULT] PUT_SUCCESS')
    sys.exit(0)
if action == 'delete':
    url = build_url(
        config_api_base + "/config",
        {"dataId": data_id, "groupName": group_name, "namespaceId": namespace_id},
    )
    code, out = curl(['-X', 'DELETE', url, '-H', auth_header])
    print(out)
    print('[RESULT] DELETE_SUCCESS')
    sys.exit(0)

print('[ERROR] 未处理 action')
sys.exit(9)
finally:
    if tunnel_proc is not None:
        try:
            if hasattr(os, 'killpg'):
                os.killpg(os.getpgid(tunnel_proc.pid), signal.SIGTERM)
            else:
                tunnel_proc.terminate()
            tunnel_proc.wait(timeout=2)
        except Exception:
            pass
PY
