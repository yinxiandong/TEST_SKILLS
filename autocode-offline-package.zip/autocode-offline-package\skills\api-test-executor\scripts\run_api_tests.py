#!/usr/bin/env python3
"""
API 测试执行器
文件路径: tests/api-test/scripts/run_api_tests.py（或由 api-test-executor 技能直接调用）

用法:
    python run_api_tests.py --smoke                          # 冒烟测试
    python run_api_tests.py --level P0                       # 按级别
    python run_api_tests.py --module auth                    # 按模块
    python run_api_tests.py --coverage-type security         # 按覆盖类型
    python run_api_tests.py --all                            # 全量回归
    python run_api_tests.py --level P0 --coverage-type positive  # 组合筛选
"""

import argparse
import os
import sys
import subprocess
import json
from datetime import datetime
from pathlib import Path

import yaml


def load_config(config_path: str = None) -> dict:
    """加载 api-test.config.yaml"""
    if config_path is None:
        candidates = [
            Path.cwd() / "tests" / "api-test" / "api-test.config.yaml",
            Path(__file__).resolve().parent.parent / "api-test.config.yaml",
        ]
        for p in candidates:
            if p.exists():
                config_path = str(p)
                break
    if config_path is None or not Path(config_path).exists():
        print("[WARN] api-test.config.yaml not found, using defaults")
        return {}
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _list_available_modules(script_dir: str) -> str:
    """列出 script_dir 下的可用模块目录"""
    if not os.path.isdir(script_dir):
        return "(script directory not found)"
    modules = [d for d in os.listdir(script_dir)
               if os.path.isdir(os.path.join(script_dir, d)) and not d.startswith(("_", "."))]
    return ", ".join(sorted(modules)) if modules else "(none)"


def build_pytest_args(args, config: dict) -> list:
    """根据参数构建 pytest 命令行"""
    pytest_args = ["pytest"]
    exec_config = config.get("execution", {})
    output_config = config.get("output", {})

    script_dir = output_config.get("script_dir", "tests/api-test/scripts")

    # 标记筛选
    marks = []
    if args.smoke:
        marks.append("smoke")
    if args.level:
        levels = [l.strip() for l in args.level.split(",")]
        marks.append(" or ".join(levels))
    if args.coverage_type:
        marks.append(args.coverage_type)

    if marks:
        mark_expr = " and ".join(f"({m})" for m in marks)
        pytest_args.extend(["-m", mark_expr])

    # 模块筛选
    if args.module:
        modules = [m.strip() for m in args.module.split(",")]
        valid_paths = []
        invalid_modules = []
        for mod in modules:
            mod_path = os.path.join(script_dir, mod)
            if os.path.isdir(mod_path):
                valid_paths.append(mod_path)
            else:
                invalid_modules.append(mod)
        if invalid_modules:
            print(f"[WARN] Module directories not found: {', '.join(invalid_modules)}")
            print(f"[INFO] Available modules: {_list_available_modules(script_dir)}")
        if not valid_paths:
            print(f"[ERROR] No valid module directories found. Aborting.")
            sys.exit(1)
        pytest_args.extend(valid_paths)
    elif not args.smoke and not args.level and not args.coverage_type:
        if not os.path.isdir(script_dir):
            print(f"[ERROR] Script directory not found: {script_dir}")
            sys.exit(1)
        pytest_args.append(script_dir)

    # 报告输出
    run_id = f"run-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    report_dir = args.output_dir or exec_config.get("report_dir", ".tests/api-reports")
    run_dir = os.path.join(report_dir, run_id)
    os.makedirs(run_dir, exist_ok=True)
    os.makedirs(os.path.join(run_dir, "logs"), exist_ok=True)

    pytest_args.extend([
        f"--junitxml={os.path.join(run_dir, 'junit.xml')}",
        f"--json-report",
        f"--json-report-file={os.path.join(run_dir, 'result.json')}",
        "-v",
        "--tb=short",
        "--strict-markers",
    ])

    # 并行执行
    parallel = args.parallel or exec_config.get("parallel_workers", 1)
    if parallel > 1:
        pytest_args.extend(["-n", str(parallel)])

    # 重试
    retry = args.retry if args.retry is not None else exec_config.get("retry_on_failure", 0)
    if retry > 0:
        pytest_args.extend(["--reruns", str(retry)])

    # 快速失败
    fail_fast = args.fail_fast if args.fail_fast else exec_config.get("fail_fast", False)
    if fail_fast:
        pytest_args.append("-x")

    # 环境变量
    if args.env:
        os.environ["API_TEST_ENV"] = args.env

    return pytest_args, run_id, run_dir


def update_latest_symlink(report_dir: str, run_id: str):
    """更新 latest 软链接"""
    latest = os.path.join(report_dir, "latest")
    if os.path.islink(latest):
        os.unlink(latest)
    elif os.path.exists(latest):
        os.remove(latest)
    os.symlink(run_id, latest)


def _check_dependencies(config: dict):
    """检查 pytest 插件依赖是否可用"""
    required = [("pytest", "pytest")]
    exec_config = config.get("execution", {})

    # json-report 始终需要
    required.append(("pytest_jsonreport", "pytest-json-report"))

    # 并行执行需要 xdist
    if exec_config.get("parallel_workers", 1) > 1:
        required.append(("xdist", "pytest-xdist"))

    # 重试需要 rerunfailures
    if exec_config.get("retry_on_failure", 0) > 0:
        required.append(("pytest_rerunfailures", "pytest-rerunfailures"))

    missing = []
    for module_name, pip_name in required:
        try:
            __import__(module_name)
        except ImportError:
            missing.append(pip_name)

    if missing:
        print(f"[ERROR] Missing pytest plugins: {', '.join(missing)}")
        print(f"[INFO] Install with: pip install {' '.join(missing)}")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="API 测试执行器")
    parser.add_argument("--smoke", action="store_true", help="仅执行冒烟用例")
    parser.add_argument("--level", type=str, help="按级别筛选（逗号分隔，如 P0,P1）")
    parser.add_argument("--module", type=str, help="按模块筛选（逗号分隔）")
    parser.add_argument("--coverage-type", type=str, help="按覆盖类型筛选")
    parser.add_argument("--all", action="store_true", help="全量回归")
    parser.add_argument("--env", type=str, help="指定环境")
    parser.add_argument("--parallel", type=int, help="并行进程数")
    parser.add_argument("--retry", type=int, help="失败重试次数")
    parser.add_argument("--fail-fast", action="store_true", help="遇到首个失败即停止")
    parser.add_argument("--output-dir", type=str, help="报告输出目录")
    parser.add_argument("--config", type=str, help="配置文件路径")

    args = parser.parse_args()
    config = load_config(args.config)

    # 合并命令行参数到 config 用于依赖检查
    check_config = dict(config)
    exec_cfg = dict(check_config.get("execution", {}))
    if args.parallel and args.parallel > 1:
        exec_cfg["parallel_workers"] = args.parallel
    if args.retry and args.retry > 0:
        exec_cfg["retry_on_failure"] = args.retry
    check_config["execution"] = exec_cfg
    _check_dependencies(check_config)

    pytest_args, run_id, run_dir = build_pytest_args(args, config)

    print(f"[INFO] Run ID: {run_id}")
    print(f"[INFO] Report dir: {run_dir}")
    print(f"[INFO] Command: {' '.join(pytest_args)}")

    result = subprocess.run(pytest_args, cwd=os.getcwd())

    report_dir = os.path.dirname(run_dir)
    update_latest_symlink(report_dir, run_id)

    # 写入执行元信息
    meta = {
        "run_id": run_id,
        "timestamp": datetime.now().isoformat(),
        "command": " ".join(pytest_args),
        "exit_code": result.returncode,
        "environment": args.env or config.get("default_environment", "dev"),
    }
    with open(os.path.join(run_dir, "meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    print(f"\n[INFO] Exit code: {result.returncode}")
    print(f"[INFO] Reports saved to: {run_dir}")

    sys.exit(result.returncode)


if __name__ == "__main__":
    main()
