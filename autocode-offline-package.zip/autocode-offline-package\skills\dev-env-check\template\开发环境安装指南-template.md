# 开发环境安装指南

> 本指南基于开发环境检查结果自动生成，提供缺失或版本不匹配依赖的详细安装方法。**以项目成功编译构建为环境就绪的最终判定标准**。

## 文档信息

- **生成时间**: `[指南生成时间]`
- **目标环境**: `[操作系统及版本，如: Ubuntu 22.04 LTS]`
- **项目路径**: `[项目根目录路径]`
- **待处理问题数**: `[问题总数]`
- **构建验证状态**: `[✅ 成功 / ❌ 失败 / ⏳ 待验证]`

## 构建验证结果

### 构建命令
```bash
[识别或人工确认的构建命令]
```

### 构建状态
- **状态**: `[✅ 成功 / ❌ 失败]`
- **退出码**: `[构建命令退出码]`
- **构建耗时**: `[构建耗时]`

### 构建日志摘要
```
[构建日志的关键输出，特别是错误信息]
```

---

## 反向背压分析

> 当构建失败时，此章节记录文档一致性检查和依赖差异分析结果

### 文档一致性检查

| 文档 | 检查项 | 文档声明 | 实际检测 | 状态 |
|------|--------|----------|----------|------|
| AGENTS.md | 技术栈 | `[文档声明]` | `[实际检测]` | `[✅/⚠️/❌]` |
| CLAUDE.md | 环境要求 | `[文档声明]` | `[实际检测]` | `[✅/⚠️/❌]` |
| pom.xml/package.json | 版本要求 | `[文档声明]` | `[实际检测]` | `[✅/⚠️/❌]` |

### 依赖差异分析

| 差异类型 | 依赖项 | 说明 | 处理方式 |
|----------|--------|------|----------|
| 文档声明但实际缺失 | `[依赖名]` | `[说明]` | 安装该依赖 |
| 实际需要但文档未声明 | `[依赖名]` | `[说明]` | 人工确认后更新文档 |
| 版本不一致 | `[依赖名]` | `[说明]` | 确认正确版本后更新 |

### 构建错误分析

| 错误特征 | 错误类型 | 可能原因 | 建议处理 |
|----------|----------|----------|----------|
| `[错误特征]` | `[错误类型]` | `[可能原因]` | `[建议处理]` |

---

## 人工确认记录

> 所有不确定的依赖必须人工确认，禁止猜测

| 确认时间 | 确认项 | 问题描述 | 用户选择 | 后续动作 |
|----------|--------|----------|----------|----------|
| `[时间]` | `[确认项]` | `[问题描述]` | `[用户选择]` | `[后续动作]` |

---

## 问题优先级

- 🔴 **P0 - 阻断级**: `[数量]` 项 - 必须立即处理，否则无法构建
- 🟠 **P1 - 紧急级**: `[数量]` 项 - 严重影响构建，应尽快处理
- 🟡 **P2 - 重要级**: `[数量]` 项 - 影响部分功能，建议近期处理
- 🟢 **P3 - 一般级**: `[数量]` 项 - 可选优化，提升开发体验

## 安装计划概览

| 依赖 | 当前状态 | 目标版本 | 优先级 | 推荐安装方式 |
|------|----------|----------|--------|--------------|
| `[依赖名称]` | `[❌缺失/⚠️版本低]` | `[目标版本]` | `[P0-P3]` | `[包管理器名称]` |

---

## 详细安装指南

### 🔴 P0 问题 - 立即处理

#### 问题 1: `[依赖名称]` 未安装

**问题描述**: `[详细描述，如: Docker 未安装，无法使用容器化开发环境]`

**影响范围**: `[对开发工作的具体影响]`

**安装方式**:

##### Linux (apt)
```bash
# 更新软件源
sudo apt update

# 安装依赖
sudo apt install [package-name]

# 验证安装
[validation-command]
# 预期输出: [expected-output]
```

##### Linux (yum/dnf)
```bash
# 安装依赖
sudo yum install [package-name]
# 或
sudo dnf install [package-name]

# 验证安装
[validation-command]
# 预期输出: [expected-output]
```

##### macOS (Homebrew)
```bash
# 安装依赖（Homebrew 需提前安装）
brew install [package-name]

# 验证安装
[validation-command]
# 预期输出: [expected-output]
```

##### Windows (Chocolatey)
```powershell
# 安装依赖（Chocolatey 需提前安装）
choco install [package-name]

# 验证安装
[validation-command]
# 预期输出: [expected-output]
```

**环境变量配置**（如需要）:
```bash
# Linux/macOS (添加到 ~/.bashrc 或 ~/.zshrc)
export [ENV_VAR_NAME]="[value]"
export PATH="$[ENV_VAR_NAME]/bin:$PATH"

# 使配置生效
source ~/.bashrc  # 或 source ~/.zshrc

# Windows - 在系统环境变量中设置
# 变量名: [ENV_VAR_NAME]
# 变量值: [value]
# Path 添加: %[ENV_VAR_NAME]%\bin
```

**常见问题**:
- **安装失败**: `[常见错误和解决方案]`
- **权限问题**: `[权限相关问题的处理]`
- **版本冲突**: `[版本冲突的解决方法]`

---

#### 问题 2: `[依赖名称]` 版本过低

**问题描述**: `[详细描述，如: Node.js 版本为 14.x，需要升级到 18.x LTS]`

**当前版本**: `[实际版本]`
**目标版本**: `[推荐版本]`
**版本差异影响**: `[说明版本差异的影响]`

**升级方式**:

##### 包管理器升级
```bash
# Linux (apt)
sudo apt update && sudo apt upgrade [package-name]

# Linux (yum/dnf)
sudo yum update [package-name]

# macOS (Homebrew)
brew upgrade [package-name]

# Windows (Chocolatey)
choco upgrade [package-name]

# 验证升级
[validation-command]
```

##### 版本管理工具升级（推荐）
```bash
# 示例: 使用 nvm 升级 Node.js
nvm install [version]
nvm use [version]
nvm alias default [version]

# 示例: 使用 sdkman 升级 Java
sdk install java [version]
sdk use java [version]

# 验证
[validation-command]
```

**升级注意事项**:
- ⚠️ `[注意事项，如: 升级可能影响现有项目兼容性]`
- ⚠️ `[其他需要注意的事项]`

---

### 🟠 P1 问题 - 尽快处理

#### 问题 3: `[依赖名称]` 配置不完整

**问题描述**: `[详细描述，如: JAVA_HOME 环境变量未配置]`

**影响范围**: `[具体影响]`

**配置步骤**:

1. **确定安装路径**
   ```bash
   # 查找安装路径
   which [command-name]
   # 或
   [specific-command-to-find-path]
   ```

2. **配置环境变量**

   **Linux/macOS**:
   ```bash
   # 编辑配置文件
   vim ~/.bashrc  # 或 ~/.zshrc

   # 添加以下内容
   export [ENV_VAR_NAME]="[path]"
   export PATH="$[ENV_VAR_NAME]/bin:$PATH"

   # 保存并生效
   source ~/.bashrc
   ```

   **Windows**:
   - 右键"此电脑" → "属性" → "高级系统设置" → "环境变量"
   - 新建系统变量: `[ENV_VAR_NAME]` = `[path]`
   - 在 Path 中添加: `%[ENV_VAR_NAME]%\bin`
   - 重启命令行工具

3. **验证配置**
   ```bash
   echo $[ENV_VAR_NAME]  # Linux/macOS
   echo %[ENV_VAR_NAME]%  # Windows

   # 验证命令可用
   [validation-command]
   ```

---

### 🟡 P2 问题 - 建议处理

#### 问题 4: `[依赖名称]` 建议安装

**问题描述**: `[详细描述]`

**安装收益**: `[安装后的好处]`

**是否必须**: `[可选/推荐]`

**安装方法**: 参考 P0/P1 问题的相应安装方式

---

### 🟢 P3 问题 - 可选优化

#### 建议 1: `[优化建议]`

**优化说明**: `[详细说明]`

**实施收益**: `[实施后的改进]`

**实施步骤**:
```bash
[具体步骤]
```

---

## 技术栈专项完整安装

### Java 开发环境

**依赖清单**:
- [ ] JDK `[版本]`
- [ ] Maven `[版本]` 或 Gradle `[版本]`
- [ ] JAVA_HOME 配置

**快速安装（推荐使用 SDKMAN）**:
```bash
# 安装 SDKMAN (Linux/macOS)
curl -s "https://get.sdkman.io" | bash
source "$HOME/.sdkman/bin/sdkman-init.sh"

# 安装 JDK 和 Maven
sdk install java [version]
sdk install maven

# 验证
java -version
mvn -version
```

**包管理器安装**:
```bash
# Ubuntu/Debian
sudo apt install openjdk-[version]-jdk maven

# macOS
brew install openjdk@[version] maven

# Windows
choco install openjdk[version] maven
```

**配置 JAVA_HOME**:
```bash
# Linux/macOS
export JAVA_HOME=$(/usr/libexec/java_home -v [version])  # macOS
# 或
export JAVA_HOME=/usr/lib/jvm/java-[version]-openjdk  # Linux
export PATH=$JAVA_HOME/bin:$PATH

# 添加到配置文件
echo 'export JAVA_HOME=/usr/lib/jvm/java-[version]-openjdk' >> ~/.bashrc
echo 'export PATH=$JAVA_HOME/bin:$PATH' >> ~/.bashrc
source ~/.bashrc
```

---

### Node.js 开发环境

**依赖清单**:
- [ ] Node.js `[版本]`
- [ ] npm `[版本]`

**快速安装（推荐使用 nvm）**:
```bash
# 安装 nvm (Linux/macOS)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
source ~/.bashrc

# 安装 Node.js
nvm install [version]
nvm use [version]
nvm alias default [version]

# 验证
node -v
npm -v
```

**包管理器安装**:
```bash
# Ubuntu/Debian
curl -fsSL https://deb.nodesource.com/setup_[version].x | sudo -E bash -
sudo apt install -y nodejs

# macOS
brew install node@[version]

# Windows
choco install nodejs-lts
```

---

### Go 开发环境

**依赖清单**:
- [ ] Go `[版本]`
- [ ] GOPATH 配置
- [ ] Go modules 启用

**安装 Go**:
```bash
# Linux
wget https://go.dev/dl/go[version].linux-amd64.tar.gz
sudo rm -rf /usr/local/go
sudo tar -C /usr/local -xzf go[version].linux-amd64.tar.gz

# macOS
brew install go@[version]

# Windows
choco install golang
```

**配置环境变量**:
```bash
# Linux/macOS
export PATH=$PATH:/usr/local/go/bin
export GOPATH=$HOME/go
export PATH=$PATH:$GOPATH/bin
export GO111MODULE=on
export GOPROXY=https://goproxy.cn,direct

# 添加到配置文件
echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.bashrc
echo 'export GOPATH=$HOME/go' >> ~/.bashrc
echo 'export PATH=$PATH:$GOPATH/bin' >> ~/.bashrc
echo 'export GO111MODULE=on' >> ~/.bashrc
source ~/.bashrc
```

---

### Python 开发环境

**依赖清单**:
- [ ] Python `[版本]`
- [ ] pip `[版本]`
- [ ] 虚拟环境工具

**安装 Python**:
```bash
# Ubuntu/Debian
sudo apt install python[version] python[version]-venv

# macOS
brew install python@[version]

# Windows
choco install python --version=[version]
```

**创建虚拟环境（推荐）**:
```bash
# 创建虚拟环境
python -m venv venv

# 激活虚拟环境
source venv/bin/activate  # Linux/macOS
venv\Scripts\activate     # Windows

# 验证
python --version
pip --version
```

---

### Docker 环境

**依赖清单**:
- [ ] Docker Engine `[版本]`
- [ ] Docker Compose `[版本]`

**安装 Docker**:
```bash
# Ubuntu/Debian
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# 配置用户权限
sudo usermod -aG docker $USER
newgrp docker

# macOS/Windows
# 下载并安装 Docker Desktop
# https://www.docker.com/products/docker-desktop
```

**验证安装**:
```bash
docker --version
docker-compose --version
docker run hello-world
```

---

## 安装后验证

### 🔴 重新构建验证（必须执行）

> 安装依赖后必须重新执行项目构建，以构建成功作为环境就绪的最终判定

#### 执行重新构建
```bash
# 重新执行构建命令
cd [项目根目录]
[构建命令]
```

#### 构建验证结果
- **状态**: `[✅ 成功 / ❌ 失败]`
- **退出码**: `[退出码]`
- **验证时间**: `[时间]`

#### 构建失败处理
如果重新构建仍然失败：
1. 分析新的错误日志
2. 检查是否有遗漏的依赖
3. 人工确认不确定的依赖
4. 重复安装和验证流程

### 完整验证流程

1. **重新运行环境检查**
   ```bash
   /dev-env-check
   ```

2. **测试项目构建**
   ```bash
   # 根据项目类型执行构建命令
   [项目构建命令]
   ```

3. **测试项目运行**
   ```bash
   # 执行项目启动命令
   [项目启动命令]
   ```

### 验证清单

- [ ] 🔴 项目构建成功（必须）
- [ ] 所有 P0 问题已解决
- [ ] 所有 P1 问题已解决或有明确处理计划
- [ ] 环境检查显示无严重问题
- [ ] 项目可正常运行
- [ ] 开发工具（IDE）可正常使用
- [ ] 人工确认记录已完整

---

## 常见问题排查

### 包管理器安装失败

**症状**: 提示 "Unable to locate package" 或类似错误

**解决方案**:
1. 更新软件源: `sudo apt update` (Linux)
2. 检查网络连接
3. 确认包名正确
4. 尝试添加官方软件源

### 环境变量配置后不生效

**症状**: `echo $VAR` 显示为空

**解决方案**:
1. 确认配置添加到正确的文件（`~/.bashrc` 或 `~/.zshrc`）
2. 重新加载配置: `source ~/.bashrc`
3. 或重启终端/会话
4. 检查语法是否正确（引号、路径等）

### 版本冲突

**症状**: 安装新版本后旧版本仍在使用

**解决方案**:
1. 检查 PATH 顺序: `echo $PATH`
2. 使用 `which [command]` 查看实际使用的命令
3. 调整 PATH 顺序，确保新版本路径在前
4. 或卸载旧版本

### 权限不足

**症状**: 提示 "Permission denied"

**解决方案**:
1. 使用 `sudo` 运行命令（需要管理员权限）
2. 检查文件/目录权限
3. 对于 Docker，确保用户在 docker 组中

---

## 参考资源

### 官方文档
- Java: https://docs.oracle.com/en/java/
- Node.js: https://nodejs.org/docs/
- Go: https://go.dev/doc/
- Python: https://docs.python.org/
- Docker: https://docs.docker.com/

### 包管理器文档
- apt: https://wiki.debian.org/Apt
- Homebrew: https://docs.brew.sh/
- Chocolatey: https://docs.chocolatey.org/

### 版本管理工具
- nvm (Node.js): https://github.com/nvm-sh/nvm
- SDKMAN (Java): https://sdkman.io/
- rustup (Rust): https://rustup.rs/

---

## 附录

### 快速参考命令

```bash
# 查看系统信息
uname -a           # Linux/macOS
systeminfo         # Windows

# 查找命令位置
which [command]    # Linux/macOS
where [command]    # Windows

# 查看环境变量
printenv           # Linux/macOS
echo $PATH         # Linux/macOS
echo %PATH%        # Windows

# 查看已安装包
apt list --installed       # Linux (apt)
brew list                  # macOS
choco list --local-only    # Windows
```

### 环境变量配置模板

**~/.bashrc 或 ~/.zshrc (Linux/macOS)**:
```bash
# Java
export JAVA_HOME=/usr/lib/jvm/java-[version]
export PATH=$JAVA_HOME/bin:$PATH

# Go
export GOPATH=$HOME/go
export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin
export GO111MODULE=on

# Node.js (使用 nvm)
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
```

---

**文档版本**: 1.0
**最后更新**: `[更新时间]`
**生成工具**: dev-env-check skill
