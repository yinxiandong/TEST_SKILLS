#!/usr/bin/env bash
set -euo pipefail

SERVER_NAME=""
CONFIG_PATH=".secrets/dev-servers.yaml"
SERVICE_ID=""
DRY_RUN="false"

usage() {
  cat <<'USAGE'
用法:
  probe_remote.sh --server <name> [--config <path>] [--service <service_id>] [--dry-run]
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --server)
      SERVER_NAME="$2"; shift 2 ;;
    --config)
      CONFIG_PATH="$2"; shift 2 ;;
    --service)
      SERVICE_ID="$2"; shift 2 ;;
    --dry-run)
      DRY_RUN="true"; shift ;;
    -h|--help)
      usage; exit 0 ;;
    *)
      echo "[ERROR] 未知参数: $1"; usage; exit 1 ;;
  esac
done

if [[ -z "$SERVER_NAME" ]]; then
  echo "[ERROR] --server 必填"; usage; exit 1
fi

if [[ ! -f "$CONFIG_PATH" ]]; then
  echo "[ERROR] 配置文件不存在: $CONFIG_PATH"
  exit 1
fi

for cmd in ssh sftp python3; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[ERROR] 缺少命令: $cmd"
    exit 1
  fi
done

parse_json() {
  python3 - "$CONFIG_PATH" "$SERVER_NAME" "$SERVICE_ID" <<'PY'
import json
import sys

config_path, server_name, service_id = sys.argv[1:]
text = open(config_path, 'r', encoding='utf-8').read()
cfg = json.loads(text)

servers = cfg.get('servers') or []
server = next((s for s in servers if isinstance(s, dict) and s.get('name') == server_name), None)
if not server:
    print("__ERROR__=未找到服务器")
    sys.exit(0)

ssh = server.get('ssh') if isinstance(server.get('ssh'), dict) else {}
auth = ssh.get('auth') if isinstance(ssh.get('auth'), dict) else {}
services = server.get('services') if isinstance(server.get('services'), list) else []
if service_id:
    services = [s for s in services if isinstance(s, dict) and s.get('service_id') == service_id]

out = {
  'ssh': {
    'host': ssh.get('host',''),
    'port': int(ssh.get('port') or 22),
    'username': ssh.get('username',''),
    'auth_type': auth.get('type','password'),
    'password': auth.get('password',''),
    'identity_file': auth.get('identity_file',''),
  },
  'defaults': server.get('defaults') if isinstance(server.get('defaults'), dict) else {},
  'services': services,
}
print(json.dumps(out, ensure_ascii=False))
PY
}

payload="$(parse_json)"
if echo "$payload" | grep -q '^__ERROR__='; then
  echo "[ERROR] $(echo "$payload" | sed 's/^__ERROR__=//')"
  exit 1
fi

HOST="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["ssh"]["host"])' <<<"$payload")"
PORT="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["ssh"]["port"])' <<<"$payload")"
USERNAME="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["ssh"]["username"])' <<<"$payload")"
AUTH_TYPE="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["ssh"]["auth_type"])' <<<"$payload")"
PASSWORD="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["ssh"].get("password",""))' <<<"$payload")"
IDENTITY_FILE="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d["ssh"].get("identity_file",""))' <<<"$payload")"

KNOWN_HOSTS_FILE="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(d.get("defaults",{}).get("known_hosts_file","/tmp/remote-dev-deploy-known-hosts"))' <<<"$payload")"
STRICT_HOST_KEY="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print("yes" if d.get("defaults",{}).get("strict_host_key_check", False) else "no")' <<<"$payload")"

SSH_BASE=(ssh -n -p "$PORT" -o "StrictHostKeyChecking=$STRICT_HOST_KEY" -o "UserKnownHostsFile=$KNOWN_HOSTS_FILE" -o ConnectTimeout=8)
SFTP_BASE=(sftp -o "StrictHostKeyChecking=$STRICT_HOST_KEY" -o "UserKnownHostsFile=$KNOWN_HOSTS_FILE" -P "$PORT")
if [[ "$AUTH_TYPE" == "key" && -n "$IDENTITY_FILE" ]]; then
  SSH_BASE+=( -i "$IDENTITY_FILE" -o BatchMode=yes )
  SFTP_BASE+=( -i "$IDENTITY_FILE" )
fi

ssh_exec() {
  local cmd="$1"
  if [[ "$AUTH_TYPE" == "password" ]]; then
    if ! command -v sshpass >/dev/null 2>&1; then
      echo "[ERROR] 缺少 sshpass（password 认证需要）"
      return 127
    fi
    sshpass -p "$PASSWORD" "${SSH_BASE[@]}" "$USERNAME@$HOST" "$cmd"
    return $?
  fi
  "${SSH_BASE[@]}" "$USERNAME@$HOST" "$cmd"
}

echo "[INFO] server=$SERVER_NAME $USERNAME@$HOST:$PORT auth=$AUTH_TYPE"

if [[ "$DRY_RUN" == "true" ]]; then
  echo "[PLAN] connect + validate services (dry-run)"
  echo "[RESULT] DRY_RUN_SUCCESS"
  exit 0
fi

echo "[STEP] 连通性检查"
ssh_exec "hostname; whoami; date '+%F %T'" >/dev/null

services_json="$(python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); print(json.dumps(d.get("services",[]), ensure_ascii=False))' <<<"$payload")"
service_count="$(python3 -c 'import json,sys; print(len(json.loads(sys.stdin.read())))' <<<"$services_json")"
if [[ "$service_count" == "0" ]]; then
  echo "[WARN] 未配置 services[]（remote-debug-setup 需要按服务逐个映射）"
  echo "[RESULT] PROBE_PARTIAL"
  exit 0
fi

echo "[STEP] 服务映射检查: $service_count 个"
python3 - "$services_json" <<'PY' | while IFS= read -r line; do
import json
import sys

services = json.loads(sys.argv[1])
for s in services:
    sid = s.get('service_id','')
    mode = s.get('mode','')
    name = s.get('name','')
    print(f"{sid}\t{mode}\t{name}")
PY
  [[ -z "$line" ]] && continue
  sid="$(cut -f1 <<<"$line")"
  mode="$(cut -f2 <<<"$line")"
  name="$(cut -f3 <<<"$line")"
  echo "[CHECK] $sid ($name) mode=$mode"
done

echo "[STEP] 输出关键证据（便于逐服务确认）"
python3 - "$services_json" <<'PY'
import json
import sys

services = json.loads(sys.argv[1])
for s in services:
    sid = s.get('service_id','')
    mode = s.get('mode','')
    print('---')
    print(f"SERVICE_ID={sid} MODE={mode}")
    if mode == 'systemd':
        unit = (s.get('systemd') or {}).get('unit','')
        print(f"systemd.unit={unit}")
    if mode == 'docker':
        container = (s.get('docker') or {}).get('container','')
        print(f"docker.container={container}")
    if mode == 'script':
        sc = s.get('script') or {}
        print(f"script.start={sc.get('start','')}")
        print(f"script.stop={sc.get('stop','')}")
        print(f"script.check={sc.get('check','')}")
    lg = s.get('logs') or {}
    print(f"logs.type={lg.get('type','')}")
    if lg.get('type') == 'journalctl':
        print(f"logs.journal_unit={lg.get('journal_unit','')}")
    if lg.get('type') == 'files':
        print(f"logs.paths={lg.get('paths',[])}")
PY

echo "[STEP] 逐服务探测（只读）"
while IFS= read -r s; do
  [[ -z "$s" ]] && continue
  sid="$(python3 -c 'import json,sys; print(json.loads(sys.stdin.read()).get("service_id",""))' <<<"$s")"
  mode="$(python3 -c 'import json,sys; print(json.loads(sys.stdin.read()).get("mode",""))' <<<"$s")"

  if [[ "$mode" == "systemd" ]]; then
    unit="$(python3 -c 'import json,sys; s=json.loads(sys.stdin.read()); print((s.get("systemd") or {}).get("unit",""))' <<<"$s")"
    [[ -z "$unit" ]] && { echo "[WARN] $sid 缺少 systemd.unit"; continue; }
    ssh_exec "systemctl is-active '$unit' >/dev/null 2>&1 && echo ACTIVE || echo INACTIVE"
    ssh_exec "systemctl show '$unit' -p User,ExecStart,MainPID --no-pager 2>/dev/null || true" | sed 's/^/[EVIDENCE] /'
    continue
  fi
  if [[ "$mode" == "docker" ]]; then
    container="$(python3 -c 'import json,sys; s=json.loads(sys.stdin.read()); print((s.get("docker") or {}).get("container",""))' <<<"$s")"
    [[ -z "$container" ]] && { echo "[WARN] $sid 缺少 docker.container"; continue; }
    ssh_exec "command -v docker >/dev/null 2>&1 || { echo NO_DOCKER; exit 0; }; docker ps --format '{{.Names}}' | grep -Fx '$container' >/dev/null 2>&1 && echo RUNNING || echo NOT_FOUND"
    ssh_exec "command -v docker >/dev/null 2>&1 && docker inspect '$container' --format '{{.Name}}\t{{.Config.Image}}\t{{json .NetworkSettings.Ports}}' 2>/dev/null || true" | sed 's/^/[EVIDENCE] /'
    continue
  fi
  if [[ "$mode" == "script" ]]; then
    start="$(python3 -c 'import json,sys; s=json.loads(sys.stdin.read()); print((s.get("script") or {}).get("start",""))' <<<"$s")"
    stop="$(python3 -c 'import json,sys; s=json.loads(sys.stdin.read()); print((s.get("script") or {}).get("stop",""))' <<<"$s")"
    check="$(python3 -c 'import json,sys; s=json.loads(sys.stdin.read()); print((s.get("script") or {}).get("check",""))' <<<"$s")"
    if [[ -z "$start" || -z "$stop" || -z "$check" ]]; then
      echo "[WARN] $sid script.start/stop/check 未补齐"
      continue
    fi
    ssh_exec "test -x '$start' && test -x '$stop' && test -x '$check' && echo OK || echo MISSING"
    continue
  fi
  echo "[WARN] $sid 未识别 mode=$mode"
done < <(python3 - "$services_json" <<'PY'
import json
import sys

services = json.loads(sys.argv[1])
for s in services:
    print(json.dumps(s, ensure_ascii=False))
PY
)

echo "[RESULT] PROBE_SUCCESS"
