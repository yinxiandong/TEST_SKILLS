# API 测试覆盖率规则体系

本文档定义了 API 接口测试用例生成的覆盖率规则，共 4 大类 21 条规则。
`api-test-case-generator` 在生成用例列表时，必须为每条用例标注所依据的 `coverage_type` 和 `coverage_rule`。

---

## 1. 正向用例（Positive Test Cases）

验证功能在合法输入、正常业务流程下的正确性，确保符合预期业务逻辑。

| 规则 ID | 规则名称 | 说明 | 典型级别 |
|---------|---------|------|---------|
| `positive-required-only` | 仅传必填字段 | 只携带接口规定的必填参数，验证核心流程是否正常执行 | P0 |
| `positive-valid-semantics` | 语义合法输入 | 输入符合业务语义的有效数据（如合法手机号、有效日期、合规状态值） | P0/P1 |
| `positive-enum-combination` | 枚举值组合覆盖 | 对所有枚举类型字段（如状态、类型、渠道），遍历其合法枚举值组合进行测试 | P1/P2 |
| `positive-normal-flow` | 正常业务流 | 包含正常业务流、成功路径、合法边界内的其他正向场景 | P0/P1 |

### 用例生成指引

- 每个 API 至少生成 1 条 `positive-required-only` 用例（P0 冒烟）
- 有枚举字段的 API 应生成 `positive-enum-combination` 用例覆盖关键枚举值
- CRUD 接口应生成完整的 `positive-normal-flow`（创建→查询→更新→删除）

---

## 2. 负向用例（Negative Test Cases）

验证功能在非法输入、异常流程下的容错性与健壮性，确保系统能正确拒绝或提示错误。

| 规则 ID | 规则名称 | 说明 | 典型级别 |
|---------|---------|------|---------|
| `negative-invalid-value` | 无效值 | 输入不符合业务规则的值（如手机号格式正确但不存在、金额为负数、状态码不存在） | P1/P2 |
| `negative-missing-field` | 缺失必填字段 | 故意不传/清空接口规定的必填参数，验证系统是否返回必填校验错误 | P1 |
| `negative-format-error` | 格式错误 | 输入格式不符合要求的数据（如邮箱少 @、日期格式错误、手机号位数不对） | P1/P2 |
| `negative-type-error` | 类型错误 | 传入与字段定义类型不匹配的数据（如字符串传数字、布尔值传对象、数字传数组） | P2 |
| `negative-semantic-illegal` | 语义非法 | 输入语义上违反业务规则的数据（如过期日期、权限外资源 ID、逻辑冲突的状态组合） | P2 |
| `negative-other` | 其他负向 | 包含异常业务流、参数越权、重复提交等其他异常场景 | P2/P3 |

### 用例生成指引

- 每个有必填字段的 API 至少生成 1 条 `negative-missing-field` 用例
- 有格式校验的字段应生成 `negative-format-error` 用例
- 有类型约束的字段应生成 `negative-type-error` 用例
- 有业务规则约束的字段应生成 `negative-semantic-illegal` 用例

---

## 3. 边界值用例（Boundary Value Test Cases）

针对数据范围、长度、空值等边界场景，验证系统对临界值的处理是否符合预期。

| 规则 ID | 规则名称 | 说明 | 典型级别 |
|---------|---------|------|---------|
| `boundary-max-min` | 极大值/极小值 | 测试数值类型字段的合法最大值、最小值（如年龄 18/99、金额 0.01/1000000） | P2 |
| `boundary-exceed` | 超出边界值 | 测试超过上限/低于下限的值（如年龄 17/100、金额超过上限） | P2 |
| `boundary-null-zero-empty` | Null/零值/空值 | 测试字段为 Null、数值 0、空字符串、空数组等场景，验证系统是否兼容或提示 | P1/P2 |
| `boundary-string-length` | 字符串过长/过短 | 测试字符串字段长度超过最大限制、低于最小要求的场景，验证长度校验逻辑 | P2 |

### 用例生成指引

- 有数值范围约束的字段应生成 `boundary-max-min` + `boundary-exceed` 用例
- 有长度限制的字符串字段应生成 `boundary-string-length` 用例
- 可选字段应生成 `boundary-null-zero-empty` 用例验证空值兼容性

---

## 4. 安全性用例（Security Test Cases）

验证系统在权限控制、注入攻击等安全场景下的防护能力。

| 规则 ID | 规则名称 | 说明 | 典型级别 |
|---------|---------|------|---------|
| `security-auth-control` | 鉴权控制 | 测试未登录、无权限、越权访问等场景，验证接口的身份认证与权限校验逻辑 | P0/P1 |
| `security-sql-injection` | SQL 注入 | 构造 SQL 注入 payload（如 `' OR '1'='1`），验证系统是否能防范 SQL 注入攻击 | P1 |
| `security-fuzzing` | 模糊输入 | 构造特殊字符、不可见字符、超长字符串等，验证系统输入过滤与容错能力 | P2 |
| `security-xss` | XSS 注入 | 构造 XSS 脚本 payload（如 `<script>alert(1)</script>`），验证系统是否能防范跨站脚本攻击 | P1/P2 |
| `security-command-injection` | 命令行注入 | 构造命令注入 payload（如 `; ls /`），验证系统是否能防范命令执行漏洞 | P1 |
| `security-json-injection` | JSON 注入 | 构造畸形 JSON、恶意 JSON 结构，验证系统 JSON 解析与防护能力 | P2 |
| `security-nosql-injection` | NoSQL 注入 | 构造 NoSQL 注入 payload（如 `{"$gt": ""}`），验证系统对 MongoDB 等 NoSQL 数据库的防护 | P2 |

### 用例生成指引

- 每个需要鉴权的 API 至少生成 1 条 `security-auth-control` 用例（未登录访问）
- 有字符串输入的 API 应生成 `security-sql-injection` 和 `security-xss` 用例
- 接受 JSON 请求体的 API 应生成 `security-json-injection` 用例
- 有文件名/路径参数的 API 应生成 `security-command-injection` 用例
- 使用 MongoDB 等 NoSQL 的系统应生成 `security-nosql-injection` 用例

---

## 覆盖率检查清单

用例列表生成后，自动校验以下覆盖率指标：

- [ ] 每个 API 至少有 1 条正向用例（positive-required-only 或 positive-normal-flow）
- [ ] 每个有必填字段的 API 至少有 1 条 negative-missing-field 用例
- [ ] 每个需要鉴权的 API 至少有 1 条 security-auth-control 用例
- [ ] 正向用例占比 ≥ 30%
- [ ] 负向用例占比 ≥ 20%
- [ ] 安全用例占比 ≥ 5%
- [ ] P0 用例覆盖所有核心 API 的正向流程

---

## 级别分配规则

| 级别 | 分配原则 | smoke 标记 |
|------|---------|-----------|
| P0 | 核心 API 的 positive-required-only + security-auth-control | `smoke: true` |
| P1 | 主要 API 的 negative-missing-field + security-sql-injection/xss + positive-valid-semantics | `smoke: false` |
| P2 | 次要 API 的 boundary-* + negative-type-error + security-fuzzing/json/nosql | `smoke: false` |
| P3 | 边缘场景的 negative-other + positive-enum-combination（非核心枚举） | `smoke: false` |
