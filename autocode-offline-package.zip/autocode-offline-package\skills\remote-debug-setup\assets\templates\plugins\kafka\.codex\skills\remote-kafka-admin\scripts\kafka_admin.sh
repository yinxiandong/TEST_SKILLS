#!/usr/bin/env bash
set -euo pipefail

SERVER_NAME=""
CONFIG_PATH=".secrets/dev-servers.yaml"
ACTION=""

TOPIC=""
PARTITIONS="1"
REPLICATION="1"

GROUP_ID=""
TO_EARLIEST="false"
TO_LATEST="false"
TO_OFFSET=""

CONFIRM="false"
DRY_RUN="false"
SSH_TIMEOUT_SECONDS="60"

usage() {
  cat <<'USAGE'
用法:
  kafka_admin.sh --server <name> --action <list-topics|describe-topic|create-topic|delete-topic|recreate-topic|list-groups|reset-offsets>
                [--config <path>]
                [--topic <name>] [--partitions <n>] [--replication <n>]
                [--group <id>] [--to-earliest|--to-latest|--to-offset <n>]
                [--ssh-timeout <seconds>]
                [--confirm] [--dry-run]

说明:
  - 通过 ssh 在远端执行 Kafka CLI（或 docker exec 容器内 CLI）。
  - 破坏性/写操作（create-topic/delete-topic/reset-offsets）必须显式加 --confirm。
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --server) SERVER_NAME="$2"; shift 2 ;;
    --config) CONFIG_PATH="$2"; shift 2 ;;
    --action) ACTION="$2"; shift 2 ;;
    --topic) TOPIC="$2"; shift 2 ;;
    --partitions) PARTITIONS="$2"; shift 2 ;;
    --replication) REPLICATION="$2"; shift 2 ;;
    --group) GROUP_ID="$2"; shift 2 ;;
    --to-earliest) TO_EARLIEST="true"; shift ;;
    --to-latest) TO_LATEST="true"; shift ;;
    --to-offset) TO_OFFSET="$2"; shift 2 ;;
    --ssh-timeout) SSH_TIMEOUT_SECONDS="$2"; shift 2 ;;
    --confirm) CONFIRM="true"; shift ;;
    --dry-run) DRY_RUN="true"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "[ERROR] 未知参数: $1"; usage; exit 1 ;;
  esac
done

if [[ -z "$SERVER_NAME" || -z "$ACTION" ]]; then
  echo "[ERROR] --server 与 --action 必填"; usage; exit 1
fi
if [[ ! -f "$CONFIG_PATH" ]]; then
  echo "[ERROR] 配置文件不存在: $CONFIG_PATH"; exit 1
fi

case "$ACTION" in
  list-topics|list-groups) ;;
  describe-topic|create-topic|delete-topic|recreate-topic)
    [[ -n "$TOPIC" ]] || { echo "[ERROR] action=$ACTION 时 --topic 必填"; exit 1; }
    ;;
  reset-offsets)
    [[ -n "$GROUP_ID" ]] || { echo "[ERROR] action=reset-offsets 时 --group 必填"; exit 1; }
    [[ -n "$TOPIC" ]] || { echo "[ERROR] action=reset-offsets 时 --topic 必填"; exit 1; }
    if [[ "$TO_EARLIEST" == "true" && "$TO_LATEST" == "true" ]]; then
      echo "[ERROR] --to-earliest 与 --to-latest 不能同时使用"; exit 1
    fi
    if [[ -n "$TO_OFFSET" && ( "$TO_EARLIEST" == "true" || "$TO_LATEST" == "true" ) ]]; then
      echo "[ERROR] --to-offset 不能与 --to-earliest/--to-latest 同时使用"; exit 1
    fi
    if [[ -n "$TO_OFFSET" && ! "$TO_OFFSET" =~ ^[0-9]+$ ]]; then
      echo "[ERROR] --to-offset 必须为非负整数"; exit 1
    fi
    ;;
  *)
    echo "[ERROR] 未支持 action=$ACTION"; usage; exit 1 ;;
esac

if ! [[ "$SSH_TIMEOUT_SECONDS" =~ ^[1-9][0-9]*$ ]]; then
  echo "[ERROR] --ssh-timeout 必须为正整数"; exit 1
fi
if [[ "$ACTION" == "create-topic" || "$ACTION" == "recreate-topic" ]]; then
  if ! [[ "$PARTITIONS" =~ ^[1-9][0-9]*$ ]]; then
    echo "[ERROR] --partitions 必须为正整数"; exit 1
  fi
  if ! [[ "$REPLICATION" =~ ^[1-9][0-9]*$ ]]; then
    echo "[ERROR] --replication 必须为正整数"; exit 1
  fi
fi

if [[ "$ACTION" == "create-topic" || "$ACTION" == "delete-topic" || "$ACTION" == "recreate-topic" || "$ACTION" == "reset-offsets" ]]; then
  if [[ "$CONFIRM" != "true" ]]; then
    echo "[ERROR] action=$ACTION 属于写/破坏性操作，必须显式加 --confirm"; exit 2
  fi
fi

for cmd in python3 ssh; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "[ERROR] 缺少命令: $cmd"; exit 1; }
done

python3 - "$CONFIG_PATH" "$SERVER_NAME" "$ACTION" "$TOPIC" "$PARTITIONS" "$REPLICATION" "$GROUP_ID" "$TO_EARLIEST" "$TO_LATEST" "$TO_OFFSET" "$DRY_RUN" "$SSH_TIMEOUT_SECONDS" <<'PY'
import json
import shlex
import subprocess
import sys
import shutil
from typing import Any, Dict, Tuple

(
  config_path, server_name, action, topic, partitions, replication,
  group_id, to_earliest, to_latest, to_offset, dry_run, ssh_timeout_seconds,
) = sys.argv[1:]

to_earliest = to_earliest.lower() == 'true'
to_latest = to_latest.lower() == 'true'
dry_run = dry_run.lower() == 'true'
ssh_timeout_seconds = int(ssh_timeout_seconds)

cfg = json.loads(open(config_path,'r',encoding='utf-8').read())
server = next((s for s in cfg.get('servers',[]) if isinstance(s,dict) and s.get('name')==server_name), None)
if not server:
    print(f"[ERROR] 未找到服务器: {server_name}")
    sys.exit(1)

ssh = server.get('ssh') if isinstance(server.get('ssh'), dict) else {}
auth = ssh.get('auth') if isinstance(ssh.get('auth'), dict) else {}
host = str(ssh.get('host') or '')
port = int(ssh.get('port') or 22)
username = str(ssh.get('username') or '')
auth_type = str(auth.get('type') or 'password')
password = str(auth.get('password') or '')
identity_file = str(auth.get('identity_file') or '')

defaults = server.get('defaults') if isinstance(server.get('defaults'), dict) else {}
known_hosts_file = str(defaults.get('known_hosts_file') or '/tmp/remote-dev-deploy-known-hosts')
strict = 'yes' if bool(defaults.get('strict_host_key_check') or False) else 'no'

components = server.get('components') if isinstance(server.get('components'), dict) else {}
kafka = components.get('kafka') if isinstance(components.get('kafka'), dict) else {}
bootstrap = str(kafka.get('bootstrap_servers') or '').strip()
if not bootstrap:
    print('[ERROR] 未配置 servers[].components.kafka.bootstrap_servers')
    sys.exit(2)
cli = kafka.get('cli') if isinstance(kafka.get('cli'), dict) else {}
cli_mode = str(cli.get('mode') or 'ssh')
bin_dir = str(cli.get('bin_dir') or '/opt/kafka/bin')
container = str(cli.get('docker_container') or '')

ssh_base = [
    'ssh','-n','-p',str(port),
    '-o',f'StrictHostKeyChecking={strict}',
    '-o',f'UserKnownHostsFile={known_hosts_file}',
    '-o','ConnectTimeout=8',
]
if auth_type == 'key' and identity_file:
    ssh_base += ['-i', identity_file, '-o', 'BatchMode=yes']
ssh_base.append(f'{username}@{host}')

def run_ssh(cmd: str) -> Tuple[int, str]:
    full = ssh_base + [cmd]
    if auth_type == 'password':
        if not password:
            return 127, '[ERROR] ssh.auth.password 为空\n'
        if shutil.which('sshpass') is None:
            return 127, '[ERROR] 缺少 sshpass（password 认证需要）\n'
        full = ['sshpass','-p',password] + full
    try:
        p = subprocess.run(full, text=True, capture_output=True, timeout=ssh_timeout_seconds)
    except subprocess.TimeoutExpired:
        return 124, f'[ERROR] SSH 命令超时（{ssh_timeout_seconds}s）\n'
    out = (p.stdout or '') + (p.stderr or '')
    return p.returncode, out

def build_remote_cmd(argv: list[str]) -> str:
    if cli_mode == 'docker':
        if not container:
            raise RuntimeError('cli.mode=docker 但 docker_container 为空')
        # 默认容器内 kafka 在 /opt/kafka/bin
        return ' '.join(['docker','exec','-i',shlex.quote(container), *[shlex.quote(a) for a in argv]])
    # ssh mode: 直接执行远端 bin
    return ' '.join([shlex.quote(a) for a in argv])

topics_sh = f"{bin_dir}/kafka-topics.sh"
groups_sh = f"{bin_dir}/kafka-consumer-groups.sh"

def plan(cmd: str) -> None:
    print(f"[PLAN] {cmd}")

def ensure_remote_docker() -> None:
    if cli_mode != 'docker':
        return
    code, out = run_ssh("command -v docker >/dev/null 2>&1 && echo OK || echo NO_DOCKER")
    if code != 0 or "OK" not in out:
        raise RuntimeError("远端缺少 docker 或不可用（cli.mode=docker 需要 docker）")

cmd = ""
if action == 'list-topics':
    cmd = build_remote_cmd([topics_sh, '--bootstrap-server', bootstrap, '--list'])
elif action == 'describe-topic':
    cmd = build_remote_cmd([topics_sh, '--bootstrap-server', bootstrap, '--describe', '--topic', topic])
elif action == 'create-topic':
    try:
        p = str(int(partitions))
        r = str(int(replication))
        if int(p) <= 0 or int(r) <= 0:
            raise ValueError("partitions/replication must be > 0")
    except Exception:
        print("[ERROR] partitions/replication 非法（必须为正整数）")
        sys.exit(6)
    cmd = build_remote_cmd([
        topics_sh, '--bootstrap-server', bootstrap, '--create',
        '--topic', topic, '--partitions', p, '--replication-factor', r,
    ])
elif action == 'delete-topic':
    cmd = build_remote_cmd([topics_sh, '--bootstrap-server', bootstrap, '--delete', '--topic', topic])
elif action == 'recreate-topic':
    try:
        p = str(int(partitions))
        r = str(int(replication))
        if int(p) <= 0 or int(r) <= 0:
            raise ValueError("partitions/replication must be > 0")
    except Exception:
        print("[ERROR] partitions/replication 非法（必须为正整数）")
        sys.exit(6)
    delete_cmd = build_remote_cmd([topics_sh, '--bootstrap-server', bootstrap, '--delete', '--topic', topic])
    create_cmd = build_remote_cmd([
        topics_sh, '--bootstrap-server', bootstrap, '--create',
        '--topic', topic, '--partitions', p, '--replication-factor', r,
    ])
    if dry_run:
        plan(delete_cmd)
        plan(create_cmd)
        print("[RESULT] DRY_RUN_SUCCESS")
        sys.exit(0)
    code1, out1 = run_ssh(delete_cmd)
    print(out1)
    code2, out2 = run_ssh(create_cmd)
    print(out2)
    print(f"[RESULT] DELETE_EXIT={code1} CREATE_EXIT={code2}")
    sys.exit(0 if code2 == 0 else 4)
elif action == 'list-groups':
    cmd = build_remote_cmd([groups_sh, '--bootstrap-server', bootstrap, '--list'])
elif action == 'reset-offsets':
    base = [groups_sh, '--bootstrap-server', bootstrap, '--group', group_id, '--reset-offsets', '--topic', topic]
    if to_earliest:
        base += ['--to-earliest']
    elif to_latest:
        base += ['--to-latest']
    elif to_offset:
        try:
            off = int(to_offset)
            if off < 0:
                raise ValueError("offset must be >= 0")
        except Exception:
            print("[ERROR] to_offset 非法（必须为非负整数）")
            sys.exit(6)
        base += ['--to-offset', str(off)]
    else:
        base += ['--to-earliest']
    # 执行必须加 --execute；我们先给出 --dry-run 的预览
    if dry_run:
        base += ['--dry-run']
    else:
        base += ['--execute']
    cmd = build_remote_cmd(base)
else:
    print(f"[ERROR] unsupported action={action}")
    sys.exit(3)

plan(cmd)
if dry_run:
    print("[RESULT] DRY_RUN_SUCCESS")
    sys.exit(0)

try:
    ensure_remote_docker()
except Exception as exc:
    print(f"[ERROR] {exc}")
    sys.exit(7)

code, out = run_ssh(cmd)
print(out)
print(f"[RESULT] EXIT_CODE={code}")
sys.exit(0 if code == 0 else 4)
PY
