---
name: project-initialize
description: "初始化项目文档体系，将现有项目改造为符合AI编码规范的结构"
mcp-servers: [sequential]
model: opus
---

## 核心原则

🔴 **禁止猜测，及时确认**
- 不清楚的依赖必须向人工确认
- 禁止基于猜测安装依赖或生成文档

🔴 **文档与实际保持一致**
- 发现差异时更新文档
- 记录所有人工确认结果

## 工作流程

将下列步骤都生成task进行跟踪，**按照步骤顺序执行**，必须完成所有步骤才能结束任务，不在步骤中的不要执行

- Step 1: **判断初始化进度**
- Step 2: **子模块分析** - addBlockedBy 1
- Step 3: **整体架构提取** - addBlockedBy 2
- Step 4: **项目完成初始化** - addBlockedBy 3
- Step 5: **结束检查和继续迭代** - addBlockedBy 4
- Step 6: **初始化报告生成** - addBlockedBy 5

**禁止**：
1. 无理由跳过执行步骤
2. 生成执行的各个skill中未明确指明的文件
3. 按照自我猜测执行动作和生成文件

### Step 1: 判断初始化进度

```
Skill(arch-current-state-scan)
```

**动作**: 调用Skill: `skills/arch-current-state-scan` 检查当前项目是未初始化、初始化完成、还是部分初始化
**技能**: `skills/arch-current-state-scan`
**依据**: 以该 Skill 输出的结构化字段 `init_state`（`uninitialized` | `partial` | `complete`）为准，并在 `init-report.md` 中记录判定依据（`init_state_reason`）。
**判断**:
  - 如果 `init_state=complete`（初始化完成）：扫描并更新已有文档
  - 如果 `init_state=partial`（部分初始化）：继续完成初始化，补充剩余的文档
  - 如果 `init_state=uninitialized`（未初始化）：启动初始化

### Step 2: 子模块分析

根据`.gitmodules`确定子模块列表，并行执行：
```
Task(subagent_type="module-analyzer", prompt="分析指定的模块{module}")
```

### Step 3: 整体架构提取

汇总子模块信息→分析依赖关系→识别共享基础设施→提取整体架构和跨模块业务流程:
```
Skill(arch-extract)
```

### Step 4: 项目完成初始化

检查项目根目录是否存在：`CLAUDE.md` 以及 `AGENTS.md`
- 如果不存在，优先使用本 Skill 内置模板 `template/AGENTS.md` 创建 `{project_root}/AGENTS.md`
- 若目标项目已存在 `CLAUDE.md`，将关键约束与目录职责摘要同步到 `{project_root}/AGENTS.md`（以避免规则散落）；如无则跳过

### Step 5: 结束检查和继续迭代
**动作**: 对产出文档进行评审，判断各输出产物内容的一致性，有不一致的优先以代码为准，再从外部文档参考；评审完进行迭代修改，直到评审内容完全被修改
**产出**: `{project_root}/docs/init-report.md`

### Step 6: 初始化报告生成
**动作**: 记录初始化过程→依据门禁规则，标注推断内容→列出遗留问题和后续建议
**产出**: 更新 `{project_root}/docs/init-report.md`
  - 提取时间和版本信息
  - 识别的模块和服务清单
  - 推断内容清单（哪些信息是推断的）
  - 遗留问题清单（需要人工确认的内容）
  - 建议后续工作（文档完善、架构优化等）


## 执行约束

### 写入边界
- **完全允许**: `{project_root}/docs/**` - 创建和写入所有文档内容
- **完全允许**: `{project_root}/AGENTS.md`，`{module_root}/AGENTS.md`
- **需用户许可**: `{project_root}/CLAUDE.md`、`{project_root}/README.md` - 仅当不存在且用户明确同意时创建（使用 AskUserQuestion）
- **绝对禁止**: `{project_root}/src/**`、`{project_root}/test/**`、`{module_root}/src/**`、`{module_root}/test/**`、构建配置(pom.xml等)、`.git/`、环境配置

### 工具边界
- **允许的网络访问策略**：
  - 默认**不进行任何网络访问**（包括但不限于 SSH/HTTP/浏览器自动化），仅执行本地只读扫描与 `docs/**` 写入。
  - 若确需进行“运行时信息提取”（如 `skills/arch-extract` 的运行时探测阶段），必须先获得用户明确授权，并在 `docs/init-report.md` 记录：授权范围、使用的访问方式（SSH/HTTP/Playwright）、访问目标与理由；未获授权则标注为“*待确认*”并跳过该阶段。
- **只读**: Read、Glob、Grep、Bash(ls/find/cat/git log等只读命令)
- **写入**: Write(仅`docs/**`)、Edit(仅`docs/**`)、Bash(仅`mkdir -p docs/**`)
- **禁止**: docs/外的任何修改

### 强制规则
1. **禁止猜测**: 不确定的架构推断必须标注为"推断"或"待确认"，并人工确认后记录
2. **可追溯性**: 文档内容必须引用来源（文件路径:行号）
3. **可复现性**: 扫描过程和判断依据必须可复现
4. **推断标注**: 所有推断内容必须标注"**推断**"或"*待确认*"
5. **人工确认记录**: 所有人工确认结果必须记录到 init-report.md

## 输出产物

### 核心文档
- **项目AGENTS**: `{project_root}/AGENTS.md`
- **系统架构**: `{project_root}/docs/architecture/系统架构设计.md` - 整体系统架构设计
- **功能架构**: `{project_root}/docs/architecture/功能架构设计.md` - 功能模块和业务架构

### 子模块文档
- **子模块AGENTS**: `{module_root}/AGENTS.md`
- **模块设计**: `{project_root}/docs/architecture/${module}/模块整体架构设计.md` - 各子模块详细设计
- **模块API**: `{project_root}/docs/architecture/${module}/模块API接口规范.md` - 各子模块API说明

### 辅助文档
- **初始化报告**: `docs/init-report.md` - 执行过程、评审跟踪和结果报告
- **编程CLI工具文档**: `AGENTS.md`、`CLAUDE.md`

## 工作边界

**智能体将执行**：
- 自动扫描项目代码和配置文件
- 识别子模块、架构模式、API接口
- 提取技术约束和编码规范
- 生成完整的文档体系
- 标注推断内容和不确定信息
- 提供后续改进建议

**智能体不会执行**：
- 代码重构和优化（保持代码不变）
- 架构重新设计（只提取现有架构）
- 修改原有文件和配置
- 需求补充和功能规划
- 直接修改代码或注释
