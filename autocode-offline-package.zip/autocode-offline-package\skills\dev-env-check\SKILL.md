---
name: dev-env-check
description: "检查项目开发环境依赖，以项目构建成功为最终判定标准，支持反向背压检查文档准确性，不确定的依赖必须人工确认"
mcp-servers: []
context: fork
model: sonnet
---

**语言**：简体中文

> **功能说明**: 该技能用于检查项目所需的开发环境依赖是否完整，**以项目成功编译构建为最终判定标准**。当构建失败时，触发反向背压机制检查 AGENTS.md、CLAUDE.md 等文档的准确性，识别文档与实际依赖的差异。对于不确定的依赖，**禁止猜测，必须向人工确认**。

## 核心原则

🔴 **构建成功 = 环境就绪**（唯一判定标准）
- 环境检查通过 ≠ 环境就绪
- 只有项目成功编译构建，才能判定环境就绪

🔴 **反向背压优先于猜测**
- 构建失败时，先检查文档准确性
- 不确定的依赖必须人工确认
- 禁止基于猜测安装依赖

🔴 **文档与实际保持一致**
- 发现差异时更新文档
- 记录所有人工确认结果

## 触发场景

- 项目初始化过程中，需要确认开发环境就绪
- 新成员加入项目，需要配置本地开发环境
- CI/CD 环境搭建时，需要验证构建环境
- 项目技术栈升级后，需要验证环境兼容性
- 构建或运行失败，怀疑环境配置问题

## 工作流程

**重要**：将下列步骤都生成 task 进行跟踪，按照步骤顺序执行，必须完成所有步骤才能结束任务

1. **识别项目技术栈**
2. **执行环境检查**
3. **CLI 回显检查结果**
4. **执行构建验证** ← 核心步骤
5. **反向背压检查**（构建失败时触发）
6. **生成安装指南**（如有缺失项）
7. **交互式自动安装**（可选）
8. **重新构建验证**（安装后必须重新验证）

---

## 步骤 1: 识别项目技术栈

**动作**: 扫描项目根目录和配置文件，识别项目使用的技术栈

### 技术栈识别规则

| 配置文件 | 技术栈 | 详细参考 |
|----------|--------|----------|
| `pom.xml` / `build.gradle` | Java | [reference/java-stack.md](reference/java-stack.md) |
| `go.mod` / `go.sum` | Go | [reference/go-stack.md](reference/go-stack.md) |
| `package.json` | Node.js/Web | [reference/nodejs-stack.md](reference/nodejs-stack.md) |
| `requirements.txt` / `pyproject.toml` | Python | [reference/python-stack.md](reference/python-stack.md) |
| `Cargo.toml` | Rust | [reference/rust-stack.md](reference/rust-stack.md) |
| `CMakeLists.txt` / `Makefile` | C/C++ | [reference/cpp-stack.md](reference/cpp-stack.md) |
| `Gemfile` | Ruby | - |
| `.csproj` / `.sln` | .NET | - |
| `Dockerfile` / `docker-compose.yml` | Docker | [reference/docker-env.md](reference/docker-env.md) |
| `.git/` | Git | [reference/git-env.md](reference/git-env.md) |

**产出**: 技术栈清单和所需依赖类型

---

## 步骤 2: 执行环境检查

**动作**: 根据识别的技术栈，并行执行相应的检查命令

### 检查流程概览

```
识别技术栈 → 并行执行检查命令 → 收集检查结果 → 对比版本要求
```

### 技术栈详细检查参考

每种技术栈的详细检查流程请参考对应文档：

| 技术栈 | 参考文档 | 主要检查项 |
|--------|----------|------------|
| **Java** | [java-stack.md](reference/java-stack.md) | JDK、Maven/Gradle、JAVA_HOME |
| **Go** | [go-stack.md](reference/go-stack.md) | Go 版本、GOPATH、Go modules |
| **Node.js** | [nodejs-stack.md](reference/nodejs-stack.md) | Node.js、npm/yarn/pnpm、engines |
| **Python** | [python-stack.md](reference/python-stack.md) | Python、pip、虚拟环境 |
| **C/C++** | [cpp-stack.md](reference/cpp-stack.md) | GCC/Clang、CMake、Make |
| **Rust** | [rust-stack.md](reference/rust-stack.md) | rustc、cargo、rustup |
| **Docker** | [docker-env.md](reference/docker-env.md) | Docker、Docker Compose、权限 |
| **Git** | [git-env.md](reference/git-env.md) | Git、用户配置、LFS |

### 通用检查命令模式

```bash
# 版本检查模式
[tool] --version 2>&1

# 环境变量检查模式
echo $[ENV_VAR]

# 配置文件检查模式
cat [config_file] 2>/dev/null || echo "配置文件不存在"
```

---

## 步骤 3: CLI 回显检查结果

**动作**: 在命令行界面直接输出检查结果，以清晰的格式展示

**输出格式**:
```
=================================================
        开发环境检查结果
=================================================

📋 项目技术栈
----------------------------
✓ Java (Maven)
✓ Node.js (npm)
✓ Docker

📊 检查结果摘要
----------------------------
✅ 正常: 5 项
⚠️  警告: 2 项
❌ 缺失: 1 项

📝 详细检查结果
----------------------------

【Java 环境】
  ✅ JDK 版本        期望: 11+     实际: 17.0.2
  ✅ Maven 版本      期望: 3.6+    实际: 3.8.1
  ✅ JAVA_HOME      已配置: /usr/lib/jvm/java-17

【Node.js 环境】
  ⚠️  Node.js 版本   期望: 16+     实际: 14.18.0  [版本过低]
  ⚠️  npm 版本       期望: 7+      实际: 6.14.15  [版本过低]

【Docker 环境】
  ❌ Docker         期望: 已安装   实际: 未安装    [阻断开发]

⚠️ 发现 3 个问题需要处理
=================================================
```

**回显要求**:
- 使用 emoji 和符号增强可读性（✅ ⚠️ ❌）
- 清晰的分区和层次结构
- 突出显示严重问题
- 简洁明了，避免冗余信息

---

## 步骤 4: 执行构建验证

🔴 **这是判定环境就绪的唯一标准**

**动作**: 执行项目的实际构建命令，以构建成功作为环境就绪的最终判定

### 4.1 构建命令识别

| 技术栈 | 构建文件 | 构建命令 | 说明 |
|--------|----------|----------|------|
| Java/Maven | pom.xml | `mvn compile -DskipTests` | 编译但跳过测试 |
| Java/Gradle | build.gradle | `./gradlew build -x test` | 构建但跳过测试 |
| Node.js | package.json | `npm install && npm run build` | 安装依赖并构建 |
| Go | go.mod | `go build ./...` | 构建所有包 |
| Rust | Cargo.toml | `cargo build` | 构建项目 |
| Python | pyproject.toml | `pip install -e . --dry-run` | 检查依赖可安装性 |
| Python | requirements.txt | `pip check` | 检查依赖一致性 |
| C/C++ | CMakeLists.txt | `cmake -B build && cmake --build build` | CMake 构建 |
| C/C++ | Makefile | `make` | Make 构建 |

**特殊情况处理**：
- 如果项目有多个构建文件，按优先级选择
- 如果无法识别构建命令，**必须使用 AskUserQuestion 询问用户**
- 禁止猜测构建命令

### 4.2 构建结果处理

**构建成功**（退出码 = 0）：
```
=================================================
        🎉 构建验证成功
=================================================
✅ 项目构建成功，开发环境就绪！

构建命令: mvn compile -DskipTests
构建耗时: 45 秒

环境状态: ✅ 就绪
=================================================
```

**构建失败**（退出码 ≠ 0）：
```
=================================================
        ❌ 构建验证失败
=================================================
构建命令: mvn compile -DskipTests
退出码: 1

错误摘要:
  - [ERROR] Failed to execute goal ...

⚠️ 即将触发反向背压检查，分析失败原因...
=================================================
```

---

## 步骤 5: 反向背压检查

🔴 **构建失败时必须执行此步骤**

**目的**: 当构建失败时，反向检查文档准确性，识别真实依赖，避免盲目猜测

### 5.1 分析构建错误

| 错误特征 | 错误类型 | 可能原因 |
|----------|----------|----------|
| `command not found` | 工具缺失 | 构建工具未安装或未加入 PATH |
| `not found`, `missing` | 依赖缺失 | 依赖包未安装 |
| `version`, `incompatible` | 版本不匹配 | 依赖版本不满足要求 |
| `permission denied` | 权限问题 | 文件或目录权限不足 |
| `connection`, `timeout` | 网络问题 | 无法下载依赖 |

### 5.2 检查文档一致性

**检查清单**：

1. **AGENTS.md** - 检查"技术栈"和"环境要求"章节
2. **CLAUDE.md** - 检查"开发环境"和"依赖"章节
3. **构建文件** - pom.xml、package.json、go.mod 等中的版本声明

**输出格式**：
```
=================================================
        📋 文档一致性检查
=================================================

【AGENTS.md 检查】
  文件位置: {project_root}/AGENTS.md
  技术栈声明: Java 11, Maven 3.6+
  实际检测: Java 17, Maven 3.8.1
  状态: ✅ 兼容

【CLAUDE.md 检查】
  文件位置: {project_root}/CLAUDE.md
  环境要求: 未声明 Node.js 版本
  实际需要: Node.js 18+ (根据 package.json)
  状态: ⚠️ 文档缺失

【差异汇总】
  - ⚠️ CLAUDE.md 缺少 Node.js 版本要求声明
=================================================
```

### 5.3 人工确认机制

🔴 **不确定的依赖必须人工确认，禁止猜测**

**触发条件**：
- 无法从构建日志明确判断缺失的依赖
- 文档与实际存在冲突
- 构建命令无法自动识别
- 依赖版本要求不明确

使用 `AskUserQuestion` 工具进行确认，所有确认结果记录到 `docs/init-report.md`

---

## 步骤 6: 生成安装指南

**动作**: 如果检查发现缺失或版本不匹配的依赖，生成详细的安装指南文档

**产出**: `{project_root}/docs/开发环境安装指南.md`

**模板**: 使用 [template/开发环境安装指南-template.md](template/开发环境安装指南-template.md)

**文档内容**:
- 问题优先级分类（P0-P3）
- 每个依赖的多种安装方式
- 包管理器安装命令（apt、yum、brew、choco）
- 环境变量配置说明
- 验证命令和预期输出

---

## 步骤 7: 交互式自动安装

**动作**: 使用 `AskUserQuestion` 询问用户是否需要自动安装缺失的依赖

### 安装流程

1. **总体确认** - 询问是否自动安装
2. **安装方式选择** - 包管理器/官方安装包
3. **逐项安装** - 显示信息、执行安装、验证结果
4. **后续配置** - 环境变量等配置
5. **完成总结** - 安装结果汇总

### 安装失败处理

如果安装失败，提供：
- 详细错误信息
- 可能原因分析
- 建议解决方案
- 安装指南参考

---

## 步骤 8: 重新构建验证

🔴 **安装依赖后必须重新验证构建**

**动作**: 在完成依赖安装后，重新执行项目构建，确认环境真正就绪

### 循环验证机制

如果重新构建仍然失败，进入循环验证：

1. **分析新的错误** → 回到步骤5
2. **识别新的依赖** → 人工确认
3. **安装新依赖** → 回到步骤7
4. **重新构建** → 回到步骤8

**循环终止条件**：
- ✅ 构建成功
- ❌ 用户选择手动处理
- ❌ 循环次数超过3次（防止无限循环）

---

## 参考文档索引

### 技术栈详细检查

| 文档 | 说明 |
|------|------|
| [reference/java-stack.md](reference/java-stack.md) | Java 技术栈检查参考 |
| [reference/go-stack.md](reference/go-stack.md) | Go 技术栈检查参考 |
| [reference/nodejs-stack.md](reference/nodejs-stack.md) | Node.js/Web 技术栈检查参考 |
| [reference/python-stack.md](reference/python-stack.md) | Python 技术栈检查参考 |
| [reference/rust-stack.md](reference/rust-stack.md) | Rust 技术栈检查参考 |
| [reference/cpp-stack.md](reference/cpp-stack.md) | C/C++ 技术栈检查参考 |
| [reference/docker-env.md](reference/docker-env.md) | Docker 环境检查参考 |
| [reference/git-env.md](reference/git-env.md) | Git 环境检查参考 |

### 模板文件

| 文档 | 说明 |
|------|------|
| [template/开发环境安装指南-template.md](template/开发环境安装指南-template.md) | 安装指南生成模板 |

---

## 输出产物

### 核心文档
- **安装指南**: `{project_root}/docs/开发环境安装指南.md` - 详细的依赖安装指导（仅在有缺失项时生成）

### CLI 输出
- 直接在命令行界面显示检查结果
- 实时显示安装过程和结果
- 无需额外文件即可查看环境状态

---

## 执行约束

### 写入边界
- **完全允许**: `{project_root}/docs/开发环境安装指南.md`
- **只读检测**: `pom.xml`, `package.json`, `go.mod` 等配置文件
- **禁止修改**: 项目源代码、配置文件、构建脚本
- **条件允许**: 用户明确同意后，可修改 `~/.bashrc`、`~/.zshrc` 等

### 工具边界
- **只读**: Read、Glob、Bash（只读命令）
- **写入**: Write（仅安装指南文档）
- **执行**: Bash（环境检查和安装命令）
- **交互**: AskUserQuestion

### 强制规则
1. **构建验证优先**: 以项目成功编译构建为环境就绪的唯一判定标准
2. **禁止猜测**: 不确定的依赖必须人工确认
3. **反向背压**: 构建失败时必须检查文档准确性
4. **明确授权**: 任何安装或配置操作必须获得用户明确同意
5. **循环验证**: 安装后必须重新构建验证

---

## 质量门禁

| 检查项 | 要求 | 门禁类型 |
|--------|------|----------|
| 构建验证成功 | 项目必须成功编译构建 | 🔴 硬性 |
| 技术栈识别准确 | 识别所有主要技术栈 | 🔴 硬性 |
| 构建命令识别 | 正确识别或人工确认 | 🔴 硬性 |
| 人工确认记录 | 不确定项已人工确认并记录 | 🔴 硬性 |
| CLI 输出清晰 | 结果易读易懂 | 🟡 必要 |
| 文档一致性检查 | 构建失败时已检查文档准确性 | 🟡 必要 |
| 安装指南生成 | 针对缺失依赖生成指南 | 🟡 必要 |

---

## 使用示例

```bash
# 在项目根目录执行，检查所有技术栈
/dev-env-check
```

## 扩展支持

### 新增技术栈支持

如需支持新的技术栈，在 `reference/` 目录下创建对应的检查参考文档：

1. 技术栈识别规则（通过配置文件特征）
2. 检查命令列表
3. 版本要求提取逻辑
4. 安装命令和方法
5. 验证命令

### 自定义检查规则

项目可通过 `.dev-env-check.yaml` 配置自定义检查规则：
```yaml
stacks:
  - name: java
    required_version: "11+"
    check_commands:
      - java -version
      - mvn -version
    required_tools:
      - java
      - javac
      - mvn
```
