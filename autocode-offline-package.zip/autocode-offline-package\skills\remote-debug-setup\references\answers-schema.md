# answers 结构说明（remote-debug-setup）

本文件描述 `remote-debug-setup` 生成器所需输入文件结构。

约定：

- 所有 `*.yaml` 文件实际内容推荐使用 **JSON 兼容格式**（即 JSON 文本，但扩展名保留 `.yaml`），避免目标机没有 `PyYAML`。
- `answers.min.json`：最小 SSH 入口，用于只读探测。
- `answers.full.json`：完整答案，用于生成 `.secrets` 与 `.codex/skills/remote-*` 套件。

## 1) answers.min.json（最小输入）

路径推荐：`{project_root}/.tmp/remote-debug-setup/answers.min.json`

说明：在 Codex UI 中应由智能体通过 AskUserQuestion 收集答案并自动落盘，用户无需手动创建文件。

### 字段

```json
{
  "suite_version": "2",
  "project": {
    "project_root": ".",
    "server_name_whitelist_regex": "^(dev|test)"
  },
  "defaults": {
    "known_hosts_file": "/tmp/remote-dev-deploy-known-hosts",
    "strict_host_key_check": false
  },
  "servers": [
    {
      "name": "dev1",
      "ssh": {
        "host": "10.0.0.1",
        "port": 22,
        "username": "root",
        "auth": {
          "type": "password",
          "password": "******",
          "identity_file": "~/.ssh/id_rsa"
        }
      },
      "probe": {
        "enable_http_probe": false,
        "http_ports_hint": [80, 443, 8080]
      }
    }
  ]
}
```

## 1.1) AskUserQuestion → answers.min.json 落盘映射（强约束）

本表用于确保智能体在 Codex UI 中提问后能**确定性落盘**，避免字段写错导致后续脚本失败。

| 问题ID（逻辑） | AskUserQuestion 输入 | 落盘 JSON Path | 规则 |
|---|---|---|---|
| Q1 | 服务器数量 | `servers[]` | 单台则数组长度=1；多台则为每台重复 Q2~Q5 |
| Q2 | server name | `servers[i].name` | 必须匹配 `project.server_name_whitelist_regex`，不匹配则继续追问 |
| Q3 | host | `servers[i].ssh.host` | 必填 |
| Q3 | port | `servers[i].ssh.port` | 默认 22；必须 1~65535 |
| Q3 | username | `servers[i].ssh.username` | 必填 |
| Q4 | auth type | `servers[i].ssh.auth.type` | 仅 `password` 或 `key` |
| Q4 | password | `servers[i].ssh.auth.password` | 仅当 type=password；默认不回显 |
| Q4 | identity_file | `servers[i].ssh.auth.identity_file` | 仅当 type=key |
| Q5 | enable_http_probe | `servers[i].probe.enable_http_probe` | 默认 false |
| Q5 | http_ports_hint | `servers[i].probe.http_ports_hint` | 默认 `[80,443,8080,8000,9000,10000,10001,10002]` |

### 约束

- `servers[].ssh.auth.type`：仅支持 `password|key`。
- `password` 模式依赖本机存在 `sshpass`。
- `key` 模式使用 `ssh -i identity_file`，要求本机可以访问该私钥文件。

## 2) probe-report.json（探测报告）

由 `probe_remote_env.py` 生成，建议存放：`{project_root}/.tmp/remote-debug-setup/probe-report.json`。

关键字段：

- `service_candidates[]`：候选服务列表（来源：systemd/docker/端口进程）。当探测提供 `--project-profile` 时，候选会优先按“项目相关性”排序，否则按通用置信度排序。
- `service_candidates[].project_match`：可选的“项目相关性”评分与解释（当探测时提供 `--project-profile` 且启用相关性计算时输出）。
- `components_hints`：按端口/进程/镜像名猜测的组件线索（仅提示，不保证准确）。
- （可选）`notes[]`：探测脚本对参数解析/兜底策略等产生的告警说明（例如非法 `--source-quota` 被忽略、`--max-candidates` 回退默认值）。

## 2.1) project-profile.json（项目画像，可选）

由 `scripts/analyze_project_profile.py` 在本地项目根目录生成，建议存放：

- `{project_root}/.tmp/remote-debug-setup/project-profile.json`

用途：

- 为共享/综合环境下的远端探测提供“本项目强绑定信号”（关键词、jar/binary 名、部署路径前缀、端口提示等）
- 探测时通过 `probe_remote_env.py --project-profile ...` 注入候选服务相关性排序与解释（`service_candidates[].project_match`）

## 3) answers.full.json（完整输入）

路径推荐：`{project_root}/.tmp/remote-debug-setup/answers.full.json`

说明：建议由智能体在读取 `probe-report.json` 后自动生成草稿（`scripts/draft_answers_full.py`），再通过 AskUserQuestion 逐服务确认并补齐，最终落盘。

### 字段（最小可用）

```json
{
  "suite_version": "2",
  "project": {
    "project_root": ".",
    "server_name_whitelist_regex": "^(dev|test)"
  },
  "defaults": {
    "deploy_root_tmp": "/tmp/remote-dev-deploy",
    "known_hosts_file": "/tmp/remote-dev-deploy-known-hosts",
    "strict_host_key_check": false
  },
  "generation": {
    "write_secrets": false,
    "force": false
  },
  "servers": [
    {
      "name": "dev1",
      "ssh": {
        "host": "10.0.0.1",
        "port": 22,
        "username": "root",
        "auth": { "type": "password", "password": "******" }
      },
      "defaults": {
        "deploy_root_tmp": "/tmp/remote-dev-deploy"
      },
      "services": [
        {
          "service_id": "svc-app",
          "name": "app",
          "mode": "systemd",
          "systemd": { "unit": "app.service", "user": "app" },
          "script": { "user": "app", "start": "", "stop": "", "check": "" },
          "docker": { "container": "", "compose_file": "" },
          "artifact": { "type": "file", "path": "/opt/app/app.jar", "pattern": "" },
          "logs": { "type": "journalctl", "journal_unit": "app.service", "paths": [] },
          "deploy": { "enabled": true, "rollback_mode": "print-only" },
          "health": { "type": "http", "url": "http://{host}:8080/actuator/health" }
        }
      ],
      "api_debug": {
        "enabled": false,
        "strategy": "none",
        "default_base_url": "http://{host}:8080"
      },
      "components": {
        "plugins": {
          "nacos": { "enabled": false },
          "db": { "enabled": false }
        },
        "nacos": {
          "enabled": false,
          "protocol": "http",
          "host": "10.0.0.1",
          "port": 8848,
          "username": "nacos",
          "password_plain": "******",
          "api_version": "v1",
          "login_path": "",
          "config_api_base": ""
        },
        "db": {
          "enabled": false,
          "db_type": "auto",
          "host": "10.0.0.1",
          "port": 5432,
          "username": "dbuser",
          "password": "******",
          "database": "appdb"
        }
      }
    }
  ]
}
```

## 3.1) AskUserQuestion → answers.full.json 落盘映射（强约束）

### 服务器级

| 问题ID（逻辑） | AskUserQuestion 输入 | 落盘 JSON Path | 规则 |
|---|---|---|---|
| Q6 | 启用 Nacos 插件 | `servers[i].components.nacos.enabled` | 默认=探测建议；若 false 则不生成插件 |
| Q6 | 启用 DB 插件 | `servers[i].components.db.enabled` | 默认=探测建议；若 false 则不生成插件 |
| Q8 | 是否写入实配 secrets | `generation.write_secrets` | true 时生成器加 `--write-secrets` |

### 服务级（按服务逐个映射）

每个候选服务 `j` 需要落盘到 `servers[i].services[j]`：

| 问题ID（逻辑） | AskUserQuestion 输入 | 落盘 JSON Path | 规则 |
|---|---|---|---|
| Q7-1 | 是否纳入生成 | `servers[i].services[j]` | 若否则不写入该服务 |
| Q7-2 | 服务名 | `servers[i].services[j].name` | 默认候选 `name_hint` |
| Q7-3 | mode | `servers[i].services[j].mode` | `systemd|docker|script` |
| Q7-3 | systemd.unit | `servers[i].services[j].systemd.unit` | mode=systemd 必填 |
| Q7-3 | docker.container | `servers[i].services[j].docker.container` | mode=docker 必填 |
| Q7-3 | script.start/stop/check | `servers[i].services[j].script.*` | mode=script 必填 |
| Q7-4 | logs.type | `servers[i].services[j].logs.type` | `journalctl|docker|files` |
| Q7-4 | logs.journal_unit | `servers[i].services[j].logs.journal_unit` | logs.type=journalctl 必填 |
| Q7-4 | logs.paths | `servers[i].services[j].logs.paths[]` | logs.type=files 必填且至少 1 条 |
| Q7-5 | api_debug enabled | `servers[i].api_debug.enabled` | 若启用则后续必须提供 spec/策略 |

## 3.2) 生成后套件读取的唯一入口（强约束）

为保证一致性：

- 插件配置唯一入口：`servers[].components.<plugin>`（例如 `components.nacos/components.db`）
- 兼容入口（不推荐）：`servers[].nacos` / `servers[].db` 仅作为兜底，脚本会输出 `[WARN] 已废弃字段`。

### 约束

- 必须按服务逐个配置 `services[]`。
- `services[].mode` 仅支持 `systemd|script|docker`。
- 生成器只负责落盘与套件生成；运行时写操作由生成出的 remote-* skills 再次门禁。

## 4) 说明：draft_answers_full.py 的自动补齐策略

`scripts/draft_answers_full.py` 会基于 `probe-report.json` 的 `components_hints` 自动：

- 设置 `components.plugins.nacos/db.enabled`
- 生成 `components.nacos` 与 `components.db` 的最小骨架（包含 host/port 等）

注意：脚本不会写入敏感值，`password_plain/password` 默认留空，需要你后续补齐。

## 5) 插件约定（强约束）

- `remote-debug-setup` 仅对 **模板目录存在的插件** 执行生成（当前仓库内默认包含：`nacos`、`db`、`kafka`、`es`）。
- 若 `answers.full.json` 中出现未知的 `components.<key>.enabled=true`，生成器会输出 `[WARN] 未识别插件已跳过`，不会中止生成，也不会生成对应插件技能。

## 6) Kafka/Elasticsearch 插件（dev/test 管理）

当探测到中间件线索时，建议在 `servers[].components` 下补齐最小骨架，并通过 AskUserQuestion 确认是否启用：

### Kafka（示例）

```json
{
  "enabled": true,
  "bootstrap_servers": "127.0.0.1:9092",
  "cli": {
    "mode": "ssh",
    "bin_dir": "/opt/kafka/bin",
    "docker_container": ""
  }
}
```

说明：
- `bootstrap_servers` 必填。
- `cli.mode=ssh` 表示在远端机器上执行 kafka CLI（通过 ssh）。如 Kafka 在 docker 内，可用 `cli.mode=docker` + `docker_container`。

### Elasticsearch（示例）

```json
{
  "enabled": true,
  "protocol": "http",
  "host": "127.0.0.1",
  "port": 9200,
  "auth": { "mode": "none", "username": "", "password_plain": "" }
}
```

说明：
- `protocol/host/port` 为最小必填。
- dev/test 写操作脚本会要求显式确认（例如 `--confirm`），避免误操作。
