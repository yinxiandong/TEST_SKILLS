---
name: remote-log-diagnose
description: "通用远程日志采集与归因技能。按 .secrets/dev-servers.yaml 的 services[] 抓取 journalctl/docker logs/文件日志，基于关键词做轻量分类，输出 DIAGNOSIS_RESULT=<json> 与结果标记，供 remote-dev-debug 编排使用。适用于远程服务异常、接口失败后的快速定位与人工介入建议输出。"
---

# remote-log-diagnose

## 概述

本技能用于：

- 从远端抓取指定服务的关键日志
- 进行轻量级错误归因（不做业务理解）
- 输出结构化结果，供自动化调试循环消费

## 用法

```bash
.codex/skills/remote-log-diagnose/scripts/log_diagnose.sh \
  --server dev1 \
  --service svc-app \
  --config .secrets/dev-servers.yaml \
  --tail-lines 200
```

