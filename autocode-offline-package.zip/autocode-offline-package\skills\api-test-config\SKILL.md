---
name: api-test-config
description: API 测试配置管理。生成和维护 api-test.config.yaml 配置文件，管理测试环境、鉴权信息、覆盖率分类和执行参数。
---

# API 测试配置管理技能

## 调用方

- `api-test-orchestrator`：在 Phase 0 检查配置是否存在，不存在时调用本技能生成
- 用户直接调用：初始化或更新 API 测试配置

## 用途

为 API 测试体系提供统一的配置中心，所有 api-test-* 技能均从 `api-test.config.yaml` 读取配置。

---

## 执行流程

```
1. 检查 `tests/api-test/` 目录下是否已有 api-test.config.yaml
   ├─ 已存在 → 读取并展示当前配置，询问是否需要修改
   └─ 不存在 → 读取模板，交互式收集配置信息，生成配置文件
2. 收集必要信息：
   ├─ 后端 API 基础 URL（dev/staging/production）
   ├─ 鉴权方式（bearer/api-key/basic/custom）
   ├─ 鉴权凭据（登录端点、用户名密码、token 字段）
   └─ 测试输出路径确认
3. 基于模板生成 api-test.config.yaml
4. 验证配置文件 YAML 语法正确性
```

---

## 配置文件说明

### 文件路径

`tests/api-test/api-test.config.yaml`

### 配置项说明

参见模板文件：`template/api-test.config.yaml.template`

| 配置块 | 必填 | 说明 |
|--------|------|------|
| `version` | 是 | 配置版本号，当前为 `"1.0"` |
| `environments` | 是 | 环境配置（base_url、timeout_ms），至少配置 dev |
| `default_environment` | 是 | 默认使用的环境名称 |
| `auth` | 是 | 鉴权配置（type、凭据、token 提取） |
| `coverage` | 否 | 覆盖率目标配置（levels 和 types 的权重/通过率） |
| `execution` | 否 | 执行参数（并行数、重试次数、快速失败） |
| `output` | 否 | 输出路径配置（使用默认值即可） |

### 鉴权类型

| 类型 | 说明 | 配置要求 |
|------|------|---------|
| `bearer` | Bearer Token（先登录获取 token） | 需配置 `token_endpoint`、`credentials`、`token_field` |
| `api-key` | API Key 直接传递 | 需配置 `header_name`、`api_key` |
| `basic` | HTTP Basic Auth | 需配置 `credentials.username`、`credentials.password` |
| `custom` | 自定义鉴权 | 需在 conftest.py 中手动实现 |

### 环境变量支持

配置文件中支持 `{{ENV_VAR}}` 占位符语法，运行时从环境变量或 `.env` 文件中读取：

- `{{API_TEST_USER}}` → 测试用户名
- `{{API_TEST_PASSWORD}}` → 测试密码
- `{{API_TEST_BASE_URL}}` → 覆盖 base_url

---

## 输出

- `tests/api-test/api-test.config.yaml`：测试目录下的配置文件

---

## 约束

- 配置文件中不硬编码真实密码，使用环境变量占位符
- 生成前检查是否已有配置文件，避免覆盖用户自定义配置（查找路径：`tests/api-test/api-test.config.yaml`）
- 配置文件格式必须为合法 YAML
