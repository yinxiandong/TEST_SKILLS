---
name: rq-plan-runtime
description: 解析并运行需求开发计划，维护阶段状态、依赖校验与断点续跑。Use when requirement plan needs deterministic runtime state management and resumable execution.
---

# RQ 计划运行时

将 `10-需求开发计划表.md` 转换为可执行运行态，作为需求开发闭环的状态机基座。

## 输入

### 必需

- 需求标识：`{rq_id}`
- 计划真源：`docs/requirement/{rq_id}/10-需求开发计划表.md`

### 可选

- `--continue`：继续执行，读取历史运行态

## 输出（固定落盘）

路径：`.claude/notepads/{rq_id}/runtime-status.md`

锁文件：`.claude/notepads/{rq_id}/runtime-status.lock`

写入策略（硬性）：
- 任何更新 `runtime-status.md` 的动作必须先获取 `runtime-status.lock`
- 使用“写临时文件 -> 原子替换”的方式落盘，避免并发写坏文件
- 写入失败时保持旧文件不变，并记录失败原因

建议结构：

```markdown
# runtime-status

## meta
- rq: rq001-xxx
- plan_source: docs/requirement/rq001-xxx/10-需求开发计划表.md
- updated_at: 2026-02-10T00:00:00Z

## stages
| stage_id | stage_name | stage_slug | status | started_at | finished_at | retry_count |
|---|---|---|---|---|---|---|
| S1 | 基础设施准备 | infrastructure-setup | in_progress | ... | - | 1 |

## tasks
| task_id | stage_id | status | deps | note |
|---|---|---|---|---|
| T1 | S1 | completed | - | ... |
```

## 核心流程

### Step 1：计划解析

1. 读取计划文档并提取：任务、依赖、阶段、子任务、状态字段。
2. 为每个阶段生成稳定 `stage_slug`（英文语义翻译 + kebab-case，只生成一次，后续续跑复用）。
3. 若格式缺失关键字段，阻塞并输出最小补齐项。

### Step 2：依赖检查

1. 校验所有依赖指向的任务是否存在。
2. 进行环依赖检测（拓扑排序校验）。
3. 发现依赖异常时，状态标记 `blocked`，禁止继续开发。

### Step 3：初始化或恢复

1. 首次执行：按计划创建运行态并将首阶段置为 `in_progress`。
2. 续跑执行：读取现有运行态，定位第一个未完成阶段恢复。
3. 若运行态中缺失 `stage_slug`，阻塞并要求修复运行态数据。

### Step 4：状态推进

1. 阶段完成后更新阶段状态和时间戳。
2. 自动将下一阶段置为 `in_progress`。
3. 全阶段完成后将总状态置为 `completed`。

## 门禁

- 计划文件不可读/结构缺失：`blocked`
- 依赖环路：`blocked`
- 阶段内存在未完成 P0/P1 子任务：不得推进下一阶段
