---
name: remote-kafka-admin
description: "Kafka 管理插件技能（dev/test）。读取 .secrets/dev-servers.yaml 中 servers[].components.kafka 配置，通过 ssh 或 docker exec 在远端执行 kafka CLI：topic 列表/创建/删除/描述，consumer group 列表与 offset 重置。写入/破坏性动作需要 --confirm。"
---

# remote-kafka-admin

## 配置要求（写入 .secrets/dev-servers.yaml）

建议配置位置：`servers[].components.kafka`

最小字段（推荐）：

```json
{
  "enabled": true,
  "bootstrap_servers": "127.0.0.1:9092",
  "cli": {
    "mode": "ssh",
    "bin_dir": "/opt/kafka/bin",
    "docker_container": ""
  }
}
```

说明：
- `cli.mode=ssh`：通过 ssh 在远端执行 `{bin_dir}/kafka-topics.sh`、`{bin_dir}/kafka-consumer-groups.sh`。
- `cli.mode=docker`：在远端执行 `docker exec <container> ...`，此时可忽略 `bin_dir`（默认尝试 `/opt/kafka/bin`）。

## 用法

```bash
.codex/skills/remote-kafka-admin/scripts/kafka_admin.sh --server dev1 --action list-topics
.codex/skills/remote-kafka-admin/scripts/kafka_admin.sh --server dev1 --action create-topic --topic demo --partitions 3 --replication 1 --confirm
.codex/skills/remote-kafka-admin/scripts/kafka_admin.sh --server dev1 --action recreate-topic --topic demo --partitions 3 --replication 1 --confirm
.codex/skills/remote-kafka-admin/scripts/kafka_admin.sh --server dev1 --action reset-offsets --group demo-group --topic demo --to-earliest --confirm
.codex/skills/remote-kafka-admin/scripts/kafka_admin.sh --server dev1 --action list-topics --ssh-timeout 120
```
