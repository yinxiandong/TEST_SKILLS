---
name: mermaid-sequence-diagram
description: 将文本交互流程转为标准 mermaid 时序图（sequenceDiagram），用于需求分析/架构设计/特性设计等文档
version: 1.0
---

## 技能说明

本技能用于把“交互流程”以一致的格式落到 mermaid 时序图，减少不同 agent/工程师输出差异。

## 输入要求
- 参与方列表（用户/前端/后端服务/外部系统/数据库等）
- 关键交互步骤（按顺序，包含异常分支则标注）
- 幂等/重试/超时/降级（如有）

## 输出产物
- `sequenceDiagram` 片段（可嵌入 `{project_root}/docs/requirement/*/02-需求分析概要设计文档.md` 或 `{project_root}/docs/architecture/系统架构设计.md`）

## 工作流程
1. 归一化参与者命名（短名 + 可读别名）
2. 输出主流程（happy path）
3. 用 `alt/else` 输出关键异常分支
4. 在关键节点标注幂等/重试/超时语义（如适用）

## 输出示例

```mermaid
sequenceDiagram
    participant U as 用户
    participant F as 前端
    participant B as 后端服务
    participant DB as 数据库

    U->>F: 提交订单
    F->>B: POST /api/orders
    B->>DB: INSERT order

    alt 创建成功
        DB-->>B: order_id
        B-->>F: 201 Created
        F-->>U: 显示订单号
    else 库存不足
        DB-->>B: error
        B-->>F: 400 Bad Request
        F-->>U: 提示库存不足
    end

    Note over B,DB: 幂等键: order_token
```

