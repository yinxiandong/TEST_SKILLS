---
name: rq-auto-dev-orchestrator
description: 基于 prepare-rq 产物的需求开发总入口，协调计划执行、测试执行、缺陷修复、代码评审与收尾闭环。Use when running end-to-end requirement development workflow from plan to final closure.
---

# RQ 自动开发编排器（总入口）

用于 `/develop-rq` 阶段的统一入口：读取 `prepare-rq` 产物，按照固定流程协调多个技能执行，直到需求完成。

## 核心定位

- 唯一入口：开发阶段优先调用本技能。
- 唯一计划真源：`docs/requirement/{rq_id}/10-需求开发计划表.md`。
- 自动闭环：开发 → 测试 → 修复 → 评审 → 再测试，直到通过。
- 幂等续跑：中断后可依据运行态继续，不重复已完成工作。

## 输入契约

### 必需输入

| 输入项 | 路径 | 说明 |
|---|---|---|
| 需求标识 | `{rq_id}` | 运行标识 |
| 开发计划 | `docs/requirement/{rq_id}/10-需求开发计划表.md` | 唯一执行计划 |
| 测试设计 | `docs/requirement/{rq_id}/20-{stage_name}-需求测试设计.md` | 按阶段测试依据 |

### 可选输入

| 输入项 | 路径 | 说明 |
|---|---|---|
| 需求分析文档 | `docs/requirement/{rq_id}/02-需求分析概要设计文档.md` | 开发上下文 |
| 架构设计文档 | `docs/requirement/{rq_id}/03-需求分析架构设计.md` | 架构约束 |
| 需求澄清记录 | `docs/requirement/{rq_id}/00-原始需求澄清记录.md` | 边界与场景补充 |

## 过程数据目录（硬性）

所有中间数据统一写入：`.claude/notepads/{rq_id}/`

- `runtime-status.md`：运行状态机
- `runtime-status.lock`：运行态互斥锁
- `stage-{n}-execution.md`：阶段执行记录
- `test-report-{stage_slug}.md`：阶段测试报告
- `test-report-history-{stage_slug}.md`：阶段测试历史摘要（按轮次追加）
- `review-report-{stage_slug}.md`：阶段评审报告
- `review-history-{stage_slug}.md`：阶段评审历史摘要（按轮次追加）
- `review-summary.md`：评审汇总报告
- `final-delivery-report.md`：最终交付报告

禁止写入 `.omc/notepads/`。

## 协调的子技能

1. `rq-plan-runtime`：解析计划、推进阶段、维护状态
2. `rq-stage-test-executor`：执行阶段测试并落盘结果
3. `rq-defect-triage-fix-loop`：失败分诊、修复、回归
4. `rq-review-gatekeeper`：评审与门禁
5. `rq-delivery-closure`：最终收尾

### 辅助技能（按需调用）

- `ui-ux-pro-max`：涉及前端页面/组件开发的任务，必须调用此技能进行 UI/UX 设计与实现，确保界面质量
- `remote-dev-debug`：远端开发环境部署与调试，用于 E2E 验证阶段

## 执行流程

### Step 0：前置检查

1. 调用 `git-worktree-master` 检查当前是否位于需求工作区。
2. 验证计划文件存在：`10-需求开发计划表.md`。
3. 若前置缺失，立即阻塞并输出补齐清单。

### Step 1：初始化/恢复运行态

调用 `rq-plan-runtime`：
- 首次执行：创建 `runtime-status.md`。
- `--continue`：读取 `runtime-status.md` 并从第一个未完成阶段继续。
- 生成并固化 `stage_slug`（每个阶段唯一且稳定），后续所有报告文件名使用 `stage_slug`。

### Step 2：阶段执行循环

对 `runtime-status.md` 中每个未完成阶段按序执行：

1. 校验该阶段测试设计文档存在：`20-{stage_name}-需求测试设计.md`。
2. 按该阶段任务进行编码实现（遵循 `.claude/rules/**`）。
   - **前端任务识别**：当任务涉及前端页面、组件、样式开发时，必须调用 `ui-ux-pro-max` 技能进行 UI/UX 设计与实现，确保界面质量符合专业标准。
3. 调用 `rq-stage-test-executor` 执行该阶段测试。
   - **E2E 触发**：`rq-stage-test-executor` 在执行时，若发现阶段测试设计中存在 `test_type: e2e` 用例，将自动调用 `e2e-orchestrator`（层 1 阶段级 E2E）。
4. 若测试失败，调用 `rq-defect-triage-fix-loop` 修复并回归，然后重新执行阶段测试。
5. 测试通过后，调用 `rq-review-gatekeeper` 执行评审门禁，输出 `review-report-{stage_slug}.md`。
6. 若评审失败，调用 `rq-defect-triage-fix-loop` 修复并回归，再次执行“测试→评审”。
7. 测试与评审均通过后，标记阶段完成。

### Step 3：E2E 验证（双层策略）

**E2E 验证分两层执行：**

**层 1 - 阶段级 E2E（嵌入 Step 2 的阶段循环中）**：
- 触发条件：阶段测试设计中含 `test_type: e2e` 且已有可运行的应用
- 执行时机：`rq-stage-test-executor` 执行时自动触发（调用 `e2e-orchestrator`）
- 执行范围：仅该阶段新增/修改功能的 E2E 用例
- 目的：早期发现跨模块集成问题

**层 2 - 全量 E2E（所有阶段完成后）**：
- 触发条件：所有阶段开发 + 阶段测试均通过
- 执行步骤：
  1. 使用 `remote-dev-debug` 将代码部署到远端开发环境
  2. 调用 `e2e-orchestrator` 执行全量 E2E 回归（覆盖所有阶段的关键业务场景）
  3. 确保功能在真实远端环境下端到端联通
- 目的：验证全链路业务流程无回归
- E2E 验证失败：调用 `rq-defect-triage-fix-loop` 进入修复循环，修复后重新执行验证
- E2E 验证通过后方可进入最终收尾（Step 4）

### Step 4：最终收尾

当所有阶段完成且 E2E 远端验证通过后，调用 `rq-delivery-closure`，生成最终交付报告。

## 门禁规则

- 任一阶段存在未关闭的 P0/P1 问题：禁止推进下一阶段。
- 评审 Critical/Important 未清零：禁止收尾。
- 阶段测试未全部通过：禁止标记完成。
- 达到自动修复上限（默认每阶段 5 轮）仍失败：转人工升级。

## 证据保留策略（控量）

- 每阶段保留 1 份最新快照：`test-report-{stage_slug}.md`、`review-report-{stage_slug}.md`
- 轮次证据写入历史摘要：`test-report-history-{stage_slug}.md`、`review-history-{stage_slug}.md`
- 历史摘要按轮次追加，避免产生过多离散文件

## 输出

- `running`：流程进行中
- `blocked`：因输入缺失、依赖冲突或多轮失败阻塞
- `completed`：所有计划项完成、评审通过、测试通过
