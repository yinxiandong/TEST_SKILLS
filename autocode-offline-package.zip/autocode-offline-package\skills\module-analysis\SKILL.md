---
name: module-analysis
description: 深入分析子模块代码，输出AGENTS.md与开发规范Rules文档
model: opus
---

# Module Analysis

根据指定的模块`{module}`，完成模块深入分析，建立AI-readable文档体系，和AI-develop的Rules规则体系

## 输入

模块名称，模块位置

## 核心步骤

将下列步骤都生成task进行跟踪，**按照步骤顺序执行**，必须完成所有步骤才能结束任务，不在步骤中的不要执行

Step 1：子模块代码深度分析 Skill(oh-my-claudecode:deepinit)
Step 2：子模块架构分析 Skill(module-arch-extract) - addBlockedBy 1
Step 3：开发规范提取 Skill(update-claude-rules) - addBlockedBy 2

## 必要输入

**必须**: 指定分析的模块：{module}

## 执行流程

### 阶段1：子模块代码深度分析

在子模块根目录，调用 Skill: `oh-my-claudecode:deepinit`，传递 `{module}`。

说明：
- 若当前运行环境支持直接调用该 Skill，优先使用 `Skill(oh-my-claudecode:deepinit)`。
- 若不支持直接调用（或该 Skill 不可用），再使用 Task 调度可用的 explore/分析子代理完成等价动作，并在输出中标注“降级路径”。
```
Task(subagent_type="oh-my-claudecode:explore",
  prompt="/oh-my-claudecode:deepinit 对{module}模块深度初始化")

```

### 阶段2：子模块架构分析

在子模块根目录，调用Skill: module-arch-extract，传递{module}
```
Task(subagent_type="oh-my-claudecode:explore",
  prompt="/module-arch-extract 对{module}模块分析提取架构")

```

### 阶段3：开发规范提取

在子模块根目录，调用Skill: update-claude-rules，传递{module}
```
Task(subagent_type="oh-my-claudecode:explore",
  prompt="/update-claude-rules 对{module}模块提取开发规则")

```
