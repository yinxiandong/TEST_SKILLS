#!/usr/bin/env python3
import argparse
import json
import re
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urljoin


def load_json(path: Path) -> Dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise RuntimeError(f"JSON 顶层必须为对象: {path}")
    return data


def render_placeholders(value: Any, mapping: Dict[str, Any]) -> Any:
    if isinstance(value, str):
        exact = re.fullmatch(r"\{([A-Za-z0-9_]+)\}", value)
        if exact:
            k = exact.group(1)
            if k in mapping:
                return mapping[k]
        out = value
        for k, v in mapping.items():
            out = out.replace("{" + k + "}", str(v))
        return out
    if isinstance(value, list):
        return [render_placeholders(x, mapping) for x in value]
    if isinstance(value, dict):
        return {k: render_placeholders(v, mapping) for k, v in value.items()}
    return value


def get_json_path(data: Any, path: str) -> Any:
    current = data
    for token in path.split("."):
        if isinstance(current, dict):
            current = current[token]
            continue
        if isinstance(current, list) and token.isdigit():
            current = current[int(token)]
            continue
        raise KeyError(path)
    return current


def http_request(method: str, url: str, headers: Dict[str, str], body: Any, timeout: int) -> Tuple[int, Dict[str, str], str]:
    import urllib.error
    import urllib.request

    data_bytes = None
    if body is not None:
        if isinstance(body, (dict, list)):
            data_bytes = json.dumps(body, ensure_ascii=False).encode("utf-8")
            headers.setdefault("Content-Type", "application/json")
        elif isinstance(body, str):
            data_bytes = body.encode("utf-8")
        else:
            data_bytes = str(body).encode("utf-8")
    req = urllib.request.Request(url, data=data_bytes, method=method.upper())
    for k, v in headers.items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            text = resp.read().decode("utf-8", errors="replace")
            resp_headers = {k: v for k, v in resp.headers.items()}
            return int(getattr(resp, "status", 0) or 0), resp_headers, text
    except urllib.error.HTTPError as exc:
        text = (exc.read() or b"").decode("utf-8", errors="replace")
        resp_headers = {k: v for k, v in (exc.headers.items() if exc.headers else [])}
        return int(exc.code or 0), resp_headers, text


def load_server(config: Dict[str, Any], server_name: str) -> Dict[str, Any]:
    for s in config.get("servers") or []:
        if isinstance(s, dict) and s.get("name") == server_name:
            return s
    raise RuntimeError(f"未找到服务器: {server_name}")


def summarize(ok: bool, passed: int, failed: int, total: int) -> str:
    status = "PASS" if ok else "FAIL"
    return f"SUMMARY: {status} ({passed}/{total}, failed={failed})"


def main() -> None:
    parser = argparse.ArgumentParser(description="remote-api-debug: 批量接口调测")
    parser.add_argument("--server", required=True)
    parser.add_argument("--config", default=".secrets/dev-servers.yaml")
    parser.add_argument("--spec-file", required=True)
    parser.add_argument("--timeout", type=int, default=12)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--auth-mode", choices=["auto", "none", "token", "login"], default="auto")
    parser.add_argument("--token", default="")
    args = parser.parse_args()

    config_path = Path(args.config)
    spec_path = Path(args.spec_file)
    if not config_path.exists():
        raise SystemExit(f"[ERROR] 配置文件不存在: {config_path}")
    if not spec_path.exists():
        raise SystemExit(f"[ERROR] spec 文件不存在: {spec_path}")

    config = load_json(config_path)
    server = load_server(config, args.server)
    ssh = server.get("ssh") if isinstance(server.get("ssh"), dict) else {}
    host = str(ssh.get("host") or server.get("host") or "")
    if not host:
        raise SystemExit("[ERROR] server.ssh.host 为空")

    spec = load_json(spec_path)
    mapping = {
        "host": host,
        "server": args.server,
    }
    spec = render_placeholders(spec, mapping)
    base_url = str(spec.get("base_url") or "").strip()
    if not base_url:
        raise SystemExit("[ERROR] spec.base_url 必填")

    auth = spec.get("auth") if isinstance(spec.get("auth"), dict) else {}
    spec_auth_mode = str(auth.get("mode") or "none")
    mode = spec_auth_mode
    if args.auth_mode != "auto":
        mode = args.auth_mode
    if mode == "token" and args.token:
        auth = {**auth, "token": args.token}
    if mode not in {"none", "token", "login"}:
        mode = "none"

    token_value = ""
    token_scheme = "Bearer"
    if mode == "token":
        token_value = str(auth.get("token") or "").strip()
        token_scheme = str(auth.get("token_scheme") or "Bearer")
        if not token_value:
            raise SystemExit("[ERROR] auth.mode=token 但 token 为空")

    if mode == "login":
        login = auth.get("login") if isinstance(auth.get("login"), dict) else {}
        login_url = str(login.get("url") or "").strip()
        token_path = str(login.get("token_path") or "").strip()
        token_scheme = str(login.get("token_scheme") or "Bearer")
        if not login_url or not token_path:
            raise SystemExit("[ERROR] auth.mode=login 需要 auth.login.url 与 auth.login.token_path")
        if args.dry_run:
            print("[PLAN] login -> get token -> run cases")
        else:
            status, headers, text = http_request(
                str(login.get("method") or "POST"),
                login_url,
                {k: str(v) for k, v in (login.get("headers") or {}).items()} if isinstance(login.get("headers"), dict) else {},
                login.get("body"),
                args.timeout,
            )
            if status < 200 or status >= 400:
                raise SystemExit(f"[ERROR] 登录失败: status={status}, body={text[:300]}")
            try:
                obj = json.loads(text)
            except Exception as exc:
                raise SystemExit(f"[ERROR] 登录返回非 JSON: {exc}")
            try:
                token_value = str(get_json_path(obj, token_path))
            except Exception as exc:
                raise SystemExit(f"[ERROR] token_path 提取失败: {exc}")
            if not token_value:
                raise SystemExit("[ERROR] 提取到的 token 为空")

    cases = spec.get("cases") if isinstance(spec.get("cases"), list) else []
    if not cases:
        raise SystemExit("[ERROR] spec.cases 不能为空")

    passed = 0
    failed = 0
    total = 0

    for case in cases:
        if not isinstance(case, dict):
            continue
        total += 1
        name = str(case.get("name") or f"case-{total}")
        method = str(case.get("method") or "GET").upper()
        path = str(case.get("path") or "/")
        url = path if path.startswith("http://") or path.startswith("https://") else urljoin(base_url.rstrip("/") + "/", path.lstrip("/"))

        headers: Dict[str, str] = {}
        if isinstance(spec.get("default_headers"), dict):
            headers.update({k: str(v) for k, v in spec.get("default_headers").items()})
        if isinstance(case.get("headers"), dict):
            headers.update({k: str(v) for k, v in case.get("headers").items()})
        if token_value:
            headers["Authorization"] = f"{token_scheme} {token_value}"

        body = case.get("body")
        expect = case.get("expect") if isinstance(case.get("expect"), dict) else {}
        exp_status = expect.get("status", 200)
        exp_contains = str(expect.get("contains") or "")

        if args.dry_run:
            print(f"[PLAN][{name}] {method} {url}")
            passed += 1
            continue

        status, resp_headers, text = http_request(method, url, headers, body, args.timeout)
        ok = True
        if isinstance(exp_status, list):
            ok = status in [int(x) for x in exp_status]
        else:
            ok = status == int(exp_status)
        if ok and exp_contains:
            ok = exp_contains in text

        if ok:
            passed += 1
            print(f"[PASS] {name} status={status} url={url}")
        else:
            failed += 1
            print(f"[FAIL] {name} status={status} url={url}")
            print(text[:600])

    ok_all = failed == 0
    print(summarize(ok_all, passed, failed, total))
    sys.exit(0 if ok_all else 2)


if __name__ == "__main__":
    main()

