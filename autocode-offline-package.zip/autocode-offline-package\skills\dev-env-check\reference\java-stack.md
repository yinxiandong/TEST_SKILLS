# Java 技术栈检查参考

> 本文档是 dev-env-check 技能的参考文档，包含 Java 技术栈的详细检查流程。

## 识别特征

| 配置文件 | 构建工具 | 说明 |
|----------|----------|------|
| `pom.xml` | Maven | Maven 项目 |
| `build.gradle` / `build.gradle.kts` | Gradle | Gradle 项目 |

## 检查项

- JDK 版本和安装路径
- Maven 或 Gradle 版本
- JAVA_HOME 环境变量
- Maven 本地仓库配置

## 检查命令

```bash
# 检查 Java 版本
java -version 2>&1
javac -version 2>&1

# 检查 JAVA_HOME
echo $JAVA_HOME

# 检查 Maven
mvn -version 2>&1

# 检查 Gradle
gradle -version 2>&1

# 检查 Maven 配置
cat ~/.m2/settings.xml 2>/dev/null || echo "Maven settings.xml 不存在"
```

## 版本要求提取

从项目配置文件中提取版本要求：

### Maven (pom.xml)

```xml
<!-- 常见位置 -->
<maven.compiler.source>11</maven.compiler.source>
<maven.compiler.target>11</maven.compiler.target>
<!-- 或 -->
<java.version>17</java.version>
<!-- 或 -->
<release>17</release>
```

### Gradle (build.gradle)

```groovy
// Groovy DSL
sourceCompatibility = '17'
targetCompatibility = '17'
// 或
java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(17)
    }
}
```

```kotlin
// Kotlin DSL (build.gradle.kts)
java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
}
```

## 期望结果

- Java 版本符合项目要求（从 pom.xml 的 `<maven.compiler.source>` 读取）
- Maven 或 Gradle 可正常执行
- JAVA_HOME 正确配置

## 构建命令

| 构建文件 | 构建命令 | 说明 |
|----------|----------|------|
| pom.xml | `mvn compile -DskipTests` | 编译但跳过测试 |
| build.gradle | `./gradlew build -x test` | 构建但跳过测试 |

**优先级**: 如果同时存在 pom.xml 和 build.gradle，优先使用 pom.xml

## 常见问题

### JAVA_HOME 未配置

**症状**: `JAVA_HOME is not set`

**解决方案**:
```bash
# Linux
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk

# macOS
export JAVA_HOME=$(/usr/libexec/java_home -v 17)

# 添加到 ~/.bashrc 或 ~/.zshrc
echo 'export JAVA_HOME=/usr/lib/jvm/java-17-openjdk' >> ~/.bashrc
source ~/.bashrc
```

### Maven 私服配置

如果项目使用私有 Maven 仓库，需要检查 `~/.m2/settings.xml` 配置：

```xml
<settings>
  <servers>
    <server>
      <id>private-repo</id>
      <username>username</username>
      <password>password</password>
    </server>
  </servers>
  <mirrors>
    <mirror>
      <id>private-mirror</id>
      <mirrorOf>central</mirrorOf>
      <url>https://private.repo.com/maven</url>
    </mirror>
  </mirrors>
</settings>
```

### 多 JDK 版本管理

推荐使用 SDKMAN 管理多个 JDK 版本：

```bash
# 安装 SDKMAN
curl -s "https://get.sdkman.io" | bash
source "$HOME/.sdkman/bin/sdkman-init.sh"

# 安装指定版本 JDK
sdk install java 17.0.9-tem

# 切换版本
sdk use java 17.0.9-tem
sdk default java 17.0.9-tem
```

## 安装方式

### 包管理器

```bash
# Ubuntu/Debian
sudo apt install openjdk-17-jdk maven

# CentOS/RHEL
sudo yum install java-17-openjdk-devel maven

# macOS
brew install openjdk@17 maven

# Windows
choco install openjdk17 maven
```

### 官方下载

- Oracle JDK: https://www.oracle.com/java/technologies/downloads/
- OpenJDK: https://adoptium.net/
- Maven: https://maven.apache.org/download.cgi
- Gradle: https://gradle.org/releases/
