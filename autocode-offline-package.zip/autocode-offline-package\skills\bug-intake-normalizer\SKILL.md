---
name: bug-intake-normalizer
description: 将人工输入的缺陷信息标准化为结构化缺陷输入文档并执行最小完整性校验。Use when receiving a new bug report and needing to normalize raw issue input into a consistent document.
---

# Bug Intake Normalizer

负责将人工输入的 bug 信息规范化并落盘到 `00-缺陷原始输入.md`。

## 输入

- `bug_id`：`{bug_id}`
- `bug_input`：人工输入文本
- 可选：`target_env`、`reporter`、`priority`

## 输出

- `docs/bugfix/{bug_id}/00-缺陷原始输入.md`

## 最小字段校验（硬性）

以下字段缺一则阻塞：
- 缺陷现象
- 影响范围
- 复现步骤（至少 1 条）
- 期望结果
- 实际结果

## 模板引用

- `references/00-bug-input-template.md`

## 处理流程

1. 读取人工输入并抽取结构化字段。
2. 按模板落盘 `00-缺陷原始输入.md`。
3. 缺失字段输出“补齐清单”并返回 `blocked`。
