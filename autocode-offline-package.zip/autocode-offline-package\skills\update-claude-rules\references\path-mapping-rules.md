# 路径匹配规则详细说明

本文档详细说明了如何根据规范文档的位置、名称和内容，智能推断适用的文件路径 glob 模式。

## 核心推断逻辑

路径匹配规则的推断遵循以下优先级：
1. **目录位置** - 规范文档所在的目录名称
2. **文件名称** - 规范文档的文件名
3. **内容关键词** - 规范文档中的技术栈和领域关键词
4. **默认规则** - 通用的代码文件匹配模式

## 基于目录位置的推断

### 前端相关目录

| 目录模式 | 推断的 paths | 说明 |
|---------|-------------|------|
| `frontend/` | `src/**/*.{ts,tsx,js,jsx,vue}` | 前端代码文件 |
| `ui/` | `src/**/*.{tsx,jsx,vue}` | UI 组件文件 |
| `components/` | `src/components/**/*` | 组件目录 |
| `pages/` | `src/pages/**/*` | 页面目录 |

### 后端相关目录

| 目录模式 | 推断的 paths | 说明 |
|---------|-------------|------|
| `backend/` | `src/**/*.{java,py,go,rs,php}` | 后端代码文件 |
| `server/` | `src/**/*.{java,py,go,rs}` | 服务端代码 |
| `api/` | `src/api/**/*` | API 相关文件 |
| `services/` | `src/services/**/*` | 服务层文件 |

### 数据库相关目录

| 目录模式 | 推断的 paths | 说明 |
|---------|-------------|------|
| `database/` | `{src/**/*.sql,migrations/**/*}` | 数据库文件 |
| `migrations/` | `migrations/**/*` | 数据库迁移 |
| `schema/` | `{src/**/*.sql,schema/**/*}` | 数据库模式 |

### 测试相关目录

| 目录模式 | 推断的 paths | 说明 |
|---------|-------------|------|
| `testing/` | `{tests/**/*,**/*.test.*,**/*.spec.*}` | 测试文件 |
| `test/` | `{tests/**/*,**/*.test.*}` | 测试文件 |

### 安全和通用目录

| 目录模式 | 推断的 paths | 说明 |
|---------|-------------|------|
| `security/` | `**/*` | 安全规范适用所有文件 |
| `general/` | 不添加 paths | 通用规范 |
| `common/` | 不添加 paths | 通用规范 |

## 基于文件名称的推断

### 语言特定规范

| 文件名模式 | 推断的 paths | 说明 |
|-----------|-------------|------|
| `*typescript*.md` | `**/*.{ts,tsx}` | TypeScript 文件 |
| `*javascript*.md` | `**/*.{js,jsx}` | JavaScript 文件 |
| `*python*.md` | `**/*.py` | Python 文件 |
| `*java*.md` | `**/*.java` | Java 文件 |
| `*go*.md` | `**/*.go` | Go 文件 |
| `*rust*.md` | `**/*.rs` | Rust 文件 |

### 框架特定规范

| 文件名模式 | 推断的 paths | 说明 |
|-----------|-------------|------|
| `*react*.md` | `src/**/*.{tsx,jsx}` | React 组件 |
| `*vue*.md` | `src/**/*.vue` | Vue 组件 |
| `*angular*.md` | `src/**/*.{ts,html}` | Angular 文件 |
| `*spring*.md` | `src/**/*.java` | Spring 项目 |
| `*django*.md` | `**/*.py` | Django 项目 |

### 领域特定规范

| 文件名模式 | 推断的 paths | 说明 |
|-----------|-------------|------|
| `*api*.md` | `src/api/**/*` | API 相关 |
| `*component*.md` | `src/components/**/*` | 组件相关 |
| `*style*.md` | `**/*.{css,scss,less}` | 样式文件 |
| `*test*.md` | `{tests/**/*,**/*.test.*}` | 测试文件 |

## 基于内容关键词的推断

### 技术栈关键词

扫描规范文档内容，识别以下关键词：

**前端技术栈**：
- `React`, `Vue`, `Angular` → 前端框架文件
- `Component`, `组件` → 组件目录
- `TypeScript`, `JavaScript` → 对应语言文件

**后端技术栈**：
- `Spring`, `Django`, `Express` → 后端框架文件
- `API`, `Endpoint`, `接口` → API 目录
- `Service`, `服务` → 服务层目录

**数据库技术栈**：
- `SQL`, `Database`, `数据库` → 数据库文件
- `Migration`, `迁移` → 迁移文件
- `Schema`, `模式` → 模式文件

## 路径模式组合规则

### 使用大括号语法

当规范适用于多个不同的路径模式时，使用大括号组合：

```yaml
paths: {src/**/*.sql,migrations/**/*}
```

### 使用逗号分隔

当规范适用于多个独立的模式时，使用逗号分隔：

```yaml
paths: tests/**/*,**/*.test.*,**/*.spec.*
```

### 文件扩展名组合

使用大括号组合多个文件扩展名：

```yaml
paths: src/**/*.{ts,tsx,js,jsx}
```

## 特殊情况处理

### 通用规范（不添加 paths）

以下情况不添加 `paths` 字段，规范适用于所有文件：
- 文件名包含 `general`、`common`、`universal`
- 目录名为 `general/`、`common/`
- 规范内容明确说明适用于所有文件
- 安全规范（`security/`）

### 多语言项目

如果项目包含多种编程语言，根据规范的具体内容选择：
- 如果规范明确针对某种语言，只匹配该语言文件
- 如果规范是通用编码规范，匹配所有代码文件

### 单体仓库（Monorepo）

对于单体仓库，路径模式应该更加精确：
- 使用 `packages/*/src/**/*.ts` 匹配所有包的 TypeScript 文件
- 使用 `apps/*/src/**/*.tsx` 匹配所有应用的 React 文件

## 推断算法伪代码

```python
def infer_paths_pattern(spec_file_path, spec_content):
    """
    推断规范文档的路径匹配模式

    Args:
        spec_file_path: 规范文档相对于 docs/specification/ 的路径
        spec_content: 规范文档的内容

    Returns:
        paths 模式字符串，如果是通用规范则返回 None
    """

    # 1. 从目录位置推断
    dir_name = get_parent_directory(spec_file_path)
    if dir_name in DIRECTORY_PATTERNS:
        return DIRECTORY_PATTERNS[dir_name]

    # 2. 从文件名推断
    file_name = get_filename(spec_file_path)
    for pattern, paths in FILENAME_PATTERNS.items():
        if pattern in file_name.lower():
            return paths

    # 3. 从内容关键词推断
    keywords = extract_keywords(spec_content)
    if has_frontend_keywords(keywords):
        return 'src/**/*.{ts,tsx,js,jsx,vue}'
    elif has_backend_keywords(keywords):
        return 'src/**/*.{java,py,go,rs}'
    elif has_database_keywords(keywords):
        return '{src/**/*.sql,migrations/**/*}'

    # 4. 检查是否为通用规范
    if is_general_spec(file_name, spec_content):
        return None  # 不添加 paths 字段

    # 5. 默认规则
    return '**/*.{ts,tsx,js,jsx,py,java,go,rs}'
```

## 验证和调整

生成的路径模式应该：
1. **准确性**：确保匹配预期的文件类型
2. **完整性**：不遗漏应该匹配的文件
3. **精确性**：不匹配不相关的文件
4. **可读性**：模式清晰易懂

建议在生成后进行人工审查和调整。
