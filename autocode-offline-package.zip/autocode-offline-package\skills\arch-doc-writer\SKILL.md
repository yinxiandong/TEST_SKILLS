---
name: arch-doc-writer
description: 将架构设计师已决策的架构结论按模板标准化落盘到目标项目 docs（需求级架构设计、arch_design、ADR、子系统文档、API、测试），聚焦“写到哪里/如何命名/结构一致/可追溯”，不承担方案取舍
version: 1.0
---

## 技能概述

本技能解决“写到哪里、怎么命名、如何保持一致性”的问题：把**架构设计师已经做出的结论**按项目规约写入目标项目文档树，并确保引用关系可追溯。

## 输入
- 需求分析概要设计文档（需求分析师传递）
- 目标项目根目录（`{project_root}/`）
- 需求目录（根据概要设计文档所在目录识别需求目录）
- 涉及的子系统列表（如 `${auth}`、`${device}` 等）

## 输出（落盘位置）
- `{project_root}/docs/requirement/{rq_id}/03-需求分析架构设计.md`（需求级架构设计，记录本需求的架构调整细节，不写代码）

## 模板引用
- 需求级架构设计模板：`template/requirement_arch_design_template.md`
- 架构检查表：`template/checklist_template.md`（用于质量自检）

## 工作流程

### 1) 选择模板（优先复制模板再填充）
- 需求级架构设计模板：`template/requirement_arch_design_template.md`

### 2) 生成/更新需求级架构设计文档
在 `{project_root}/docs/requirement/{rq_id}/03-需求分析架构设计.md` 中写清（按模板）：
- 架构介入原因与现状约束
- 至少两案（最小改动 vs 演进）与取舍结论
- 架构调整细节（模块边界/接口契约/数据与存储/可观测性/回滚）
- 影响评估与测试策略（与架构师结论一致）

### 3) 引用与可追溯
在文档中明确引用：
- 相关需求目录：`{project_root}/docs/requirement/rqXXX-*/`
- 需求开发目录：`{project_root}/docs/develop/`
- 相关测试文档：`{project_root}/docs/test/*`

### 4) 质量自检
使用 `template/checklist_template.md` 进行质量检查：
- 架构完整性检查
- 方案对比完备性
- 影响评估覆盖度
- 测试策略充分性
- 文档可追溯性

## 失败与缺失处理
- 若目标项目未建立 `docs/`：终止执行，提示需要先对项目进行初始化。
- 若仅允许补充而不允许改结构：保持现有章节，追加“本次变更”小节并标注差异点。
