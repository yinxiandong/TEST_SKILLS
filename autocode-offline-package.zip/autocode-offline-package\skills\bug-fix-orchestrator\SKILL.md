---
name: bug-fix-orchestrator
description: 缺陷修复工作流总入口，协调缺陷标准化、根因方案、代码修复、远程验证、文档回填与评审收尾。Use when running end-to-end bug fix workflow from intake to human handoff.
---

# Bug Fix Orchestrator

用于 `/fix-bug` 阶段的统一入口。该技能负责编排完整 bug-fix 闭环流程，并支持 `execution_mode + resume` 执行。

## 核心定位

- 命令入口唯一编排技能。
- 文档真源目录：`docs/bugfix/{bug_id}/`
- 过程目录：`.claude/notepads/{bug_id}/`
- 远程调试统一调用主技能：`remote-dev-debug`

## 输入契约

### 必需输入

| 输入项 | 说明 |
|---|---|
| `bug_id` | 缺陷标识，格式 `{bug_id}` |
| `execution_mode` | `default|analyze-only|fix-only|verify-only` |
| `resume` | `true|false`，由命令层 `--continue` 映射 |

### 可选输入

| 输入项 | 说明 |
|---|---|
| `bug_input` | 人工补充缺陷描述（现象、环境、复现步骤） |
| `target_env` | 验证环境（如 dev/staging） |

## 输出产物

目录：`docs/bugfix/{bug_id}/`

- `00-缺陷原始输入.md`
- `10-根因修复与同类排查.md`
- `20-修复实施记录.md`
- `30-远程验证报告.md`
- `90-人工核对清单.md`

过程状态：`.claude/notepads/{bug_id}/runtime-status.md`

## 状态机

- `running`
- `blocked`
- `need_human_check`
- `completed`

## 运行态写入规则（硬性）

- 运行态文件：`.claude/notepads/{bug_id}/runtime-status.md`
- 锁文件：`.claude/notepads/{bug_id}/runtime-status.lock`
- 任何更新运行态前必须先获取锁
- 写入使用“临时文件 -> 原子替换”，失败时保持旧文件不变

## 编排子技能

1. `bug-intake-normalizer`
2. `bug-rca-plan`
3. `bug-fix-implementer`
4. `bug-verify-runner`
5. `bug-review-closure`

## 执行流程

### Step 0：前置检查

1. 检查缺陷目录是否存在，不存在则初始化目录结构。
2. 检查过程目录并初始化 `runtime-status.md` 与 `runtime-status.lock`。
3. 若 `resume=true`，读取状态并从首个未完成步骤恢复。

### Step 1：标准化输入

调用 `bug-intake-normalizer` 生成/更新 `00-缺陷原始输入.md`。

### Step 2：根因与修复方案

调用 `bug-rca-plan` 生成 `10-根因修复与同类排查.md`（初版）。

### Step 3：代码修复

调用 `bug-fix-implementer` 执行修复，输出 `20-修复实施记录.md`。

### Step 4：远程验证

调用 `bug-verify-runner`，由其统一调用 `remote-dev-debug`，输出 `30-远程验证报告.md`。

### Step 5：文档回填

调用 `bug-rca-plan` 回填最终根因与同类排查结果到 `10-根因修复与同类排查.md`。

### Step 6：评审收尾

调用 `bug-review-closure` 完成评审门禁与人工核对清单生成。

## 子模式规则

- `execution_mode=analyze-only`：执行 Step 1~2。
- `execution_mode=fix-only`：执行 Step 3~5，要求已存在 `10-根因修复与同类排查.md`。
- `execution_mode=verify-only`：执行 Step 4~6，要求已存在 `20-修复实施记录.md`。

## 门禁规则

- 远程验证失败：状态 `blocked`，必须回到 Step 2 或 Step 3。
- 评审 Critical/Important 未清零：状态 `blocked`。
- 收尾通过后输出 `need_human_check`，不自动提交代码。

## 人工核对后状态更新

人工完成核对并提交后，更新 `runtime-status.md`：
- `status: completed`
- `completed_by: <human>`
- `completed_at: <timestamp>`
