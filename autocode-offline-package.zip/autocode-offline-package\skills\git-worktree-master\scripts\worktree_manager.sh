#!/bin/bash
# Git Worktree Manager for Requirement-Based Development
# 用于需求开发工作流的 Git Worktree 管理工具

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 辅助函数
print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

# 检查是否在 Git 仓库根目录
check_git_root() {
    if [ ! -d ".git" ]; then
        print_error "不在 Git 仓库根目录"
        exit 1
    fi
}

# 获取项目名称
get_project_name() {
    basename "$(pwd)"
}

# 创建需求工作区
create_requirement_worktree() {
    local req_id="$1"

    if [ -z "$req_id" ]; then
        print_error "请提供需求标识，格式：rqXXX-需求名"
        echo "示例：$0 create rq001-s3-storage-manage"
        exit 1
    fi

    check_git_root

    local project_name=$(get_project_name)
    local worktree_path="../${project_name}-${req_id}"

    print_info "开始创建需求工作区..."
    print_info "需求标识：${req_id}"
    print_info "工作区路径：${worktree_path}"

    # 检查工作区是否已存在
    if [ -d "${worktree_path}" ]; then
        print_error "工作区已存在：${worktree_path}"
        exit 1
    fi

    # 检查分支是否已存在
    if git branch --list "${req_id}" | grep -q "${req_id}"; then
        print_warning "分支已存在：${req_id}"
        read -p "是否使用已有分支创建工作区？(y/n) " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            git worktree add "${worktree_path}" "${req_id}"
        else
            exit 1
        fi
    else
        # 创建新分支和工作区
        git worktree add "${worktree_path}" -b "${req_id}"
    fi

    print_success "工作区创建成功"

    # 进入工作区
    cd "${worktree_path}"
    print_info "已进入工作区：$(pwd)"

    # 初始化子模块
    if [ -f ".gitmodules" ]; then
        print_info "初始化子模块..."
        git submodule update --init --recursive

        # 为所有子模块创建同名分支
        print_info "为子模块创建需求分支..."
        git submodule foreach "git checkout -b ${req_id} 2>/dev/null || git checkout ${req_id}"

        print_success "子模块分支创建完成"
    else
        print_info "项目无子模块"
    fi

    # 显示状态
    echo ""
    print_success "需求工作区创建完成！"
    echo ""
    show_worktree_status
}

# 切换到需求工作区
switch_to_requirement_worktree() {
    local req_id="$1"

    if [ -z "$req_id" ]; then
        print_error "请提供需求标识"
        echo "示例：$0 switch rq001-s3-storage-manage"
        exit 1
    fi

    check_git_root

    local project_name=$(get_project_name)
    local worktree_path="../${project_name}-${req_id}"

    if [ ! -d "${worktree_path}" ]; then
        print_error "工作区不存在：${worktree_path}"
        print_info "使用 '$0 create ${req_id}' 创建工作区"
        exit 1
    fi

    # 检查当前工作区是否有未提交修改
    if [ -n "$(git status --porcelain)" ]; then
        print_warning "当前工作区有未提交的修改："
        git status --short
        read -p "是否继续切换？(y/n) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi

    cd "${worktree_path}"
    print_success "已切换到需求工作区：${worktree_path}"

    # 显示状态
    show_worktree_status
}

# 显示工作区状态
show_worktree_status() {
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "📍 当前目录：$(pwd)"
    echo "🌿 主项目分支：$(git branch --show-current)"

    local changes=$(git status --porcelain | wc -l)
    if [ "$changes" -gt 0 ]; then
        echo "📊 工作区状态：${changes} 个文件有修改"
        git status --short | head -10
        if [ "$changes" -gt 10 ]; then
            echo "   ... 还有 $((changes - 10)) 个文件"
        fi
    else
        echo "📊 工作区状态：干净"
    fi

    if [ -f ".gitmodules" ]; then
        echo ""
        echo "🔗 子模块状态："
        git submodule foreach --quiet 'echo "  - $(basename $sm_path): $(git branch --show-current)"'
    fi
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

# 列出所有工作区
list_worktrees() {
    check_git_root

    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "📋 所有工作区列表："
    echo ""
    git worktree list
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

# 清理需求工作区
cleanup_requirement_worktree() {
    local req_id="$1"
    local force="${2:-false}"

    if [ -z "$req_id" ]; then
        print_error "请提供需求标识"
        echo "示例：$0 cleanup rq001-s3-storage-manage"
        exit 1
    fi

    check_git_root

    local project_name=$(get_project_name)
    local worktree_path="../${project_name}-${req_id}"

    print_warning "准备清理需求工作区：${req_id}"

    if [ "$force" != "true" ]; then
        read -p "确认删除工作区和分支？(y/n) " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            print_info "已取消"
            exit 0
        fi
    fi

    # 删除 worktree
    if git worktree list | grep -q "${worktree_path}"; then
        print_info "删除工作区：${worktree_path}"
        git worktree remove "${worktree_path}" --force
        print_success "工作区已删除"
    else
        print_warning "工作区不存在：${worktree_path}"
    fi

    # 删除主项目分支
    if git branch --list "${req_id}" | grep -q "${req_id}"; then
        print_info "删除主项目分支：${req_id}"
        if git branch -d "${req_id}" 2>/dev/null; then
            print_success "分支已删除"
        else
            print_warning "分支未合并，使用 -D 强制删除"
            read -p "是否强制删除？(y/n) " -n 1 -r
            echo
            if [[ $REPLY =~ ^[Yy]$ ]]; then
                git branch -D "${req_id}"
                print_success "分支已强制删除"
            fi
        fi
    else
        print_warning "分支不存在：${req_id}"
    fi

    # 清理子模块分支
    if [ -f ".gitmodules" ]; then
        print_info "清理子模块分支..."
        git submodule foreach "git branch -d ${req_id} 2>/dev/null && echo '✅ 已删除分支' || echo '⚠️  分支未合并或不存在'"
    fi

    print_success "清理完成"
}

# 检查工作区状态（详细）
check_worktree_status() {
    local req_id="$1"

    if [ -z "$req_id" ]; then
        # 检查当前工作区
        show_worktree_status
    else
        # 检查指定需求的工作区
        check_git_root
        local project_name=$(get_project_name)
        local worktree_path="../${project_name}-${req_id}"

        if [ ! -d "${worktree_path}" ]; then
            print_error "工作区不存在：${worktree_path}"
            exit 1
        fi

        cd "${worktree_path}"
        show_worktree_status
    fi
}

# 显示帮助信息
show_help() {
    cat << EOF
Git Worktree Manager - 需求开发工作流工具

用法：
    $0 <command> [options]

命令：
    create <req_id>         创建需求工作区
                           示例：$0 create rq001-s3-storage-manage

    switch <req_id>         切换到需求工作区
                           示例：$0 switch rq001-s3-storage-manage

    status [req_id]         显示工作区状态
                           示例：$0 status
                           示例：$0 status rq001-s3-storage-manage

    list                    列出所有工作区
                           示例：$0 list

    cleanup <req_id>        清理需求工作区和分支
                           示例：$0 cleanup rq001-s3-storage-manage

    help                    显示此帮助信息

需求标识格式：
    rqXXX-需求名
    示例：rq001-s3-storage-manage

工作流程：
    1. 需求分析前：$0 create rq001-xxx
    2. 开发准备：   $0 switch rq001-xxx
    3. 开发实施：   在工作区内进行开发
    4. 需求完成：   $0 cleanup rq001-xxx

EOF
}

# 主函数
main() {
    local command="${1:-help}"

    case "$command" in
        create)
            create_requirement_worktree "$2"
            ;;
        switch)
            switch_to_requirement_worktree "$2"
            ;;
        status)
            check_worktree_status "$2"
            ;;
        list)
            list_worktrees
            ;;
        cleanup)
            cleanup_requirement_worktree "$2" "$3"
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            print_error "未知命令：$command"
            echo ""
            show_help
            exit 1
            ;;
    esac
}

# 执行主函数
main "$@"
