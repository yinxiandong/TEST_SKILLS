# Docker 环境检查参考

> 本文档是 dev-env-check 技能的参考文档，包含 Docker 环境的详细检查流程。

## 识别特征

| 配置文件 | 说明 |
|----------|------|
| `Dockerfile` | Docker 镜像定义 |
| `docker-compose.yml` / `docker-compose.yaml` | Docker Compose 配置 |
| `compose.yml` / `compose.yaml` | Docker Compose V2 配置 |
| `.dockerignore` | Docker 构建忽略文件 |

## 检查项

- Docker 版本
- Docker Compose 版本
- Docker 服务状态
- 用户权限

## 检查命令

```bash
# 检查 Docker 版本
docker --version 2>&1

# 检查 Docker Compose 版本（V2）
docker compose version 2>&1

# 检查 Docker Compose 版本（V1，已弃用）
docker-compose --version 2>&1

# 检查 Docker 服务状态
docker info 2>&1

# 检查当前用户是否在 docker 组
groups | grep docker

# 测试 Docker 运行
docker ps 2>&1

# 测试 Docker 镜像拉取
docker pull hello-world 2>&1

# 运行测试容器
docker run --rm hello-world 2>&1
```

## 期望结果

- Docker 服务正常运行
- 用户有执行 Docker 命令的权限
- Docker Compose 版本匹配

## 构建命令

| 场景 | 构建命令 | 说明 |
|------|----------|------|
| 构建镜像 | `docker build -t app .` | 构建 Docker 镜像 |
| Compose 启动 | `docker compose up -d` | 启动所有服务 |
| Compose 构建 | `docker compose build` | 构建 Compose 服务 |

## 常见问题

### Docker 服务未启动

```bash
# Linux - 启动 Docker 服务
sudo systemctl start docker
sudo systemctl enable docker  # 开机自启

# 检查状态
sudo systemctl status docker

# macOS/Windows
# 启动 Docker Desktop 应用
```

### 权限问题

```bash
# 将当前用户添加到 docker 组
sudo usermod -aG docker $USER

# 刷新组（避免重新登录）
newgrp docker

# 或重新登录使组生效
# 注意：添加到 docker 组相当于授予 root 权限
```

### Docker Compose V1 vs V2

```bash
# Docker Compose V2（推荐）- 作为 Docker 插件
docker compose version
docker compose up -d

# Docker Compose V1（已弃用）- 独立命令
docker-compose --version
docker-compose up -d

# 如果需要兼容性，可以创建别名
alias docker-compose='docker compose'
```

### 镜像拉取超时

```bash
# 配置 Docker 镜像加速器
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json <<EOF
{
    "registry-mirrors": [
        "https://docker.mirrors.ustc.edu.cn",
        "https://hub-mirror.c.163.com"
    ]
}
EOF

# 重启 Docker
sudo systemctl daemon-reload
sudo systemctl restart docker

# 验证配置
docker info | grep -A 5 "Registry Mirrors"
```

### 磁盘空间不足

```bash
# 查看 Docker 磁盘使用
docker system df

# 清理未使用的资源
docker system prune -a

# 清理悬空镜像
docker image prune

# 清理未使用的卷
docker volume prune

# 清理构建缓存
docker builder prune
```

## 安装方式

### Linux (Ubuntu/Debian)

```bash
# 使用官方脚本安装（推荐）
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# 配置用户权限
sudo usermod -aG docker $USER
newgrp docker

# 安装 Docker Compose V2
sudo apt install docker-compose-plugin

# 验证安装
docker --version
docker compose version
```

### Linux (CentOS/RHEL)

```bash
# 安装依赖
sudo yum install -y yum-utils

# 添加仓库
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo

# 安装 Docker
sudo yum install docker-ce docker-ce-cli containerd.io docker-compose-plugin

# 启动服务
sudo systemctl start docker
sudo systemctl enable docker
```

### macOS

```bash
# 方式1：Docker Desktop（推荐）
# 下载: https://www.docker.com/products/docker-desktop

# 方式2：Homebrew
brew install --cask docker
# 然后启动 Docker Desktop 应用
```

### Windows

```bash
# 方式1：Docker Desktop（推荐）
# 下载: https://www.docker.com/products/docker-desktop

# 方式2：Chocolatey
choco install docker-desktop

# 注意：Windows 需要启用 WSL 2 或 Hyper-V
```

## Docker Desktop 替代方案

### Colima (macOS/Linux)

```bash
# 安装
brew install colima docker

# 启动
colima start

# 使用标准 docker 命令
docker ps
```

### Podman

```bash
# Ubuntu/Debian
sudo apt install podman

# 使用 podman（命令兼容 docker）
podman ps
podman build -t app .

# 创建 docker 别名
alias docker=podman
```

## Docker Compose 示例

### 基础配置

```yaml
# docker-compose.yml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=development
    volumes:
      - .:/app
    depends_on:
      - db

  db:
    image: postgres:15
    environment:
      POSTGRES_PASSWORD: password
    volumes:
      - pgdata:/var/lib/postgresql/data

volumes:
  pgdata:
```

### 常用命令

```bash
# 启动服务
docker compose up -d

# 查看日志
docker compose logs -f

# 停止服务
docker compose down

# 重建并启动
docker compose up -d --build

# 查看服务状态
docker compose ps
```

## 官方文档

- Docker: https://docs.docker.com/
- Docker Compose: https://docs.docker.com/compose/
- Docker Hub: https://hub.docker.com/
- Docker Desktop: https://docs.docker.com/desktop/
