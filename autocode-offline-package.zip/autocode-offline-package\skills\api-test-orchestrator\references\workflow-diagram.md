# API 测试工作流图

## 完整流程

```
┌─────────────────────────────────────────────────────────────────┐
│                    API 测试编排工作流                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Phase 0: 配置检查                                               │
│  ┌──────────────────────┐                                       │
│  │ api-test-config.yaml │──→ 不存在? → 调用 api-test-config 生成  │
│  └──────────┬───────────┘                                       │
│             ↓                                                   │
│  Phase 1: 特性清单生成                                            │
│  ┌──────────────────────────────┐                               │
│  │ feature-api-list-generator   │                               │
│  │ 输入: 后端代码/API文档/Swagger │                               │
│  │ 输出: docs/features/*.csv    │                               │
│  └──────────┬───────────────────┘                               │
│             ↓                                                   │
│  Phase 2: 用例列表生成（一阶段）                                    │
│  ┌──────────────────────────────┐                               │
│  │ api-test-case-generator      │                               │
│  │ ┌─────┐ ┌─────┐ ┌─────┐    │                               │
│  │ │路径A│ │路径B│ │路径C│    │                               │
│  │ │需求 │ │代码 │ │Git │    │                               │
│  │ └──┬──┘ └──┬──┘ └──┬──┘    │                               │
│  │    └───────┼───────┘        │                               │
│  │            ↓                │                               │
│  │  覆盖率规则引擎（4类21条）    │                               │
│  │  正向│负向│边界│安全         │                               │
│  │            ↓                │                               │
│  │  输出: 用例列表 CSV          │                               │
│  └──────────┬───────────────────┘                               │
│             ↓                                                   │
│  ⏸ 人工审查（必须）                                               │
│  ┌──────────────────────────────┐                               │
│  │ 审查用例完整性/级别/覆盖均衡   │                               │
│  │ status: pending → approved   │                               │
│  └──────────┬───────────────────┘                               │
│             ↓                                                   │
│  Phase 3: 用例详情+脚本生成（二阶段）                               │
│  ┌──────────────────────────────┐                               │
│  │ api-test-detail-generator    │                               │
│  │ 输出:                        │                               │
│  │  ├─ YAML 用例详情             │                               │
│  │  ├─ pytest 脚本 (httpx)      │                               │
│  │  ├─ conftest.py              │                               │
│  │  └─ utils/ 工具模块           │                               │
│  └──────────┬───────────────────┘                               │
│             ↓                                                   │
│  Phase 4: 执行测试                                               │
│  ┌──────────────────────────────┐                               │
│  │ api-test-executor            │                               │
│  │ 模式: smoke│level│module│all │                               │
│  │ 输出: junit.xml + result.json│                               │
│  └──────────┬───────────────────┘                               │
│             ↓                                                   │
│  Phase 5: 报告生成                                               │
│  ┌──────────────────────────────┐                               │
│  │ api-test-report-builder      │                               │
│  │ 输出:                        │                               │
│  │  ├─ ai-report.json (AI可读)  │                               │
│  │  └─ report.html (人读HTML)   │                               │
│  └──────────┬───────────────────┘                               │
│             ↓                                                   │
│  ✅ 完成: 输出测试结果摘要                                         │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## 技能依赖关系

```
api-test-orchestrator
├── api-test-config
├── feature-api-list-generator
├── api-test-case-generator
│   └── references/coverage-rules.md
├── api-test-detail-generator
│   └── references/pytest-patterns.md
├── api-test-executor
└── api-test-report-builder
```

## 目录产物映射

```
Phase 0 → tests/api-test/api-test.config.yaml
Phase 1 → docs/features/{module}-api-features.csv
Phase 2 → tests/api-test/usecase/{module}/{module}-case-list.csv
Phase 3 → tests/api-test/usecase/{module}/{feature}.yaml
          tests/api-test/scripts/{module}/test_{feature}.py
          tests/api-test/scripts/conftest.py
          tests/api-test/scripts/utils/
          tests/api-test/testcase-registry.csv
Phase 4 → .tests/api-reports/{run-id}/junit.xml
          .tests/api-reports/{run-id}/result.json
Phase 5 → .tests/api-reports/{run-id}/ai-report.json
          .tests/api-reports/{run-id}/report.html
```
