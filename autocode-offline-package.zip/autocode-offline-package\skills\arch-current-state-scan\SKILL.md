---
name: arch-current-state-scan
description: 扫描并理解目标项目的现有架构与约束，基于 docs 目录与代码结构输出现状摘要、依赖关系、关键数据流与技术风险
---

## 技能概述

本技能用于在“目标业务项目仓库”中，按照 `{project_root}/AGENTS.md`（项目结构规范章节）约定的目录结构读取现有文档与代码线索，形成可供架构设计决策使用的现状报告。

## 输入
- 目标项目根目录（`{project_root}/`）
- 本次需求/变更点简述（可为空，但建议提供）

## 输出
- 在会话上下文记录目录结构和对应目录及文件的作用
- 输出一份**结构化现状摘要**（用于上层工作流可复现地分支判断），至少包含：
  - `init_state`: `uninitialized` | `partial` | `complete`
  - `init_state_reason`: 判定依据要点列表（每条尽量可追溯到“文件路径/目录是否存在/关键文档是否缺失”等客观事实）
  - `artifacts_present`: 已存在的关键文档/目录清单（路径列表）
  - `artifacts_missing`: 缺失的关键文档/目录清单（路径列表）

## 初始化状态判定规则（用于 `init_state`）

> 目标：让上层工作流（如 `/init-project`）可以不依赖“主观描述”，只根据 `init_state` + `reason` 做出稳定分支。

**关键产物（最小基线）**：扫描时默认至少检查下列路径是否存在，并据此填充 `artifacts_present/missing`：

**层级1：项目基础（必需）**
- `{project_root}/AGENTS.md`
- `{project_root}/docs/`
- `{project_root}/docs/architecture/`

**层级2：项目架构（必需）**
- `{project_root}/docs/architecture/系统架构设计.md`
- `{project_root}/docs/architecture/功能架构设计.md`
- `{project_root}/docs/init-report.md`

**层级3：子模块文档（多模块项目必需）**
- 对于每个子模块 `${module}`：
  - `{module_root}/AGENTS.md`
  - `{project_root}/docs/architecture/${module}/`
  - `{project_root}/docs/architecture/${module}/模块整体架构设计.md`
  - `{project_root}/docs/architecture/${module}/模块API接口规范.md`

**可选文档**
- `{project_root}/CLAUDE.md`
- `{project_root}/AGENTS.md`

**状态映射**：
- `uninitialized`：缺失 `{project_root}/AGENTS.md` 或缺失 `{project_root}/docs/`（无法建立"按文档体系扫描/更新"的基线）
- `partial`：
  - 层级1完整，但层级2缺失任何必需文档
  - 或层级2完整，但多模块项目的层级3缺失任何子模块的必需文档
  - 或子模块边界/模块清单无法稳定识别（需人工确认）
- `complete`：
  - 层级1、层级2的所有必需文档均存在
  - 单模块项目：无需层级3检查
  - 多模块项目：所有子模块的层级3必需文档均存在
  - `artifacts_missing` 为空或仅包含可选文档（CLAUDE.md、AGENTS.md）

## 工作流程

### 1) 项目整体感知
- `{project_root}/AGENTS.md`：项目介绍，项目结构，目录说明，子模块和作用说明
- 读取和理解 `{project_root}/docs/architecture/` 目录下的文件，理解项目的规格、技术与功能架构
- 读取和理解 `{project_root}/docs/test/` 目录下的所有文件，理解项目的整体出口标准，包括测试场景和测试约束等

### 2) 子模块感知
根据 `AGENTS.md` 中的目录结构：
- 读取 `.gitmodules` 记录子模块位置，如果不存在子模块，则说明当前项目是个单模块项目，那么直接依据项目 `AGENTS.md` 读取和理解当前项目的结构。
- 读取和理解每个子模块的记录文件 `{module_root}/CLAUDE.md`、`{module_root}/AGENTS.md` 文件不存在则跳过
- 读取和理解每个子模块的AGENTS文件 `{module_root}/AGENTS.md` 文件不存在则进行警告
- 读取和理解 `{project_root}/docs/architecture/${module}` 目录下的所有文件，理解项目的各个子模块的内部结构、技术要求、api接口、系统上下文等

### 3) 产出结果
**产出位置**: 保存在当前会话中
至少包含：
- 文档的完整性：已有的文档和缺失的文档
- 项目AGENTS.md
- 架构概览（子模块/分层/组件/边界/接口）
- 文档目录结构（架构/功能/接口/模块/需求/特性）
- 依赖关系（模块间依赖方向、共享组件）
- 已知约束（技术栈、部署、性能/稳定性目标、接口/数据契约）
- （可选，如果指定了需求）当前处理的需求（需求目录、需求分析文档、需求设计文档）

## 失败与缺失处理
- 若发现相关文档缺失：向上报告缺失的文件。
- 若无法定位代码目录结构：及时中断告知人工处理。
