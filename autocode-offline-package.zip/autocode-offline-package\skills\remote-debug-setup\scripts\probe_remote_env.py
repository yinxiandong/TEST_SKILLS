#!/usr/bin/env python3
import argparse
import json
import os
import re
import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


def load_json(path: Path) -> Dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    data = json.loads(text)
    if not isinstance(data, dict):
        raise RuntimeError("answers 顶层必须为对象")
    return data


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def now_ts() -> str:
    return time.strftime("%Y%m%d-%H%M%S", time.localtime())


def mask_secret(value: str) -> str:
    if not value:
        return ""
    if len(value) <= 10:
        return "******"
    return value[:3] + "..." + value[-2:]


def which(cmd: str) -> bool:
    return shutil.which(cmd) is not None


@dataclass
class SshTarget:
    host: str
    port: int
    username: str
    auth_type: str
    password: str
    identity_file: str
    known_hosts_file: str
    strict_host_key_check: bool


def build_ssh_prefix(target: SshTarget) -> List[str]:
    common = [
        "ssh",
        "-n",
        "-p",
        str(target.port),
        "-o",
        f"StrictHostKeyChecking={'yes' if target.strict_host_key_check else 'no'}",
        "-o",
        f"UserKnownHostsFile={target.known_hosts_file}",
        "-o",
        "ConnectTimeout=8",
        "-o",
        "ServerAliveInterval=5",
        "-o",
        "ServerAliveCountMax=3",
    ]
    if target.auth_type == "key":
        common.extend(["-i", target.identity_file, "-o", "BatchMode=yes"])
    common.append(f"{target.username}@{target.host}")
    return common


def run_ssh(target: SshTarget, command: str) -> Tuple[int, str]:
    ssh_cmd = build_ssh_prefix(target) + [command]
    if target.auth_type == "password":
        if not which("sshpass"):
            return 127, "[ERROR] 缺少 sshpass（password 认证需要）\n"
        ssh_cmd = ["sshpass", "-p", target.password] + ssh_cmd
    try:
        proc = subprocess.run(ssh_cmd, capture_output=True, text=True, timeout=25)
    except subprocess.TimeoutExpired:
        return 124, "[ERROR] SSH 命令超时（25s）\n"
    output = (proc.stdout or "") + (proc.stderr or "")
    return proc.returncode, output


def save_evidence(evidence_dir: Path, name: str, command: str, code: int, output: str) -> None:
    def redact(text: str) -> str:
        if not text:
            return text
        redacted = text
        # key=value / key: value
        redacted = re.sub(
            r"(?i)\b(password|passwd|pwd|token|secret|access[_-]?token|refresh[_-]?token)\b\s*[:=]\s*([^\s'\";]+)",
            r"\1=******",
            redacted,
        )
        # Authorization: Bearer xxx
        redacted = re.sub(r"(?i)(authorization\s*:\s*bearer)\s+([^\s]+)", r"\1 ******", redacted)
        # URL basic auth scheme://user:pass@
        redacted = re.sub(r"(https?://)([^\s:/@]+):([^\s@]+)@", r"\1******:******@", redacted)
        return redacted

    safe = re.sub(r"[^A-Za-z0-9._-]+", "_", name)
    path = evidence_dir / f"{safe}.log"
    header = {
        "command": command,
        "exit_code": code,
    }
    text = json.dumps(header, ensure_ascii=False) + "\n" + (redact(output)[:20000] if output else "")
    path.write_text(text, encoding="utf-8")


def parse_systemd_units(list_units_output: str) -> List[str]:
    units: List[str] = []
    seen: set[str] = set()
    for line in list_units_output.splitlines():
        line = line.strip()
        if not line:
            continue
        # systemctl --no-legend: UNIT LOAD ACTIVE SUB DESCRIPTION
        unit = line.split()[0]
        if unit.endswith(".service") and unit not in seen:
            units.append(unit)
            seen.add(unit)
    return units


def parse_systemctl_show(show_output: str) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for line in show_output.splitlines():
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip()
        if k:
            result[k] = v
    return result


def parse_docker_ps(output: str) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for line in output.splitlines():
        line = line.rstrip("\n")
        if not line.strip():
            continue
        # 过滤 SSH Banner 等噪声：真实 docker --format 输出应包含制表符分隔列。
        if "\t" not in line:
            continue
        parts = line.split("\t")
        name = parts[0].strip() if len(parts) >= 1 else ""
        image = parts[1].strip() if len(parts) >= 2 else ""
        ports = parts[2].strip() if len(parts) >= 3 else ""
        if name and re.match(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$", name):
            rows.append({"name": name, "image": image, "ports": ports})
    return rows


def parse_listening_ports_ss(output: str) -> List[Dict[str, Any]]:
    # 兼容 ss -lntp 的常见格式，尽量提取 port/pid/process
    ports: List[Dict[str, Any]] = []
    for line in output.splitlines():
        line = line.strip()
        if not line:
            continue
        lower = line.lower()
        if lower.startswith("state") or lower.startswith("active internet connections"):
            continue
        port: Optional[int] = None
        # ss 常见: [::ffff:172.16.21.122]:10011
        m_ipv6_mapped = re.search(r"\[::ffff:[0-9.]+\]:(\d+)", line, flags=re.IGNORECASE)
        if m_ipv6_mapped:
            port = int(m_ipv6_mapped.group(1))
        if port is None:
            # host:port，兼容 [::]:port / :::port / 0.0.0.0:port / *:port
            m_addr = re.search(r"(?<!\d)(?:\*|\[::\]|::|[0-9.]+|\[[0-9A-Fa-f:]+\]):(\d+)\b", line)
            if m_addr:
                port = int(m_addr.group(1))
        if port is None:
            # netstat 常见列: Local Address 在第4列
            fields = line.split()
            if len(fields) >= 4:
                local_addr = fields[3].strip()
                m_local = re.search(r":(\d+)$", local_addr)
                if m_local:
                    port = int(m_local.group(1))
        if port is None:
            continue
        proc_name = ""
        pid = None
        m_proc = re.search(r'users:\(\(\"([^\"]+)\",pid=(\d+)', line)
        if m_proc:
            proc_name = m_proc.group(1)
            pid = int(m_proc.group(2))
        else:
            # netstat 常见: ... LISTEN 123/java
            m_netstat_proc = re.search(r"\s(\d+)/([^\s/]+)\s*$", line)
            if m_netstat_proc:
                pid = int(m_netstat_proc.group(1))
                proc_name = m_netstat_proc.group(2)
        ports.append({"port": port, "process": proc_name, "pid": pid, "raw": line})
    # 去重
    seen = set()
    out: List[Dict[str, Any]] = []
    for item in ports:
        key = (item.get("port"), item.get("pid"), item.get("process"))
        if key in seen:
            continue
        seen.add(key)
        out.append(item)
    return sorted(out, key=lambda x: int(x.get("port") or 0))


def detect_component_hints(
    listening_ports: List[Dict[str, Any]],
    ps_output: str,
    docker_containers: List[Dict[str, Any]],
    systemd_units: List[Dict[str, Any]],
) -> Dict[str, List[Dict[str, Any]]]:
    mapping = {
        5432: ("databases", "postgresql"),
        3306: ("databases", "mysql"),
        6379: ("middlewares", "redis"),
        8848: ("config_centers", "nacos"),
        9848: ("config_centers", "nacos"),
        9092: ("middlewares", "kafka"),
        2181: ("middlewares", "zookeeper"),
        9200: ("middlewares", "elasticsearch"),
    }
    result: Dict[str, List[Dict[str, Any]]] = {"databases": [], "config_centers": [], "middlewares": []}
    for item in listening_ports:
        port = int(item.get("port") or 0)
        if port in mapping:
            group, typ = mapping[port]
            result[group].append({"type": typ, "port": port, "evidence": f"port {port} listening"})

    # Nacos 多信号兜底：端口漏检时仍可给出建议。
    has_nacos = any(x.get("type") == "nacos" for x in result["config_centers"])
    if not has_nacos:
        ps_lower = (ps_output or "").lower()
        if "nacos-server.jar" in ps_lower or re.search(r"\bnacos\b", ps_lower):
            result["config_centers"].append({"type": "nacos", "evidence": "process contains nacos keyword"})
            has_nacos = True
    if not has_nacos:
        for item in docker_containers:
            name = str(item.get("name") or "").lower()
            image = str(item.get("image") or "").lower()
            if "nacos" in name or "nacos" in image:
                result["config_centers"].append({"type": "nacos", "evidence": "docker container/image contains nacos"})
                has_nacos = True
                break
    if not has_nacos:
        for item in systemd_units:
            unit = str(item.get("unit") or "").lower()
            exec_start = str(item.get("exec_start") or "").lower()
            if "nacos" in unit or "nacos" in exec_start:
                result["config_centers"].append({"type": "nacos", "evidence": "systemd unit/exec contains nacos"})
                break

    # 去重
    out: Dict[str, List[Dict[str, Any]]] = {"databases": [], "config_centers": [], "middlewares": []}
    for group in ["databases", "config_centers", "middlewares"]:
        seen = set()
        for item in result[group]:
            key = (item.get("type"), item.get("port"), item.get("evidence"))
            if key in seen:
                continue
            seen.add(key)
            out[group].append(item)
    return out


def load_project_profile(path: Optional[Path]) -> Dict[str, Any]:
    if not path:
        return {}
    try:
        if not path.exists():
            return {}
        data = load_json(path)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def extract_profile_signals(profile: Dict[str, Any]) -> Dict[str, Any]:
    signals = profile.get("signals") if isinstance(profile.get("signals"), dict) else {}
    keywords = [str(x).strip().lower() for x in (signals.get("keywords") or []) if str(x).strip()]
    jar_names = [str(x).strip() for x in (signals.get("jar_names") or []) if str(x).strip()]
    main_classes = [str(x).strip() for x in (signals.get("main_classes") or []) if str(x).strip()]
    binary_names = [str(x).strip() for x in (signals.get("binary_names") or []) if str(x).strip()]
    path_prefixes = [str(x).strip() for x in (signals.get("path_prefixes") or []) if str(x).strip()]
    port_hints: List[int] = []
    for x in signals.get("port_hints") or []:
        try:
            port_hints.append(int(x))
        except Exception:
            continue
    cmdline_regexes = [str(x) for x in (signals.get("cmdline_regexes") or []) if str(x).strip()]

    # 去噪：过滤过短/过泛关键词
    keywords2: List[str] = []
    seen = set()
    for k in keywords:
        k = re.sub(r"[^a-z0-9._-]+", "-", k).strip("-")
        if not k or len(k) < 3:
            continue
        if k in {"app", "service", "server", "web", "api", "deploy", "docker", "compose"}:
            continue
        if k in seen:
            continue
        seen.add(k)
        keywords2.append(k)
        if len(keywords2) >= 120:
            break

    # path_prefixes 去重
    pp2: List[str] = []
    seen2 = set()
    for p in path_prefixes:
        p = p.strip()
        if not p:
            continue
        if p in seen2:
            continue
        seen2.add(p)
        pp2.append(p)
        if len(pp2) >= 60:
            break

    return {
        "keywords": keywords2,
        "jar_names": jar_names[:120],
        "main_classes": main_classes[:120],
        "binary_names": binary_names[:120],
        "path_prefixes": pp2,
        "port_hints": sorted(set(port_hints))[:200],
        "cmdline_regexes": cmdline_regexes[:200],
    }


def quick_text_contains_any(text: str, needles: List[str], max_hits: int = 8) -> List[str]:
    if not text or not needles:
        return []
    lower = text.lower()
    matched: List[str] = []
    for n in needles:
        if not n:
            continue
        if n.lower() in lower:
            matched.append(n)
            if len(matched) >= max_hits:
                break
    return matched


def fetch_proc_fingerprint(target: SshTarget, pid: int) -> Dict[str, Any]:
    if not isinstance(pid, int) or pid <= 0:
        return {}
    # 只读 /proc 取证；失败则空（权限/进程退出等）
    cmd = (
        "pid=%d; "
        "cmdline=''; cwd=''; exe=''; "
        "if [ -r /proc/$pid/cmdline ]; then cmdline=$(tr '\\0' ' ' < /proc/$pid/cmdline 2>/dev/null || true); fi; "
        "if [ -r /proc/$pid/cwd ]; then cwd=$(readlink -f /proc/$pid/cwd 2>/dev/null || true); fi; "
        "if [ -r /proc/$pid/exe ]; then exe=$(readlink -f /proc/$pid/exe 2>/dev/null || true); fi; "
        "echo \"CMDLINE=$cmdline\"; echo \"CWD=$cwd\"; echo \"EXE=$exe\"; "
        "ps -p $pid -o user=,pid=,ppid=,args= 2>/dev/null || true"
    ) % pid
    code, out = run_ssh(target, cmd)
    if code != 0 and not out:
        return {}
    fp: Dict[str, Any] = {"pid": pid, "cmdline": "", "cwd": "", "exe": "", "java": {}, "bin": {}}
    for line in (out or "").splitlines():
        if line.startswith("CMDLINE="):
            fp["cmdline"] = line[len("CMDLINE=") :].strip()
        elif line.startswith("CWD="):
            fp["cwd"] = line[len("CWD=") :].strip()
        elif line.startswith("EXE="):
            fp["exe"] = line[len("EXE=") :].strip()
    cmdline = str(fp.get("cmdline") or "")
    exe = str(fp.get("exe") or "")

    if "java" in cmdline:
        java: Dict[str, Any] = {}
        m_jar = re.search(r"(?:^|\s)-jar\s+([^\s]+)", cmdline)
        if m_jar:
            jar_path = m_jar.group(1).strip().strip('"').strip("'")
            java["jar_path"] = jar_path
            java["jar_basename"] = os.path.basename(jar_path)
        m_cp = re.search(r"(?:^|\s)-(?:cp|classpath)\s+([^\s]+)\s+([A-Za-z_][\w$]*(?:\.[\w$]+){2,})", cmdline)
        if m_cp:
            java["classpath"] = m_cp.group(1)[:200]
            java["main_class"] = m_cp.group(2)[:200]
        m_port = re.search(r"(?:--server\.port=|-Dserver\.port=)(\d{2,5})\b", cmdline)
        if m_port:
            java["server_port"] = int(m_port.group(1))
        m_app = re.search(r"(?:--spring\.application\.name=|-Dspring\.application\.name=)([A-Za-z0-9_.-]{1,80})\b", cmdline)
        if m_app:
            java["spring_app_name"] = m_app.group(1)
        fp["java"] = java

    if exe:
        fp["bin"] = {"exe_basename": os.path.basename(exe)}
    return fp


SYSTEM_SERVICE_HINTS = {
    "sshd.service",
    "ssh.service",
    "cron.service",
    "crond.service",
    "rsyslog.service",
    "systemd-journald.service",
    "systemd-logind.service",
    "dbus.service",
    "network.service",
    "NetworkManager.service",
    "firewalld.service",
    "ufw.service",
}


def compute_project_match(candidate: Dict[str, Any], signals: Dict[str, Any]) -> Dict[str, Any]:
    score = float(candidate.get("confidence") or 0.0)
    strong_hit = False
    reasons: List[str] = []
    matched_keywords: List[str] = []
    matched_ports: List[int] = []

    keywords: List[str] = signals.get("keywords") or []
    jar_names: List[str] = signals.get("jar_names") or []
    main_classes: List[str] = signals.get("main_classes") or []
    binary_names: List[str] = signals.get("binary_names") or []
    path_prefixes: List[str] = signals.get("path_prefixes") or []
    port_hints: List[int] = signals.get("port_hints") or []

    jar_set = set(jar_names)
    main_class_set = set(main_classes)
    binary_set = set(binary_names)

    def jar_fuzzy_match(jar_basename: str) -> Optional[str]:
        # 允许 xxx-1.2.3.jar 命中 profile 中的 xxx.jar
        jb = (jar_basename or "").strip()
        if not jb:
            return None
        if jb in jar_set:
            return jb
        for known in jar_names:
            k = (known or "").strip()
            if not k.endswith(".jar"):
                continue
            stem = k[: -len(".jar")]
            if not stem:
                continue
            if jb.startswith(stem + "-") and jb.endswith(".jar"):
                return k
        return None

    src = str(candidate.get("source") or "")

    # docker：name/image 关键词命中
    if src == "docker":
        dock = candidate.get("docker") if isinstance(candidate.get("docker"), dict) else {}
        img = str(dock.get("image") or "")
        name = str(dock.get("container") or dock.get("name") or "")
        hits = quick_text_contains_any(f"{name} {img}", keywords, max_hits=4)
        if hits:
            score += 0.6
            strong_hit = True
            matched_keywords.extend(hits)
            reasons.append(f"docker name/image 命中关键词: {','.join(hits)}")

        # docker inspect labels/mounts（只读证据，用于增强匹配）
        detail = candidate.get("docker_detail") if isinstance(candidate.get("docker_detail"), dict) else {}
        labels = detail.get("labels") if isinstance(detail.get("labels"), dict) else {}
        if labels:
            # labels 以 values 为主做匹配
            joined = " ".join([str(v) for v in labels.values() if v is not None])[:5000]
            hits2 = quick_text_contains_any(joined, keywords, max_hits=4)
            if hits2:
                score += 0.3
                strong_hit = True
                matched_keywords.extend(hits2)
                reasons.append(f"docker labels 命中关键词: {','.join(hits2)}")
        mounts = detail.get("mounts") if isinstance(detail.get("mounts"), list) else []
        if mounts:
            # 若命中更窄路径前缀则加分；/home 仍按弱信号处理
            joined_paths = " ".join([str(m.get("Source") or "") + " " + str(m.get("Destination") or "") for m in mounts if isinstance(m, dict)])[:5000]
            for pref in path_prefixes:
                if not pref:
                    continue
                if pref == "/home":
                    if "/home/" in joined_paths:
                        score += 0.05
                        reasons.append("docker mounts 命中: /home (弱信号)")
                    continue
                if pref.rstrip("/") and pref.rstrip("/") in joined_paths:
                    score += 0.4
                    strong_hit = True
                    reasons.append(f"docker mounts 路径前缀命中: {pref}")
                    break

    # port：端口命中
    if src == "port":
        proc = candidate.get("process") if isinstance(candidate.get("process"), dict) else {}
        try:
            p = int(proc.get("port") or 0)
        except Exception:
            p = 0
        if p and p in port_hints:
            score += 0.3
            strong_hit = True
            matched_ports.append(p)
            reasons.append(f"端口命中 port_hints: {p}")

    # systemd：ExecStart/FragmentPath 与路径前缀
    if src == "systemd":
        detail = candidate.get("_sysd_detail") if isinstance(candidate.get("_sysd_detail"), dict) else {}
        exec_start = str(detail.get("exec_start") or "")
        fragment = str(detail.get("fragment_path") or "")
        hits = quick_text_contains_any(f"{exec_start} {fragment}", keywords, max_hits=4)
        if hits:
            score += 0.6
            strong_hit = True
            matched_keywords.extend(hits)
            reasons.append(f"systemd ExecStart/FragmentPath 命中关键词: {','.join(hits)}")
        for pref in path_prefixes:
            if not pref:
                continue
            if pref == "/home":
                if "/home/" in (exec_start + " " + fragment):
                    score += 0.05
                    reasons.append("路径命中: /home (弱信号)")
                continue
            if pref.rstrip("/") and pref.rstrip("/") in (exec_start + " " + fragment):
                score += 0.7
                strong_hit = True
                reasons.append(f"路径前缀命中: {pref}")
                break

    # /proc：进程指纹（Java/C++/Go）
    fp = candidate.get("process_fingerprint") if isinstance(candidate.get("process_fingerprint"), dict) else {}
    cmdline = str(fp.get("cmdline") or "")
    cwd = str(fp.get("cwd") or "")
    exe = str(fp.get("exe") or "")
    has_home = False
    if cmdline or cwd or exe:
        java = fp.get("java") if isinstance(fp.get("java"), dict) else {}
        jar_base = str(java.get("jar_basename") or "")
        if jar_base:
            matched_known = jar_fuzzy_match(jar_base)
            if matched_known:
                score += 0.9
                strong_hit = True
                reasons.append(f"java -jar 命中 jar: {jar_base} (~{matched_known})")
        main_class = str(java.get("main_class") or "")
        if main_class and main_class in main_class_set:
            score += 0.7
            strong_hit = True
            reasons.append(f"java mainClass 命中: {main_class}")
        binfo = fp.get("bin") if isinstance(fp.get("bin"), dict) else {}
        exe_base = str(binfo.get("exe_basename") or "")
        if exe_base and exe_base in binary_set:
            score += 0.9
            strong_hit = True
            reasons.append(f"exe 命中 binary: {exe_base}")

        hits = quick_text_contains_any(f"{cmdline} {cwd} {exe}", keywords, max_hits=4)
        if hits:
            score += 0.6
            strong_hit = True
            matched_keywords.extend(hits)
            reasons.append(f"/proc cmdline/cwd/exe 命中关键词: {','.join(hits)}")

        for pref in path_prefixes:
            if not pref:
                continue
            if pref == "/home":
                if "/home/" in (cmdline + " " + cwd + " " + exe):
                    has_home = True
                    score += 0.05
                    reasons.append("路径命中: /home (弱信号)")
                continue
            if pref.rstrip("/") and pref.rstrip("/") in (cmdline + " " + cwd + " " + exe):
                score += 0.7
                strong_hit = True
                reasons.append(f"路径前缀命中: {pref}")
                break

        # 组合加分：/home + jar/binary
        if has_home and (any(r.startswith("java -jar 命中 jar") for r in reasons) or any(r.startswith("exe 命中 binary") for r in reasons)):
            score += 0.35
            reasons.append("/home + jar/binary 组合加分")

        server_port = java.get("server_port")
        if isinstance(server_port, int) and server_port in port_hints:
            score += 0.3
            strong_hit = True
            matched_ports.append(server_port)
            reasons.append(f"java server.port 命中 port_hints: {server_port}")

    # 轻度负向：系统服务且无正向命中
    if src == "systemd":
        sysd = candidate.get("systemd") if isinstance(candidate.get("systemd"), dict) else {}
        unit = str(sysd.get("unit") or "")
        if unit in SYSTEM_SERVICE_HINTS and len(reasons) == 0:
            score -= 0.4
            reasons.append("systemd unit 疑似系统服务（无正向命中，轻度降权）")

    # clamp
    if score < 0:
        score = 0.0
    if score > 2.0:
        score = 2.0

    mk_out: List[str] = []
    seen_mk = set()
    for k in matched_keywords:
        k2 = str(k).lower()
        if k2 in seen_mk:
            continue
        seen_mk.add(k2)
        mk_out.append(k2)
        if len(mk_out) >= 20:
            break
    mp_out: List[int] = []
    seen_p = set()
    for p in matched_ports:
        if p in seen_p:
            continue
        seen_p.add(p)
        mp_out.append(p)
        if len(mp_out) >= 20:
            break

    return {"score": score, "strong_hit": bool(strong_hit), "reasons": reasons[:12], "matched_keywords": mk_out, "matched_ports": mp_out}


def build_service_candidates(
    systemd_units: List[Dict[str, Any]],
    docker_containers: List[Dict[str, Any]],
    listening_ports: List[Dict[str, Any]],
    source_quota: Optional[Dict[str, int]] = None,
    max_candidates: int = 80,
    profile_signals: Optional[Dict[str, Any]] = None,
    docker_detail_by_name: Optional[Dict[str, Dict[str, Any]]] = None,
) -> List[Dict[str, Any]]:
    candidates: List[Dict[str, Any]] = []
    for item in systemd_units:
        sysd_detail = {"exec_start": item.get("exec_start"), "fragment_path": item.get("fragment_path")}
        candidates.append(
            {
                "source": "systemd",
                "confidence": 0.9,
                "mode_candidates": ["systemd"],
                "systemd": {"unit": item.get("unit"), "user": item.get("user")},
                "name_hint": item.get("unit"),
                "evidence": item.get("evidence"),
                "_sysd_detail": sysd_detail,
                "process_fingerprint": item.get("_process_fingerprint") if isinstance(item.get("_process_fingerprint"), dict) else {},
            }
        )
    for item in docker_containers:
        name = str(item.get("name") or "")
        docker_detail = {}
        if isinstance(docker_detail_by_name, dict) and name and name in docker_detail_by_name:
            docker_detail = docker_detail_by_name.get(name) or {}
        candidates.append(
            {
                "source": "docker",
                "confidence": 0.8,
                "mode_candidates": ["docker"],
                "docker": {"container": item.get("name"), "image": item.get("image")},
                "name_hint": item.get("name"),
                "evidence": "docker ps",
                "docker_detail": docker_detail if isinstance(docker_detail, dict) else {},
            }
        )
    # systemd MainPID 用于跨 source 关联：若端口进程 pid 属于某 unit，则不再单独生成 port 候选。
    main_pid_to_unit: Dict[int, Dict[str, Any]] = {}
    for item in systemd_units:
        mp = item.get("main_pid")
        if isinstance(mp, int) and mp > 0:
            main_pid_to_unit[mp] = item

    for item in listening_ports:
        pid = item.get("pid")
        if isinstance(pid, int) and pid > 0:
            if pid in main_pid_to_unit:
                # 端口已被 systemd unit 覆盖；保留端口信息给 unit 使用，由后续问答确认。
                continue
            confidence = 0.5
        else:
            # 非 root/权限受限时，ss/netstat 可能拿不到 pid/process；仍保留端口线索给问答确认。
            confidence = 0.3

        port = item.get("port")
        proc = item.get("process") or "unknown"
        name_hint = f"{proc}:{port}" if proc and port else (f"port:{port}" if port else "port")
        candidates.append(
            {
                "source": "port",
                "confidence": confidence,
                "mode_candidates": ["script"],
                "process": {"pid": pid if isinstance(pid, int) else None, "process": item.get("process"), "port": port},
                "name_hint": name_hint,
                "evidence": item.get("raw"),
                "process_fingerprint": item.get("_process_fingerprint") if isinstance(item.get("_process_fingerprint"), dict) else {},
            }
        )

    # 去重：同 source 下按核心标识去重；跨 source 暂不强行合并（避免误合并）。
    seen: set[str] = set()
    deduped: List[Dict[str, Any]] = []
    for c in candidates:
        if c.get("source") == "systemd":
            key = f"systemd:{(c.get('systemd') or {}).get('unit','')}"
        elif c.get("source") == "docker":
            key = f"docker:{(c.get('docker') or {}).get('container') or (c.get('docker') or {}).get('name') or ''}"
        else:
            proc = c.get("process") if isinstance(c.get("process"), dict) else {}
            key = f"port:{proc.get('pid')}:{proc.get('port')}:{proc.get('process')}"
        if key in seen:
            continue
        seen.add(key)
        deduped.append(c)

    # 若提供 profile_signals，则为候选计算 project_match，并按相关性优先排序。
    if isinstance(profile_signals, dict) and (
        (profile_signals.get("keywords") or [])
        or (profile_signals.get("jar_names") or [])
        or (profile_signals.get("binary_names") or [])
        or (profile_signals.get("path_prefixes") or [])
    ):
        for c in deduped:
            c["project_match"] = compute_project_match(c, profile_signals)

        def sort_key(x: Dict[str, Any]) -> Tuple[float, float, str]:
            pm = x.get("project_match") if isinstance(x.get("project_match"), dict) else {}
            pm_score = float(pm.get("score") or 0.0) if pm else 0.0
            conf = float(x.get("confidence") or 0.0)
            src = str(x.get("source") or "")
            return (pm_score, conf, src)

        deduped.sort(key=sort_key, reverse=True)
    else:
        deduped.sort(key=lambda x: float(x.get("confidence") or 0), reverse=True)

    quotas = {"systemd": 20, "docker": 20, "port": 40}
    if isinstance(source_quota, dict):
        for key in ["systemd", "docker", "port"]:
            value = source_quota.get(key)
            if isinstance(value, int) and value >= 0:
                quotas[key] = value

    max_total = max(1, int(max_candidates or 80))
    selected: List[Dict[str, Any]] = []
    selected_count = {"systemd": 0, "docker": 0, "port": 0}
    for item in deduped:
        source = str(item.get("source") or "")
        if source not in selected_count:
            continue
        if selected_count[source] >= quotas[source]:
            continue
        selected.append(item)
        selected_count[source] += 1
        if len(selected) >= max_total:
            break
    return selected


def http_probe(host: str, port: int, scheme: str, timeout_seconds: int = 4) -> Dict[str, Any]:
    import urllib.error
    import urllib.request

    url = f"{scheme}://{host}:{port}/"
    req = urllib.request.Request(url, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout_seconds) as resp:
            headers = {k: v for k, v in resp.headers.items()}
            status = getattr(resp, "status", None)
            return {"url": url, "status": status, "headers": headers}
    except urllib.error.HTTPError as exc:
        headers = {k: v for k, v in exc.headers.items()} if exc.headers else {}
        return {"url": url, "status": exc.code, "headers": headers, "error": "HTTPError"}
    except Exception as exc:
        return {"url": url, "error": str(exc)}


def guess_auth_hints(http_result: Dict[str, Any]) -> List[Dict[str, Any]]:
    headers = {k.lower(): v for k, v in (http_result.get("headers") or {}).items()}
    hints: List[Dict[str, Any]] = []
    www = headers.get("www-authenticate", "")
    if "bearer" in www.lower():
        hints.append({"type": "bearer", "evidence": f"WWW-Authenticate: {www[:120]}"})
    if "set-cookie" in headers:
        hints.append({"type": "cookie", "evidence": "Set-Cookie present"})
    return hints


def probe_one_server(
    project_root: Path,
    defaults: Dict[str, Any],
    server: Dict[str, Any],
    dry_run: bool,
    max_candidates: int,
    source_quota: Optional[Dict[str, int]],
    profile_signals: Optional[Dict[str, Any]],
    enable_proc_enrich: bool,
    proc_enrich_top: int,
    docker_inspect_top: int,
) -> Dict[str, Any]:
    name = str(server.get("name") or "").strip()
    ssh = server.get("ssh") if isinstance(server.get("ssh"), dict) else {}
    auth = ssh.get("auth") if isinstance(ssh.get("auth"), dict) else {}

    known_hosts_file = str(defaults.get("known_hosts_file") or "/tmp/remote-dev-deploy-known-hosts")
    strict_host_key_check = bool(defaults.get("strict_host_key_check") or False)

    target = SshTarget(
        host=str(ssh.get("host") or ""),
        port=int(ssh.get("port") or 22),
        username=str(ssh.get("username") or ""),
        auth_type=str(auth.get("type") or "password"),
        password=str(auth.get("password") or ""),
        identity_file=os.path.expanduser(str(auth.get("identity_file") or "")),
        known_hosts_file=known_hosts_file,
        strict_host_key_check=strict_host_key_check,
    )

    # 避免 server name 注入路径（例如以 "/" 开头导致写到 project_root 外）
    safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._-")
    if not safe_name:
        safe_name = "server"
    safe_name = safe_name[:64]
    evidence_dir = project_root / ".tmp/remote-debug-setup" / "probe-evidence" / f"{safe_name}-{now_ts()}"
    ensure_dir(evidence_dir)

    result: Dict[str, Any] = {
        "server": {
            "name": name,
            "host": target.host,
            "port": target.port,
            "username": target.username,
            "auth_type": target.auth_type,
            "password_masked": mask_secret(target.password) if target.auth_type == "password" else "",
            "identity_file": target.identity_file if target.auth_type == "key" else "",
        },
        "access": {"ssh_ok": False},
        "os": {},
        "deployment": {"modes_detected": []},
        "runtime": {"listening_ports": []},
        "components_hints": {"databases": [], "config_centers": [], "middlewares": []},
        "api_surface": {"http_candidates": [], "auth_hints": []},
        "service_candidates": [],
        "project_profile": {},
        "evidence_dir": str(evidence_dir),
        "notes": [],
    }

    if dry_run:
        result["access"]["ssh_ok"] = False
        result["notes"].append("dry-run: 未执行远端命令")
        return result

    code, out = run_ssh(target, "echo PROBE_OK")
    save_evidence(evidence_dir, "connect", "echo PROBE_OK", code, out)
    if code != 0 or "PROBE_OK" not in out:
        result["notes"].append("SSH 连接失败，请检查 host/port/username/auth")
        return result
    result["access"]["ssh_ok"] = True

    commands = {
        "uname": "uname -a",
        "os_release": "(cat /etc/os-release 2>/dev/null || true)",
        "ps": "ps -eo user:20,pid,ppid,cmd --no-headers | head -n 2000",
        "ports": "(command -v ss >/dev/null 2>&1 && ss -lntp) || (command -v netstat >/dev/null 2>&1 && netstat -lntp) || true",
        "systemd_units": "(command -v systemctl >/dev/null 2>&1 && systemctl list-units --type=service --state=running --no-legend --no-pager) || true",
        "docker_ps": "(command -v docker >/dev/null 2>&1 && docker ps --format '{{.Names}}\t{{.Image}}\t{{.Ports}}') || true",
    }
    outputs: Dict[str, str] = {}
    for key, cmd in commands.items():
        c, o = run_ssh(target, cmd)
        save_evidence(evidence_dir, key, cmd, c, o)
        outputs[key] = o

    result["os"]["uname"] = (outputs.get("uname") or "").strip()
    if "PRETTY_NAME=" in (outputs.get("os_release") or ""):
        for line in outputs["os_release"].splitlines():
            if line.startswith("PRETTY_NAME="):
                result["os"]["distro"] = line.split("=", 1)[1].strip().strip('"')
                break

    ports = parse_listening_ports_ss(outputs.get("ports") or "")
    result["runtime"]["listening_ports"] = ports

    # systemd details
    units = parse_systemd_units(outputs.get("systemd_units") or "")
    systemd_units_detail: List[Dict[str, Any]] = []
    # show 过多会变慢；按配额做上限（至少 30）
    sys_quota = 20
    if isinstance(source_quota, dict) and isinstance(source_quota.get("systemd"), int):
        sys_quota = max(0, int(source_quota.get("systemd") or 0))
    detail_limit = max(30, min(120, sys_quota * 3 if sys_quota > 0 else 30))
    for unit in units[:detail_limit]:
        show_cmd = f"systemctl show {unit} -p User,ExecStart,FragmentPath,MainPID 2>/dev/null || true"
        c, o = run_ssh(target, show_cmd)
        save_evidence(evidence_dir, f"systemctl_show_{unit}", show_cmd, c, o)
        props = parse_systemctl_show(o)
        main_pid = 0
        try:
            main_pid = int((props.get("MainPID") or "0").strip() or 0)
        except Exception:
            main_pid = 0
        systemd_units_detail.append(
            {
                "unit": unit,
                "user": props.get("User") or "",
                "exec_start": props.get("ExecStart") or "",
                "fragment_path": props.get("FragmentPath") or "",
                "main_pid": main_pid,
                "evidence": "systemctl list-units/show",
            }
        )
    if systemd_units_detail:
        result["deployment"]["modes_detected"].append("systemd")
        result["deployment"]["systemd_units"] = systemd_units_detail

    # docker details
    docker_rows = parse_docker_ps(outputs.get("docker_ps") or "")
    if docker_rows:
        result["deployment"]["modes_detected"].append("docker")
        result["deployment"]["docker"] = {"containers": docker_rows}

    # script/process mode is inferred
    if ports:
        result["deployment"]["modes_detected"].append("script")

    result["components_hints"] = detect_component_hints(
        ports,
        outputs.get("ps") or "",
        docker_rows,
        systemd_units_detail,
    )

    # 挂载 project signals（用于解释；避免回填过多本地信息）
    signals = profile_signals if isinstance(profile_signals, dict) else {}
    if signals and (signals.get("keywords") or signals.get("jar_names") or signals.get("binary_names") or signals.get("path_prefixes")):
        result["project_profile"] = {"signals": signals}

    # /proc enrich：进程部署场景关键（Java -jar / C++ 可执行）
    pid_cmd: Dict[int, str] = {}
    for line in (outputs.get("ps") or "").splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(None, 3)
        if len(parts) < 4:
            continue
        try:
            pid = int(parts[1])
        except Exception:
            continue
        pid_cmd[pid] = parts[3]

    pids: List[int] = []
    for u in systemd_units_detail:
        mp = u.get("main_pid")
        if isinstance(mp, int) and mp > 0:
            pids.append(mp)
    for it in ports:
        pid = it.get("pid")
        if isinstance(pid, int) and pid > 0:
            pids.append(pid)
    uniq: List[int] = []
    seen_pid = set()
    for pid in pids:
        if pid in seen_pid:
            continue
        seen_pid.add(pid)
        uniq.append(pid)

    if enable_proc_enrich and uniq:
        keywords = (signals.get("keywords") or []) if isinstance(signals, dict) else []
        jar_names = (signals.get("jar_names") or []) if isinstance(signals, dict) else []
        binary_names = (signals.get("binary_names") or []) if isinstance(signals, dict) else []

        prefer: List[int] = []
        other: List[int] = []
        needles = keywords[:50]
        for pid in uniq:
            cmd = pid_cmd.get(pid, "")
            if quick_text_contains_any(cmd, needles, max_hits=1):
                prefer.append(pid)
                continue
            # jar/binary 也算优先
            if any(j in cmd for j in jar_names[:30]) or any(b in cmd for b in binary_names[:30]):
                prefer.append(pid)
                continue
            other.append(pid)
        ordered = (prefer + other)[: max(1, int(proc_enrich_top or 0))]

        pid_fp: Dict[int, Dict[str, Any]] = {}
        for pid in ordered:
            fp = fetch_proc_fingerprint(target, pid)
            if fp:
                pid_fp[pid] = fp
                save_evidence(evidence_dir, f"proc_{pid}", f"/proc fingerprint pid={pid}", 0, json.dumps(fp, ensure_ascii=False))

        for u in systemd_units_detail:
            mp = u.get("main_pid")
            if isinstance(mp, int) and mp in pid_fp:
                u["_process_fingerprint"] = pid_fp[mp]
        for it in ports:
            pid = it.get("pid")
            if isinstance(pid, int) and pid in pid_fp:
                it["_process_fingerprint"] = pid_fp[pid]

    # docker inspect enrich（只读，按需）
    docker_detail_by_name: Dict[str, Dict[str, Any]] = {}
    if docker_rows and docker_inspect_top and int(docker_inspect_top) > 0:
        needles = (signals.get("keywords") or []) if isinstance(signals, dict) else []
        preferred: List[Dict[str, Any]] = []
        rest: List[Dict[str, Any]] = []
        for d in docker_rows:
            name = str(d.get("name") or "")
            image = str(d.get("image") or "")
            if quick_text_contains_any(f"{name} {image}", needles[:50], max_hits=1):
                preferred.append(d)
            else:
                rest.append(d)
        ordered = (preferred + rest)[: int(docker_inspect_top)]
        for d in ordered:
            name = str(d.get("name") or "")
            if not name:
                continue
            cmd_labels = f"docker inspect {name} --format '{{{{json .Config.Labels}}}}' 2>/dev/null || true"
            c1, o1 = run_ssh(target, cmd_labels)
            save_evidence(evidence_dir, f"docker_inspect_labels_{name}", cmd_labels, c1, o1)
            labels: Dict[str, Any] = {}
            try:
                t1 = (o1 or "").strip()
                labels = json.loads(t1) if t1.startswith("{") else {}
            except Exception:
                labels = {}
            cmd_mounts = f"docker inspect {name} --format '{{{{json .Mounts}}}}' 2>/dev/null || true"
            c2, o2 = run_ssh(target, cmd_mounts)
            save_evidence(evidence_dir, f"docker_inspect_mounts_{name}", cmd_mounts, c2, o2)
            mounts: Any = []
            try:
                t2 = (o2 or "").strip()
                mounts = json.loads(t2) if t2.startswith("[") else []
            except Exception:
                mounts = []
            docker_detail_by_name[name] = {"labels": labels, "mounts": mounts}

    result["service_candidates"] = build_service_candidates(
        systemd_units_detail,
        docker_rows,
        ports,
        source_quota=source_quota,
        max_candidates=max_candidates,
        profile_signals=signals if result.get("project_profile") else None,
        docker_detail_by_name=docker_detail_by_name,
    )

    # 弱绑定降级提示：
    # - /home 属于宽泛信号，不能用它来判断“已强绑定”
    # - 仅当出现 strong_hit（jar/binary/关键词/端口/窄路径等）才视为真实绑定命中
    pm_items = [
        c.get("project_match")
        for c in (result.get("service_candidates") or [])
        if isinstance(c, dict) and isinstance(c.get("project_match"), dict)
    ]
    strong_scores: List[float] = []
    for pm in pm_items:
        try:
            if bool(pm.get("strong_hit") or False):
                strong_scores.append(float(pm.get("score") or 0.0))
        except Exception:
            continue
    if pm_items and (not strong_scores or max(strong_scores) < 0.7):
        result["notes"].append("项目绑定信号偏弱：候选排序可能不准（建议补充 extra_keywords/更窄的路径前缀）")
        # 回退为通用排序（保持候选集不变）
        result["service_candidates"].sort(key=lambda x: float(x.get("confidence") or 0.0), reverse=True)

    probe_cfg = server.get("probe") if isinstance(server.get("probe"), dict) else {}
    enable_http_probe = bool(probe_cfg.get("enable_http_probe") or False)
    http_ports_hint = probe_cfg.get("http_ports_hint") if isinstance(probe_cfg.get("http_ports_hint"), list) else [80, 443, 8080]
    if enable_http_probe:
        http_candidates: List[Dict[str, Any]] = []
        auth_hints: List[Dict[str, Any]] = []
        for port_item in ports:
            port = int(port_item.get("port") or 0)
            if port in http_ports_hint or port in {80, 8080, 8000, 9000, 10000, 10001, 10002}:
                prefer_https = port in {443, 8443, 9443}
                scheme = "https" if prefer_https else "http"
                r = http_probe(target.host, port, scheme=scheme)
                # https 探测失败时补一次 http（某些环境 443 上也可能是 http 或中间件探针端口）
                if prefer_https and r.get("error"):
                    r2 = http_probe(target.host, port, scheme="http")
                    # 仅当 fallback 有有效信息时替换
                    if r2.get("status") or r2.get("headers"):
                        r = r2
                http_candidates.append(r)
                auth_hints.extend(guess_auth_hints(r))
                if len(http_candidates) >= 6:
                    break
        result["api_surface"]["http_candidates"] = http_candidates
        # 去重
        seen = set()
        out_hints: List[Dict[str, Any]] = []
        for h in auth_hints:
            key = (h.get("type"), h.get("evidence"))
            if key in seen:
                continue
            seen.add(key)
            out_hints.append(h)
        result["api_surface"]["auth_hints"] = out_hints

    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="remote-debug-setup: 只读探测远端环境并生成 probe-report.json")
    parser.add_argument("--project-root", default=".", help="目标项目根目录")
    parser.add_argument("--answers", required=True, help="answers.min.json")
    parser.add_argument("--out", required=True, help="probe-report.json 输出路径")
    parser.add_argument("--project-profile", default="", help="可选：project-profile.json（用于候选服务相关性排序）")
    parser.add_argument("--dry-run", action="store_true", help="不连接远端，仅输出骨架")
    parser.add_argument("--max-candidates", type=int, default=80, help="候选服务总上限（默认 80）")
    parser.add_argument(
        "--source-quota",
        default="systemd=20,docker=20,port=40",
        help="分来源候选上限，如 systemd=20,docker=20,port=40",
    )
    parser.add_argument("--disable-proc-enrich", action="store_true", help="禁用 /proc 只读取证（默认启用）")
    parser.add_argument("--proc-enrich-top", type=int, default=12, help="/proc 取证 pid 上限（默认 12）")
    parser.add_argument("--docker-inspect-top", type=int, default=6, help="docker inspect 容器上限（默认 6；设为 0 可禁用）")
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    answers_path = Path(args.answers).expanduser().resolve()
    out_path = Path(args.out).resolve()

    answers = load_json(answers_path)
    defaults = answers.get("defaults") if isinstance(answers.get("defaults"), dict) else {}
    servers = answers.get("servers")
    if not isinstance(servers, list) or not servers:
        raise SystemExit("[ERROR] answers.servers 必须为非空数组")

    project_profile_path = Path(args.project_profile).expanduser().resolve() if args.project_profile else None
    project_profile = load_project_profile(project_profile_path)
    profile_signals = extract_profile_signals(project_profile) if project_profile else {}
    if args.project_profile and not project_profile:
        print(f"[WARN] project-profile 加载失败或为空：{args.project_profile}")

    source_quota: Dict[str, int] = {}
    parse_warnings: List[str] = []
    for part in (args.source_quota or "").split(","):
        part = part.strip()
        if not part:
            continue
        if "=" not in part:
            parse_warnings.append(f"忽略非法 source_quota 片段: {part}")
            continue
        key, val = part.split("=", 1)
        key = key.strip()
        val = val.strip()
        if key not in {"systemd", "docker", "port"}:
            parse_warnings.append(f"忽略未知 source_quota 键: {key}")
            continue
        if not re.match(r"^\d+$", val):
            parse_warnings.append(f"忽略非法 source_quota 值: {key}={val}")
            continue
        source_quota[key] = int(val)

    effective_max_candidates = int(args.max_candidates or 80)
    if effective_max_candidates <= 0:
        parse_warnings.append(f"max-candidates 非法({effective_max_candidates})，已回退为 80")
        effective_max_candidates = 80
    for warn in parse_warnings:
        print(f"[WARN] {warn}")

    report: Dict[str, Any] = {
        "schema_version": "remote-debug-suite/probe-report/v1",
        "generated_at": time.strftime("%F %T"),
        "project_root": str(project_root),
        "servers": [],
        "notes": parse_warnings,
        "probe_config": {
            "max_candidates": effective_max_candidates,
            "source_quota": {
                "systemd": source_quota.get("systemd", 20),
                "docker": source_quota.get("docker", 20),
                "port": source_quota.get("port", 40),
            },
            "project_profile": str(project_profile_path) if project_profile_path else "",
            "proc_enrich_enabled": (not bool(args.disable_proc_enrich)),
            "proc_enrich_top": int(args.proc_enrich_top or 30),
            "docker_inspect_top": int(args.docker_inspect_top or 10),
        },
    }
    for server in servers:
        if not isinstance(server, dict):
            continue
        report["servers"].append(
            probe_one_server(
                project_root,
                defaults,
                server,
                args.dry_run,
                max_candidates=effective_max_candidates,
                source_quota=source_quota,
                profile_signals=profile_signals,
                enable_proc_enrich=(not bool(args.disable_proc_enrich)),
                proc_enrich_top=int(args.proc_enrich_top or 30),
                docker_inspect_top=int(args.docker_inspect_top or 10),
            )
        )

    ensure_dir(out_path.parent)
    out_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] probe report written: {out_path}")


if __name__ == "__main__":
    main()
