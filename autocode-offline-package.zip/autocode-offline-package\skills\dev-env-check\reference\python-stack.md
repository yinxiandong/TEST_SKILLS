# Python 技术栈检查参考

> 本文档是 dev-env-check 技能的参考文档，包含 Python 技术栈的详细检查流程。

## 识别特征

| 配置文件 | 说明 |
|----------|------|
| `requirements.txt` | pip 依赖文件 |
| `pyproject.toml` | 现代 Python 项目配置 |
| `setup.py` | 传统包配置 |
| `Pipfile` | Pipenv 项目 |
| `poetry.lock` | Poetry 项目 |

## 检查项

- Python 版本
- pip 版本
- 虚拟环境工具（venv、virtualenv、conda）
- 常用开发工具（pylint、black 等）

## 检查命令

```bash
# 检查 Python 版本
python --version 2>&1
python3 --version 2>&1

# 检查 pip 版本
pip --version 2>&1
pip3 --version 2>&1

# 检查虚拟环境工具
which virtualenv 2>&1
which conda 2>&1
which poetry 2>&1
which pipenv 2>&1

# 检查当前是否在虚拟环境
echo $VIRTUAL_ENV
python -c "import sys; print(sys.prefix)"
```

## 版本要求提取

### pyproject.toml

```toml
[project]
requires-python = ">=3.9"

# 或 Poetry 格式
[tool.poetry.dependencies]
python = "^3.9"
```

### setup.py

```python
setup(
    python_requires='>=3.9',
)
```

提取命令：
```bash
# 从 pyproject.toml 提取
grep "requires-python" pyproject.toml 2>/dev/null
grep "python = " pyproject.toml 2>/dev/null

# 从 setup.py 提取
grep "python_requires" setup.py 2>/dev/null
```

## 期望结果

- Python 版本符合项目要求
- pip 可正常使用
- 建议使用虚拟环境

## 构建/依赖检查命令

| 配置文件 | 检查命令 | 说明 |
|----------|----------|------|
| pyproject.toml | `pip install -e . --dry-run` | 检查依赖可安装性 |
| requirements.txt | `pip check` | 检查依赖一致性 |
| Pipfile | `pipenv check` | Pipenv 检查 |
| poetry.lock | `poetry check` | Poetry 检查 |

## 常见问题

### 虚拟环境管理

**推荐使用虚拟环境隔离项目依赖**：

```bash
# 使用内置 venv
python -m venv venv
source venv/bin/activate  # Linux/macOS
venv\Scripts\activate     # Windows

# 退出虚拟环境
deactivate
```

### Python 版本管理

使用 pyenv 管理多个 Python 版本：

```bash
# 安装 pyenv
curl https://pyenv.run | bash

# 添加到 ~/.bashrc
export PYENV_ROOT="$HOME/.pyenv"
export PATH="$PYENV_ROOT/bin:$PATH"
eval "$(pyenv init -)"

# 安装指定版本
pyenv install 3.11.7
pyenv global 3.11.7

# 项目级版本
pyenv local 3.11.7  # 创建 .python-version 文件
```

### pip 镜像配置

```bash
# 临时使用
pip install package -i https://pypi.tuna.tsinghua.edu.cn/simple

# 永久配置
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple

# 或编辑 ~/.pip/pip.conf (Linux/macOS) 或 %APPDATA%\pip\pip.ini (Windows)
[global]
index-url = https://pypi.tuna.tsinghua.edu.cn/simple
trusted-host = pypi.tuna.tsinghua.edu.cn
```

### 依赖冲突

```bash
# 检查依赖冲突
pip check

# 查看依赖树
pip install pipdeptree
pipdeptree

# 重新安装依赖
pip install -r requirements.txt --force-reinstall
```

## 包管理工具对比

| 工具 | 配置文件 | 优点 | 适用场景 |
|------|----------|------|----------|
| pip + venv | requirements.txt | 简单、内置 | 小型项目 |
| Poetry | pyproject.toml | 依赖解析强、发布方便 | 库开发 |
| Pipenv | Pipfile | 自动管理虚拟环境 | 应用开发 |
| conda | environment.yml | 支持非 Python 依赖 | 数据科学 |

### Poetry 使用

```bash
# 安装 Poetry
curl -sSL https://install.python-poetry.org | python3 -

# 创建项目
poetry new myproject

# 安装依赖
poetry install

# 添加依赖
poetry add requests

# 运行命令
poetry run python main.py

# 进入虚拟环境
poetry shell
```

### Pipenv 使用

```bash
# 安装 Pipenv
pip install pipenv

# 创建虚拟环境并安装依赖
pipenv install

# 安装开发依赖
pipenv install --dev pytest

# 进入虚拟环境
pipenv shell

# 运行命令
pipenv run python main.py
```

## 安装方式

### 包管理器

```bash
# Ubuntu/Debian
sudo apt install python3 python3-pip python3-venv

# macOS
brew install python@3.11

# Windows
choco install python
```

### 官方安装

- 官方下载: https://www.python.org/downloads/
- Anaconda: https://www.anaconda.com/download/
- Miniconda: https://docs.conda.io/en/latest/miniconda.html

## 常用开发工具

```bash
# 代码格式化
pip install black isort

# 静态分析
pip install pylint flake8 mypy

# 测试
pip install pytest pytest-cov

# 文档
pip install sphinx

# 一键安装常用工具
pip install black isort pylint mypy pytest
```

## 官方文档

- Python: https://docs.python.org/
- pip: https://pip.pypa.io/
- venv: https://docs.python.org/3/library/venv.html
- Poetry: https://python-poetry.org/docs/
- pyenv: https://github.com/pyenv/pyenv
