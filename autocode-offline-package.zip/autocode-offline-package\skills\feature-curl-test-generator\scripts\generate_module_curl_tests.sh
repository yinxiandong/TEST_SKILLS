#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY_GENERATOR="${SCRIPT_DIR}/generate_module_curl_tests.py"
PROJECT_ROOT="$(pwd)"

DEFAULT_OUTPUT_ROOT="tests/feature-curl"
DEFAULT_HOST="127.0.0.1"
DEFAULT_PORT="6050"
DEFAULT_SCHEME="https"

FEATURE_DIR=""
MODULE_NAME=""
LIST_MODULES=false
EXECUTE_AFTER_GEN=false
OUTPUT_ROOT="${DEFAULT_OUTPUT_ROOT}"
BASE_URL=""
TARGET_ENV=""
ENV_FILE=""
ENV_HOST_KEY_TEMPLATE=""
PORT="${DEFAULT_PORT}"
API_KEY_HEADER=""
API_KEY=""
ALIASES_FILE=""

usage() {
  cat <<'USAGE'
用法:
  generate_module_curl_tests.sh --feature-dir <目录> --module <模块> [选项]
  generate_module_curl_tests.sh --feature-dir <目录> --list-modules [选项]

选项:
  --feature-dir <目录>           特性清单目录（必填）
  --module <模块>               模块名（支持 slug、标题、显示名或别名文件中的别名）
  --list-modules                列出可用模块与别名
  --output-root <目录>          输出根目录（默认: tests/feature-curl）
  --execute                     生成后立即执行 curl-tests.sh
  --base-url <URL>              接口基地址（优先级高于 --env）
  --api-key-header <Header>     API Key 请求头（默认: X-API-Key）
  --api-key <Key>               API Key（默认空）
  --env <环境名>                目标环境名，与 --env-file / --env-host-key-template 配合使用
  --env-file <文件>             环境配置文件
  --env-host-key-template <模板> 环境主机键模板，如 FEATURE_ENV_{ENV}_HOST
  --port <端口>                 环境端口（默认: 6050）
  --aliases-file <文件>         可选模块别名文件
  -h, --help                    显示帮助
USAGE
}

make_abs() {
  local value="$1"
  if [[ -z "${value}" ]]; then
    return
  fi
  if [[ "${value}" = /* ]]; then
    printf '%s' "${value}"
  else
    printf '%s' "${PROJECT_ROOT}/${value}"
  fi
}

normalize_env_key() {
  local value="$1"
  value="$(printf '%s' "${value}" | tr '[:lower:]-' '[:upper:]_')"
  printf '%s' "${value//[^A-Z0-9_]/_}"
}

read_kv_config() {
  local key="$1"
  local file="$2"
  awk -v k="${key}" -F '=' '
    {
      line=$0
      sub(/[[:space:]]*#.*/, "", line)
      if (line ~ "^[[:space:]]*" k "[[:space:]]*=") {
        sub(/^[^=]*=[[:space:]]*/, "", line)
        gsub(/^"/, "", line)
        gsub(/"$/, "", line)
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", line)
        print line
        exit
      }
    }
  ' "${file}"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --feature-dir)
      FEATURE_DIR="${2:-}"
      shift 2
      ;;
    --module)
      MODULE_NAME="${2:-}"
      shift 2
      ;;
    --list-modules)
      LIST_MODULES=true
      shift
      ;;
    --output-root)
      OUTPUT_ROOT="${2:-}"
      shift 2
      ;;
    --execute)
      EXECUTE_AFTER_GEN=true
      shift
      ;;
    --base-url)
      BASE_URL="${2:-}"
      shift 2
      ;;
    --api-key-header)
      API_KEY_HEADER="${2:-}"
      shift 2
      ;;
    --api-key)
      API_KEY="${2:-}"
      shift 2
      ;;
    --env)
      TARGET_ENV="${2:-}"
      shift 2
      ;;
    --env-file)
      ENV_FILE="${2:-}"
      shift 2
      ;;
    --env-host-key-template)
      ENV_HOST_KEY_TEMPLATE="${2:-}"
      shift 2
      ;;
    --port)
      PORT="${2:-}"
      shift 2
      ;;
    --aliases-file)
      ALIASES_FILE="${2:-}"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "未知参数: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

if [[ -z "${FEATURE_DIR}" ]]; then
  echo "--feature-dir 为必填参数" >&2
  usage >&2
  exit 2
fi

FEATURE_DIR_ABS="$(make_abs "${FEATURE_DIR}")"
if [[ ! -d "${FEATURE_DIR_ABS}" ]]; then
  echo "特性清单目录不存在: ${FEATURE_DIR_ABS}" >&2
  exit 1
fi

if [[ ! -f "${PY_GENERATOR}" ]]; then
  echo "生成器脚本不存在: ${PY_GENERATOR}" >&2
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "缺少 python3，请先安装后重试" >&2
  exit 1
fi

OUTPUT_ROOT_ABS="$(make_abs "${OUTPUT_ROOT}")"
mkdir -p "${OUTPUT_ROOT_ABS}"

ALIASES_FILE_ABS=""
if [[ -n "${ALIASES_FILE}" ]]; then
  ALIASES_FILE_ABS="$(make_abs "${ALIASES_FILE}")"
  if [[ ! -f "${ALIASES_FILE_ABS}" ]]; then
    echo "别名文件不存在: ${ALIASES_FILE_ABS}" >&2
    exit 1
  fi
fi

if [[ -n "${ENV_FILE}" ]]; then
  ENV_FILE_ABS="$(make_abs "${ENV_FILE}")"
  if [[ ! -f "${ENV_FILE_ABS}" ]]; then
    echo "环境配置文件不存在: ${ENV_FILE_ABS}" >&2
    exit 1
  fi
else
  ENV_FILE_ABS=""
fi

if [[ -z "${BASE_URL}" && -n "${TARGET_ENV}" && -n "${ENV_FILE_ABS}" && -n "${ENV_HOST_KEY_TEMPLATE}" ]]; then
  ENV_KEY="$(normalize_env_key "${TARGET_ENV}")"
  ENV_HOST_KEY="${ENV_HOST_KEY_TEMPLATE//\{ENV\}/${ENV_KEY}}"
  ENV_HOST="$(read_kv_config "${ENV_HOST_KEY}" "${ENV_FILE_ABS}" || true)"
  if [[ -n "${ENV_HOST}" ]]; then
    BASE_URL="${DEFAULT_SCHEME}://${ENV_HOST}:${PORT}"
  fi
fi

if [[ -z "${BASE_URL}" ]]; then
  BASE_URL="${DEFAULT_SCHEME}://${DEFAULT_HOST}:${DEFAULT_PORT}"
fi

if [[ -z "${API_KEY_HEADER}" ]]; then
  API_KEY_HEADER="X-API-Key"
fi

PY_ARGS=(
  --feature-dir "${FEATURE_DIR_ABS}"
  --output-root "${OUTPUT_ROOT_ABS}"
  --base-url "${BASE_URL}"
  --api-key-header "${API_KEY_HEADER}"
  --api-key "${API_KEY}"
)

if [[ -n "${ALIASES_FILE_ABS}" ]]; then
  PY_ARGS+=(--aliases-file "${ALIASES_FILE_ABS}")
fi

if [[ "${LIST_MODULES}" == "true" ]]; then
  PY_ARGS+=(--list-modules)
else
  if [[ -z "${MODULE_NAME}" ]]; then
    echo "--module 为必填参数（除非使用 --list-modules）" >&2
    usage >&2
    exit 2
  fi
  PY_ARGS+=(--module "${MODULE_NAME}")
fi

if [[ "${EXECUTE_AFTER_GEN}" == "true" ]]; then
  PY_ARGS+=(--execute)
fi

echo "== feature-curl-test-generator =="
echo "特性目录: ${FEATURE_DIR_ABS}"
echo "输出目录: ${OUTPUT_ROOT_ABS}"
echo "BASE_URL: ${BASE_URL}"
echo "API_KEY_HEADER: ${API_KEY_HEADER}"
if [[ -n "${ALIASES_FILE_ABS}" ]]; then
  echo "ALIASES_FILE: ${ALIASES_FILE_ABS}"
fi
echo

python3 "${PY_GENERATOR}" "${PY_ARGS[@]}"
