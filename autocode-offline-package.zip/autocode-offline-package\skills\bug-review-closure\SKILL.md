---
name: bug-review-closure
description: 执行缺陷修复后的代码评审门禁与收尾汇总，生成人工核对清单并等待人工提交。Use when verification has finished and bug fix work needs quality gating and final handoff.
---

# Bug Review Closure

负责 bug-fix 流程最后的评审与收尾，不自动提交代码。

## 输入

- `bug_id`
- `docs/bugfix/{bug_id}/10-根因修复与同类排查.md`
- `docs/bugfix/{bug_id}/20-修复实施记录.md`
- `docs/bugfix/{bug_id}/30-远程验证报告.md`

## 输出

- `docs/bugfix/{bug_id}/90-人工核对清单.md`
- `.claude/notepads/{bug_id}/review-report-{round}.md`
- `.claude/notepads/{bug_id}/review-report.md`（最新快照，可覆盖）
- `.claude/notepads/{bug_id}/closure-summary.md`

## 模板引用

- `references/90-human-checklist-template.md`

## 评审策略

1. 优先调用 `superpowers:code-reviewer` 进行评审。
2. 若不可用则降级为本地规则审查（`.claude/rules/**` + 测试证据复核）。
3. 每轮评审落盘 `review-report-{round}.md`，并同步更新 `review-report.md` 快照。

## 门禁规则

- Critical > 0：阻塞
- Important > 0：阻塞
- 远程验证非 pass：阻塞
- 全部通过：状态置为 `need_human_check`

## 收尾要求

人工核对清单至少包含：
- 修复范围确认
- 验证证据确认
- 风险与回滚确认
- 提交前检查项
