---
name: remote-db-probe
description: "数据库依赖探测插件技能（通用版）。读取 .secrets/dev-servers.yaml 中 servers[].components.db 或 servers[].db（兼容）配置，做端口连通性探测与基础提示。默认不执行建库/建表/数据初始化；如需要初始化，应在项目内另行提供 SQL 目录与明确执行规则。"
---

# remote-db-probe

## 概述

该插件用于确认远端数据库可达性与类型线索（mysql/postgresql），并给出下一步建议。

## 配置要求（写入 .secrets/dev-servers.yaml）

建议配置位置：`servers[].components.db`

可选字段：
- `access.mode`：`direct|ssh`。`ssh` 表示通过 SSH 临时端口转发探测 DB（适合本地无法直连内网端口的场景）；password 认证需要本机 `sshpass`。若未显式配置 `host`，`ssh` 模式默认使用 `127.0.0.1` 作为远端目标地址。

## 用法

```bash
.codex/skills/remote-db-probe/scripts/probe_remote_db.sh --server dev1 --config .secrets/dev-servers.yaml
```
